#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Переупаковка уже скачанного датасета Bullinger под дешёвую геометрию.

Зачем: песочница (2 ядра CPU, ~1.5 ГБ ОЗУ) не тянет полную строку в 64 символа
на холсте 32x256 (обучение упирается в OOM), а урезать одну только МЕТКУ до
max_len нельзя — картинка продолжала бы показывать все 64 символа, и модель
училась бы «видеть текст и останавливаться на середине». Поэтому строка
режется СЛЕВА на долю crop_chars/len(text) ширины: при более-менее равномерном
шаге письма в кадр попадают именно первые crop_chars символов (±1-2 знака на
границе — честно документируемый шум, а не систематическая рассинхронизация).
Выигрыш двойной: метка и кадр согласованы, а пикселей и шагов декодера вдвое
меньше, причём px/символ не падает (кадр у́же, но и символов меньше).

Работает локально по manifest.tsv и кэшу оригиналов bullinger_fetch.py —
сеть не нужна.

    python3 tools/bullinger_recrop.py --src data/bullinger --raw-dir /tmp/bull_raw \
        --out data/bull40 --crop-chars 40 --img-w 160 --img-h 32
"""

import argparse
import os
import sys

SPECIAL = ["<PAD>", "<SOS>", "<EOS>"]


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", default="data/bullinger")
    ap.add_argument("--raw-dir", default="/tmp/bull_raw")
    ap.add_argument("--out", default="data/bull40")
    ap.add_argument("--crop-chars", type=int, default=40)
    ap.add_argument("--img-w", type=int, default=160)
    ap.add_argument("--img-h", type=int, default=32)
    args = ap.parse_args()

    from PIL import Image, ImageOps
    os.makedirs(os.path.join(args.out, "img"), exist_ok=True)

    rows = {}
    with open(os.path.join(args.src, "manifest.tsv"), encoding="utf-8") as f:
        head = f.readline()
        for line in f:
            sp, idx, page, text = line.rstrip("\n").split("\t")
            rows.setdefault(sp, []).append((int(idx), page, text))

    made = skipped = 0
    for sp, items in rows.items():
        out = []
        for idx, page, text in items:
            raw = os.path.join(args.raw_dir, f"{idx:06d}.img")
            if not os.path.exists(raw):
                skipped += 1
                continue
            # обрезаем метку и кадр согласованно
            label = text
            frac = 1.0
            if len(text) > args.crop_chars:
                frac = args.crop_chars / len(text)
                label = text[: args.crop_chars]
            try:
                im = Image.open(raw).convert("L")
                im = ImageOps.autocontrast(im, cutoff=1)
                if frac < 1.0:
                    im = im.crop((0, 0, max(8, int(im.width * frac)), im.height))
                im.thumbnail((args.img_w, args.img_h), Image.LANCZOS)
                name = f"{sp[0]}{idx:06d}.png"
                im.save(os.path.join(args.out, "img", name), "PNG", optimize=True)
            except Exception as e:                                # noqa: BLE001
                log(f"  {idx}: {e}")
                skipped += 1
                continue
            out.append((f"img/{name}", label))
            made += 1
        with open(os.path.join(args.out, f"{sp}.csv"), "w", encoding="utf-8") as f:
            for path, label in out:
                f.write('{},"{}"\n'.format(path, label.replace('"', '""')))
        log(f"  {sp}.csv: {len(out)} строк")

    if rows.get("a_train") and rows.get("b_train"):
        with open(os.path.join(args.out, "val.csv"), "w", encoding="utf-8") as f:
            for sp in ("val_a", "val_b"):
                p = os.path.join(args.out, f"{sp}.csv")
                if os.path.exists(p):
                    f.write(open(p, encoding="utf-8").read())

    # словари — по урезанным меткам: редкие хвостовые символы уходят сами
    def charset(sp):
        cs = set()
        p = os.path.join(args.out, f"{sp}.csv")
        for line in open(p, encoding="utf-8"):
            cs |= set(line.rstrip("\n").split(',"', 1)[1].rsplit('"', 1)[0].replace('""', '"'))
        return SPECIAL + sorted(cs)

    ca, cb = charset("a_train"), charset("b_train")
    call = SPECIAL + sorted(set(ca[3:]) | set(cb[3:]))
    for fn, cs in (("charset_a.txt", ca), ("charset_b.txt", cb), ("charset_all.txt", call)):
        with open(os.path.join(args.out, fn), "w", encoding="utf-8") as f:
            f.write("\n".join(cs) + "\n")
    log(f"готово: {made} кадров, пропущено {skipped}; словари {len(ca)}/{len(cb)}/{len(call)}")


if __name__ == "__main__":
    main()
