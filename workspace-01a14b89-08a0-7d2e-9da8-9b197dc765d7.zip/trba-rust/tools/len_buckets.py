#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Разбивает конвертированный корпус на корзины по длине текста — по корзине на эксперта.

Каждая корзина becomes отдельным экспертом MoPE со своим --max-len (верхняя
граница корзины) и своим --img-w. Строки ДЛИННЕЕ --max-len загрузчик trba-rust
обрезает молча, поэтому корзина обязана содержать только строки не длиннее своей
верхней границы: заимствовать можно исключительно короткие. Отсюда три схемы:

  auto   смежные диапазоны [lo..hi], в каждом не меньше --min-rows строк
         (корзин меньше, каждая плотная; паддинг минимален — РЕКОМЕНДУЕТСЯ)
  exact  ровно по одной длине: 4, 5, 6, … --hi (до 37 экспертов; длинные корзины
         могут оказаться крошечными или пустыми — тогда эксперт не обучится)
  cum    накопительно: корзина L содержит все строки длиной ≤ L (последняя
         корзина видит весь датасет и обучается дольше всех)

  python3 tools/len_buckets.py --in YeniseiGovReports-HWR/train/full_train.csv \
      --val YeniseiGovReports-HWR/val/full_val.csv \
      --lo 4 --hi 40 --min-rows 1000 --scheme auto

Пишет рядом с --in: bucket_<tag>.csv, bucket_<tag>_val.csv и buckets_plan.tsv
со столбцами  tag lo hi rows img_w max_len  — его построчно читает
scripts/run_len_buckets.sh. Пути к картинкам остаются относительными к каталогу
CSV, потому что load_csv резолвит их от родительского каталога файла.
"""
import argparse
import csv
import os


def read_rows(path):
    """(filename, text) без заголовка; заголовок `filename,...` пропускается."""
    out = []
    with open(path, encoding='utf-8', newline='') as f:
        for i, row in enumerate(csv.reader(f)):
            if len(row) < 2:
                continue
            if i == 0 and row[0].strip().lower() == 'filename':
                continue
            out.append((row[0], row[1]))
    return out


def write_rows(path, rows):
    with open(path, 'w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        for r in rows:
            w.writerow(r)


def img_w_for(hi):
    """Ширина кадра под длину слова: ~2 моделированных пикселя на символ после
    приведения к высоте 32, кратно 32, в диапазоне 64…256."""
    return max(64, min(256, 32 * ((hi + 1) // 2)))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='inp', required=True)
    ap.add_argument('--val', default='')
    ap.add_argument('--lo', type=int, default=4)
    ap.add_argument('--hi', type=int, default=40)
    ap.add_argument('--min-rows', type=int, default=1000)
    ap.add_argument('--scheme', choices=('auto', 'exact', 'cum'), default='auto')
    ap.add_argument('--min-chars', type=int, default=2)
    a = ap.parse_args()

    rows = [r for r in read_rows(a.inp) if len(r[1]) >= a.min_chars]
    val = [r for r in read_rows(a.val) if len(r[1]) >= a.min_chars] if a.val else []
    out_dir = os.path.dirname(os.path.abspath(a.inp))
    lens = sorted(len(r[1]) for r in rows)
    if not lens:
        raise SystemExit('в корпусе нет строк')
    mx = lens[-1]
    print(f'корпус: {len(rows)} строк | длина min {lens[0]} · p50 {lens[len(lens)//2]} · '
          f'p90 {lens[int(len(lens)*0.9)]} · p99 {lens[int(len(lens)*0.99)]} · max {mx}')
    hist = {}
    for L in lens:
        hist[L] = hist.get(L, 0) + 1
    print('гистограмма длин: ' + ' '.join(f'{L}:{hist[L]}' for L in sorted(hist))[:400])
    if a.hi > mx:
        print(f'⚠️  --hi {a.hi} больше максимальной длины {mx}: корзины длиннее {mx} будут пустыми и пропущены')
    if a.hi < mx:
        print(f'⚠️  строк длиннее --hi {a.hi}: {sum(v for k, v in hist.items() if k > a.hi)} — '
              f'они не попадут ни в одну корзину (обрезать их нельзя: загрузчик сделает это молча)')

    # границы корзин: список (lo, hi)
    bounds = []
    if a.scheme == 'exact':
        for L in range(a.lo, a.hi + 1):
            if hist.get(L, 0):
                bounds.append((L, L))
    elif a.scheme == 'cum':
        for L in range(a.lo, a.hi + 1):
            if sum(v for k, v in hist.items() if k <= L):
                bounds.append((a.lo, L))
    else:  # auto
        cur_lo, cnt = None, 0
        for L in range(a.lo, a.hi + 1):
            n = hist.get(L, 0)
            if not n:
                continue
            if cur_lo is None:
                cur_lo, cnt = L, n
            else:
                cnt += n
            if cnt >= a.min_rows:
                bounds.append((cur_lo, L))
                cur_lo, cnt = None, 0
        if cur_lo is not None:
            if bounds and cnt < a.min_rows // 4:
                # хвост слишком жидкий — приклеиваем к последней корзине
                lo, hi = bounds[-1]
                bounds[-1] = (lo, a.hi)
                print(f'ℹ️  хвост {cur_lo}…{a.hi} ({cnt} строк) приклеен к корзине {lo}…{a.hi}')
            else:
                bounds.append((cur_lo, a.hi))

    plan = os.path.join(out_dir, 'buckets_plan.tsv')
    with open(plan, 'w', encoding='utf-8') as f:
        print(f'{"корзина":<12}{"длины":>9}{"строк":>8}{"контроль":>9}{"img_w":>7}{"max_len":>9}')
        for lo, hi in bounds:
            sub = [r for r in rows if lo <= len(r[1]) <= hi]
            if not sub:
                continue
            tag = f'{lo:02d}_{hi:02d}'
            vsub = [r for r in val if lo <= len(r[1]) <= hi]
            write_rows(os.path.join(out_dir, f'bucket_{tag}.csv'), sub)
            if val:
                write_rows(os.path.join(out_dir, f'bucket_{tag}_val.csv'), vsub)
            iw = img_w_for(hi)
            f.write(f'{tag}\t{lo}\t{hi}\t{len(sub)}\t{iw}\t{hi}\n')
            print(f'bucket_{tag:<7}{f"{lo}…{hi}":>9}{len(sub):>8}{len(vsub):>9}{iw:>7}{hi:>9}')
    n = sum(1 for _ in open(plan, encoding='utf-8'))
    print(f'\n▶ корзин: {n} | план: {plan}')
    print('  у каждой корзины свой --max-len (= hi) и свой --img-w: паддинг не')
    print('  считается впустую, а CER каждой корзины измеряется на строках её длины.')
    if n > 12:
        print(f'  ⚠️  {n} экспертов в одном роутере: шаг обучения делает {n} teacher-forced')
        print('      прогонов, поэтому держите --mope-limit небольшим и --mope-cache 4…6.')


if __name__ == '__main__':
    main()
