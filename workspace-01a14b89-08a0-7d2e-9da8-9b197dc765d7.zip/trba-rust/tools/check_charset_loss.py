#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Какие токены словаря обнуляются на подмножестве корпуса.

Ровно так из общего словаря MoPE пропали "+ І Ц Ы і Ѣ" (BUGFIX_REPORT §20.15).
Программа считает частоты посимвольным поиском подстроки по всему файлу
(moe::count_charset_in_file → `s.matches(tok).count()`), поэтому скрипт повторяет
ТУ ЖЕ арифметику и сравнивает полный корпус с его первыми N строками — теми,
что попадают в `--mope-char-counts` после `head -N`.

Запрета на дореформенные буквы в коде нет: «Ѣ» и «Ц» обрабатываются как «а».
Ноль означает лишь «в этом файле подстрока не встретилась».

  python3 tools/check_charset_loss.py \
      --charset YeniseiGovReports-HWR/charset_trba.txt \
      --corpus  YeniseiGovReports-HWR/train/trba_train.csv \
      --subsets 500,5000,20000,50000 --min-freq 1
"""
import argparse

PREREFORM = set('ѢѣІіѲѳѴѵЪъЫЦ+ЭэѦѧѪѫѮѯѰѱѼѽѾѿҌҍ')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--charset', required=True, help='charset эксперта (<PAD>,<SOS>,<EOS> + символы)')
    ap.add_argument('--corpus', required=True, help='ПОЛНЫЙ CSV, по которому обучался эксперт')
    ap.add_argument('--subsets', default='500,5000,20000,50000',
                    help='первые N строк для сравнения (через запятую)')
    ap.add_argument('--min-freq', type=int, default=1, help='порог --mope-min-freq')
    ap.add_argument('--top', type=int, default=40)
    a = ap.parse_args()

    toks = [l.rstrip('\n') for l in open(a.charset, encoding='utf-8') if l.strip()]
    full = open(a.corpus, encoding='utf-8').read()
    lines = full.split('\n')
    subs = {}
    for n in [int(x) for x in a.subsets.split(',') if x.strip()]:
        subs[n] = '\n'.join(lines[:n + 1])

    print(f'токенов в словаре: {len(toks)} (3 служебных) | строк в корпусе: {len(lines)}')
    print(f'{"токен":<6}{"полный":>9}' + ''.join(f'{"head " + str(n):>11}' for n in subs))
    lost, absent, risk = [], [], []
    for t in toks[3:]:
        cf = full.count(t)
        cs = {n: s.count(t) for n, s in subs.items()}
        if cf == 0:
            absent.append(t)
        elif any(v < a.min_freq for v in cs.values()):
            lost.append((t, cf, cs))
        elif min(cs.values()) * 20 < cf:
            risk.append((t, cf, cs))
        if cf and (t in PREREFORM or any(v < a.min_freq for v in cs.values())):
            mark = '  ← дореформенная/служебная' if t in PREREFORM else ''
            print(f'{t!r:<6}{cf:>9}' + ''.join(f'{cs[n]:>11}' for n in subs) + mark)

    print()
    print(f'❶ совсем нет в ПОЛНОМ корпусе ({len(absent)}): {absent[:20]!r}')
    print(f'❷ обнулились бы на подмножестве ({len(lost)}) — ИХ ТЕРЯЛ СТАРЫЙ КОД:')
    for t, cf, cs in sorted(lost, key=lambda x: x[1])[:a.top]:
        print(f'    {t!r:<6} полный {cf:<7} ' + ' '.join(f'head{n}={cs[n]}' for n in cs))
    print(f'❸ сильно разрежены на подмножестве ({len(risk)}) — риск при --min-freq > 1:')
    for t, cf, cs in sorted(risk, key=lambda x: x[1])[:10]:
        print(f'    {t!r:<6} полный {cf:<7} ' + ' '.join(f'head{n}={cs[n]}' for n in cs))
    print()
    print('Вывод: если ❷ непустой — передавайте в --mope-char-counts ПОЛНЫЙ train.csv,')
    print('а не head -N. После правки §20.15 нули больше не отсеивают токен (он')
    print('помечается непроверенным), но частоты для --mope-min-freq > 1 остаются')
    print('неверными, пока корпус не полный.')


if __name__ == '__main__':
    main()
