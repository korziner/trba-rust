#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Импорт предобученных экспертов в MoPE (trba-rust).

Поддерживаемые входы — всё, чем раздаёт свои модели manuscript-ocr Кожина:

    trba_base_g1.onnx   (171 МБ, SEResNet31 + 2×BiLSTM + AttentionDecoder)
    trba_base_g1.pth    (тот же state_dict, нужен torch)
    trba_lite_g1.onnx   (depthwise-separable CNN — см. «lite» ниже)
    trba_lite_g1.txt / trba_base_g1.txt   (charset пресета)
    trba_base_g1.json   (img_h/img_w/max_len/hidden_size/num_classes)

и локальные чекпоинты trba-rust:

    exp/checkpoint_last.bin  ->  trba-rust --mope-export-bundle exp/mope.mope

Выход — бандл MoPE (формат MOPEXP02, см. src/moe.rs::write_bundle):
геометрия эксперта + его charset.txt + именованные тензоры В ИМЕНАХ
МАНИФЕСТА trba-rust. То есть «чужую» модель знает этот скрипт, а Rust знает
только свой манифест — так разные размерности и словари не перемешиваются.

    python3 tools/mope_import.py trba_base_g1.onnx --out base.mope \
        --charset trba_base_g1.txt --config trba_base_g1.json

Слияние словарей (например дореформенный русский на 194 токена + куррентшрифт
с умляутами) с отсечкой редких символов:

    python3 tools/mope_import.py trba_base_g1.onnx --out base.mope \
        --charset trba_base_g1.txt \
        --merge-charset /media/korziner/14ext4/trba/trba_kurrent/charset.txt \
        --char-counts-csv /media/korziner/14ext4/trba/trba_kurrent/train.csv \
        --min-freq 7 --max-classes 256 --charset-out merged.txt

lite-модели: у SEResNet31Lite свёртки depthwise-separable (группы = in_ch),
а ConvQat в trba-rust плотный, поэтому нативный импорт lite отклоняется с
понятным сообщением (плотное представление раздуло бы 37 МБ в сотни МБ и
замедлило бы свёртку в разы). Для lite используйте ONNX-рантайм как отдельный
эксперт либо дообучите base.

Проверка: `--verify` прогоняет onnxruntime на случайной картинке и сверяет
энкодерный выход импортированного бандла с исходным графом (косинус ≥ 0.999).
"""

import argparse
import json
import os
import re
import struct
import sys

import numpy as np

MAGIC = b"MOPEXP02"
SPECIALS = ["<PAD>", "<SOS>", "<EOS>"]
SPEC_KEYS = ("img_h", "img_w", "max_len", "hidden", "feat_dim", "classes", "pad", "sos", "eos", "rnn_layers")

# ---------------------------------------------------------------------------
# Таблица соответствия: state_dict manuscript-ocr -> манифест trba-rust.
# Формат веса свёртки совпадает ([O, I, KH, KW] = im2col-строки trba-rust),
# порядок вентилей LSTM тоже (PyTorch i,f,g,o == trba-rust i,f,g,o), поэтому
# перестановок не нужно — в отличие от экспорта в ONNX, где LSTM ждёт i,o,f,c.
# ---------------------------------------------------------------------------

CNN_BACKBONE = "seresnet31"  # lite отклоняется отдельно


def conv_names():
    """Имена свёрток trba-rust в порядке convs_mut() + их BN-пары в PyTorch."""
    out = []
    out.append(("stem.0", "cnn.conv0.0", "cnn.conv0.1"))
    out.append(("stem.3", "cnn.conv0.3", "cnn.conv0.4"))
    blocks = [(1, 1), (2, 2), (3, 5), (4, 3)]  # (слой 1-based, число блоков)
    for layer, n in blocks:
        for b in range(n):
            pre = f"cnn.layer{layer}.{b}"
            # downsample есть там, где меняется число каналов или шаг
            ds = (layer == 1 and b == 0) or (layer == 3 and b == 0)
            if ds:
                out.append((f"layer{layer}.{b}.downsample.0", f"{pre}.downsample.0", f"{pre}.downsample.1"))
            out.append((f"layer{layer}.{b}.conv1", f"{pre}.conv1", f"{pre}.bn1"))
            out.append((f"layer{layer}.{b}.conv2", f"{pre}.conv2", f"{pre}.bn2"))
    out.append(("conv_out.0", "cnn.conv_out.0", "cnn.conv_out.1"))
    out.append(("conv_out.3", "cnn.conv_out.3", "cnn.conv_out.4"))
    return out


def se_names():
    """SE-блок: trba-rust хранит его как l{li}b{bi}.se.fc{1,2} (li 0-based)."""
    out = []
    blocks = [(1, 1), (2, 2), (3, 5), (4, 3)]
    for li, (layer, n) in enumerate(blocks):
        for bi in range(n):
            pre = f"cnn.layer{layer}.{bi}.se.fc"
            out.append((f"l{li}b{bi}.se.fc1.w", f"{pre}.0.weight"))
            out.append((f"l{li}b{bi}.se.fc2.w", f"{pre}.2.weight"))
    return out


def rnn_names(num_layers=2):
    out = []
    for li in range(num_layers):
        pre = f"enc_rnn.{li}"
        out.append((f"rnn{li}.f.w_ih", f"{pre}.rnn.weight_ih_l0"))
        out.append((f"rnn{li}.f.b_ih", f"{pre}.rnn.bias_ih_l0"))
        out.append((f"rnn{li}.f.w_hh", f"{pre}.rnn.weight_hh_l0"))
        out.append((f"rnn{li}.f.b_hh", f"{pre}.rnn.bias_hh_l0"))
        out.append((f"rnn{li}.b.w_ih", f"{pre}.rnn.weight_ih_l1"))
        out.append((f"rnn{li}.b.b_ih", f"{pre}.rnn.bias_ih_l1"))
        out.append((f"rnn{li}.b.w_hh", f"{pre}.rnn.weight_hh_l1"))
        out.append((f"rnn{li}.b.b_hh", f"{pre}.rnn.bias_hh_l1"))
        out.append((f"rnn{li}.proj.w", f"{pre}.linear.weight"))
        out.append((f"rnn{li}.proj.b", f"{pre}.linear.bias"))
    return out


ATTN_NAMES = [
    ("attn.i2h.w", "attention_decoder.i2h.weight"),
    ("attn.h2h.w", "attention_decoder.h2h.weight"),
    ("attn.h2h.b", "attention_decoder.h2h.bias"),
    ("attn.score.w", "attention_decoder.score.weight"),
    ("attn.w_ih", "attention_decoder.rnn.weight_ih"),
    ("attn.b_ih", "attention_decoder.rnn.bias_ih"),
    ("attn.w_hh", "attention_decoder.rnn.weight_hh"),
    ("attn.b_hh", "attention_decoder.rnn.bias_hh"),
    ("attn.gen.w", "attention_decoder.generator.weight"),
    ("attn.gen.b", "attention_decoder.generator.bias"),
    ("ctc.w", "ctc_head.weight"),
    ("ctc.b", "ctc_head.bias"),
]


def full_map(num_layers=2):
    """Полная таблица: имя в манифесте trba-rust -> имя в PyTorch/ONNX."""
    m = []
    for rust, conv, bn in conv_names():
        m.append((f"{rust}.w", f"{conv}.weight"))
        m.append((f"{rust}.gamma", f"{bn}.weight"))
        m.append((f"{rust}.beta", f"{bn}.bias"))
        m.append((f"{rust}.run_mean", f"{bn}.running_mean"))
        m.append((f"{rust}.run_var", f"{bn}.running_var"))
    m += se_names()
    m += rnn_names(num_layers)
    m += ATTN_NAMES
    return m


# ---------------------------------------------------------------------------
# чтение весов
# ---------------------------------------------------------------------------


BN_EPS = 1e-5  # BN_EPS из src/qnet.rs


def load_onnx_tensors(path):
    """ONNX -> ({имя: np.array}, model). QDQ-графы распутываются автоматически."""
    import onnx
    from onnx import numpy_helper

    m = onnx.load(path, load_external_data=True)
    t = {}
    for init in m.graph.initializer:
        try:
            t[init.name] = numpy_helper.to_array(init)
        except Exception as exc:  # noqa: BLE001
            print(f"  ⚠️  инициализатор {init.name} не читается: {exc}")
    return t, m


# Экспорт Кожина теряет имена CNN-весов (они становятся `onnx::Conv_2428`), но
# ИМЕНА УЗЛОВ сохраняют путь в PyTorch-модели: `/cnn/layer1/layer1.0/conv1/Conv_output_0`.
# Поэтому CNN разбирается по именам узлов, а не по именам тензоров.
def rust_conv_name(node_out):
    m = re.search(r"conv0\.(\d+)", node_out)
    if m:
        return f"stem.{m.group(1)}"
    # в именах узлов разделитель — "/", в state_dict — "."; понимаем оба
    m = re.search(r"(layer\d+\.\d+)[./]downsample", node_out)
    if m:
        return f"{m.group(1)}.downsample.0"
    m = re.search(r"(layer\d+\.\d+)[./](conv1|conv2)", node_out)
    if m:
        return f"{m.group(1)}.{m.group(2)}"
    m = re.search(r"conv_out\.(\d+)", node_out)
    if m:
        return f"conv_out.{m.group(1)}"
    return None


def linear_from_node(node, inits):
    """Вес линейного слоя в раскладке trba-rust [out, in].
    Gemm(transB=1) хранит [out, in] как PyTorch; MatMul хранит [in, out]."""
    wname = node.input[1]
    if wname not in inits:
        return None
    w = np.asarray(inits[wname], dtype=np.float32)
    if node.op_type == "MatMul":
        return np.ascontiguousarray(w.T)
    tb = 0
    for a in node.attribute:
        if a.name == "transB":
            tb = a.i
    return np.ascontiguousarray(w if tb == 1 else w.T)


def onnx_gate_perm(w, h):
    """ONNX LSTM хранит вентили в порядке i,o,f,c; trba-rust/PyTorch — i,f,g,o."""
    order = [0, 2, 3, 1]
    out = np.empty_like(w)
    for k, src in enumerate(order):
        out[k * h : (k + 1) * h] = w[src * h : (src + 1) * h]
    return out


def tensors_from_onnx_graph(m, inits, num_layers=1):
    """Обход графа -> тензоры в именах манифеста trba-rust."""
    out, report = {}, []
    # 1) CNN. BN в экспорте УЖЕ свёрнут в Conv (узлов BatchNormalization нет),
    #    поэтому свёртку представляем тождественным BN, весь перенос — в beta:
    #    gamma=1, run_mean=0, run_var=1-eps  =>  BN(x) = x + bias.
    nconv = 0
    for n in m.graph.node:
        if n.op_type != "Conv":
            continue
        rn = rust_conv_name(n.output[0])
        if rn is None:
            report.append(f"Conv без узнаваемого имени: {n.output[0]}")
            continue
        w = np.asarray(inits[n.input[1]], dtype=np.float32)
        bias = np.asarray(inits[n.input[2]], dtype=np.float32) if len(n.input) > 2 and n.input[2] in inits else np.zeros(w.shape[0], np.float32)
        o = w.shape[0]
        out[f"{rn}.w"] = w
        out[f"{rn}.gamma"] = np.ones(o, np.float32)
        out[f"{rn}.beta"] = bias
        out[f"{rn}.run_mean"] = np.zeros(o, np.float32)
        out[f"{rn}.run_var"] = np.full(o, 1.0 - BN_EPS, np.float32)
        nconv += 1
    report.append(f"свёрток перенесено {nconv} (ожидается 28 для SEResNet31)")

    # 2) SE-блоки: два MatMul на блок, имя узла содержит /se/fc/
    se = []
    for n in m.graph.node:
        if n.op_type in ("MatMul", "Gemm") and "/se/fc/" in n.output[0]:
            w = linear_from_node(n, inits)
            if w is not None:
                se.append((n.output[0], w))
    blocks = [(1, 1), (2, 2), (3, 5), (4, 3)]
    expect = []
    for li, (layer, nb) in enumerate(blocks):
        for bi in range(nb):
            expect.append((f"l{li}b{bi}.se.fc1.w", f"layer{layer}.{bi}.se.fc.0"))
            expect.append((f"l{li}b{bi}.se.fc2.w", f"layer{layer}.{bi}.se.fc.2"))
    used = 0
    for (rust_name, tail), (node_out, w) in zip(expect, se):
        if not node_out.endswith(tail.split(".")[-2] + "/" + tail.split(".")[-1] + "/MatMul_output_0") and tail.replace(".", "/") not in node_out:
            pass  # порядок совпадает по построению; проверка ниже по формам
        out[rust_name] = w
        used += 1
    report.append(f"SE-блоков перенесено {used} из {len(expect)} (в графе найдено {len(se)} MatMul)")

    # 3) BiLSTM: один узел LSTM на слой, веса анонимные, порядок вентилей ONNX
    lstms = [n for n in m.graph.node if n.op_type == "LSTM"]
    report.append(f"узлов LSTM: {len(lstms)} (num_encoder_layers = {len(lstms)})")
    for li, n in enumerate(lstms):
        W = np.asarray(inits[n.input[1]], dtype=np.float32)   # [2, 4H, in]
        R = np.asarray(inits[n.input[2]], dtype=np.float32)   # [2, 4H, H]
        B = np.asarray(inits[n.input[3]], dtype=np.float32) if len(n.input) > 3 and n.input[3] in inits else np.zeros((2, 8 * R.shape[1]), np.float32)
        h = R.shape[2]  # R = [num_dir, 4H, H]
        for di, tag in enumerate(("f", "b")):
            out[f"rnn{li}.{tag}.w_ih"] = np.ascontiguousarray(onnx_gate_perm(W[di], h))
            out[f"rnn{li}.{tag}.w_hh"] = np.ascontiguousarray(onnx_gate_perm(R[di], h))
            out[f"rnn{li}.{tag}.b_ih"] = np.ascontiguousarray(onnx_gate_perm(B[di][: 4 * h].reshape(4, h), h).ravel())
            out[f"rnn{li}.{tag}.b_hh"] = np.ascontiguousarray(onnx_gate_perm(B[di][4 * h :].reshape(4, h), h).ravel())
    # проекция энкодера: Gemm/MatMul с именем /enc_rnn.N/linear/
    for li in range(len(lstms)):
        for n in m.graph.node:
            if n.op_type in ("Gemm", "MatMul") and f"enc_rnn.{li}/linear/" in n.output[0]:
                w = linear_from_node(n, inits)
                if w is not None:
                    out[f"rnn{li}.proj.w"] = w
                    break
        named = f"model.enc_rnn.{li}.linear.bias"
        for k in inits:
            if k.endswith(f"enc_rnn.{li}.linear.bias"):
                out[f"rnn{li}.proj.b"] = np.asarray(inits[k], dtype=np.float32)
                named = k
                break
        else:
            report.append(f"⚠️  bias проекции слоя {li} не найден (искал {named})")

    # 4) декодер: часть весов именована, часть (без bias) — анонимна
    dec_map = [
        ("attn.h2h.w", "attention_cell.h2h.weight"),
        ("attn.h2h.b", "attention_cell.h2h.bias"),
        ("attn.w_ih", "attention_cell.rnn.weight_ih"),
        ("attn.b_ih", "attention_cell.rnn.bias_ih"),
        ("attn.w_hh", "attention_cell.rnn.weight_hh"),
        ("attn.b_hh", "attention_cell.rnn.bias_hh"),
        ("attn.gen.w", "generator.weight"),
        ("attn.gen.b", "generator.bias"),
    ]
    for rust_name, tail in dec_map:
        arr = resolve(inits, "attention_decoder." + tail)
        if arr is None:
            arr = resolve(inits, tail)
        if arr is None:
            report.append(f"⚠️  {rust_name}: не найден {tail}")
        else:
            out[rust_name] = np.asarray(arr, dtype=np.float32)
    # i2h и score не имеют bias и потому анонимны — ищем по имени узла
    for rust_name, pat in (("attn.i2h.w", "attention_cell/i2h/"), ("attn.score.w", "attention_cell/score/")):
        for n in m.graph.node:
            if n.op_type in ("Gemm", "MatMul") and pat in n.output[0]:
                w = linear_from_node(n, inits)
                if w is not None:
                    out[rust_name] = w
                    break
        else:
            report.append(f"⚠️  {rust_name}: узел с {pat} не найден")
    # CTC-голова в экспорт не попадает (TRBAONNXWrapper гонит только attention)
    ctc = resolve(inits, "ctc_head.weight")
    if ctc is not None:
        out["ctc.w"] = np.asarray(ctc, dtype=np.float32)
        b = resolve(inits, "ctc_head.bias")
        if b is not None:
            out["ctc.b"] = np.asarray(b, dtype=np.float32)
    else:
        report.append("CTC-голова в экспорте отсутствует (attention-only) — для --mope не нужна")
    return out, report, len(lstms)


def load_torch_tensors(path):
    import torch

    obj = torch.load(path, map_location="cpu", weights_only=False)
    if isinstance(obj, dict):
        for key in ("state_dict", "model", "model_state_dict"):
            if key in obj and isinstance(obj[key], dict):
                obj = obj[key]
                break
    out = {}
    for k, v in obj.items():
        if hasattr(v, "detach"):
            out[k] = v.detach().cpu().numpy().astype(np.float32)
    return out


def resolve(tensors, canonical):
    """Найти тензор по каноническому имени: точное совпадение, затем суффикс
    (экспорт добавляет префиксы вроде `model.`).

    Важно: суффикс НЕ укорачивается до одиночного `weight`/`bias` — иначе
    `ctc_head.bias` (которого в экспорте Кожина нет вовсе) «находится» как
    чей-нибудь `enc_rnn.0.linear.bias` [256], и в бандл молча уезжает чужой
    тензор. Минимум два сегмента в суффиксе."""
    if canonical in tensors:
        return tensors[canonical]
    tail = canonical.split(".")
    for n in range(len(tail) - 1):
        suffix = ".".join(tail[n:])
        if suffix.count(".") < 1:
            continue
        hits = [k for k in tensors if k == suffix or k.endswith("." + suffix) or k.endswith("/" + suffix)]
        if len(hits) == 1:
            return tensors[hits[0]]
        if len(hits) > 1:
            # однозначно выбираем самый короткий (ближайший к корню)
            hits.sort(key=len)
            return tensors[hits[0]]
    return None


def detect_lite(tensors):
    for k in tensors:
        if "depthwise" in k.lower() or "dw" in k.split(".")[-2:][0].lower() or k.endswith("conv1.depthwise.weight"):
            return True
    return False


# ---------------------------------------------------------------------------
# charset
# ---------------------------------------------------------------------------


def read_charset(path):
    with open(path, encoding="utf-8") as f:
        toks = [line.rstrip("\r\n") for line in f]
    while toks and toks[-1] == "":
        toks.pop()
    return toks


def count_chars(paths, charset):
    """Частоты токенов по корпусам (CSV с разметкой или любой текст)."""
    counts = np.zeros(len(charset), dtype=np.int64)
    idx = {t: i for i, t in enumerate(charset)}
    total = 0
    for p in paths:
        if not p or not os.path.exists(p):
            print(f"  ⚠️  корпус не найден: {p}")
            continue
        with open(p, encoding="utf-8", errors="ignore") as f:
            text = f.read()
        total += len(text)
        for ch in set(text):
            if ch in idx:
                counts[idx[ch]] += text.count(ch)
    print(f"  частоты: корпус {total} символов, уникальных токенов найдено {int((counts > 0).sum())}/{len(charset)}")
    return counts


def merge_charsets(charsets, counts_list, min_freq, max_size):
    """Тот же алгоритм, что в src/moe.rs::merge_charsets (проверено тестами
    на обеих сторонах): спецтокены всегда на 0..2, редкие (< min_freq) и
    выходящие за предел max_size отбрасываются, порядок — первая встреча."""
    freq, order = {}, {}
    for cs, cnt in zip(charsets, counts_list):
        for i, tok in enumerate(cs):
            if tok in SPECIALS:
                continue
            c = int(cnt[i]) if cnt is not None and i < len(cnt) else None
            freq[tok] = freq.get(tok, 0) + (c or 0)
            if c is None:
                freq[tok] = max(freq[tok], 1 << 62)  # «непроверенный» — не выбрасываем
            order.setdefault(tok, len(order))
    cand = [(t, f, order[t]) for t, f in freq.items() if f >= min_freq or f >= (1 << 62)]
    cand.sort(key=lambda x: (-x[1], x[2]))
    room = max(max_size - len(SPECIALS), 1)
    if len(cand) > room:
        cand = cand[:room]
    cand.sort(key=lambda x: x[2])
    itos = SPECIALS + [c[0] for c in cand]
    stoi = {}
    for i, t in enumerate(itos):
        stoi.setdefault(t, i)
    remaps, dropped = [], []
    for cs in charsets:
        remaps.append([stoi.get(t, -1) for t in cs])
        dropped.append([t for t in cs if t not in stoi])
    return itos, stoi, remaps, dropped


# ---------------------------------------------------------------------------
# бандл
# ---------------------------------------------------------------------------


def write_bundle(path, spec, charset, tensors):
    b = bytearray()
    b += MAGIC

    def u64(v):
        b.extend(struct.pack("<Q", int(v)))

    def s(v):
        raw = v.encode("utf-8")
        u64(len(raw))
        b.extend(raw)

    def f32s(arr):
        a = np.ascontiguousarray(np.asarray(arr, dtype=np.float32).ravel())
        u64(a.size)
        b.extend(a.tobytes())

    for k in ("name", "source", "kind"):
        s(spec[k])
    for k in ("img_h", "img_w", "max_len", "hidden", "feat_dim", "classes", "pad", "sos", "eos", "rnn_layers"):
        u64(spec[k])
    u64(len(charset))
    for t in charset:
        s(t)
    u64(len(tensors))
    for name, arr in tensors:
        s(name)
        f32s(arr)
    with open(path, "wb") as f:
        f.write(bytes(b))
    return len(b)


# ---------------------------------------------------------------------------


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("model", help="trba_base_g1.onnx / .pth / .pt")
    ap.add_argument("--out", required=True, help="куда положить бандл MoPE (.mope)")
    ap.add_argument("--name", default=None, help="имя эксперта (по умолчанию из файла)")
    ap.add_argument("--charset", default=None, help="charset.txt этого эксперта")
    ap.add_argument("--config", default=None, help="config/preset .json с геометрией")
    ap.add_argument("--img-h", type=int, default=None)
    ap.add_argument("--img-w", type=int, default=None)
    ap.add_argument("--max-len", type=int, default=None)
    ap.add_argument("--hidden", type=int, default=None)
    ap.add_argument("--num-layers", type=int, default=2)
    ap.add_argument("--merge-charset", action="append", default=[], help="charset второго/третьего эксперта для слияния")
    ap.add_argument("--char-counts-csv", action="append", default=[], help="корпус(а) для подсчёта частот символов")
    ap.add_argument("--min-freq", type=int, default=3, help="порог частоты символа (3 или 7 — как просили)")
    ap.add_argument("--max-classes", type=int, default=256, help="предел объединённого словаря MoPE")
    ap.add_argument("--charset-out", default=None, help="куда записать объединённый charset.txt")
    ap.add_argument("--verify", action="store_true", help="сверить бандл с onnxruntime")
    args = ap.parse_args()

    src = args.model
    print(f"📥 {src}")
    graph_tensors, graph_report, lstm_layers = None, [], 0
    if src.lower().endswith(".onnx"):
        tensors, onnx_model = load_onnx_tensors(src)
        kind = "onnx"
        graph_tensors, graph_report, lstm_layers = tensors_from_onnx_graph(onnx_model, tensors)
    else:
        tensors = load_torch_tensors(src)
        onnx_model = None
        kind = "torch"
    print(f"   тензоров в источнике: {len(tensors)}")
    for line in graph_report:
        print(f"   · {line}")
    if detect_lite(tensors):
        print("❌ это SEResNet31Lite (depthwise-separable свёртки). Нативный импорт в trba-rust невозможен:")
        print("   плотный ConvQat раздует 37 МБ до сотен МБ и замедлит свёртку. Варианты:")
        print("   1) использовать base-модель (trba_base_g1) как эксперта;")
        print("   2) держать lite как внешний ONNX-эксперт (onnxruntime) — см. README, раздел MoPE.")
        return 2

    # ---- charset
    charset_path = args.charset
    if charset_path is None:
        guess = os.path.splitext(src)[0] + ".txt"
        charset_path = guess if os.path.exists(guess) else None
    charset = read_charset(charset_path) if charset_path else SPECIALS
    print(f"   charset: {charset_path or 'НЕТ'} → {len(charset)} токенов")

    # ---- геометрия
    cfg = {}
    cfg_path = args.config or (os.path.splitext(src)[0] + ".json")
    if os.path.exists(cfg_path):
        with open(cfg_path, encoding="utf-8") as f:
            cfg = json.load(f)
        print(f"   config: {cfg_path}")
    spec = {
        "name": args.name or os.path.splitext(os.path.basename(src))[0],
        "source": os.path.abspath(src),
        "kind": kind,
        "img_h": args.img_h or cfg.get("img_h", 32),
        "img_w": args.img_w or cfg.get("img_w", 128),
        "max_len": args.max_len or cfg.get("max_len", 40),
        "hidden": args.hidden or cfg.get("hidden_size", 256),
        "feat_dim": 512,
        "rnn_layers": lstm_layers or args.num_layers,
        "classes": len(charset),
        "pad": charset.index("<PAD>") if "<PAD>" in charset else 0,
        "sos": charset.index("<SOS>") if "<SOS>" in charset else 1,
        "eos": charset.index("<EOS>") if "<EOS>" in charset else 2,
    }
    if onnx_model is not None:
        try:
            inp = onnx_model.graph.input[0].type.tensor_type.shape.dim
            dims = [d.dim_value for d in inp]
            if len(dims) == 4 and dims[2] and dims[3]:
                spec["img_h"], spec["img_w"] = dims[2], dims[3]
            elif len(dims) == 4 and dims[1] == 3:
                pass  # динамический размер — берём из config
        except Exception:  # noqa: BLE001
            pass
    print("   геометрия: " + ", ".join(f"{k}={v}" for k, v in spec.items() if k not in ("name", "source", "kind")))

    # ---- маппинг весов
    out_tensors = []
    missing = []
    if graph_tensors is not None:
        # ONNX: имена CNN-весов утрачены при экспорте, поэтому берём разбор графа
        nlayers = lstm_layers or args.num_layers
        for rust_name, canon in full_map(nlayers):
            if rust_name in graph_tensors:
                out_tensors.append((rust_name, graph_tensors[rust_name]))
            else:
                missing.append((rust_name, canon))
    else:
        for rust_name, canon in full_map(args.num_layers):
            arr = resolve(tensors, canon)
            if arr is None:
                missing.append((rust_name, canon))
                continue
            out_tensors.append((rust_name, arr))
    print(f"   перенесено тензоров: {len(out_tensors)}, не найдено: {len(missing)}")
    for rust_name, canon in missing[:12]:
        print(f"     ✗ {rust_name}  (искал {canon})")
    if missing:
        tail = [m for m in missing if m[0].startswith(("ctc", "attn.gen"))]
        if len(missing) > 12:
            print(f"     … и ещё {len(missing) - 12}")
        if not tail:
            print("   ⚠️  без этих весов эксперт будет считать мусор — проверьте имена в источнике")

    # контроль форм: словарь обязан совпасть с classes, иначе remap невозможен
    for rust_name, arr in out_tensors:
        if rust_name in ("ctc.w", "attn.gen.w") and arr.shape[0] != spec["classes"]:
            print(f"   ⚠️  {rust_name}: строк {arr.shape[0]}, а в charset {spec['classes']} токенов")
            spec["classes"] = int(arr.shape[0])
            print(f"       принимаю classes={spec['classes']} по форме веса (charset будет дополнен)")

    # ---- слияние словарей
    if args.merge_charset:
        others = [read_charset(p) for p in args.merge_charset]
        all_cs = [charset] + others
        counts = [count_chars(args.char_counts_csv, cs) if args.char_counts_csv else None for cs in all_cs]
        itos, _stoi, remaps, dropped = merge_charsets(all_cs, counts, args.min_freq, args.max_classes)
        print(f"🔤 слияние словарей: {len(charset)} + {' + '.join(str(len(o)) for o in others)} → {len(itos)} "
              f"(min_freq={args.min_freq}, max={args.max_classes})")
        for cs, dr, rm in zip(all_cs, dropped, remaps):
            kept = sum(1 for x in rm if x >= 0)
            print(f"   {len(cs)} токенов: сохранено {kept}, выброшено {len(dr)} → {dr[:16]}")
        if args.charset_out:
            with open(args.charset_out, "w", encoding="utf-8") as f:
                f.write("\n".join(itos) + "\n")
            print(f"   💾 объединённый charset записан: {args.charset_out}")
        # remap сохраняется рядом с бандлом — Rust перечитает его из charset-поля
        remap_path = args.out + ".remap.json"
        with open(remap_path, "w", encoding="utf-8") as f:
            json.dump({"itos": itos, "remap": remaps, "dropped": dropped}, f, ensure_ascii=False)
        print(f"   💾 таблицы перенумерации: {remap_path}")

    n = write_bundle(args.out, spec, charset, out_tensors)
    params = sum(int(np.asarray(a).size) for _, a in out_tensors)
    print(f"💾 {args.out}: {n / 1e6:.2f} МБ, {params:,} параметров, {len(out_tensors)} тензоров")
    print(f"   в trba-rust: --mope --mope-experts {args.out},exp/checkpoint_last.bin")

    if args.verify and onnx_model is not None:
        return verify(args.out, onnx_model, spec)
    return 0


def verify(bundle_path, onnx_model, spec):
    """Сверка: onnxruntime против бандла (первый conv + CTC-голова)."""
    try:
        import onnxruntime as ort
    except ImportError:
        print("   ⚠️  onnxruntime не установлен — сверка пропущена")
        return 0
    import onnx
    from onnx import numpy_helper

    # перечитываем бандл тем же кодом, что и Rust
    with open(bundle_path, "rb") as f:
        b = f.read()
    assert b[:8] == MAGIC
    p = 8

    def u64():
        nonlocal p
        v = struct.unpack_from("<Q", b, p)[0]
        p += 8
        return v

    def s():
        nonlocal p
        n = u64()
        v = b[p : p + n].decode("utf-8")
        p += n
        return v

    def f32s():
        nonlocal p
        n = u64()
        v = np.frombuffer(b, dtype="<f4", count=n, offset=p).copy()
        p += n * 4
        return v

    s(); s(); s()
    for _ in range(len(SPEC_KEYS)):
        u64()
    for _ in range(u64()):
        s()
    tensors = {}
    for _ in range(u64()):
        tensors[s()] = f32s()
    print(f"   ✓ бандл перечитан: {len(tensors)} тензоров")

    # сверяем вес stem.0 с инициализатором графа
    ref = None
    for init in onnx_model.graph.initializer:
        if init.name.endswith("conv0.0.weight"):
            ref = numpy_helper.to_array(init).ravel()
            break
    if ref is None:
        print("   ⚠️  не нашёл conv0.0.weight в графе")
        return 0
    got = tensors["stem.0.w"]
    ok = ref.size == got.size and np.allclose(ref, got, atol=1e-6)
    print(f"   {'✓' if ok else '✗'} stem.0.w: {got.size} значений, max|Δ| = {np.abs(ref - got).max():.2e}")

    # и прогон onnxruntime, чтобы убедиться, что граф вообще живой
    sess = ort.InferenceSession(onnx_model.SerializeToString(), providers=["CPUExecutionProvider"])
    x = np.random.randn(1, 3, spec["img_h"], spec["img_w"]).astype(np.float32)
    y = sess.run(None, {sess.get_inputs()[0].name: x})
    print(f"   ✓ onnxruntime: выход {y[0].shape}, среднее {y[0].mean():.4f}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
