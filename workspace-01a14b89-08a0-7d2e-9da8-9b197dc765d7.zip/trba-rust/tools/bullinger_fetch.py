#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Датасет для двух экспертов MoPE из dh-unibe/image-text_bullinger-autoren-lines.

Набор — строки латинских писем Буллингеру (73 502 строки, 8.3 ГБ): image + text
+ page + line_index. Строки длинные: медиана 76 символов, коротких (≤20) всего
4%, ≤64 — уже 30%. Резать строку на слова по проекции чернил НЕЛЬЗЯ: почерк
(XVI в., курсив) сливает и буквы, и слова — на 11 слов проекция даёт 8 run'ов,
то есть метка фрагмента перестанет соответствовать картинке. Поэтому берётся
строка ЦЕЛИКОМ, а под неё подбирается холст: при 32×256 строка в 64 символа
ложится в ~225 px без искажений (3.5 px на символ).

Разбиение — по страницам (`page` = XML-страница письма = практически рука/
писарь): первые страницы → обучение A, следующие → контроль A, затем →
обучение B и контроль B. Утечки между train и val нет даже на уровне письма.
Контроль намеренно состоит из ДВУХ частей (val_a и val_b): на val_a эксперт A
в своей тарелке, а B — нет, и наоборот, поэтому роутеру есть что решать —
определять руку по картинке, ровно как в сценарии «два писаря».

Картинки вписываются в холст trba-rust: `load_image_q` масштабирует по
min(img_h/h, img_w/w) и дополняет белым, поэтому здесь строка заранее
уменьшается до (img_w × img_h) — масштаб в рантайме равен 1, искажений нет.

    python3 tools/bullinger_fetch.py --out data/bullinger --raw-dir /tmp/bull_raw \
        --img-w 256 --img-h 32 --a 200 --b 400 --val-a 40 --val-b 60 --max-chars 64

Выход: img/*.png, a_train.csv, b_train.csv, val_a.csv, val_b.csv, val.csv,
charset_a.txt, charset_b.txt, charset_all.txt, manifest.tsv.
Только stdlib + Pillow; кэш оригиналов позволяет перезапускать без сети.
"""

import argparse
import concurrent.futures as cf
import json
import os
import re
import sys
import time
import urllib.request

API = ("https://datasets-server.huggingface.co/rows"
       "?dataset=dh-unibe/image-text_bullinger-autoren-lines"
       "&config=default&split=train&offset={off}&length={n}")

# Латиница, цифры и пунктуация переписки. Лигатуры, надстрочники и греческий
# отбрасываются вместе со строкой: усекать текст нельзя — метка обязана
# совпадать с изображением.
ALLOWED = re.compile(r"^[A-Za-z0-9 \.,;:!\?\-'()]+$")
SPECIAL = ["<PAD>", "<SOS>", "<EOS>"]
PACE = 1.2          # пауза между запросами к datasets-server: он щедр на 429


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def http_get(url, tries=6, base_wait=8.0, want_json=True):
    """GET с экспоненциальным откатом на 429/5xx."""
    last = None
    for k in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "trba-rust-demo/1.0"})
            with urllib.request.urlopen(req, timeout=90) as r:
                data = r.read()
            return json.loads(data.decode("utf-8")) if want_json else data
        except Exception as e:                                    # noqa: BLE001
            last = e
            code = getattr(e, "code", None)
            if k + 1 < tries:
                wait = base_wait * (2 ** k) if code in (429, 500, 502, 503, 504) else base_wait
                log(f"    {code or type(e).__name__}: жду {wait:.0f} с, попытка {k + 2}/{tries}")
                time.sleep(wait)
    log(f"    не получилось: {url[:90]}… ({last})")
    return None


def to_canvas(raw, img_w, img_h):
    """Grayscale + autocontrast + вписать в холст, сохранив пропорции."""
    from PIL import Image, ImageOps
    import io
    im = Image.open(io.BytesIO(raw))
    im = ImageOps.exif_transpose(im).convert("L")
    im = ImageOps.autocontrast(im, cutoff=1)
    im.thumbnail((img_w, img_h), Image.LANCZOS)
    return im


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default="data/bullinger")
    ap.add_argument("--raw-dir", default="/tmp/bull_raw",
                    help="кэш оригиналов (~100 КБ/шт) — держите вне рабочего каталога")
    ap.add_argument("--img-w", type=int, default=256)
    ap.add_argument("--img-h", type=int, default=32)
    ap.add_argument("--a", type=int, default=200)
    ap.add_argument("--b", type=int, default=400)
    ap.add_argument("--val-a", type=int, default=40)
    ap.add_argument("--val-b", type=int, default=60)
    ap.add_argument("--max-chars", type=int, default=64)
    ap.add_argument("--min-chars", type=int, default=8)
    ap.add_argument("--scan", type=int, default=4000, help="просмотреть строк датасета")
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--offset", type=int, default=0)
    args = ap.parse_args()

    os.makedirs(os.path.join(args.out, "img"), exist_ok=True)
    os.makedirs(args.raw_dir, exist_ok=True)

    # 1. метаданные: text/page/src, сразу с фильтром длины и алфавита
    log(f"[1/4] метаданные строк {args.offset}..{args.offset + args.scan} "
        f"(фильтр {args.min_chars}..{args.max_chars} символов)")
    rows, off = [], args.offset
    while len(rows) < 10 ** 6 and off < args.offset + args.scan:
        d = http_get(API.format(off=off, n=min(100, args.offset + args.scan - off)))
        if not d or not d.get("rows"):
            break
        for r in d["rows"]:
            row = r["row"]
            img = row.get("image") or {}
            t = (row.get("text") or "").replace("\u00a0", " ").replace("\u2019", "'").strip()
            if not (t and img.get("src") and ALLOWED.match(t)):
                continue
            if not (args.min_chars <= len(t) <= args.max_chars):
                continue
            rows.append({"row_idx": r.get("row_idx", off), "page": row.get("page") or "",
                         "text": t, "src": img["src"]})
        off += 100
        log(f"      просмотрено {off - args.offset}, подошло {len(rows)}")
        time.sleep(PACE)
    need = args.a + args.b + args.val_a + args.val_b
    if len(rows) < need:
        log(f"      ⚠️ подошло только {len(rows)} из нужных {need}: поднимите --scan "
            f"или --max-chars (дальше работаем с тем, что есть)")

    # 2. корзины по страницам: A-train, A-val, B-train, B-val
    pages, order = {}, []
    for r in rows:
        if r["page"] not in pages:
            pages[r["page"]] = []
            order.append(r["page"])
        pages[r["page"]].append(r)

    def take(n, start):
        acc, i = [], start
        while i < len(order) and len(acc) < n:
            acc.extend(pages[order[i]])
            i += 1
        return acc[:n], i

    a_tr, i = take(args.a, 0)
    a_va, i = take(args.val_a, i)
    b_tr, i = take(args.b, i)
    b_va, i = take(args.val_b, i)
    log(f"[2/4] страниц {len(order)}; A {len(a_tr)}/{len(a_va)}, B {len(b_tr)}/{len(b_va)}")

    # 3. картинки (кэш оригиналов на диске, затем PNG в холсте)
    todo = [(sp, r) for sp, rs in (("a_train", a_tr), ("val_a", a_va),
                                   ("b_train", b_tr), ("val_b", b_va)) for r in rs]
    log(f"[3/4] скачиваю {len(todo)} оригиналов ({args.workers} потока)")

    def fetch(item):
        sp, r = item
        p = os.path.join(args.raw_dir, f"{r['row_idx']:06d}.img")
        if not (os.path.exists(p) and os.path.getsize(p) > 1000):
            raw = http_get(r["src"], tries=4, base_wait=5.0, want_json=False)
            if not raw:
                return sp, r, None
            with open(p, "wb") as f:
                f.write(raw)
        try:
            with open(p, "rb") as f:
                im = to_canvas(f.read(), args.img_w, args.img_h)
            name = f"{sp[0]}{r['row_idx']:06d}.png"
            im.save(os.path.join(args.out, "img", name), "PNG", optimize=True)
        except Exception as e:                                        # noqa: BLE001
            log(f"    не обработалась строка {r['row_idx']}: {e}")
            return sp, r, None
        return sp, r, f"img/{name}"

    groups = {"a_train": [], "val_a": [], "b_train": [], "val_b": []}
    with cf.ThreadPoolExecutor(max_workers=args.workers) as ex:
        for k, (sp, r, name) in enumerate(ex.map(fetch, todo), 1):
            if name:
                r["file"] = name
                groups[sp].append(r)
            if k % 100 == 0:
                log(f"      {k}/{len(todo)}")

    # 4. CSV, словари, манифест
    def write_csv(fn, rs):
        with open(os.path.join(args.out, fn), "w", encoding="utf-8") as f:
            for r in rs:
                f.write('{},"{}"\n'.format(r["file"], r["text"].replace('"', '""')))

    log("[4/4] пишу CSV и словари")
    for fn, key in (("a_train.csv", "a_train"), ("val_a.csv", "val_a"),
                    ("b_train.csv", "b_train"), ("val_b.csv", "val_b")):
        if groups[key]:
            write_csv(fn, groups[key])
            log(f"      {fn}: {len(groups[key])}")
    if groups["val_a"] or groups["val_b"]:
        write_csv("val.csv", groups["val_a"] + groups["val_b"])
        log(f"      val.csv: {len(groups['val_a']) + len(groups['val_b'])}")

    def charset(rs):
        return SPECIAL + sorted({c for r in rs for c in r["text"]})

    ca, cb = charset(groups["a_train"]), charset(groups["b_train"])
    call = SPECIAL + sorted(set(ca[3:]) | set(cb[3:]))
    for fn, cs in (("charset_a.txt", ca), ("charset_b.txt", cb), ("charset_all.txt", call)):
        with open(os.path.join(args.out, fn), "w", encoding="utf-8") as f:
            f.write("\n".join(cs) + "\n")
    log(f"      charset_a {len(ca)} | charset_b {len(cb)} | общий {len(call)}; "
        f"только у A: {''.join(sorted(set(ca[3:]) - set(cb[3:]))) or '—'}, "
        f"только у B: {''.join(sorted(set(cb[3:]) - set(ca[3:]))) or '—'}")

    with open(os.path.join(args.out, "manifest.tsv"), "w", encoding="utf-8") as f:
        f.write("split\trow_idx\tpage\ttext\n")
        for sp in ("a_train", "val_a", "b_train", "val_b"):
            for r in groups[sp]:
                f.write(f"{sp}\t{r['row_idx']}\t{r['page']}\t{r['text']}\n")

    pa = len({r["page"] for r in groups["a_train"]})
    pb = len({r["page"] for r in groups["b_train"]})
    log(f"готово: A = {len(groups['a_train'])} строк с {pa} страниц, "
        f"B = {len(groups['b_train'])} с {pb} страниц, общих страниц "
        f"{len({r['page'] for r in groups['a_train']} & {r['page'] for r in groups['b_train']})}; "
        f"контроль {len(groups['val_a'])} + {len(groups['val_b'])}")


if __name__ == "__main__":
    main()
