#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Восстановить кэш оригиналов Bullinger по уже собранному manifest.tsv.

Зачем: `bullinger_fetch.py` кэширует сырые кадры в `--raw-dir` (по умолчанию
/tmp/bull_raw), а /tmp живёт только до перезапуска песочницы. `manifest.tsv`
переживает её вместе с датасетом, и в нём есть `row_idx` каждой строки, поэтому
оригиналы можно заказать заново ровно в том же составе — 14 обращений к
datasets-server (по одному на блок из 100 строк) и 700 скачиваний кадров,
~4 минуты. Текст каждой строки сверяется с манифестом: если API вернул не ту
строку, скрипт останавливается, а не пишет кадр под чужим именем.

После этого `bullinger_recrop.py` пересобирает дешёвую геометрию байт в байт:

    python3 tools/bullinger_refetch.py --src data/bullinger --raw-dir /tmp/bull_raw
    python3 tools/bullinger_recrop.py --src data/bullinger --raw-dir /tmp/bull_raw \
        --out data/bull40 --crop-chars 40 --img-w 160 --img-h 32
"""

import argparse
import json
import os
import sys
import time
import urllib.error
import urllib.request

API = ("https://datasets-server.huggingface.co/rows?dataset="
       "dh-unibe/image-text_bullinger-autoren-lines"
       "&config=default&split=train&offset={off}&length={n}")
PACE = 1.2          # datasets-server щедр на 429: темп важнее скорости
IMG_PAUSE = 0.12


def log(*a):
    print(*a, file=sys.stderr, flush=True)


def http_get(url, want_json=True, tries=5, base_wait=3.0):
    """GET с экспоненциальным откатом на 429/5xx."""
    for k in range(tries):
        req = urllib.request.Request(url, headers={"User-Agent": "trba-rust-refetch/1.0"})
        try:
            with urllib.request.urlopen(req, timeout=90) as r:
                body = r.read()
            return json.loads(body) if want_json else body
        except urllib.error.HTTPError as e:
            code = e.code
            if code == 404:
                raise
            wait = base_wait * (2 ** k) if code in (429, 500, 502, 503, 504) else base_wait
            log(f"  HTTP {code} на {url[:80]}… — ждём {wait:.0f} с")
            time.sleep(wait)
        except Exception as e:                                    # noqa: BLE001
            log(f"  {type(e).__name__}: {e} — ждём {base_wait * (2 ** k):.0f} с")
            time.sleep(base_wait * (2 ** k))
    raise RuntimeError(f"не удалось скачать {url[:120]}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--src", default="data/bullinger", help="каталог с manifest.tsv")
    ap.add_argument("--raw-dir", default="/tmp/bull_raw")
    ap.add_argument("--limit", type=int, default=0, help="0 = все строки манифеста")
    args = ap.parse_args()

    os.makedirs(args.raw_dir, exist_ok=True)
    want = {}
    with open(os.path.join(args.src, "manifest.tsv"), encoding="utf-8") as f:
        f.readline()
        for line in f:
            sp, idx, page, text = line.rstrip("\n").split("\t")
            want[int(idx)] = text
    idxs = sorted(want)
    if args.limit:
        idxs = idxs[: args.limit]
        want = {i: want[i] for i in idxs}
    blocks = sorted({i // 100 for i in idxs})
    log(f"[1/2] нужно {len(idxs)} кадров, {len(blocks)} блоков по 100 строк")

    todo = set(idxs)
    got = bad = 0
    for b in blocks:
        if not todo:
            break
        d = http_get(API.format(off=b * 100, n=100))
        for r in d.get("rows", []):
            i = r.get("row_idx")
            if i not in todo:
                continue
            txt = (r.get("row") or {}).get("text") or ""
            if txt != want[i]:
                bad += 1
                log(f"  ⚠️  строка {i}: текст не совпал с манифестом — пропускаю")
                continue
            src = ((r.get("row") or {}).get("image") or {}).get("src")
            if not src:
                bad += 1
                continue
            raw = http_get(src, want_json=False, tries=4, base_wait=5.0)
            with open(os.path.join(args.raw_dir, f"{i:06d}.img"), "wb") as f:
                f.write(raw)
            todo.discard(i)
            got += 1
            time.sleep(IMG_PAUSE)
        log(f"[2/2] блок {b * 100}..{b * 100 + 99}: всего {got} кадров, осталось {len(todo)}")
        time.sleep(PACE)

    log(f"готово: скачано {got}, пропущено {bad}, не найдено {len(todo)}")
    if todo:
        log(f"  не хватает: {sorted(todo)[:10]}{'…' if len(todo) > 10 else ''}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
