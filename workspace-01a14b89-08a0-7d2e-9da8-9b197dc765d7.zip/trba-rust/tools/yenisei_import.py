#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""YeniseiGovReports-HWR (раскладка <split>/{img/,labels.csv}) → CSV и charset для trba-rust.

Почему конвертер вообще нужен:
  * trba-rust читает `path,text` БЕЗ заголовка (main.rs:parse_csv_line), а в
    labels.csv заголовок `filename,text` есть — он превратился бы в строку
    с картинкой "filename";
  * пути разрешаются относительно КАТАЛОГА CSV (main.rs:load_csv), а в labels.csv
    имя файла без `img/`;
  * неизвестные символы из текста ВЫБРАСЫВАЮТСЯ, а текст длиннее --max-len
    ОБРЕЗАЕТСЯ, и строка при этом НЕ пропускается (main.rs:800) — молчаливая
    порча разметки. Весь фильтр поэтому делается здесь и печатается счётчиками;
  * charset-файл trba-rust сам не строит: три служебные строки <PAD> <SOS> <EOS>,
    затем по одному символу на строку в порядке кодовых точек (так устроены
    data/bull40/charset_*.txt из поставки).

Выход пишется рядом с labels.csv, чтобы пути до картинок оставались короткими:
  <root>/<split>/trba_<split>.csv, <root>/charset_trba.txt, <root>/trba_import_report.txt
"""
import argparse, csv, os, sys
from collections import Counter


def read_labels(path):
    with open(path, newline='', encoding='utf-8') as f:
        rows = list(csv.reader(f))
    if rows and rows[0] and rows[0][0].strip().lower() in ('filename', 'file', 'path', 'image'):
        rows = rows[1:]                       # заголовок
    out = []
    for r in rows:
        if len(r) < 2:
            continue
        out.append((r[0].strip(), r[1].strip()))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True, help='каталог YeniseiGovReports-HWR')
    ap.add_argument('--splits', default='train,val')
    ap.add_argument('--img-dir', default='img', help='подкаталог с PNG внутри сплита')
    ap.add_argument('--labels', default='labels.csv')
    ap.add_argument('--max-len', type=int, default=40, help='как --max-len обучения')
    ap.add_argument('--min-chars', type=int, default=2)
    ap.add_argument('--limit', type=int, default=0, help='0 = все строки, N = первые N')
    ap.add_argument('--stride', type=int, default=1, help='брать каждую K-ю строку')
    ap.add_argument('--charset-split', default='train', help='по какому сплиту строить словарь')
    a = ap.parse_args()

    splits = [s for s in a.splits.split(',') if s]
    raw, kept, drop = {}, {}, Counter()
    lengths = Counter()
    for sp in splits:
        lp = os.path.join(a.root, sp, a.labels)
        if not os.path.exists(lp):
            print(f'⚠️  {lp} не найден — сплит пропущен'); continue
        rows = read_labels(lp)
        if a.stride > 1:
            rows = rows[::a.stride]
        if a.limit:
            rows = rows[:a.limit]
        raw[sp] = rows
        img_dir = os.path.join(a.root, sp, a.img_dir)
        k = []
        for fn, text in rows:
            if not text:
                drop['пустой текст'] += 1; continue
            if len(text) < a.min_chars:
                drop[f'короче {a.min_chars}'] += 1; continue
            if len(text) > a.max_len:
                drop[f'длиннее {a.max_len} (был бы обрезан)'] += 1; continue
            if not os.path.exists(os.path.join(img_dir, fn)):
                drop['нет картинки'] += 1; continue
            k.append((fn, text)); lengths[len(text)] += 1
        kept[sp] = k
        print(f'   {sp}: {len(rows)} строк → {len(k)} годных')

    if a.charset_split not in kept or not kept.get(a.charset_split):
        sys.exit(f'нет сплита {a.charset_split} — словарь строить не из чего')
    chars = sorted({ch for _, t in kept[a.charset_split] for ch in t})
    cs_path = os.path.join(a.root, 'charset_trba.txt')
    with open(cs_path, 'w', encoding='utf-8') as f:
        f.write('<PAD>\n<SOS>\n<EOS>\n')
        for ch in chars:
            f.write(ch + '\n')
    vocab = set(chars)
    print(f'🔤 charset {cs_path}: {len(chars) + 3} токенов (3 служебных + {len(chars)} символов по {a.charset_split})')

    for sp in splits:
        if sp not in kept:
            continue
        rows = [(fn, t) for fn, t in kept[sp] if all(ch in vocab for ch in t)]
        drop['символ вне словаря'] += len(kept[sp]) - len(rows)
        out = os.path.join(a.root, sp, f'trba_{sp}.csv')
        with open(out, 'w', newline='', encoding='utf-8') as f:
            w = csv.writer(f, quoting=csv.QUOTE_MINIMAL)
            for fn, t in rows:
                w.writerow([f'{a.img_dir}/{fn}', t])
        print(f'💾 {out}: {len(rows)} строк')

    if lengths:
        ks = sorted(lengths); tot = sum(lengths.values()); q = {}
        for p in (50, 90, 99):
            acc = 0                      # сбрасывается для КАЖДОГО процентиля:
            for k in ks:                 # без этого p90/p99 выходили меньше p50
                acc += lengths[k]
                if acc >= tot * p / 100:
                    q[p] = k; break
        print(f'📏 длина текста: p50 {q.get(50)} · p90 {q.get(90)} · p99 {q.get(99)} · max {ks[-1]}')
    try:
        from PIL import Image
        sp = a.charset_split if a.charset_split in kept else splits[0]
        sample = kept[sp][:200]
        ws, hs = [], []
        for fn, _ in sample:
            with Image.open(os.path.join(a.root, sp, a.img_dir, fn)) as im:
                ws.append(im.size[0]); hs.append(im.size[1])
        if ws:
            ws.sort(); hs.sort()
            print(f'🖼  картинки ({len(ws)} шт): ширина min {ws[0]} / p50 {ws[len(ws)//2]} / max {ws[-1]}, '
                  f'высота min {hs[0]} / p50 {hs[len(hs)//2]} / max {hs[-1]}')
            print('   препроцессинг trba-rust: RGB → resize с сохранением пропорций → белый холст, '
                  'поэтому кадр 32×160 подходит и словам 30×22, и 140×29')
    except Exception as e:
        print(f'   (PIL недоступен, размеры картинок не измерены: {e})')
    if drop:
        print('🧹 отброшено: ' + ', '.join(f'{k} {v}' for k, v in sorted(drop.items())))
    rep = os.path.join(a.root, 'trba_import_report.txt')
    with open(rep, 'w', encoding='utf-8') as f:
        f.write(f'root={a.root} max_len={a.max_len} min_chars={a.min_chars} limit={a.limit} stride={a.stride}\n')
        for sp in splits:
            if sp in kept:
                f.write(f'{sp}: raw={len(raw.get(sp, []))} kept={len(kept[sp])}\n')
        f.write(f'charset={len(chars) + 3}\n')
        for k, v in sorted(drop.items()):
            f.write(f'drop {k}: {v}\n')
    print(f'📄 {rep}')


if __name__ == '__main__':
    main()
