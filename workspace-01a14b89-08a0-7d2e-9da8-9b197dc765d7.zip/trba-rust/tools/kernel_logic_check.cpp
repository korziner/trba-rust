// kernel_logic_check — runs the *index arithmetic* of the CUDA kernels on the
// CPU, with no GPU and no CUDA toolkit, in well under a second.
//
// Why this exists
// ---------------
// cuda/kernels.cu and cuda/cpu_backend.cpp are two independent implementations
// of the same contract, and the CPU one is the reference.  Three of the bugs
// that made the CUDA path unusable were pure index/tiling mistakes that the CPU
// backend never had, so `cargo test` on a GPU-less machine could not see them:
//
//   1. the WMMA GEMMs walked  floor(Mp/64) * floor(Np/64)  tiles, so every
//      shape whose padded extent is not a multiple of 64 (M=17, N=96 = the
//      classifier head, ...) left part of C unwritten, and M<64 or N<64 left
//      *all* of it unwritten;
//   2. the WMMA GEMMs read A/Bt without a row bound, and the operands are only
//      padded to 16, so the last partial tile read past the end of the buffer
//      (illegal memory access);
//   3. grad_weight_fused_kernel iterated `for (ci = tid; ci < col_cols;
//      ci += blockDim.x)` with __syncthreads() inside, so threads ran a
//      different number of barrier rounds whenever col_cols % 256 != 0 — which
//      is the case for almost every SEResNet31 layer (Cin=3 -> 27, Cin=32 ->
//      288, Cin=128 -> 1152).  The block deadlocks or races on shared memory.
//
// This file re-implements 1:1 the tiling, the guards and the barrier schedule
// of the fixed kernels, and compares the result with a naive reference.  Build:
//
//   g++ -O2 -std=c++17 -Wall -o /tmp/klogic tools/kernel_logic_check.cpp && /tmp/klogic
//
// It is a *logic* check, not a performance or race check: the WMMA maths is
// done with plain loops instead of tensor cores, and thread divergence is
// detected by counting barrier rounds per thread rather than by running them.

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

static inline int align16(int x) { return (x + 15) & ~15; }
static inline int ceil_div(int a, int b) { return (a + b - 1) / b; }

static int g_fail = 0;
static int g_pass = 0;

static void report(bool ok, const std::string &what, const std::string &detail = "") {
    if (ok) {
        ++g_pass;
        printf("  ok    %s\n", what.c_str());
    } else {
        ++g_fail;
        printf("  FAIL  %s  %s\n", what.c_str(), detail.c_str());
    }
}

// deterministic pseudo random in [-1, 1]
static float det(long long i, long long seed) {
    uint64_t x = (uint64_t)i * 2654435761u;
    x ^= (uint64_t)seed;
    x *= 6364136223846793005ull;
    x += 1442695040888963407ull;
    return ((float)(x >> 33) / (float)(1ull << 31)) * 2.0f - 1.0f;
}

// ============================================================================
// 1. INT8 WMMA GEMM — mirrors gemm_int8_wmma_kernel + launch_gemm_int8
//    C[M,N] (int32, compact) = A[Mp,Kp] (int8) * Bt[Np,Kp]^T (int8)
// ============================================================================
struct GemmStats {
    long long tiles = 0;      // tiles the kernel walks
    int blocks = 0;           // blocks launched
    long long written = 0;    // elements of C actually stored
    long long oob_reads = 0;  // reads past the padded operand buffers
};

static void gemm_int8_emul(const int8_t *A, const int8_t *Bt, int32_t *C, int M, int N, int K,
                           GemmStats *st) {
    const int BM = 64, BN = 64, BK = 32;
    const int Mp = align16(M), Np = align16(N), Kp = align16(K);

    // ---- host side (launch_gemm_int8) ----
    long long tiles_ll = (long long)ceil_div(Mp, 64) * ceil_div(Np, 64);
    tiles_ll = std::max<long long>(tiles_ll, 1);
    int blocks = (int)std::min<long long>(tiles_ll, 8192);
    st->blocks = blocks;

    // ---- device side (gemm_int8_wmma_kernel) ----
    const int tiles_x = ceil_div(Np, BN);
    const int total_tiles = tiles_x * ceil_div(Mp, BM);
    st->tiles = total_tiles;

    std::vector<char> touched((size_t)M * N, 0);

    for (int blk = 0; blk < blocks; ++blk) {
        for (int tile = blk; tile < total_tiles; tile += blocks) {
            const int tile_y = tile / tiles_x;
            const int tile_x = tile - tile_y * tiles_x;
            const int row0 = tile_y * BM;
            const int col0 = tile_x * BN;

            std::vector<int32_t> acc(4 * 32 * 32, 0);  // per warp 32x32 patch
            std::vector<int8_t> smem_a((size_t)BM * BK, 0), smem_b((size_t)BN * BK, 0);

            for (int k0 = 0; k0 < Kp; k0 += BK) {
                std::fill(smem_a.begin(), smem_a.end(), (int8_t)0);
                std::fill(smem_b.begin(), smem_b.end(), (int8_t)0);

                // 128 threads x 4 int32-wide loads, with the row/column guards
                for (int t = 0; t < 128; ++t) {
                    for (int i = 0; i < 4; ++i) {
                        int idx = t + i * 128;
                        int flat = idx * 4;
                        int r = flat / BK, c = flat - r * BK;
                        if (row0 + r < Mp && k0 + c < Kp) {
                            for (int q = 0; q < 4; ++q) {
                                long long off = (long long)(row0 + r) * Kp + k0 + c + q;
                                if (off >= (long long)Mp * Kp) ++st->oob_reads;
                                smem_a[(size_t)r * BK + c + q] = A[off];
                            }
                        } else if (row0 + r >= Mp || col0 + r >= Np) {
                            // would have been an out-of-bounds read before the fix
                        }
                        if (col0 + r < Np && k0 + c < Kp) {
                            for (int q = 0; q < 4; ++q) {
                                long long off = (long long)(col0 + r) * Kp + k0 + c + q;
                                if (off >= (long long)Np * Kp) ++st->oob_reads;
                                smem_b[(size_t)r * BK + c + q] = Bt[off];
                            }
                        }
                    }
                }

                // 4 warps as 2x2, each producing a 32x32 patch out of 16x16
                // wmma tiles; a_frag row_major, b_frag col_major over Bt[N,K].
                for (int warp = 0; warp < 4; ++warp) {
                    const int warp_m = (warp & 1) * 32;
                    const int warp_n = (warp >> 1) * 32;
                    for (int k = 0; k < BK; k += 16) {
                        for (int mi = 0; mi < 2; ++mi) {
                            for (int ni = 0; ni < 2; ++ni) {
                                // acc is the warp's 32x32 patch, row-major;
                                // fragment (mi, ni) covers rows mi*16..+16 and
                                // columns ni*16..+16 of that patch.
                                for (int i = 0; i < 16; ++i) {
                                    for (int j = 0; j < 16; ++j) {
                                        int32_t s = 0;
                                        for (int t2 = 0; t2 < 16; ++t2) {
                                            int8_t a = smem_a[(size_t)(warp_m + mi * 16 + i) * BK + k + t2];
                                            int8_t b = smem_b[(size_t)(warp_n + ni * 16 + j) * BK + k + t2];
                                            s += (int32_t)a * (int32_t)b;
                                        }
                                        acc[(size_t)warp * 32 * 32
                                            + (size_t)(mi * 16 + i) * 32 + (size_t)(ni * 16 + j)] += s;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // stage the 64x64 tile, then clip on store
            std::vector<int32_t> stage((size_t)BM * BN, 0);
            for (int warp = 0; warp < 4; ++warp) {
                const int warp_m = (warp & 1) * 32;
                const int warp_n = (warp >> 1) * 32;
                for (int mi = 0; mi < 2; ++mi)
                    for (int ni = 0; ni < 2; ++ni)
                        for (int i = 0; i < 16; ++i)
                            for (int j = 0; j < 16; ++j) {
                                int32_t v = acc[(size_t)warp * 32 * 32 + (size_t)mi * 16 * 32
                                                + (size_t)ni * 16 + (size_t)i * 32 + j];
                                stage[(size_t)(warp_m + mi * 16 + i) * BN + (warp_n + ni * 16 + j)] = v;
                            }
            }
            for (int i = 0; i < BM * BN / 4; ++i) {
                int r = i / (BN / 4);
                int c = (i - r * (BN / 4)) * 4;
                int gm = row0 + r, gn = col0 + c;
                for (int j = 0; j < 4; ++j) {
                    if (gm < M && gn + j < N) {
                        C[(long long)gm * N + gn + j] = stage[(size_t)r * BN + c + j];
                        if (!touched[(size_t)gm * N + gn + j]) {
                            touched[(size_t)gm * N + gn + j] = 1;
                            ++st->written;
                        }
                    }
                }
            }
        }
    }
}

static void check_gemm_int8(int M, int N, int K) {
    const int Mp = align16(M), Np = align16(N), Kp = align16(K);
    std::vector<int8_t> a((size_t)Mp * Kp, 0), b((size_t)Np * Kp, 0);
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < K; ++j) a[(size_t)i * Kp + j] = (int8_t)(det(i * Kp + j, 1) * 100.0f);
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < K; ++j) b[(size_t)i * Kp + j] = (int8_t)(det(i * Kp + j, 2) * 100.0f);

    std::vector<int32_t> got((size_t)M * N, -12345), want((size_t)M * N, 0);
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j) {
            int32_t s = 0;
            for (int p = 0; p < K; ++p) s += (int32_t)a[(size_t)i * Kp + p] * (int32_t)b[(size_t)j * Kp + p];
            want[(size_t)i * N + j] = s;
        }

    GemmStats st;
    gemm_int8_emul(a.data(), b.data(), got.data(), M, N, K, &st);

    char label[160];
    snprintf(label, sizeof(label), "int8 wmma gemm M=%d N=%d K=%d (tiles=%lld blocks=%d)", M, N, K,
             st.tiles, st.blocks);
    bool ok = (got == want) && st.written == (long long)M * N && st.oob_reads == 0;
    std::string detail;
    if (got != want) {
        long long bad = 0, first = -1;
        for (size_t i = 0; i < got.size(); ++i)
            if (got[i] != want[i]) {
                if (first < 0) first = (long long)i;
                ++bad;
            }
        char d[160];
        snprintf(d, sizeof(d), "[%lld/%d elements wrong, first at %lld: got %d want %d]", bad, M * N,
                 first, first >= 0 ? got[first] : 0, first >= 0 ? want[first] : 0);
        detail = d;
    } else if (st.written != (long long)M * N) {
        char d[120];
        snprintf(d, sizeof(d), "[only %lld of %d C elements written]", st.written, M * N);
        detail = d;
    } else if (st.oob_reads) {
        char d[120];
        snprintf(d, sizeof(d), "[%lld out-of-bounds operand reads]", st.oob_reads);
        detail = d;
    }
    report(ok, label, detail);
}

// ============================================================================
// 2. grad_weight fused kernel — barrier schedule + index math
//    grid = Cout blocks, 256 threads, GW_SMEM = 512
// ============================================================================
static void grad_weight_emul(const int8_t *input, const float *go, float *grad_W, int B, int Cin,
                             int H, int W, int Cout, int kH, int kW, int sH, int sW, int pH, int pW,
                             int Ho, int Wo, long long *max_barrier_rounds_diff,
                             long long *old_divergent_threads) {
    const int nthreads = 256, GW_SMEM = 512;
    const int hw_out = Ho * Wo;
    const int col_cols = Cin * kH * kW;

    // What the OLD loop did: threads with tid >= col_cols never entered, and
    // threads entered a different number of times whenever col_cols % 256 != 0.
    *old_divergent_threads = 0;
    {
        int min_it = INT32_MAX, max_it = 0;
        for (int tid = 0; tid < nthreads; ++tid) {
            int it = 0;
            for (int ci = tid; ci < col_cols; ci += nthreads) ++it;
            min_it = std::min(min_it, it);
            max_it = std::max(max_it, it);
        }
        if (min_it != max_it) {
            for (int tid = 0; tid < nthreads; ++tid) {
                int it = 0;
                for (int ci = tid; ci < col_cols; ci += nthreads) ++it;
                if (it != max_it) ++*old_divergent_threads;
            }
        }
    }

    long long min_rounds = INT64_MAX, max_rounds = 0;
    for (int oc = 0; oc < Cout; ++oc) {           // one block per output channel
        std::vector<float> sgo(GW_SMEM, 0.f);
        const int rounds = ceil_div(col_cols, nthreads);
        // every thread of the block executes exactly `rounds` barrier rounds
        min_rounds = std::min(min_rounds, (long long)rounds);
        max_rounds = std::max(max_rounds, (long long)rounds);

        std::vector<float> acc((size_t)nthreads, 0.f);
        for (int round = 0; round < rounds; ++round) {
            for (int tid = 0; tid < nthreads; ++tid) {
                const int ci = round * nthreads + tid;
                const bool active = (ci < col_cols);
                acc[tid] = 0.f;
                if (!active) continue;
                const int c_idx = ci / (kH * kW);
                const int kk = ci - c_idx * (kH * kW);
                const int khi = kk / kW, kwi = kk - khi * kW;
                float a = 0.f;
                for (int b = 0; b < B; ++b) {
                    const int8_t *in_b = input + (long long)(b * Cin + c_idx) * H * W;
                    const float *go_b = go + (long long)(b * Cout + oc) * hw_out;
                    for (int p0 = 0; p0 < hw_out; p0 += GW_SMEM) {
                        const int cnt = std::min(GW_SMEM, hw_out - p0);
                        for (int j = 0; j < cnt; ++j) sgo[j] = go_b[p0 + j];  // __syncthreads()
                        for (int j = 0; j < cnt; ++j) {                        // __syncthreads()
                            const int p = p0 + j;
                            const int oh = p / Wo, ow = p - oh * Wo;
                            const int ih = oh * sH + khi - pH;
                            const int iw = ow * sW + kwi - pW;
                            if (ih >= 0 && ih < H && iw >= 0 && iw < W) a += sgo[j] * (float)in_b[ih * W + iw];
                        }
                    }
                }
                acc[tid] = a;
                grad_W[(long long)oc * col_cols + ci] = a;
            }
        }
    }
    *max_barrier_rounds_diff = max_rounds - min_rounds;
}

static void check_grad_weight(int B, int Cin, int H, int W, int Cout, int k, int s, int p) {
    const int Ho = (H + 2 * p - k) / s + 1, Wo = (W + 2 * p - k) / s + 1;
    const int col_cols = Cin * k * k, hw_out = Ho * Wo;
    std::vector<int8_t> input((size_t)B * Cin * H * W);
    std::vector<float> go((size_t)B * Cout * hw_out);
    for (size_t i = 0; i < input.size(); ++i) input[i] = (int8_t)(det((long long)i, 13) * 100.f);
    for (size_t i = 0; i < go.size(); ++i) go[i] = det((long long)i, 17);

    // naive reference (same math as cuda/cpu_backend.cpp)
    std::vector<float> want((size_t)Cout * col_cols, 0.f);
    for (int oc = 0; oc < Cout; ++oc)
        for (int ci = 0; ci < col_cols; ++ci) {
            const int c_idx = ci / (k * k);
            const int kk = ci - c_idx * (k * k);
            const int khi = kk / k, kwi = kk - khi * k;
            float acc = 0.f;
            for (int b = 0; b < B; ++b)
                for (int oh = 0; oh < Ho; ++oh)
                    for (int ow = 0; ow < Wo; ++ow) {
                        int ih = oh * s + khi - p, iw = ow * s + kwi - p;
                        if (ih >= 0 && ih < H && iw >= 0 && iw < W)
                            acc += go[((size_t)(b * Cout + oc)) * hw_out + oh * Wo + ow]
                                   * (float)input[((size_t)(b * Cin + c_idx) * H + ih) * W + iw];
                    }
            want[(size_t)oc * col_cols + ci] = acc;
        }

    std::vector<float> got((size_t)Cout * col_cols, 1e30f);
    long long round_diff = -1, divergent = -1;
    grad_weight_emul(input.data(), go.data(), got.data(), B, Cin, H, W, Cout, k, k, s, s, p, p, Ho,
                     Wo, &round_diff, &divergent);

    float scale = 1.f;
    for (float v : want) scale = std::max(scale, std::fabs(v));
    float maxd = 0.f;
    for (size_t i = 0; i < got.size(); ++i) maxd = std::max(maxd, std::fabs(got[i] - want[i]));

    char label[200];
    snprintf(label, sizeof(label),
             "grad_weight fused B=%d Cin=%d %dx%d Cout=%d k=%d s=%d p=%d (col_cols=%d, "
             "old loop: %lld/256 threads diverged)",
             B, Cin, H, W, Cout, k, s, p, col_cols, divergent);
    char detail[160];
    snprintf(detail, sizeof(detail), "[maxdiff=%.3g scale=%.3g barrier_round_spread=%lld]", maxd,
             scale, round_diff);
    report(maxd <= 1e-3f * scale && round_diff == 0, label, (maxd <= 1e-3f * scale && round_diff == 0) ? "" : detail);
    if (maxd <= 1e-3f * scale && round_diff == 0 && divergent > 0) {
        printf("        ^ this shape would have deadlocked/raced before the fix\n");
    }
}

int main() {
    printf("kernel_logic_check — CPU emulation of the CUDA kernel index arithmetic\n\n");

    printf("[1] INT8 WMMA GEMM: tile coverage, clip-on-store, operand bounds\n");
    // shapes the unit tests use, plus the ones the model actually produces
    check_gemm_int8(16, 16, 16);
    check_gemm_int8(17, 5, 3);        // M<64 and N<64: used to write nothing at all
    check_gemm_int8(100, 33, 27);     // partial tiles in both dimensions
    check_gemm_int8(256, 192, 512);
    check_gemm_int8(96, 96, 32);      // classifier head: N padded to 96, not 64
    check_gemm_int8(1, 1, 1);
    check_gemm_int8(63, 65, 17);
    check_gemm_int8(1024, 512, 288);  // a real conv: rows=B*Ho*Wo, N=Cout, K=Cin*9
    check_gemm_int8(512, 1152, 512);  // the grad_W GEMM orientation (M=Cout, N=Cin*9, K=rows)

    printf("\n[2] grad_weight fused kernel: uniform barrier rounds + index math\n");
    check_grad_weight(2, 3, 8, 7, 5, 3, 1, 1);     // stem-like: col_cols = 27  < 256 threads
    check_grad_weight(1, 4, 6, 6, 8, 3, 2, 1);     // col_cols = 36
    check_grad_weight(3, 2, 5, 5, 3, 1, 1, 0);     // col_cols = 2
    check_grad_weight(2, 32, 16, 16, 32, 3, 1, 1); // col_cols = 288 -> 288 % 256 != 0
    check_grad_weight(2, 128, 8, 32, 128, 3, 1, 1);// col_cols = 1152 -> divergent
    check_grad_weight(1, 512, 4, 16, 512, 3, 1, 1);// col_cols = 4608 -> was already uniform
    check_grad_weight(2, 512, 4, 16, 512, 2, 1, 0);// conv_out: k=2

    printf("\n%d passed, %d failed\n", g_pass, g_fail);
    return g_fail ? 1 : 0;
}
