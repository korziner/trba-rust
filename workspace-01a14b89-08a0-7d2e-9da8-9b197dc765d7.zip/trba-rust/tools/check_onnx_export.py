#!/usr/bin/env python3
"""Сверка ONNX-экспорта trba-rust с onnxruntime и с эталоном из Rust.

    python3 tools/check_onnx_export.py REF_DIR MODEL.onnx

REF_DIR — то, что написал `--onnx-ref DIR` (input.raw, ref_feat.raw,
ref_enc.raw, ref_logits.raw, meta.txt).

Проверяются четыре независимых вещи:

A. `onnx.checker` + сессия onnxruntime: файл валиден и исполняется.
B. Rust ↔ onnxruntime на одном входе: `feat`/`enc`/`logits`. Точного
   совпадения здесь быть не может по построению — CNN в trba-rust считает
   int8 QAT-свёртки, а экспортированный граф fp32, — поэтому смотрим
   корреляцию, относительную ошибку и совпадение argmax.
C. Независимый numpy-пересчёт stem (Conv+BN→Relu ×2, MaxPool 2×2) против
   выхода `stem` из onnxruntime: ловит ошибку в раскладке входа, pads,
   strides и в свёртке BatchNorm в Conv.
D. Независимый numpy-пересчёт BiLSTM+проекция (по ONNX-спеке: гейты
   i,o,f,c; реверсное направление кладёт hidden позиции tt в слот T-1-tt)
   против выхода `enc`, и CTC-голова против `logits`. Вход — `feat`,
   посчитанный самим onnxruntime, чтобы ошибка CNN не накапливалась.

C и D работают только если граф собран с `--onnx-debug` (нужны выходы
`stem` и `enc`).

Требуется: onnx, onnxruntime, numpy.
"""
import os
import sys

import numpy as np
import onnx
import onnxruntime as ort



def read_charset(path):
    """Словарь: одна строка = один токен. ВАЖНО: токен-пробел — это
    полноценный класс (в charset.txt Кожина он стоит четвёртым, после
    <PAD> <SOS> <EOS>), поэтому фильтр `if l.strip()` молча его выбрасывал и
    сдвигал все id на единицу: секция F рапортовала «текст не совпал 0/3» при
    совпавших 96/96 argmax логитов. Отбрасываем только пустые строки в хвосте.
    """
    with open(path, encoding="utf-8") as f:
        toks = [line.rstrip("\r\n") for line in f]
    while toks and toks[-1] == "":
        toks.pop()
    return toks


def read_meta(d):
    m = {}
    with open(os.path.join(d, "meta.txt")) as f:
        for line in f:
            if "=" in line:
                k, v = line.split("=", 1)
                m[k.strip()] = v.strip()
    return m


def rd(d, name):
    return np.fromfile(os.path.join(d, name), dtype=np.float32)


def report(tag, a, b):
    """a — эталон, b — проверяемое."""
    a = np.asarray(a, dtype=np.float64).ravel()
    b = np.asarray(b, dtype=np.float64).ravel()
    assert a.shape == b.shape, f"{tag}: формы не совпали {a.shape} vs {b.shape}"
    num = float(np.dot(a, b))
    den = float(np.linalg.norm(a) * np.linalg.norm(b))
    cos = num / den if den > 0 else 1.0
    mad = float(np.max(np.abs(a - b)))
    rel = mad / max(float(np.max(np.abs(a))), 1e-12)
    print(f"   {tag:<22} cos={cos:.9f}  max|Δ|={mad:.3e}  rel={rel:.2e}")
    return cos, rel


def numpy_stem(x_nchw, W0, B0, W1, B1):
    """Conv(pad 1)+Relu ×2 и MaxPool 2×2 — ровно то, что делает stem модели."""
    def conv_relu(x, W, B):
        n, c, h, w = x.shape
        oc, _, kh, kw = W.shape
        xp = np.pad(x, ((0, 0), (0, 0), (1, 1), (1, 1)))
        y = np.zeros((n, oc, h, w), dtype=np.float64)
        for i in range(kh):
            for j in range(kw):
                y += np.einsum("ncij,oc->noij", xp[:, :, i : i + h, j : j + w].astype(np.float64), W[:, :, i, j].astype(np.float64))
        return np.maximum(y + B.astype(np.float64)[None, :, None, None], 0.0)

    y = conv_relu(x_nchw, W0, B0)
    y = conv_relu(y, W1, B1)
    n, c, h, w = y.shape
    return y[:, :, : (h // 2) * 2, : (w // 2) * 2].reshape(n, c, h // 2, 2, w // 2, 2).max(axis=(3, 5))


def numpy_bilstm(x, W, R, B, pw, pb):
    """x [N,T,D] → [N,T,out]; гейты ONNX (i,o,f,c), реверс по позиции tt."""
    n, t, d = x.shape
    nd, four_h, _ = W.shape
    h = R.shape[2]
    outs = []
    for dir_id in range(nd):
        Wi, Ri, Bi = W[dir_id], R[dir_id], B[dir_id]
        bi, br = Bi[: 4 * h], Bi[4 * h :]
        hs = np.zeros((t, n, h), dtype=np.float64)
        hprev = np.zeros((n, h), dtype=np.float64)
        cprev = np.zeros((n, h), dtype=np.float64)
        for step in range(t):
            tt = (t - 1 - step) if dir_id == 1 else step
            g = x[:, tt, :].astype(np.float64) @ Wi.T.astype(np.float64) + bi.astype(np.float64)
            g = g + hprev @ Ri.T.astype(np.float64) + br.astype(np.float64)
            i = 1.0 / (1.0 + np.exp(-g[:, 0:h]))
            o = 1.0 / (1.0 + np.exp(-g[:, h : 2 * h]))
            f = 1.0 / (1.0 + np.exp(-g[:, 2 * h : 3 * h]))
            cc = np.tanh(g[:, 3 * h : 4 * h])
            cprev = f * cprev + i * cc
            hprev = o * np.tanh(cprev)
            # слот step хранит позицию tt — как Y[step, dir] в ONNX
            hs[step] = hprev
        if dir_id == 1:
            # hs[step] — hidden после обработки x[T-1-step]; позиции tt
            # соответствует step = T-1-tt, то есть массив нужно перевернуть
            hs = hs[::-1]
        outs.append(hs)
    cat = np.concatenate([np.transpose(outs[0], (1, 0, 2)), np.transpose(outs[1], (1, 0, 2))], axis=2)
    flat = cat.reshape(n * t, 2 * h)
    return (flat @ pw.T.astype(np.float64) + pb.astype(np.float64)).reshape(n, t, pw.shape[0])


def numpy_decoder(enc, W, n_steps, sos):
    """Независимая развёртка attention-декодера (attn.rs::greedy_decode_full)."""
    n, t, c = enc.shape
    hs = W["h2h_W"].shape[0]
    v = W["gen_W"].shape[0]
    sig = lambda z: 1.0 / (1.0 + np.exp(-z))
    proj_h = (enc.reshape(-1, c).astype(np.float64) @ W["i2h_W"].T).reshape(n, t, hs)
    h = np.zeros((n, hs))
    cc = np.zeros((n, hs))
    prev = np.full((n,), sos, dtype=np.int64)
    outs = []
    for _ in range(n_steps):
        hh = h @ W["h2h_W"].T + W["h2h_B"]
        e = np.tanh(proj_h + hh[:, None, :]) @ W["score_W"]
        e = e - e.max(axis=1, keepdims=True)
        ex = np.exp(e)
        a = (ex / ex.sum(axis=1, keepdims=True)).transpose(0, 2, 1)
        ctxv = (a @ enc.astype(np.float64)).reshape(n, c)
        oh = np.zeros((n, v))
        oh[np.arange(n), prev] = 1.0
        ci = np.concatenate([ctxv, oh], axis=1)
        pre = ci @ W["w_ih"].T + W["b_sum"] + h @ W["w_hh"].T
        gi, gf, gg, go = np.split(pre, 4, axis=1)
        cc = sig(gf) * cc + sig(gi) * np.tanh(gg)
        h = sig(go) * np.tanh(cc)
        outs.append(h @ W["gen_W"].T + W["gen_B"])
        prev = outs[-1].argmax(axis=-1)
    return np.stack(outs, axis=1)


def decoder_section(model, got, ref_dir, meta, n, classes):
    if "pred" not in got or "logits" not in got or meta.get("dec_steps", "0") == "0":
        return
    steps = int(meta["dec_steps"])
    sos, eos = int(meta["sos"]), int(meta["eos"])
    print(f"E. numpy-развёртка attention-декодера ({steps} шагов, вход — enc из onnxruntime):")
    want = {"i2h_W": "/dec_i2h_W", "h2h_W": "/dec_h2h_W", "h2h_B": "/dec_h2h_B",
            "score_W": "/dec_score_W", "w_ih": "/dec_w_ih", "b_sum": "/dec_b_ih_plus_b_hh",
            "w_hh": "/dec_w_hh", "gen_W": "/dec_gen_W", "gen_B": "/dec_gen_B"}
    inits = {t.name: onnx.numpy_helper.to_array(t).astype(np.float64) for t in model.graph.initializer}
    W = {}
    for k, suf in want.items():
        hits = [v for nm, v in inits.items() if nm.endswith(suf)]
        if len(hits) != 1:
            raise SystemExit(f"декодер: инициализатор *{suf} найден {len(hits)} раз")
        W[k] = hits[0]
    ref = numpy_decoder(got["enc"], W, steps, sos)
    cos, rel = report("logits (декодер)", ref, got["logits"].astype(np.float64))
    print("   ✅ декодер совпадает" if cos > 0.999999 and rel < 1e-4
          else "   ⚠️  декодер НЕ совпал с независимым пересчётом")

    # текст: Rust (--infer-конвенция, без раннего стопа) против pred из графа
    toks = None
    if len(sys.argv) > 3:
        toks = read_charset(sys.argv[3])
    p = os.path.join(ref_dir, "ref_text.txt")
    if os.path.exists(p) and toks:
        rust_txt = [l.rstrip("\n") for l in open(p, encoding="utf-8")]
        onnx_txt = ["".join(toks[k] for k in row if k != eos and k < len(toks))
                    for row in got["pred"].astype(np.int64)]
        same = sum(1 for a, b in zip(rust_txt, onnx_txt) if a == b)
        print(f"F. Текст: Rust ↔ ONNX совпал у {same}/{len(rust_txt)} картинок")
        for i, (a, b) in enumerate(zip(rust_txt, onnx_txt)):
            raw = " ".join(str(int(k)) for k in got["pred"][i])
            print(f"     [{i}] {'=' if a == b else '≠'} rust={a!r} onnx={b!r} | pred id: {raw}")
    if os.path.exists(os.path.join(ref_dir, "ref_dec_logits.raw")):
        print("G. Rust (int8 QAT) ↔ onnxruntime на выходе декодера:")
        # Rust пишет логиты декодера step-major: greedy_decode_full дописывает
        # по блоку [B, V] на каждый шаг, поэтому файл — это [steps, B, V], а
        # onnxruntime отдаёт [B, steps, V]. Раньше здесь стоял
        # reshape(n, steps, classes) — отсюда косинус 0.22 при полностью
        # совпавших текстах (секции E/F не затронуты, они этот файл не читают).
        raw = rd(ref_dir, "ref_dec_logits.raw")
        st = raw.size // (n * classes)
        rl = raw.reshape(st, n, classes).transpose(1, 0, 2)
        report("dec logits", rl, got["logits"])
        am = int(np.sum(rl.argmax(-1) == got["logits"].argmax(-1)))
        print(f"   argmax совпал в {am}/{rl.size // classes} позициях")

def main():
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    ref_dir, model_path = sys.argv[1], sys.argv[2]
    meta = read_meta(ref_dir)
    n, t = int(meta["n"]), int(meta["t"])
    img_h, img_w = int(meta["img_h"]), int(meta["img_w"])
    hidden, classes = int(meta["hidden"]), int(meta["classes"])
    layout = meta.get("layout", "nhwc")
    print(f"== meta: n={n} t={t} img={img_h}x{img_w} hidden={hidden} classes={classes} layout={layout} ckpt={meta.get('ckpt')}")

    model = onnx.load(model_path)
    onnx.checker.check_model(model)
    print(f"A. onnx.checker: OK | узлов {len(model.graph.node)} | инициализаторов {len(model.graph.initializer)}"
          f" | opset {model.opset_import[0].version} | ir {model.ir_version}")
    names_in = [i.name for i in model.graph.input]
    names_out = [o.name for o in model.graph.output]
    print(f"   входы {names_in} | выходы {names_out}")

    x_hwc = rd(ref_dir, "input.raw").reshape(n, img_h, img_w, 3)
    feed = x_hwc if layout == "nhwc" else np.ascontiguousarray(x_hwc.transpose(0, 3, 1, 2))
    so = ort.SessionOptions()
    so.log_severity_level = 3
    sess = ort.InferenceSession(model_path, sess_options=so, providers=["CPUExecutionProvider"])
    got = sess.run(None, {names_in[0]: feed.astype(np.float32)})
    got = dict(zip(names_out, got))
    for k, v in got.items():
        print(f"   ort {k:<8} {str(v.shape):<20} {v.dtype}")

    print("B. Rust (int8 QAT) ↔ onnxruntime (fp32) — точного совпадения и не ждём:")
    sp = os.path.join(ref_dir, "ref_stem.raw")
    if os.path.exists(sp) and "stem" in got and meta.get("stem", "none") != "none":
        sh = [int(v) for v in meta["stem"].split("x")]
        rs = rd(ref_dir, "ref_stem.raw").reshape(*sh).astype(np.float64)
        os_ = got["stem"].astype(np.float64)
        report("stem (2 слоя)", rs, os_)
        q = lambda a: " ".join(f"{v:8.3f}" for v in np.percentile(np.abs(a), [50, 90, 99, 100]))
        print(f"      |rust| p50/p90/p99/max: {q(rs)}")
        print(f"      |ort | p50/p90/p99/max: {q(os_)}")
        d = np.abs(rs - os_)
        print(f"      |Δ|    p50/p90/p99/max: {q(d)}  (доля элементов с |Δ|>0.1: {100.0*float((d>0.1).mean()):.3f}%)")
    ref_feat = rd(ref_dir, "ref_feat.raw").reshape(n, t, 512)
    ref_enc = rd(ref_dir, "ref_enc.raw").reshape(n, t, hidden)
    ref_logits = rd(ref_dir, "ref_logits.raw").reshape(n, t, classes)
    ctc_out = "ctc_logits" if "ctc_logits" in got else "logits"
    report("feat", ref_feat, got["feat"])
    if "enc" in got:
        report("enc", ref_enc, got["enc"])
    report(f"{ctc_out} (CTC)", ref_logits, got[ctc_out])
    am = int(np.sum(np.argmax(ref_logits, axis=-1) == np.argmax(got[ctc_out], axis=-1)))
    print(f"   argmax(logits) совпал в {am}/{ref_logits.shape[0]*ref_logits.shape[1]} позициях")

    # CTC-greedy текст: то, что реально получает потребитель графа. blank = 0
    # (<PAD>) — как в ctc_loss_backward(..., blank=0).
    toks = None
    if len(sys.argv) > 3:
        toks = read_charset(sys.argv[3])

    def ctc_greedy(lg):
        out = []
        for bi in range(lg.shape[0]):
            seq, prev = [], -1
            for tt in range(lg.shape[1]):
                k = int(np.argmax(lg[bi, tt]))
                if k != 0 and k != prev:
                    seq.append(k)
                prev = k
            out.append("".join(toks[k] if toks and k < len(toks) else f"#{k}" for k in seq))
        return out

    a, b = ctc_greedy(ref_logits), ctc_greedy(got[ctc_out])
    same = sum(1 for x, y in zip(a, b) if x == y)
    print(f"   CTC-greedy текст совпал у {same}/{len(a)} картинок")
    for i, (x, y) in enumerate(zip(a, b)):
        mark = "=" if x == y else "≠"
        print(f"     [{i}] {mark} rust={x!r} onnx={y!r}")

    _index(model)
    convs = [nd for nd in model.graph.node if nd.op_type == "Conv"]
    if "stem" in got and convs:
        print("C. numpy stem (независимый пересчёт Conv+BN→Relu ×2, MaxPool 2×2):")
        w0 = resolve_weight(model, convs[0].input[1])
        b0 = resolve_weight(model, convs[0].input[2])
        w1 = resolve_weight(model, convs[1].input[1])
        b1 = resolve_weight(model, convs[1].input[2])
        x_nchw = x_hwc.transpose(0, 3, 1, 2) if layout == "nhwc" else x_hwc
        st = numpy_stem(x_nchw, w0, b0, w1, b1)
        cos, rel = report("stem", st, got["stem"].astype(np.float64))
        if cos < 0.999999 or rel > 1e-4:
            print("   ⚠️  stem не совпал: раскладка входа / pads / свёртка BN отличаются от ожидаемых")
        else:
            print("   ✅ stem совпадает: раскладка, pads, strides и свёртка BN в Conv верны")

    lstms = [nd for nd in model.graph.node if nd.op_type == "LSTM"]
    if "enc" in got and len(lstms) == 2:
        print("D. numpy BiLSTM+проекция и CTC-голова (вход — feat из onnxruntime):")
        cur = got["feat"].astype(np.float64)
        for li, nd in enumerate(lstms):
            W = resolve_weight(model, nd.input[1])
            R = resolve_weight(model, nd.input[2])
            B = resolve_weight(model, nd.input[3])
            # проекция — Gemm сразу за Reshape выхода LSTM
            # имя инициализатора веса: Graph.uid() санитизирует «lstm0.proj_W» в «/lstm0_proj_W»
            gemms = [g for g in model.graph.node
                     if g.op_type == "Gemm" and len(g.input) > 1 and f"lstm{li}_proj_W" in g.input[1]]
            if not gemms:
                raise SystemExit(f"не нашёл Gemm проекции слоя {li}")
            gm = gemms[0]
            pw = resolve_weight(model, gm.input[1])
            pb = resolve_weight(model, gm.input[2])
            cur = numpy_bilstm(cur.astype(np.float32), W, R, B, pw, pb)
        cos, rel = report("enc", cur, got["enc"].astype(np.float64))
        if cos < 0.999999 or rel > 1e-4:
            print("   ⚠️  BiLSTM не совпал: порядок гейтов или разворот реверса неверны")
        else:
            print("   ✅ BiLSTM совпадает: порядок гейтов i,o,f,c и разворот реверсного направления верны")
        ctc = [g for g in model.graph.node
               if g.op_type == "Gemm" and len(g.input) > 1 and g.input[1].endswith("/ctc_W")]
        if ctc:
            cw = resolve_weight(model, ctc[0].input[1])
            cb = resolve_weight(model, ctc[0].input[2])
            lg = (got["enc"].astype(np.float64).reshape(-1, hidden) @ cw.T.astype(np.float64)
                  + cb.astype(np.float64)).reshape(n, t, classes)
            report("ctc head (из enc ort)", lg, got[ctc_out].astype(np.float64))
    decoder_section(model, got, ref_dir, meta, n, classes)
    print("== готово")


_DQ = {}


def _index(model):
    """Карта «имя выхода узла → узел» и «имя инициализатора → массив»."""
    if _DQ:
        return _DQ
    inits = {t.name: onnx.numpy_helper.to_array(t) for t in model.graph.initializer}
    producer = {}
    for nd in model.graph.node:
        for o in nd.output:
            if o:
                producer[o] = nd
    _DQ["inits"] = inits
    _DQ["producer"] = producer
    return _DQ


def resolve_weight(model, name):
    """Вес узла в fp32: либо инициализатор, либо DequantizeLinear(int8, scale, zp).

    В QDQ-графе вес лежит int8-тензором со скалярной шкалой; onnxruntime
    считает свёртку по этим же числам, поэтому для независимой сверки их
    нужно сначала деквантовать.
    """
    idx = _index(model)
    if name in idx["inits"]:
        return idx["inits"][name].astype(np.float64)
    nd = idx["producer"].get(name)
    if nd is not None and nd.op_type == "DequantizeLinear":
        q = idx["inits"][nd.input[0]].astype(np.float64)
        sc = idx["inits"][nd.input[1]].astype(np.float64)
        zp = idx["inits"][nd.input[2]].astype(np.float64) if len(nd.input) > 2 else 0.0
        return (q - zp) * sc
    raise SystemExit(f"{name!r}: не инициализатор и не DequantizeLinear")




if __name__ == "__main__":
    main()
