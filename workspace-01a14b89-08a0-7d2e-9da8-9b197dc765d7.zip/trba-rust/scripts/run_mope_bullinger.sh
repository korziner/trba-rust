#!/usr/bin/env bash
# Связка двух предобученных экспертов Bullinger (200 и 400 строк) в MoPE — CUDA, sm_75.
# Долгих обучений нет: распаковка ~5 с, сборка 1–3 мин (один раз), связка ~1 мин на GPU,
# инференс 20 строк ~1 мин. В песочнице эти же шаги на 2 ядрах CPU заняли 56 с и 85 с.
#
# Предварительно, один раз, в вашем чекауте ~/Downloads/195a.ZIP/trba-rust:
#   patch -p1 < trba-cuda-fixes.patch          # 24 файла, все правки раундов 1–13
#   cp -r <из песочницы>/experts .             # bull_a.mope.zst, bull_b.mope.zst, franken.bin.zst
#   cp -r <из песочницы>/data/bull40 data/     # 700 PNG 32x160 + CSV 200/400/50/50 + charsets
set -euo pipefail
cd "$(dirname "$0")/.."
D=data/bull40; E=experts; B=target/release/trba-rust

# 0. Распаковка. Эксперты (fd=128, по 2.93 МБ) сжаты zstd -22 → 1.001x: int8 несжимаем,
#    энтропия 7.99 бит/байт. franken.bin (MOPEFR02, 2.87 МБ) → 1.133x.
zstd -d -k -f "$E/bull_a.mope.zst" "$E/bull_b.mope.zst" "$E/franken.bin.zst"
mv -f "$E/franken.bin.zst.dst" "$E/franken_from_archive.bin" 2>/dev/null || true

# 1. Сборка строго под sm_75 (TRBA_REQUIRE_CUDA=1 не даст молча уйти на CPU).
#    Хотите AVX1-сборку CPU-бэкенда: добавьте TRBA_AVX=1 и
#    RUSTFLAGS="-C target-feature=+avx" (замер: .text +0.61%, батч 22.6 -> 20.2 с).
TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release

# 2. СВЯЗКА. Обучаются только роутер, PID-баланс, агрегатор (CCA + Res-scale) и адаптеры;
#    оба эксперта заморожены (85 811 592 параметра). Словари разные (64 и 68 токенов) —
#    это рабочий случай: каждый эксперт остаётся в своей нумерации, общий словарь (70)
#    используется для отчётов, непокрытые символы оплачиваются moe::penalized_ce.
rm -rf exp_mope
$B $D/mope_train.csv $D/mope_val.csv exp_mope \
  --charset $D/charset_all.txt --img-h 32 --img-w 160 --max-len 40 --hidden 64 --feat-dim 128 \
  --mope --mope-train \
  --mope-experts $E/bull_a.mope,$E/bull_b.mope \
  --mope-char-counts $D/a_train.csv,$D/b_train.csv \
  --mope-min-freq 1 --mope-charset-max 256 \
  --epochs 2 --mope-limit 20 --mope-target soft \
  --mope-n 4 --mope-c 2 --mope-tau 8 --mope-cache 2 \
  --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
  --mope-save-franken $E/franken.bin --seed 7

# Ожидаемый вывод (проверено в песочнице):
#   ⇄ эксперт 1 отличается от 0: словарь 68 против 64 токенов
#   🔤 общий словарь: 70 токенов; выброшено по экспертам: [0, 0]
#   🧠 MoPE: 2 экспертов -> int8 за 0.0 с (42 МБ/шт, 42 905 024 параметров)
#      резидентно в VRAM 2 шт = 0.09 ГБ из 10.00 ГБ | подмена одного ~27 мс по PCIe
#   Эпоха 1/2 | роутер 0.6621 | агрегатор 3.4447 | оракул 3.3863 | попадание 90.0%
#   Эпоха 2/2 | роутер 0.6096 | агрегатор 3.3631 | оракул 3.3629 | попадание 100.0%
#   💾 Franken-MoPE: experts/franken.bin (2.87 МБ)
# Числа у вас будут чуть другими: инициализация весов НЕ сидируется от --seed
# (rand::thread_rng в qnet.rs:108,481) — см. BUGFIX_REPORT §20.9.

# 3. ИНФЕРЕНС готовой связкой: роутер заморожен, ничего не обучается.
#    MOPEFR02 хранит геометрию раундов, поэтому --mope-n/-c/-t/-tau можно не задавать.
rm -rf exp_inf
$B $D/mope_val.csv "" exp_inf \
  --charset $D/charset_all.txt --img-h 32 --img-w 160 --max-len 40 --hidden 64 --feat-dim 128 \
  --mope --mope-experts $E/bull_a.mope,$E/bull_b.mope \
  --mope-franken $E/franken.bin --mope-t 2 --seed 7 --mope-temperature 0 --mope-limit 20
# Ожидаемо: маршрутизация [1] из 2, s(top-1) 0.75...0.80, загрузка [0.0, 20.0],
#   bias (уравнение 5) [+0.0393, -0.0393], побед Best-of-N [0, 20].
#   Эксперт B (400 строк) выигрывает почти везде — PID-член как раз толкает загрузку обратно.

# 4. ЕСЛИ захотите полную тренировку роутера на своих данных: при E=2, N=4, C=2 один шаг
#    декодера — это 9 проходов, поэтому на 214 049 строках эпоха идёт десятки часов.
#    Ставьте --mope-limit 20000 или --mope-n 2 --mope-c 1.
