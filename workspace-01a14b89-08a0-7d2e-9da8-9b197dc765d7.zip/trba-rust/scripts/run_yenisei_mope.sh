#!/usr/bin/env bash
# YeniseiGovReports-HWR (русские слова: 124 768 train / 22 401 val) → свой эксперт →
# MoPE вместе с буллинговскими экспертами. Ни один шаг не рассчитан на >300 с:
# сначала замер на 500 строках, масштабирование — по измеренной скорости.
#
# Переменные: R=каталог датасета, N=строк для эксперта, BS=batch size.
set -euo pipefail
cd "$(dirname "$0")/.."
R=${R:-YeniseiGovReports-HWR}; B=target/release/trba-rust; N=${N:-20000}; BS=${BS:-16}
P=$R/train; V=$R/val
# Геометрия ОБЯЗАНА совпадать у всех связываемых экспертов: входные картинки
# кодируются одной геометрией из командной строки, а --max-len должен быть
# ≤ max_len каждого эксперта (иначе позиционные эмбеддинги вылезут за границу).
G="--img-h 32 --img-w 160 --max-len 40 --hidden 64 --feat-dim 128"

# 0. Сборка строго под sm_75
TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release

# 1. Импорт (секунды): CSV `img/<file>,<text>` без заголовка + charset
#    (<PAD>,<SOS>,<EOS> + символы по train). Фильтр пустых/коротких/длинных строк
#    делается здесь, потому что trba-rust длинный текст молча ОБРЕЗАЕТ.
python3 tools/yenisei_import.py --root "$R" --max-len 40 --min-chars 2

# 2. ЗАМЕР скорости (500 строк, 1 эпоха): чтобы не запускать вслепую большое обучение.
head -501 $P/trba_train.csv > $P/probe500.csv
head -101 $V/trba_val.csv   > $V/probe100.csv
$B $P/probe500.csv $V/probe100.csv exp_probe --charset $R/charset_trba.txt $G \
   --batch-size $BS --epochs 1 --no-resume --seed 7
echo "→ по строке «Эпоха 1/1 | N с» посчитайте с/строку и выберите N для шага 3"

# 3. Эксперт C на русских словах. --resume дописывает эпохи несколькими запусками
#    (моменты Adam лежат в чекпоинте), поэтому длинное обучение можно резать на части.
head -$((N+1)) $P/trba_train.csv > $P/trba_train_$N.csv
$B $P/trba_train_$N.csv $V/trba_val.csv exp_yen --charset $R/charset_trba.txt $G \
   --batch-size $BS --epochs 2 --no-resume --seed 7
#   продолжить: та же команда БЕЗ --no-resume и с --epochs 4

# 4. Экспорт в int8-контейнер MOPEBI01 (секунды, 4× меньше fp32)
$B $P/trba_train_$N.csv "" exp_yen --charset $R/charset_trba.txt $G \
   --mope-export-bundle experts/yen_c.mope --mope-int8

# 5. Связка двух РАЗНЫХ датасетов: Bullinger-строки (эксперт B, 68 токенов)
#    + енисейские слова (эксперт C). Словари разные — это рабочий случай.
head -2001 $P/trba_train.csv > $P/mope_train_2k.csv
head -201  $V/trba_val.csv   > $V/mope_val_200.csv
$B $P/mope_train_2k.csv $V/mope_val_200.csv exp_mope_yen \
   --charset $R/charset_trba.txt $G \
   --mope --mope-train \
   --mope-experts experts/bull_b.mope,experts/yen_c.mope \
   --mope-char-counts data/bull40/b_train.csv,$P/trba_train_$N.csv \
   --mope-min-freq 1 --mope-charset-max 256 \
   --epochs 2 --mope-limit 200 --mope-target soft \
   --mope-n 4 --mope-c 2 --mope-tau 8 --mope-cache 2 \
   --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
   --mope-save-franken experts/franken_yen.bin --seed 7
#   Учтите: --charset здесь должен покрывать ТЕКСТЫ ОБУЧАЮЩИХ СТРОК роутера.
#   Хотите учить роутер сразу на строках обоих датасетов — соберите объединённый
#   словарь: cat data/bull40/charset_all.txt $R/charset_trba.txt | сортировка с
#   сохранением <PAD>,<SOS>,<EOS> первыми тремя строками.

# 6. ПРОДОЛЖЕНИЕ тренировки MoPE с выученного состояния: --mope-franken подставляет
#    роутер, PID-баланс, агрегатор (CCA + Res-scale), адаптеры И состояния Adam.
#    Признак тёплого старта в логе: «шагов обучения 40» и loss роутера около 0.61,
#    а не 0.66. Счётчик ЭПОХ при этом начинается заново (контейнер хранит шаги).
$B $P/mope_train_2k.csv $V/mope_val_200.csv exp_mope_yen \
   --charset $R/charset_trba.txt $G \
   --mope --mope-train --mope-franken experts/franken_yen.bin \
   --mope-experts experts/bull_b.mope,experts/yen_c.mope \
   --mope-char-counts data/bull40/b_train.csv,$P/trba_train_$N.csv \
   --mope-min-freq 1 --mope-charset-max 256 \
   --epochs 2 --mope-limit 200 --mope-target soft \
   --mope-n 4 --mope-c 2 --mope-tau 8 --mope-cache 2 \
   --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
   --mope-save-franken experts/franken_yen.bin --seed 7

# 7. Инференс: ПОЛНЫЙ набор RSA-флагов. Без --mope-tau 8 получите
#    «⚠️ агрегатор обучен на промпте C=2·τ=8, а запрошено C=4·τ=4» и агрегатор
#    будет резать хвосты кандидатов не так, как его учили.
$B $V/mope_val_200.csv "" exp_inf_yen \
   --charset $R/charset_trba.txt $G \
   --mope --mope-experts experts/bull_b.mope,experts/yen_c.mope \
   --mope-franken experts/franken_yen.bin \
   --mope-n 4 --mope-c 2 --mope-t 2 --mope-tau 8 --mope-temperature 0 --mope-limit 50
