#!/usr/bin/env bash
# Корзины по длине: МНОГО экспертов (по одному на диапазон длин) под одним роутером.
#   SCHEME=auto MIN_ROWS=1000 LO=4 HI=40 EPOCHS=10 FD=128 bash scripts/run_len_buckets.sh
# SCHEME=auto   смежные диапазоны, в каждом ≥ MIN_ROWS строк (рекомендуется)
#        exact  по одной длине: 4,5,6,…,HI — до 37 экспертов, длинные корзины жидкие
#        cum    корзина L видит все строки ≤ L (последняя обучается дольше всех)
set -euo pipefail
cd "$(dirname "$0")/.."
B=target/release/trba-rust
R=${R:-YeniseiGovReports-HWR}
LO=${LO:-4}; HI=${HI:-40}; SCHEME=${SCHEME:-auto}; MIN_ROWS=${MIN_ROWS:-1000}
EPOCHS=${EPOCHS:-10}; BS=${BS:-16}; FD=${FD:-128}; IH=${IH:-32}; H=${H:-64}
SEED=${SEED:-7}; CACHE=${CACHE:-4}; LIMIT=${LIMIT:-200}
[ -x "$B" ] || { echo "нет $B — TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release"; exit 1; }

# 0. Полный корпус и ОДИН словарь на все корзины. Словарь общий, потому что роутер
#    и агрегатор работают в объединённой нумерации; частоты для --mope-min-freq
#    считаются по ПОЛНОМУ корпусу, иначе редкие символы обнуляются (§20.15).
python3 tools/yenisei_import.py --root "$R" --max-len "$HI" --min-chars 2
cp $R/train/trba_train.csv $R/train/full_train.csv
cp $R/val/trba_val.csv     $R/val/full_val.csv
$B --build-charset $R/train/full_train.csv,$R/val/full_val.csv --charset $R/charset_full.txt </dev/null

# 1. Разбивка: bucket_<tag>.csv, bucket_<tag>_val.csv и buckets_plan.tsv
python3 tools/len_buckets.py --in $R/train/full_train.csv --val $R/val/full_val.csv \
    --lo $LO --hi $HI --min-rows $MIN_ROWS --scheme $SCHEME
PLAN=$R/train/buckets_plan.tsv
NB=$(wc -l < "$PLAN")
MAXL=$(awk '{if($6>m)m=$6}END{print m}' "$PLAN")
echo; echo "▶ корзин $NB | потолок прогона max_len=$MAXL | fd=$FD эпох $EPOCHS batch $BS"

# 2. Эксперты: каждый обучается ТОЛЬКО на своей корзине и контролируется на строках
#    своей длины — иначе CER корзины меряется на чужих длинах и уходит за 100%.
EXPERTS=""
while read -r tag blo bhi rows iw ml; do
  echo; echo "════ корзина bucket_$tag: длины $blo…$bhi, строк $rows, img ${IH}×${iw}, max_len $ml ════"
  G="--charset $R/charset_full.txt --img-h $IH --img-w $iw --max-len $ml --hidden $H --feat-dim $FD"
  V=$R/train/bucket_${tag}_val.csv
  [ -s "$V" ] || V=$R/val/full_val.csv
  rm -rf exp_len_$tag
  $B $R/train/bucket_$tag.csv "$V" exp_len_$tag $G \
     --batch-size $BS --epochs $EPOCHS --no-resume --seed $SEED </dev/null
  $B $R/train/bucket_$tag.csv "" exp_len_$tag $G \
     --mope-export-bundle experts/yen_$tag.mope --mope-int8 </dev/null
  EXPERTS=${EXPERTS:+$EXPERTS,}experts/yen_$tag.mope
done < "$PLAN"
echo; echo "▶ эксперты: $EXPERTS"

# 3. Один роутер на все корзины. Порядок ВАЖЕН: роутеру подаётся признак ПЕРВОГО
#    эксперта (в коде out.feat0 при ei == 0), поэтому первым лучше ставить корзину
#    средней длины, а не самую короткую. tau ≤ beta/2, где beta = MAXL.
head -2001 $R/train/full_train.csv > $R/train/mope_train_2k.csv
head -201  $R/val/full_val.csv     > $R/val/mope_val_200.csv
$B $R/train/mope_train_2k.csv $R/val/mope_val_200.csv exp_buckets \
   --charset $R/charset_full.txt --img-h $IH --img-w 256 --max-len $MAXL --hidden $H --feat-dim $FD \
   --mope --mope-train --mope-experts "$EXPERTS" --mope-char-counts $R/train/full_train.csv \
   --mope-min-freq 1 --mope-charset-max 512 \
   --epochs 2 --mope-limit $LIMIT --mope-target soft \
   --mope-n 4 --mope-c 2 --mope-tau 4 --mope-cache $CACHE \
   --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
   --mope-save-franken experts/franken_buckets.bin --seed $SEED </dev/null

# 4. Инференс — ТЕ ЖЕ флаги словаря, иначе общий словарь пересчитается иначе и
#    состояние роутера не подставится (§20.15, пункт 3 разбора в README §9.5).
$B $R/val/mope_val_200.csv "" exp_inf_buckets \
   --charset $R/charset_full.txt --img-h $IH --img-w 256 --max-len $MAXL --hidden $H --feat-dim $FD \
   --mope --mope-experts "$EXPERTS" --mope-char-counts $R/train/full_train.csv \
   --mope-min-freq 1 --mope-charset-max 512 \
   --mope-franken experts/franken_buckets.bin --mope-temperature 0 --mope-limit 50 </dev/null
echo; echo "→ ищите в логе: «📏 длина прогона по экспертам: [...]» и «загрузка экспертов»"
