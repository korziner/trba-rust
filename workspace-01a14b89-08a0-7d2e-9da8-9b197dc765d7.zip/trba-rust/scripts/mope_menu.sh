#!/usr/bin/env bash
# Интерактивный помощник: на каждый вопрос 4 варианта из разумного диапазона.
# Неинтерактивно задаётся переменными WHAT/GEO/FD/ROWS/MODE (тогда read не зовётся).
#   WHAT: 1 импорт · 2 замер · 3 обучение эксперта · 4 связка MoPE + инференс
set -euo pipefail
cd "$(dirname "$0")/.."
B=target/release/trba-rust
R=${R:-YeniseiGovReports-HWR}
P=$R/train; V=$R/val
CHOICE=1
ask() {
  local q="$1"; shift
  echo; echo "── $q"
  local i=1; for v in "$@"; do printf '   %d) %s\n' "$i" "$v"; i=$((i+1)); done
  if [ -t 0 ]; then read -r -p "   выбор [1-$#, Enter = 1]: " CHOICE || CHOICE=1; fi
  CHOICE=${CHOICE:-1}
  case "$CHOICE" in ''|*[!0-9]*) CHOICE=1;; esac
  if [ "$CHOICE" -lt 1 ] || [ "$CHOICE" -gt "$#" ]; then
    echo "   ⚠️  вне диапазона — беру 1"; CHOICE=1
  fi
}

[ -x "$B" ] || { echo "нет $B — сначала: TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release"; exit 1; }

if [ -z "${WHAT:-}" ]; then
  ask "Что делаем?" \
    "импорт датасета $R в формат trba-rust (секунды)" \
    "замер скорости на 500 строках (~1 мин, чтобы не запускать вслепую)" \
    "обучить эксперта / продолжить обучение" \
    "связать двух экспертов в MoPE и прогнать инференс" \
    "корзины по длине: много экспертов (длины 4…40) и один франкен"
  WHAT=$CHOICE
fi

IH=32; IW=160; ML=20; FDV=128; H=64
if [ "$WHAT" != 1 ] && [ "$WHAT" != 5 ]; then
  if [ -z "${GEO:-}" ]; then
    ask "Геометрия? Обязана совпадать у всех связываемых экспертов." \
      "32×160, max_len 40 — строки рукописи (Bullinger)" \
      "32×160, max_len 20 — слова до ~18 символов (Енисей: p50 5, max 32)" \
      "32×160, max_len 24 — компромисс: длинный хвост не теряется" \
      "32×128, max_len 16 — самые короткие слова, быстрее всего"
    GEO=$CHOICE
  fi
  case "$GEO" in
    1) ML=40;; 2) ML=20;; 3) ML=24;; *) IW=128; ML=16;;
  esac
  if [ -z "${FD:-}" ]; then
    ask "Ширина энкодера (--feat-dim)?" \
      "128 — 2.63M conv-весов, эксперт 2.93 МБ (как в поставке)" \
      "256 — 10.54M весов, ~11 МБ, медленнее примерно вдвое" \
      "512 — 42.15M весов, 43 МБ (историческая SEResNetQ)" \
      "128 при --hidden 128 — шире память декодера, те же веса энкодера"
    FD=$CHOICE
  fi
  case "$FD" in 2) FDV=256;; 3) FDV=512;; 4) FDV=128; H=128;; *) FDV=128; H=64;; esac
fi
G="--img-h $IH --img-w $IW --max-len $ML --hidden $H --feat-dim $FDV"
echo; echo "▶ геометрия: $G"

case "$WHAT" in
1) # ---------------- импорт ----------------
  python3 tools/yenisei_import.py --root "$R" --max-len "$ML" --min-chars 2
  echo "→ CSV и charset готовы; процентили длины текста выше — по ним и выбирали max_len"
  ;;
2) # ---------------- замер ----------------
  python3 tools/yenisei_import.py --root "$R" --max-len "$ML" --min-chars 2 --limit 600
  head -501 $P/trba_train.csv > $P/probe500.csv
  head -101 $V/trba_val.csv > $V/probe100.csv
  $B $P/probe500.csv $V/probe100.csv exp_probe --charset $R/charset_trba.txt $G \
     --batch-size 16 --epochs 1 --no-resume --seed 7
  echo "→ по «Эпоха 1/1 | N с» и по «длина: эталон/гипотеза» проверьте, что max_len в пору"
  ;;
3) # ---------------- обучение эксперта ----------------
  if [ -z "${ROWS:-}" ]; then
    ask "Сколько обучающих строк?" "500 (проба)" "5 000" "20 000" "весь train"
    ROWS=$CHOICE
  fi
  case "$ROWS" in 1) N=500;; 2) N=5000;; 3) N=20000;; *) N=0;; esac
  if [ -z "${MODE:-}" ]; then
    ask "Режим обучения?" \
      "с нуля, 2 эпохи, batch 16" \
      "с нуля, 5 эпох, batch 16" \
      "с нуля, 10 эпох, batch 32" \
      "продолжить (--resume) ещё 2 эпохи тем же batch"
    MODE=$CHOICE
  fi
  case "$MODE" in 1) EP=2; BS=16; RESUME=--no-resume;; 2) EP=5; BS=16; RESUME=--no-resume;;
                  3) EP=10; BS=32; RESUME=--no-resume;; *) EP=2; BS=16; RESUME=;; esac
  python3 tools/yenisei_import.py --root "$R" --max-len "$ML" --min-chars 2 ${N:+--limit $N}
  if [ "$N" -gt 0 ]; then head -$((N+1)) $P/trba_train.csv > $P/trba_sel.csv; else cp $P/trba_train.csv $P/trba_sel.csv; fi
  rm -rf exp_yen; [ -n "$RESUME" ] || rm -rf exp_yen
  $B $P/trba_sel.csv $V/trba_val.csv exp_yen --charset $R/charset_trba.txt $G \
     --batch-size $BS --epochs $EP $RESUME --seed 7
  echo; echo "→ CER выше 100% означает, что гипотеза длиннее эталона: уменьшите max_len (пункт геометрии)"
  $B $P/trba_sel.csv "" exp_yen --charset $R/charset_trba.txt $G \
     --mope-export-bundle experts/yen_c.mope --mope-int8
  ;;
5) # ---------------- корзины по длине ----------------
  if [ -z "${SCHEME:-}" ]; then
    ask "Схема корзин?" \
      "auto — смежные диапазоны, в каждом не меньше MIN_ROWS строк: корзин меньше, каждая плотная, паддинг минимален (рекомендуется)" \
      "exact — ровно по одной длине 4,5,6,…,40: до 37 экспертов, длинные корзины жидкие или пустые" \
      "cum — накопительно: корзина L видит все строки длиной ≤ L, последняя обучается дольше всех" \
      "только план (ничего не обучать): показать корзины и их размеры"
    SCHEME=$CHOICE
  fi
  case "$SCHEME" in 2) SCH=exact;; 3) SCH=cum;; 4) SCH=plan;; *) SCH=auto;; esac
  if [ -z "${MINROWS:-}" ]; then
    ask "Минимум строк в корзине?" "300 — корзин больше, эксперты слабее" "1000 — равновесие" "3000 — корзин меньше, эксперты сильнее" "5000"
    MINROWS=$CHOICE
  fi
  case "$MINROWS" in 1) MR=300;; 2) MR=1000;; 3) MR=3000;; *) MR=5000;; esac
  if [ -z "${EPOCHS:-}" ]; then
    ask "Эпох на корзину? (каждая корзина мала, поэтому эпох нужно больше, чем на полном датасете)" \
      "3 — быстро прикинуть" "6" "10 — рабочее качество" "15 — максимум"
    EPOCHS=$CHOICE
  fi
  case "$EPOCHS" in 1) EP=3;; 2) EP=6;; 3) EP=10;; *) EP=15;; esac
  LO=${LO:-4}; HI=${HI:-40}
  if [ "$SCH" = plan ]; then
    python3 tools/yenisei_import.py --root "$R" --max-len "$HI" --min-chars 2
    python3 tools/len_buckets.py --in $R/train/trba_train.csv --val $R/val/trba_val.csv \
        --lo $LO --hi $HI --min-rows $MR --scheme auto
    echo "→ ничего не обучали; plan в $R/train/buckets_plan.tsv"
  else
    SCHEME=$SCH MIN_ROWS=$MR EPOCHS=$EP LO=$LO HI=$HI FD=$FDV BS=16 \
      bash scripts/run_len_buckets.sh
  fi
  ;;
4) # ---------------- связка + инференс ----------------
  EXP=${EXP:-experts/bull_b.mope,experts/yen_c.mope}
  CNT=${CNT:-data/bull40/b_train.csv,$P/trba_train.csv}
  head -2001 $P/trba_train.csv > $P/mope_train_2k.csv 2>/dev/null || true
  head -201 $V/trba_val.csv > $V/mope_val_200.csv 2>/dev/null || true
  echo "▶ эксперты: $EXP"; echo "▶ корпус для частот: $CNT"
  $B $P/mope_train_2k.csv $V/mope_val_200.csv exp_mope_yen \
     --charset $R/charset_trba.txt $G \
     --mope --mope-train --mope-experts "$EXP" --mope-char-counts "$CNT" \
     --mope-min-freq 1 --mope-charset-max 256 \
     --epochs 2 --mope-limit 200 --mope-target soft \
     --mope-n 4 --mope-c 2 --mope-tau 8 --mope-cache 2 \
     --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
     --mope-save-franken experts/franken_yen.bin --seed 7
  # Инференс: MOPEFR02 сам подставит N/C/T/τ, а вот флаги словаря повторить нужно —
  # иначе общий словарь пересчитается иначе и состояние не подставится.
  $B $V/mope_val_200.csv "" exp_inf_yen \
     --charset $R/charset_trba.txt $G \
     --mope --mope-experts "$EXP" --mope-char-counts "$CNT" --mope-min-freq 1 --mope-charset-max 256 \
     --mope-franken experts/franken_yen.bin --mope-temperature 0 --mope-limit 50
  ;;
esac
