// ============================================================
// trba-rust — CPU fallback backend
//
// Implements exactly the same `extern "C"` surface as cuda/kernels.cu, so the
// binary builds and runs on a machine with no CUDA toolkit and no GPU.  Used
// by `cargo test` and by `cargo run --bin diagnose` to check that the fused
// backward kernels compute the same gradients as a straightforward reference
// implementation.
//
// "Device" pointers are just malloc'd host pointers, streams are no-ops and
// every call is synchronous.
//
// Build with -fopenmp when available; everything also works single-threaded.
// ============================================================

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
#include <vector>
#include <atomic>

#ifdef _OPENMP
#include <omp.h>
#endif

namespace {

inline void *xmalloc(size_t n) {
    void *p = std::malloc(n ? n : 1);
    if (!p) {
        fprintf(stderr, "\n[CPU FATAL] out of memory allocating %zu bytes\n", n);
        std::abort();
    }
    return p;
}

// ---- IEEE-754 half <-> float (no F16C dependency) ----
inline float half_to_float(uint16_t h) {
    uint32_t sign = (uint32_t)(h >> 15) & 1u;
    uint32_t exp = (uint32_t)(h >> 10) & 0x1Fu;
    uint32_t man = (uint32_t)h & 0x3FFu;
    uint32_t bits;
    if (exp == 0) {
        if (man == 0) {
            bits = sign << 31;
        } else {
            exp = 127 - 15 + 1;
            while ((man & 0x400u) == 0) { man <<= 1; --exp; }
            man &= 0x3FFu;
            bits = (sign << 31) | (exp << 23) | (man << 13);
        }
    } else if (exp == 31) {
        bits = (sign << 31) | 0x7F800000u | (man << 13);
    } else {
        bits = (sign << 31) | ((exp + 127 - 15) << 23) | (man << 13);
    }
    float f;
    std::memcpy(&f, &bits, 4);
    return f;
}

inline uint16_t float_to_half(float f) {
    uint32_t bits;
    std::memcpy(&bits, &f, 4);
    uint32_t sign = (bits >> 16) & 0x8000u;
    int32_t exp = (int32_t)((bits >> 23) & 0xFFu) - 127 + 15;
    uint32_t man = bits & 0x7FFFFFu;
    if (exp <= 0) return (uint16_t)sign;                 // flush denormals
    if (exp >= 31) return (uint16_t)(sign | 0x7C00u);    // inf
    return (uint16_t)(sign | ((uint32_t)exp << 10) | (man >> 13));
}

inline int align16(int x) { return (x + 15) & ~15; }

// The workspace pool lives next to trba_workspace_acquire below.

void *g_cnn_weights = nullptr;
void *g_bilstm_weights = nullptr;
void *g_attention_weights = nullptr;
void *g_ctc_weights = nullptr;

}  // namespace

// ============================================================
// GEMMs
// ============================================================

// C[M,N](int32) = A[M,K](int8) * Bt[N,K](int8)^T
// Operands are zero-padded to a multiple of 16 in every dimension; C is not.
extern "C" void launch_gemm_int8(const int8_t *A, const int8_t *B, int32_t *C,
                                 int M, int N, int K, void *) {
    if (M <= 0 || N <= 0 || K <= 0) return;
    const int Kp = align16(K);
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int m = 0; m < M; ++m) {
        const int8_t *a = A + (long long)m * Kp;
        int32_t *c = C + (long long)m * N;
        for (int n = 0; n < N; ++n) {
            const int8_t *b = B + (long long)n * Kp;
            int32_t acc = 0;
            for (int k = 0; k < K; ++k) acc += (int32_t)a[k] * (int32_t)b[k];
            c[n] = acc;
        }
    }
}

// C[M,N](f32) = A[M,K](f16) * Bt[N,K](f16)^T   (same padding contract)
extern "C" void launch_gemm_fp16(const void *A, const void *B, float *C, int M,
                                 int N, int K, void *) {
    if (M <= 0 || N <= 0 || K <= 0) return;
    const int Kp = align16(K);
    const uint16_t *a = static_cast<const uint16_t *>(A);
    const uint16_t *b = static_cast<const uint16_t *>(B);
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int m = 0; m < M; ++m) {
        for (int n = 0; n < N; ++n) {
            float acc = 0.f;
            for (int k = 0; k < K; ++k)
                acc += half_to_float(a[(long long)m * Kp + k]) *
                       half_to_float(b[(long long)n * Kp + k]);
            C[(long long)m * N + n] = acc;
        }
    }
}

// C[M,N] = A[M,K] * B[K,N]
extern "C" void launch_gemm_fp32(const float *A, const float *B, float *C,
                                 int M, int N, int K, void *) {
    if (M <= 0 || N <= 0 || K <= 0) return;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int m = 0; m < M; ++m) {
        const float *a = A + (long long)m * K;
        float *c = C + (long long)m * N;
        for (int n = 0; n < N; ++n) c[n] = 0.f;
        for (int k = 0; k < K; ++k) {
            const float av = a[k];
            if (av == 0.f) continue;
            const float *b = B + (long long)k * N;
            for (int n = 0; n < N; ++n) c[n] += av * b[n];
        }
    }
}

// ============================================================
// Conv epilogue
// ============================================================
extern "C" void launch_conv_epilogue(const int32_t *acc, const float *bias,
                                     int8_t *out, int acc_ld, float acc_div,
                                     float out_mul, int B, int C, int Ho, int Wo,
                                     void *) {
    long long total = (long long)B * C * Ho * Wo;
    // Must precede the pragma: `#pragma omp parallel for` has to be attached
    // directly to the loop, otherwise the file does not compile with -fopenmp
    // and build.rs quietly drops OpenMP for the whole backend.
    const long long hw = (long long)Ho * Wo;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long i = 0; i < total; ++i) {
        // out is [B, C, Ho, Wo]; acc is [B*Ho*Wo, C] row-major with leading
        // dimension acc_ld (>= C).  The old `i % C` / `i / C` mapping treated
        // the output as NHWC and read the accumulator with the wrong strides,
        // so every activation after the first conv was garbage.  Note that for
        // B > 1 the batch index has to come out of the row, not of oc.
        long long b = i / ((long long)C * hw);
        int oc = (int)((i / hw) % C);
        long long row = b * hw + (i % hw);
        float v = (float)acc[row * (long long)acc_ld + oc] / acc_div + bias[oc];
        v = std::max(v, 0.0f) * out_mul;
        v = std::min(std::max(v, -127.0f), 127.0f);
        out[i] = (int8_t)std::lrint(v);
    }
}

// ============================================================
// im2col
// ============================================================
extern "C" void launch_im2col_pad(const int8_t *input, int8_t *col, int batch,
                                  int C, int H, int W, int kH, int kW, int sH,
                                  int sW, int pH, int pW, int Ho, int Wo,
                                  int col_ld, void *) {
    const int col_cols = C * kH * kW;
    const long long rows = (long long)batch * Ho * Wo;
    if (col_ld < col_cols || (col_ld & 15) || rows <= 0) return;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long row = 0; row < rows; ++row) {
        int b = (int)(row / ((long long)Ho * Wo));
        int rem = (int)(row - (long long)b * Ho * Wo);
        int oh = rem / Wo, ow = rem - oh * Wo;
        int8_t *dst = col + row * col_ld;
        for (int c = col_cols; c < col_ld; ++c) dst[c] = 0;
        int p = 0;
        for (int ci = 0; ci < C; ++ci) {
            const int8_t *in_b = input + (long long)(b * C + ci) * H * W;
            for (int khi = 0; khi < kH; ++khi) {
                int ih = oh * sH + khi - pH;
                for (int kwi = 0; kwi < kW; ++kwi) {
                    int iw = ow * sW + kwi - pW;
                    dst[p++] = (ih >= 0 && ih < H && iw >= 0 && iw < W)
                                   ? in_b[ih * W + iw]
                                   : (int8_t)0;
                }
            }
        }
    }
    // Rows in [rows, align16(rows)) are padding the GEMM may read; zero them.
    const long long rows_p = ((rows + 15) / 16) * 16;
    if (rows_p > rows)
        std::memset(col + rows * col_ld, 0, (size_t)(rows_p - rows) * col_ld);
}

extern "C" void launch_im2col_gpu(const int8_t *input, float *col, int batch,
                                  int C, int H, int W, int kH, int kW, int sH,
                                  int sW, int pH, int pW, int Ho, int Wo,
                                  void *) {
    const int col_cols = C * kH * kW;
    const int hw_out = Ho * Wo;
    const long long rows = (long long)batch * hw_out;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long row = 0; row < rows; ++row) {
        int b = (int)(row / hw_out);
        int rem = (int)(row - (long long)b * hw_out);
        int oh = rem / Wo, ow = rem - oh * Wo;
        float *dst = col + row * col_cols;
        int p = 0;
        for (int c = 0; c < C; ++c) {
            const int8_t *in_b = input + (long long)(b * C + c) * H * W;
            for (int khi = 0; khi < kH; ++khi) {
                int ih = oh * sH + khi - pH;
                for (int kwi = 0; kwi < kW; ++kwi) {
                    int iw = ow * sW + kwi - pW;
                    dst[p++] = (ih >= 0 && ih < H && iw >= 0 && iw < W)
                                   ? (float)in_b[ih * W + iw]
                                   : 0.0f;
                }
            }
        }
    }
}

// ============================================================
// Fused conv backward
// ============================================================
extern "C" void launch_conv_backward_grad_weight(const int8_t *input,
                                                 const float *go, float *grad_W,
                                                 int B, int Cin, int H, int W,
                                                 int Cout, int kH, int kW, int sH,
                                                 int sW, int pH, int pW, int Ho,
                                                 int Wo, void *) {
    if (B <= 0 || Cout <= 0 || Cin <= 0) return;
    const int col_cols = Cin * kH * kW;
    const int hw_out = Ho * Wo;
#ifdef _OPENMP
#pragma omp parallel for schedule(static) collapse(2)
#endif
    for (int oc = 0; oc < Cout; ++oc) {
        for (int ci = 0; ci < col_cols; ++ci) {
            const int c_idx = ci / (kH * kW);
            const int kk = ci - c_idx * (kH * kW);
            const int khi = kk / kW, kwi = kk - khi * kW;
            float acc = 0.0f;
            for (int b = 0; b < B; ++b) {
                const int8_t *in_b = input + (long long)(b * Cin + c_idx) * H * W;
                const float *go_b = go + (long long)(b * Cout + oc) * hw_out;
                for (int p = 0; p < hw_out; ++p) {
                    int oh = p / Wo, ow = p - oh * Wo;
                    int ih = oh * sH + khi - pH;
                    int iw = ow * sW + kwi - pW;
                    if (ih >= 0 && ih < H && iw >= 0 && iw < W)
                        acc += go_b[p] * (float)in_b[ih * W + iw];
                }
            }
            grad_W[(long long)oc * col_cols + ci] = acc;
        }
    }
}

extern "C" void launch_conv_backward_grad_bias(const float *go, float *grad_bias,
                                               int B, int Cout, int Ho, int Wo,
                                               void *) {
    if (B <= 0 || Cout <= 0) return;
    const long long hw = (long long)Ho * Wo;
    std::memset(grad_bias, 0, (size_t)Cout * sizeof(float));
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int oc = 0; oc < Cout; ++oc) {
        float acc = 0.0f;
        for (int b = 0; b < B; ++b) {
            const float *g = go + ((long long)b * Cout + oc) * hw;
            for (long long i = 0; i < hw; ++i) acc += g[i];
        }
        grad_bias[oc] = acc;
    }
}

extern "C" void launch_conv_backward_grad_input(const float *go, const float *Wt,
                                                float *grad_input, int B, int Cin,
                                                int H, int W, int Cout, int kH,
                                                int kW, int sH, int sW, int pH,
                                                int pW, int Ho, int Wo, void *) {
    if (B <= 0 || Cin <= 0 || H <= 0 || W <= 0) return;
    const int hw_out = Ho * Wo;
    const int col_cols = Cin * kH * kW;
    const int hw_in = H * W;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int b = 0; b < B; ++b) {
        const float *go_b = go + (long long)b * Cout * hw_out;
        for (int ci = 0; ci < Cin; ++ci) {
            float *gi = grad_input + (long long)(b * Cin + ci) * hw_in;
            for (int ih = 0; ih < H; ++ih) {
                for (int iw = 0; iw < W; ++iw) {
                    float acc = 0.0f;
                    for (int khi = 0; khi < kH; ++khi) {
                        int numh = ih + pH - khi;
                        if (numh < 0 || numh % sH != 0) continue;
                        int oh = numh / sH;
                        if (oh >= Ho) continue;
                        for (int kwi = 0; kwi < kW; ++kwi) {
                            int numw = iw + pW - kwi;
                            if (numw < 0 || numw % sW != 0) continue;
                            int ow = numw / sW;
                            if (ow >= Wo) continue;
                            const float *wp = Wt + (long long)(ci * kH + khi) * kW + kwi;
                            const float *gp = go_b + oh * Wo + ow;
                            for (int oc = 0; oc < Cout; ++oc)
                                acc += gp[(long long)oc * hw_out] *
                                       wp[(long long)oc * col_cols];
                        }
                    }
                    gi[ih * W + iw] = acc;
                }
            }
        }
    }
}

extern "C" void launch_conv_backward_grad_input_i8(const float *go, const int8_t *Wq,
                                                   int w_ld, float w_scale, float *grad_input,
                                                   int B, int Cin, int H, int W, int Cout,
                                                   int kH, int kW, int sH, int sW, int pH,
                                                   int pW, int Ho, int Wo, void *) {
    if (B <= 0 || Cin <= 0 || H <= 0 || W <= 0) return;
    const int hw_out = Ho * Wo;
    const int hw_in = H * W;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int b = 0; b < B; ++b) {
        const float *go_b = go + (long long)b * Cout * hw_out;
        for (int ci = 0; ci < Cin; ++ci) {
            float *gi = grad_input + (long long)(b * Cin + ci) * hw_in;
            for (int ih = 0; ih < H; ++ih) {
                for (int iw = 0; iw < W; ++iw) {
                    float acc = 0.0f;
                    for (int khi = 0; khi < kH; ++khi) {
                        int numh = ih + pH - khi;
                        if (numh < 0 || numh % sH != 0) continue;
                        int oh = numh / sH;
                        if (oh >= Ho) continue;
                        for (int kwi = 0; kwi < kW; ++kwi) {
                            int numw = iw + pW - kwi;
                            if (numw < 0 || numw % sW != 0) continue;
                            int ow = numw / sW;
                            if (ow >= Wo) continue;
                            const int8_t *wp = Wq + (long long)(ci * kH + khi) * kW + kwi;
                            const float *gp = go_b + oh * Wo + ow;
                            for (int oc = 0; oc < Cout; ++oc)
                                acc += gp[(long long)oc * hw_out] * (float)wp[(long long)oc * w_ld];
                        }
                    }
                    gi[ih * W + iw] = acc * w_scale;
                }
            }
        }
    }
}

// ============================================================
// Maxpool 2x2 backward
// ============================================================
extern "C" void launch_maxpool2x2_backward(const float *grad_output,
                                           const long long *max_indices,
                                           float *grad_input,
                                           long long output_size,
                                           long long input_size, void *) {
    std::memset(grad_input, 0, (size_t)input_size * sizeof(float));
    for (long long i = 0; i < output_size; ++i)
        grad_input[max_indices[i]] += grad_output[i];
}

extern "C" void maxpool2x2_backward_host(const float *grad_output,
                                         const unsigned long long *max_indices,
                                         float *grad_input,
                                         unsigned long long output_size,
                                         unsigned long long input_size) {
    std::memset(grad_input, 0, (size_t)input_size * sizeof(float));
    for (unsigned long long i = 0; i < output_size; ++i)
        grad_input[(size_t)max_indices[i]] += grad_output[i];
}

// ============================================================
// Device-resident conv optimiser state (CPU mirror)
// ============================================================
extern "C" void launch_grad_accum_i32(const int32_t *acc, float *g, float scale, long long n,
                                      void *) {
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long i = 0; i < n; ++i) g[i] += (float)acc[i] * scale;
}

extern "C" void launch_sum_sq_add_f32(const float *x, double *out, long long n, void *) {
    double s = 0.0;
#ifdef _OPENMP
#pragma omp parallel for schedule(static) reduction(+ : s)
#endif
    for (long long i = 0; i < n; ++i) {
        const double v = (double)x[i];
        s += v * v;
    }
    *out += s;
}

extern "C" void launch_adam_f32(float *p, const float *g, float *m, float *v, long long n,
                                double lr, double wd, double clip, double b1, double b2,
                                double eps, double bc1, double bc2, void *) {
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long i = 0; i < n; ++i) {
        const double gi = (double)(float)((double)g[i] * clip) + wd * (double)p[i];
        const float mf = (float)(b1 * (double)m[i] + (1.0 - b1) * gi);
        const float vf = (float)(b2 * (double)v[i] + (1.0 - b2) * gi * gi);
        m[i] = mf;
        v[i] = vf;
        const double mh = (double)mf / bc1;
        const double vh = (double)vf / bc2;
        p[i] -= (float)(lr * mh / (std::sqrt(vh) + eps));
    }
}

extern "C" void launch_max_abs_f32(const float *x, float *out, long long n, void *) {
    float mx = 0.0f;
#ifdef _OPENMP
#pragma omp parallel for schedule(static) reduction(max : mx)
#endif
    for (long long i = 0; i < n; ++i) mx = std::max(mx, std::fabs(x[i]));
    *out = mx;
}

extern "C" void launch_quantize_pad_i8(const float *w, const float *max_abs, float *w_s_out,
                                       int8_t *w_q_pad, long long rows, long long col,
                                       long long kp, void *) {
    if (rows <= 0 || col <= 0) return;
    if (kp < col || (kp & 15) || w_q_pad == nullptr || max_abs == nullptr) {
        fprintf(stderr, "\n[CPU FATAL] launch_quantize_pad_i8: rows=%lld col=%lld kp=%lld\n",
                rows, col, kp);
        std::abort();
    }
    const double mx = (double)(*max_abs);
    const float s = (float)(mx > 0.0 ? mx / 127.0 : 1.0);
    if (w_s_out != nullptr) *w_s_out = s;
    const long long rp = (rows + 15) & ~15LL;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long r = 0; r < rp; ++r) {
        for (long long c = 0; c < kp; ++c) {
            float v = 0.0f;
            if (r < rows && c < col) {
                v = (float)((double)w[r * col + c] / (double)s);
                v = std::min(std::max(v, -127.0f), 127.0f);
            }
            w_q_pad[r * kp + c] = (int8_t)roundf(v);
        }
    }
}

// Device-side 2x2 maxpool, no index tensor.  Same first-strict-maximum rule as
// conv2d::maxpool2x2_with_indices, so the CPU and CUDA backends agree on which
// input element of a tie wins.
extern "C" void launch_maxpool2x2_forward_i8(const int8_t *x, int8_t *y, int B, int C,
                                             int H, int W, void *) {
    if (B <= 0 || C <= 0 || H < 2 || W < 2 || (H % 2) || (W % 2)) {
        fprintf(stderr, "\n[CPU FATAL] launch_maxpool2x2_forward_i8: bad shape B=%d C=%d H=%d W=%d\n",
                B, C, H, W);
        std::abort();
    }
    const int Ho = H / 2, Wo = W / 2;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int bc = 0; bc < B * C; ++bc) {
        const int8_t *p = x + (long long)bc * H * W;
        int8_t *q = y + (long long)bc * Ho * Wo;
        for (int oh = 0; oh < Ho; ++oh)
            for (int ow = 0; ow < Wo; ++ow) {
                const int8_t *w = p + (oh * 2) * W + ow * 2;
                int8_t best = w[0];
                if (w[1] > best) best = w[1];
                if (w[W] > best) best = w[W];
                if (w[W + 1] > best) best = w[W + 1];
                q[oh * Wo + ow] = best;
            }
    }
}

extern "C" void launch_maxpool2x2_backward_i8(const int8_t *x, const float *dy, float *dx,
                                              int B, int C, int H, int W, void *) {
    if (B <= 0 || C <= 0 || H < 2 || W < 2 || (H % 2) || (W % 2)) {
        fprintf(stderr, "\n[CPU FATAL] launch_maxpool2x2_backward_i8: bad shape B=%d C=%d H=%d W=%d\n",
                B, C, H, W);
        std::abort();
    }
    const int Ho = H / 2, Wo = W / 2;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int bc = 0; bc < B * C; ++bc) {
        const int8_t *p = x + (long long)bc * H * W;
        float *d = dx + (long long)bc * H * W;
        const float *g = dy + (long long)bc * Ho * Wo;
        for (int ih = 0; ih < H; ++ih) {
            for (int iw = 0; iw < W; ++iw) {
                const int oh = ih >> 1, ow = iw >> 1;
                const int8_t *w = p + (oh * 2) * W + ow * 2;
                long long win = 0;
                int8_t best = w[0];
                if (w[1] > best) { best = w[1]; win = 1; }
                if (w[W] > best) { best = w[W]; win = W; }
                if (w[W + 1] > best) { best = w[W + 1]; win = W + 1; }
                const long long off = (long long)ih * W + iw;
                const long long base = (long long)(oh * 2) * W + ow * 2;
                d[off] = (base + win == off) ? g[oh * Wo + ow] : 0.0f;
            }
        }
    }
}

// ============================================================
// Small utilities
// ============================================================
extern "C" void cuda_float_to_half(const float *src, void *dst, long long n, void *) {
    uint16_t *d = static_cast<uint16_t *>(dst);
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long i = 0; i < n; ++i) d[i] = float_to_half(src[i]);
}

extern "C" void cuda_scale_vector(float *data, float scale, long long n, void *) {
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long i = 0; i < n; ++i) data[i] *= scale;
}

// dst[j,i] = src[i,j]
extern "C" void cuda_transpose_f32(const float *src, float *dst, int rows,
                                   int cols, void *) {
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (int i = 0; i < rows; ++i)
        for (int j = 0; j < cols; ++j)
            dst[(long long)j * rows + i] = src[(long long)i * cols + j];
}

// ============================================================
// Runtime plumbing
// ============================================================
extern "C" void cuda_malloc(void **ptr, size_t size) {
    *ptr = size ? xmalloc(size) : nullptr;
    if (size) std::memset(*ptr, 0, size);
}

extern "C" void cuda_free(void *ptr) { std::free(ptr); }

extern "C" void cuda_memcpy_dtod(void *dst, const void *src, size_t size, void *) {
    std::memcpy(dst, src, size);
}

// ---- Optional PCIe traffic counter ----------------------------------------
// TRBA_PCIE_COUNTER=1 prints the total host<->device bytes at exit.  Every
// transfer the Rust side initiates goes through cuda_memcpy_h2d /
// cuda_memcpy_d2h, so this *measures* the cost of a step instead of estimating
// it — that is how the 797 MB/batch baseline was found and how the traffic fixes
// were verified.  Costs one predictable branch per transfer when unset.
static std::atomic<unsigned long long> g_h2d_bytes{0}, g_d2h_bytes{0};
static std::atomic<unsigned long long> g_h2d_calls{0}, g_d2h_calls{0};

static void pcie_report_at_exit() {
    const double mb = 1024.0 * 1024.0;
    const unsigned long long hb = g_h2d_bytes.load(), db = g_d2h_bytes.load();
    fprintf(stderr,
            "\n[pcie] H2D %.2f MB (%llu calls) | D2H %.2f MB (%llu calls) | total %.2f MB\n",
            (double)hb / mb, g_h2d_calls.load(), (double)db / mb, g_d2h_calls.load(),
            (double)(hb + db) / mb);
}

static const bool g_pcie_count = [] {
    const char *e = std::getenv("TRBA_PCIE_COUNTER");
    if (e != nullptr && e[0] == '1') {
        std::atexit(pcie_report_at_exit);
        return true;
    }
    return false;
}();

static inline void pcie_count_h2d(size_t size) {
    if (g_pcie_count) {
        g_h2d_bytes.fetch_add(size, std::memory_order_relaxed);
        g_h2d_calls.fetch_add(1, std::memory_order_relaxed);
    }
}
static inline void pcie_count_d2h(size_t size) {
    if (g_pcie_count) {
        g_d2h_bytes.fetch_add(size, std::memory_order_relaxed);
        g_d2h_calls.fetch_add(1, std::memory_order_relaxed);
    }
}

extern "C" void cuda_memcpy_h2d(void *dst, const void *src, size_t size, void *) {
    if (size == 0) return;
    pcie_count_h2d(size);
    std::memcpy(dst, src, size);
}

extern "C" void cuda_memcpy_d2h(void *dst, const void *src, size_t size, void *) {
    if (size == 0) return;
    pcie_count_d2h(size);
    std::memcpy(dst, src, size);
}

extern "C" void cuda_sync(void *) {}
extern "C" void cuda_stream_create(void **stream) { *stream = nullptr; }
extern "C" void cuda_stream_destroy(void *) {}

extern "C" void cuda_get_memory_info(size_t *free_mem, size_t *total_mem) {
    size_t total = 0, avail = 0;
    FILE *f = std::fopen("/proc/meminfo", "r");
    if (f) {
        char line[256];
        while (std::fgets(line, sizeof(line), f)) {
            unsigned long long v = 0;
            if (std::sscanf(line, "MemTotal: %llu kB", &v) == 1) total = (size_t)v * 1024;
            else if (std::sscanf(line, "MemAvailable: %llu kB", &v) == 1) avail = (size_t)v * 1024;
        }
        std::fclose(f);
    }
    if (total_mem) *total_mem = total;
    if (free_mem) *free_mem = avail;
}

// See cuda/kernels.cu for why this is a pool and not a single arena: two
// GpuWorkspaces can be alive at once (cargo test runs tests in parallel), and a
// shared arena handed both of them the same pointer.
struct WsBlock {
    void *ptr;
    size_t size;
    bool in_use;
};
static std::vector<WsBlock> g_ws_pool;
// Pool lock.  Not std::mutex: nvcc compiles this file with -U_GNU_SOURCE (the
// glibc >= 2.41 sinpi/cospi workaround), and that makes <mutex> fail to
// compile because <bits/gthr-default.h> then misses pthread_mutex_timedlock.
static std::atomic<bool> g_ws_lock(false);
struct WsLock {
    WsLock() { while (g_ws_lock.exchange(true, std::memory_order_acquire)) {} }
    ~WsLock() { g_ws_lock.store(false, std::memory_order_release); }
};

extern "C" void *trba_workspace_acquire(size_t bytes) {
    if (bytes == 0) return nullptr;
    WsLock lk;
    for (size_t i = 0; i < g_ws_pool.size(); ++i) {
        if (!g_ws_pool[i].in_use && g_ws_pool[i].size >= bytes) {
            g_ws_pool[i].in_use = true;
            return g_ws_pool[i].ptr;
        }
    }
    const size_t want = bytes + bytes / 8;
    void *p = xmalloc(want);
    g_ws_pool.push_back(WsBlock{p, want, true});
    return p;
}

extern "C" size_t trba_workspace_size(void) {
    WsLock lk;
    size_t total = 0;
    for (size_t i = 0; i < g_ws_pool.size(); ++i) total += g_ws_pool[i].size;
    return total;
}

extern "C" void trba_workspace_release(void *ptr) {
    if (ptr == nullptr) return;
    WsLock lk;
    for (size_t i = 0; i < g_ws_pool.size(); ++i) {
        if (g_ws_pool[i].ptr == ptr) { g_ws_pool[i].in_use = false; return; }
    }
}

extern "C" void trba_workspace_release_all(void) {
    WsLock lk;
    for (size_t i = 0; i < g_ws_pool.size(); ++i) std::free(g_ws_pool[i].ptr);
    g_ws_pool.clear();
}

extern "C" const char *trba_backend_name(void) { return "cpu"; }
extern "C" int trba_device_cc_major(void) { return 0; }
extern "C" int trba_device_cc_minor(void) { return 0; }
extern "C" const char *trba_device_name(void) { return "CPU (no CUDA)"; }

extern "C" void allocate_model_weights(size_t cnn_size, size_t bilstm_size,
                                       size_t attn_size, size_t ctc_size) {
    if (cnn_size > 0) g_cnn_weights = xmalloc(cnn_size);
    if (bilstm_size > 0) g_bilstm_weights = xmalloc(bilstm_size);
    if (attn_size > 0) g_attention_weights = xmalloc(attn_size);
    if (ctc_size > 0) g_ctc_weights = xmalloc(ctc_size);
}


// ============================================================
// BatchNorm + dynamic-quantisation helpers (CPU mirror)
// ============================================================
extern "C" void launch_bn_stats(const float *x, int B, int C, int HW, float *mean,
                                float *var, void *) {
    long long n = (long long)B * C * HW;
    if (n <= 0) return;
    std::fill(mean, mean + C, 0.0f);
    std::fill(var, var + C, 0.0f);
    const long long count = (long long)B * HW;
#pragma omp parallel
    {
        std::vector<double> s(C, 0.0), sq(C, 0.0);
#pragma omp for schedule(static)
        for (long long i = 0; i < n; ++i) {
            int c = (int)((i / HW) % C);
            double v = x[i];
            s[c] += v;
            sq[c] += v * v;
        }
#pragma omp critical
        for (int c = 0; c < C; ++c) { mean[c] += (float)s[c]; var[c] += (float)sq[c]; }
    }
    for (int c = 0; c < C; ++c) {
        float m = mean[c] / (float)count;
        float v = var[c] / (float)count - m * m;
        mean[c] = m;
        var[c] = v < 0.0f ? 0.0f : v;
    }
}

extern "C" void launch_bn_apply(const float *x, const float *mean, const float *var,
                                const float *gamma, const float *beta, float eps, float *y,
                                int C, int HW, long long n, void *) {
    std::vector<float> r(C);
    for (int c = 0; c < C; ++c) r[c] = 1.0f / std::sqrt(var[c] + eps);
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) {
        int c = (int)((i / HW) % C);
        y[i] = (x[i] - mean[c]) * r[c] * gamma[c] + beta[c];
    }
}

extern "C" void launch_bn_bwd_sums(const float *dy, const float *x, const float *mean,
                                   const float *var, float eps, int C, int HW, long long n,
                                   float *sum_dy, float *sum_dy_xhat, void *) {
    std::fill(sum_dy, sum_dy + C, 0.0f);
    std::fill(sum_dy_xhat, sum_dy_xhat + C, 0.0f);
    std::vector<float> r(C);
    for (int c = 0; c < C; ++c) r[c] = 1.0f / std::sqrt(var[c] + eps);
#pragma omp parallel
    {
        std::vector<double> s(C, 0.0), sx(C, 0.0);
#pragma omp for schedule(static)
        for (long long i = 0; i < n; ++i) {
            int c = (int)((i / HW) % C);
            double xhat = (x[i] - mean[c]) * r[c];
            s[c] += dy[i];
            sx[c] += dy[i] * xhat;
        }
#pragma omp critical
        for (int c = 0; c < C; ++c) { sum_dy[c] += (float)s[c]; sum_dy_xhat[c] += (float)sx[c]; }
    }
}

extern "C" void launch_bn_bwd_dx(const float *dy, const float *x, const float *mean,
                                 const float *var, const float *gamma, const float *sum_dy,
                                 const float *sum_dy_xhat, float eps, int C, int HW, long long n,
                                 long long count, float *dx, void *) {
    std::vector<float> r(C);
    for (int c = 0; c < C; ++c) r[c] = 1.0f / std::sqrt(var[c] + eps);
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) {
        int c = (int)((i / HW) % C);
        float xhat = (x[i] - mean[c]) * r[c];
        dx[i] = gamma[c] * r[c] / (float)count *
                ((float)count * dy[i] - sum_dy[c] - xhat * sum_dy_xhat[c]);
    }
}

extern "C" void launch_reduce_max_abs(const float *x, long long n, float *out, void *) {
    float m = 0.0f;
#pragma omp parallel for reduction(max : m) schedule(static)
    for (long long i = 0; i < n; ++i) {
        float v = std::fabs(x[i]);
        if (v > m) m = v;
    }
    *out = m;
}

extern "C" void launch_quant_f32_i8(const float *x, long long n, float scale, int8_t *q, void *) {
    float inv = 1.0f / scale;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) {
        float v = std::min(std::max(x[i] * inv, -127.0f), 127.0f);
        q[i] = (int8_t)std::lrint(v);
    }
}

extern "C" void launch_relu_quant(const float *y, long long n, float scale, int8_t *q, void *) {
    float inv = 1.0f / scale;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) {
        float v = std::min(std::max(y[i], 0.0f) * inv, 127.0f);
        q[i] = (int8_t)std::lrint(v);
    }
}

extern "C" void launch_dequant_i8_f32(const int8_t *q, long long n, float scale, float *x, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) x[i] = (float)q[i] * scale;
}

extern "C" void launch_add_scaled_i8(const int8_t *a, float sa, const int8_t *b, float sb,
                                     long long n, float *out, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) out[i] = (float)a[i] * sa + (float)b[i] * sb;
}

extern "C" void launch_epilogue_f32(const int32_t *acc, int acc_ld, float scale, float *out,
                                    int C, int Ho, int Wo, long long total, void *) {
    const long long hw = (long long)Ho * Wo;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < total; ++i) {
        long long b = i / ((long long)C * hw);
        int oc = (int)((i / hw) % C);
        long long row = b * hw + (i % hw);
        out[i] = (float)acc[row * (long long)acc_ld + oc] * scale;
    }
}

extern "C" void launch_avgpool_hw(const float *x, int C, int HW, long long B, float *out, void *) {
    long long bc = B * C;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < bc; ++i) {
        const float *p = x + i * HW;
        double s = 0.0;
        for (int j = 0; j < HW; ++j) s += p[j];
        out[i] = (float)(s / HW);
    }
}

extern "C" void launch_avgpool_hw_backward(const float *dy, int C, int HW, long long B, float *dx, void *) {
    long long bc = B * C;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < bc; ++i) {
        float v = dy[i] / (float)HW;
        float *p = dx + i * HW;
        for (int j = 0; j < HW; ++j) p[j] = v;
    }
}

extern "C" void launch_mul_gate(const float *x, const float *gate, int C, int HW, long long n,
                                float *out, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) {
        int c = (int)((i / HW) % C);
        long long b = i / ((long long)C * HW);
        out[i] = x[i] * gate[b * C + c];
    }
}

extern "C" void launch_mask_relu_bwd(const float *y, const float *dy, long long n, float *dx, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) dx[i] = y[i] > 0.0f ? dy[i] : 0.0f;
}

extern "C" void launch_zero_f32(float *p, long long n, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) p[i] = 0.0f;
}


extern "C" void launch_transpose_i8(const int8_t *src, int rows, int cols, int8_t *dst, void *) {
#pragma omp parallel for schedule(static) collapse(2)
    for (int c = 0; c < cols; ++c)
        for (int r = 0; r < rows; ++r) dst[(long long)c * rows + r] = src[(long long)r * cols + c];
}


extern "C" void launch_add_f32(const float *a, const float *b, long long n, float *o, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) o[i] = a[i] + b[i];
}
extern "C" void launch_mul_f32(const float *a, const float *b, long long n, float *o, void *) {
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < n; ++i) o[i] = a[i] * b[i];
}
extern "C" void launch_meanpool_h(const float *x, int C, int H, int W, long long B, float *out, void *) {
    long long total = B * W * C;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < total; ++i) {
        int c = (int)(i % C);
        int w = (int)((i / C) % W);
        long long b = i / ((long long)C * W);
        float s = 0.0f;
        const float *p = x + ((b * C + c) * H) * W + w;
        for (int h = 0; h < H; ++h) s += p[(long long)h * W];
        out[i] = s / (float)H;
    }
}
extern "C" void launch_meanpool_h_backward(const float *dy, int C, int H, int W, long long B, float *dx, void *) {
    long long total = B * W * C;
#pragma omp parallel for schedule(static)
    for (long long i = 0; i < total; ++i) {
        int c = (int)(i % C);
        int w = (int)((i / C) % W);
        long long b = i / ((long long)C * W);
        float v = dy[i] / (float)H;
        float *p = dx + ((b * C + c) * H) * W + w;
        for (int h = 0; h < H; ++h) p[(long long)h * W] = v;
    }
}

extern "C" void upload_cnn_weights(const void *d, size_t s) {
    if (g_cnn_weights && d && s) std::memcpy(g_cnn_weights, d, s);
}
extern "C" void upload_bilstm_weights(const void *d, size_t s) {
    if (g_bilstm_weights && d && s) std::memcpy(g_bilstm_weights, d, s);
}
extern "C" void upload_attention_weights(const void *d, size_t s) {
    if (g_attention_weights && d && s) std::memcpy(g_attention_weights, d, s);
}
extern "C" void upload_ctc_weights(const void *d, size_t s) {
    if (g_ctc_weights && d && s) std::memcpy(g_ctc_weights, d, s);
}
extern "C" void *get_cnn_weights_ptr(void) { return g_cnn_weights; }
extern "C" void *get_bilstm_weights_ptr(void) { return g_bilstm_weights; }
extern "C" void *get_attention_weights_ptr(void) { return g_attention_weights; }
extern "C" void *get_ctc_weights_ptr(void) { return g_ctc_weights; }

extern "C" void free_model_weights(void) {
    std::free(g_cnn_weights); g_cnn_weights = nullptr;
    std::free(g_bilstm_weights); g_bilstm_weights = nullptr;
    std::free(g_attention_weights); g_attention_weights = nullptr;
    std::free(g_ctc_weights); g_ctc_weights = nullptr;
}

// ============================================================
// BiLSTM (fp32): CPU-зеркала ядер из kernels.cu. Индексы и последовательность
// операций те же; отличие только в том, что warp-редукция заменена
// последовательной суммой, поэтому тесты эквивалентности сравнивают с допуском.
// ============================================================

extern "C" void launch_lstm_fwd_step(const float *x, const float *w_ih, const float *b_ih,
                                     const float *w_hh, const float *b_hh, float *gates,
                                     float *c_out, float *h_out, long long B, long long T,
                                     long long D, long long H, long long slot, long long rev,
                                     void *) {
    if (B <= 0 || T <= 0 || D <= 0 || H <= 0 || slot < 0 || slot >= T) return;
    const long long tt = rev ? (T - 1 - slot) : slot;
    for (long long w = 0; w < B * H; ++w) {
        const long long bi = w / H;
        const long long i = w - bi * H;
        const float *xr = x + (bi * T + tt) * D;
        const float *cp = c_out + (slot - 1) * B * H + bi * H;
        const float *hp = h_out + (slot - 1) * B * H + bi * H;
        float g[4];
        for (int q = 0; q < 4; ++q) {
            const long long o = q * H + i;
            float s = b_ih[o] + b_hh[o];
            const float *wi = w_ih + o * D;
            for (long long k = 0; k < D; ++k) s += xr[k] * wi[k];
            if (slot != 0) {
                const float *wh = w_hh + o * H;
                for (long long k = 0; k < H; ++k) s += hp[k] * wh[k];
            }
            g[q] = s;
        }
        const float ig = 1.0f / (1.0f + std::exp(-g[0]));
        const float fg = 1.0f / (1.0f + std::exp(-g[1]));
        const float cg = std::tanh(g[2]);
        const float og = 1.0f / (1.0f + std::exp(-g[3]));
        const float c_prev_i = (slot == 0) ? 0.0f : cp[i];
        const float c_new = fg * c_prev_i + ig * cg;
        const float h_new = og * std::tanh(c_new);
        const long long gs = (slot * B + bi) * (4 * H);
        gates[gs + i] = ig;
        gates[gs + H + i] = fg;
        gates[gs + 2 * H + i] = cg;
        gates[gs + 3 * H + i] = og;
        const long long cs = (slot * B + bi) * H;
        c_out[cs + i] = c_new;
        h_out[cs + i] = h_new;
    }
}

extern "C" void launch_lstm_bwd_cell(const float *dh_out, const float *gates, const float *ctrace,
                                     const float *dh_next, const float *dc_next, float *dgates,
                                     float *dc_next_out, long long B, long long H, long long slot,
                                     void *) {
    if (B <= 0 || H <= 0) return;
    for (long long idx = 0; idx < B * H; ++idx) {
        const long long bi = idx / H;
        const long long i = idx - bi * H;
        const long long cs = (slot * B + bi) * H;
        const long long gs = (slot * B + bi) * (4 * H);
        const float c_prev_i = (slot == 0) ? 0.0f : ctrace[((slot - 1) * B + bi) * H + i];
        const float ig = gates[gs + i];
        const float fg = gates[gs + H + i];
        const float cg = gates[gs + 2 * H + i];
        const float og = gates[gs + 3 * H + i];
        const float c = ctrace[cs + i];
        const float tc = std::tanh(c);
        const float dh = dh_out[cs + i] + dh_next[bi * H + i];
        const float dc = dh * og * (1.0f - tc * tc) + dc_next[bi * H + i] * fg;
        dgates[gs + i] = dc * cg * ig * (1.0f - ig);
        dgates[gs + H + i] = dc * c_prev_i * fg * (1.0f - fg);
        dgates[gs + 2 * H + i] = dc * ig * (1.0f - cg * cg);
        dgates[gs + 3 * H + i] = dh * tc * og * (1.0f - og);
        dc_next_out[bi * H + i] = dc;
    }
}

extern "C" void launch_lstm_bwd_rec(const float *dgates, const float *w_ih, const float *w_hh,
                                    float *dx, float *dh_next, long long B, long long T,
                                    long long D, long long H, long long slot, long long rev,
                                    void *) {
    if (B <= 0 || T <= 0 || D <= 0 || H <= 0) return;
    const long long tt = rev ? (T - 1 - slot) : slot;
    for (long long idx = 0; idx < B * (D + H); ++idx) {
        const long long bi = idx / (D + H);
        const long long k = idx - bi * (D + H);
        const long long gs = (slot * B + bi) * (4 * H);
        // 4 независимых накопителя: одна цепочка `s +=` упирается в латентность FMA
        // (~4 такта на итерацию), а не в пропускную способность. 4*H всегда кратно 4,
        // хвостовой цикл оставлен на случай некруглого H.
        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        if (k < D) {
            long long o = 0;
            for (; o + 3 < 4 * H; o += 4) {
                s0 += dgates[gs + o] * w_ih[o * D + k];
                s1 += dgates[gs + o + 1] * w_ih[(o + 1) * D + k];
                s2 += dgates[gs + o + 2] * w_ih[(o + 2) * D + k];
                s3 += dgates[gs + o + 3] * w_ih[(o + 3) * D + k];
            }
            for (; o < 4 * H; ++o) s0 += dgates[gs + o] * w_ih[o * D + k];
            dx[(bi * T + tt) * D + k] = (s0 + s1) + (s2 + s3);
        } else {
            const long long kk = k - D;
            long long o = 0;
            for (; o + 3 < 4 * H; o += 4) {
                s0 += dgates[gs + o] * w_hh[o * H + kk];
                s1 += dgates[gs + o + 1] * w_hh[(o + 1) * H + kk];
                s2 += dgates[gs + o + 2] * w_hh[(o + 2) * H + kk];
                s3 += dgates[gs + o + 3] * w_hh[(o + 3) * H + kk];
            }
            for (; o < 4 * H; ++o) s0 += dgates[gs + o] * w_hh[o * H + kk];
            dh_next[bi * H + kk] = (s0 + s1) + (s2 + s3);
        }
    }
}

// Один член суммы градиента веса по плоскому индексу j = slot*B + bi.
// dgates[(slot*B+bi)*(4H)+o] == dgates[j*(4H)+o], поэтому вложенный цикл
// (slot, bi) разворачивается в один плоский — и его можно считать четырьмя
// независимыми накопителями.
static inline float wgrad_ih_term(const float *dgates, const float *x, long long j,
                                 long long B, long long T, long long D, long long H,
                                 long long o, long long k, long long rev) {
    const long long slot = j / B;
    const long long bi = j - slot * B;
    const long long tt = rev ? (T - 1 - slot) : slot;
    return dgates[j * (4 * H) + o] * x[(bi * T + tt) * D + k];
}

static inline float wgrad_hh_term(const float *dgates, const float *htrace, long long j,
                                 long long B, long long H, long long o, long long k) {
    const long long slot = j / B;
    const long long bi = j - slot * B;
    return dgates[j * (4 * H) + o] * htrace[((slot - 1) * B + bi) * H + k];
}

extern "C" void launch_lstm_wgrad_ih(const float *dgates, const float *x, float *g_w, long long B,
                                     long long T, long long D, long long H, long long rev,
                                     long long accumulate, void *) {
    if (B <= 0 || T <= 0 || D <= 0 || H <= 0) return;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long idx = 0; idx < 4 * H * D; ++idx) {
        const long long o = idx / D;
        const long long k = idx - o * D;
        const long long n = T * B;
        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        long long j = 0;
        for (; j + 3 < n; j += 4) {
            s0 += wgrad_ih_term(dgates, x, j, B, T, D, H, o, k, rev);
            s1 += wgrad_ih_term(dgates, x, j + 1, B, T, D, H, o, k, rev);
            s2 += wgrad_ih_term(dgates, x, j + 2, B, T, D, H, o, k, rev);
            s3 += wgrad_ih_term(dgates, x, j + 3, B, T, D, H, o, k, rev);
        }
        for (; j < n; ++j) s0 += wgrad_ih_term(dgates, x, j, B, T, D, H, o, k, rev);
        const float s = (s0 + s1) + (s2 + s3);
        if (accumulate) {
            g_w[o * D + k] += s;
        } else {
            g_w[o * D + k] = s;
        }
    }
}

extern "C" void launch_lstm_wgrad_hh(const float *dgates, const float *htrace, float *g_w,
                                     long long B, long long T, long long H, long long accumulate,
                                     void *) {
    if (B <= 0 || T <= 0 || H <= 0) return;
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long idx = 0; idx < 4 * H * H; ++idx) {
        const long long o = idx / H;
        const long long k = idx - o * H;
        // j начинается с B: при slot = 0 состояния h_prev нет (нули), вклад нулевой
        const long long n = T * B;
        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        long long j = B;
        for (; j + 3 < n; j += 4) {
            s0 += wgrad_hh_term(dgates, htrace, j, B, H, o, k);
            s1 += wgrad_hh_term(dgates, htrace, j + 1, B, H, o, k);
            s2 += wgrad_hh_term(dgates, htrace, j + 2, B, H, o, k);
            s3 += wgrad_hh_term(dgates, htrace, j + 3, B, H, o, k);
        }
        for (; j < n; ++j) s0 += wgrad_hh_term(dgates, htrace, j, B, H, o, k);
        const float s = (s0 + s1) + (s2 + s3);
        if (accumulate) {
            g_w[o * H + k] += s;
        } else {
            g_w[o * H + k] = s;
        }
    }
}

extern "C" void launch_lstm_bgrad(const float *dgates, float *g_b_ih, float *g_b_hh, long long B,
                                  long long T, long long H, long long accumulate, void *) {
    if (B <= 0 || T <= 0 || H <= 0) return;
    for (long long idx = 0; idx < 4 * H; ++idx) {
        const long long n = T * B;
        float s0 = 0.0f, s1 = 0.0f, s2 = 0.0f, s3 = 0.0f;
        long long j = 0;
        for (; j + 3 < n; j += 4) {
            s0 += dgates[j * (4 * H) + idx];
            s1 += dgates[(j + 1) * (4 * H) + idx];
            s2 += dgates[(j + 2) * (4 * H) + idx];
            s3 += dgates[(j + 3) * (4 * H) + idx];
        }
        for (; j < n; ++j) s0 += dgates[j * (4 * H) + idx];
        const float s = (s0 + s1) + (s2 + s3);
        if (accumulate) {
            g_b_ih[idx] += s;
            g_b_hh[idx] += s;
        } else {
            g_b_ih[idx] = s;
            g_b_hh[idx] = s;
        }
    }
}

// Muon (momentum-free): зеркало muon_step_f32_kernel. См. cuda/kernels.cu.
extern "C" void launch_muon_step_f32(float *w, const float *g, const double *gsq, long long n,
                                     double lr, double wd, double clip, double min_dim,
                                     double max_dim, double cap, long long autoscale, void *) {
    if (n <= 0 || !w || !g || !gsq) return;
    const double frob = std::sqrt(std::fmax(*gsq, 1e-30));
    const double scale = std::fmin(std::sqrt(min_dim) / std::fmax(frob, 1e-8), cap);
    const double lre = autoscale ? lr * std::sqrt(max_dim) : lr;
    const float step = (float)(clip * lre * scale);
    const float dec = (float)(1.0 - lr * wd);
#ifdef _OPENMP
#pragma omp parallel for schedule(static)
#endif
    for (long long i = 0; i < n; ++i) {
        const float u = w[i] * dec - step * g[i];
        w[i] = std::isfinite(u) ? u : 0.0f;
    }
}
