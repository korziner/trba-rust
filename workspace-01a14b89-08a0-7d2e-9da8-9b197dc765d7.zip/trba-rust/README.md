# trba-rust
TRBA OCR port to Rust and CUDA

## Backends

`build.rs` compiles one of two native backends with the same `extern "C"` surface:

* `cuda/kernels.cu` through `nvcc` — used whenever a CUDA toolkit is found
  (`TRBA_NVCC`, `CUDA_PATH`, `/usr/local/cuda`, `/opt/cuda`, `PATH`);
* `cuda/cpu_backend.cpp` through the C++ compiler — fallback, or `TRBA_FORCE_CPU=1`.

Everything is linked statically, so no `LD_LIBRARY_PATH` is needed at run time.

**Always build the GPU binary with `TRBA_REQUIRE_CUDA=1`.** Without it a failed `nvcc`
run silently links the CPU backend and the binary still starts — you would train on the
CPU believing it is the GPU. With it, the build fails loudly, and `src/main.rs` also
refuses to start if the linked backend is not `cuda`.

## Building and running on a GPU

```bash
nvidia-smi --query-gpu=name,compute_cap --format=csv,noheader   # e.g. 7.5 -> sm_75

TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release     # your card's sm_XX
cargo test --release                                            # 23 kernel tests, seconds on a GPU
./target/release/trba-rust train.csv val.csv exp --batch-size 32 --epochs 100
```

The first line printed must be `🚀 TRBA ... | бэкенд: cuda | NVIDIA ...`.

One command for the whole bring-up (build + kernel tests + a short smoke run on synthetic
data, no dataset required; `SANITIZE=1` additionally runs it under `compute-sanitizer`):

```bash
ARCH=75 ./scripts/run_cuda_smoke.sh
```

Smoke run by hand (needs a `charset.txt` whose first three tokens are `<PAD> <SOS> <EOS>`):

```bash
./target/release/trba-rust --smoke 2 --batch-size 2 --img-h 32 --img-w 128 \
    --max-len 24 --charset charset.txt exp_smoke
```

Start small: `NetTrace` keeps the pre/post-BN activations of all 28 conv layers alive until
the backward pass, and the device optimiser state below adds ~643 MiB, so `--batch-size 32
--img-w 1024` is a lot of device memory.

## PCIe traffic (this is what hurts on PCIe 2.0 x4)

Everything that used to travel per batch now stays on the device:

* the 2x2 maxpool runs on the GPU over int8, and its backward **recomputes the argmax** from the
  activations the trace already keeps — the u64 index tensor no longer exists (that was 256 MB
  per batch upstream, plus 256 MB of host RAM);
* `grad_input` reads the int8 fake-quant weights the forward GEMM already uploaded, so the fp32
  master weights (160.8 MB per batch) never cross the bus;
* the conv optimiser lives on the device: `w`, `g`, `m`, `v` of all 28 layers (42.15M
  parameters), the int32 `grad_W` accumulator folded into the fp32 gradient by a kernel, the
  global grad-norm clip assembled from one 8-byte device scalar, and QAT re-quantisation done on
  the GPU with only the 4-byte scale mirrored back per layer.  The arithmetic matches
  `src/opt.rs` (f64 intermediates, f32 state) and is covered by a bit-exact test.

Measured with `TRBA_PCIE_COUNTER=1` (prints the H2D/D2H totals at exit; run `--smoke 2` and
`--smoke 4`, divide the difference by two to get one batch, which removes the one-off costs):

| mode | MB per batch |
|------|--------------|
| host Adam + fp32 `grad_input` (the original design) | 361.4 |
| host Adam + int8 `grad_input` | 201.1 |
| device Adam + device re-quantisation (default) | **0.6** |

That weight traffic is independent of batch size and image size.  At `--batch-size 32 --img-h 32
--img-w 1024` add the activations that genuinely have to travel (3 MB of images in, 16 MB of
features to the host RNN and back): **~19 MB per batch instead of ~797 MB**, i.e. 15-19 ms
instead of 0.6-0.8 s on a pageable PCIe 2.0 x4 link.

| variable | effect |
|----------|--------|
| `TRBA_PCIE_COUNTER=1` | print the actual host<->device byte totals at exit (both backends) |
| `TRBA_HOST_CONV_ADAM=1` | keep the conv optimiser on the host: frees ~643 MiB of VRAM, costs +201 MB per batch over PCIe |
| `TRBA_GRAD_INPUT_FP32=1` | compute `grad_input` from the fp32 master weights (numerical reference): +161 MB per batch |
| `TRBA_GPU_RNN=1` | run the BiLSTM on the GPU instead of the host (stage 1: LSTM directions on device, projection on host) — see *BiLSTM on the GPU* |
| `TRBA_OPT=adam` | use the previous Adam for **all** parameters instead of Muon (A/B switch) — see *Muon instead of Adam* |
| `TRBA_MUON_Q=1` | MuonQ: quantise the gradient to int8 in blocks before the Muon step (regularisation, not speed — see below) |
| `TRBA_MUON_Q_BLOCK=N` | MuonQ block size, default 128 |
| `TRBA_MUON_CAP=X` | cap on `sqrt(min_dim)/\|\|g\|\|_F`, default 10 |
| `TRBA_MUON_AUTOSCALE=0` | disable the `lr * sqrt(max_dim)` rescaling |
| `TRBA_CLIP_WARMUP=N` / `--clip-warmup N` | apply the global grad-norm clip only on the first N steps, default 500 |

`PCIE=1 ARCH=75 ./scripts/run_cuda_smoke.sh` runs the smoke with the counter on.

Note that the CPU fallback backend is compiled with OpenMP; if your compiler rejects `-fopenmp`
the build prints a loud warning, because that silently makes every reference kernel
single-threaded.

## Picking batch size and crop width (`--autotune`)

`--autotune` searches the (batch_size, img_w) space on *your* GPU and reports throughput,
VRAM and PCIe cost per batch, then recommends a pair. Optuna-style: a budget of trials,
a deterministic sampler seeded by `--seed`, and an objective you choose.

```bash
# вся сетка (мелкие конфигурации первыми)
./target/release/trba-rust train.csv val.csv exp --charset charset.txt --autotune

# бюджет 24 пробы по 6 батчей, цель — картинки/с на GiB занятой памяти, предел 8 GB
./target/release/trba-rust train.csv val.csv exp --charset charset.txt \
    --autotune --autotune-trials 24 --autotune-batches 6 \
    --autotune-objective efficiency --autotune-vram 8000

# свои списки (например, только ширины из вашего пайплайна)
./target/release/trba-rust train.csv val.csv exp --charset charset.txt \
    --autotune --autotune-widths 256,384,512 --autotune-batch-sizes 4,8,16
```

Each trial is a **separate child process** running `--smoke K` with those shapes. That is
deliberate: `an illegal memory access was encountered` and CUDA OOM destroy the context, so
a crashing configuration cannot be measured from inside the same process — the parent just
records the failure (with the signal / stderr reason) and keeps searching. The report is
written to `<exp_dir>/autotune.json`.

Objectives: `throughput` (images/s, default), `efficiency` (images/s per GiB — the "best
ratio" number), `latency` (s/batch).

### Crop sizes follow the EAST detector grid

Widths come from the detector in
[`manuscript-ocr`](https://github.com/konstantinkozhin/manuscript-ocr/tree/main/src/manuscript/detectors/_east):
`EASTDataset(target_size=512, score_geo_scale=0.25)` normalises a page to a 512×512 canvas
and emits a 128×128 score map, i.e. a **4 px detection stride**, and `warp_quad` cuts crops
in canvas pixels. The recognizer reference config
(`recognizers/_trba/configs/config.json`) is `img_h=32, img_w=128, max_len=40`.

So `src/autotune.rs` uses:

* step = 4 px (EAST stride) × 8 (SEResNetQ width downsample, `T = img_w / 8`) = **32 px**:
  every candidate width is a multiple of 32, which keeps the crop boundary on the detector
  grid and every conv stage (maxpool 2×2, layer1 s2, layer3 s2, conv_out 2×2) integral;
* the ladder `128…512` in 32 px steps (inside one EAST canvas), then `640…1024` in 128 px
  steps (up to two canvases) so the expensive end is not oversampled;
* a floor of `max_len × 8`: with `T = img_w / 8` feature steps CTC cannot emit more than `T`
  symbols, so `max_len=40` needs `img_w ≥ 320` and `max_len=64` needs `img_w ≥ 512`.
  The reference `img_w=128` only fits `max_len ≤ 16` — worth knowing before copying that
  config into a run with long lines.

## Checkpoints and resuming

```bash
# каждые 200 батчей + в конце каждой эпохи (по умолчанию — каждые 500 батчей)
./target/release/trba-rust train.csv val.csv exp --ckpt-every-batch 200 --ckpt-every 2

# тот же запуск после Ctrl-C / OOM / падения драйвера продолжает с места обрыва
./target/release/trba-rust train.csv val.csv exp --ckpt-every-batch 200
#   📂 resume: exp/checkpoint_last.bin
#      завершено эпох: 3 | продолжать с эпохи 4, батч 201 | шаг оптимизатора 42201 |
#      Adam-моменты: восстановлены
```

`--ckpt-every-batch N` (default 500, `0` = off) writes the rolling `<exp_dir>/checkpoint_last.bin`
every N batches, and it is written again at the end of every epoch. Writes are atomic
(`.tmp` + `rename`), so interrupting a save cannot corrupt the previous one.
`--ckpt-every N` additionally keeps numbered files, with the epoch loss in the name, so the curve
is visible straight from `ls`:

```
exp/checkpoint_epoch003_loss4.1234.bin
exp/checkpoint_epoch004_loss3.9871.bin
```

### `best.bin`

Every validation (`--eval-every N`, off by default only if `val.csv` is missing) that improves the
metric writes a file whose name carries both numbers, and links `best.bin` to it:

```
exp/checkpoint_best_cer12.345_loss3.9871_epoch004.bin    ← the real file
exp/best.bin                                             ← hard link to it
```

`best.bin` is a **hard link**, not a copy: both names are one inode, so the 553 MB is stored once
(`ls -i exp` shows the same inode, `du` counts it once). The previous best file is deleted, so
improvements do not pile up. On filesystems without hard links (FAT/exFAT, some network shares) the
code falls back to a copy and says so in the log.

The selection metric is **CER**: the reference `validate()` never computed a validation loss (it
prints `acc`/`CER`, and its `loss` variable was dead code), while CER is what OCR quality is
measured by. The training loss of the epoch is still in the file name. On resume the best CER is
parsed back out of the existing file name, so `best.bin` is rewritten only on a real improvement
and not on the first validation after a restart.

`--autotune` probes never write checkpoints. A probe *is* one epoch, so the epoch-end save used to
add ~500 MB of D2H traffic plus a 553 MB disk write to every trial — which showed up as ~15 MB per
batch of "PCIe" in the autotune report. `TRBA_AUTOTUNE_PROBE=1` (set by the parent) disables the
rolling save, the numbered save and the banner.

Resume is automatic: the same command line picks the newest checkpoint in `exp_dir` (by mtime —
the rolling file or a numbered one, whichever is newer), `--resume PATH` picks a specific file,
`--no-resume` starts over. Training continues at `epoch_done + 1` and **skips the batches of that
epoch that were already done**, so an interrupted epoch is not repeated from the start.

Format `TRBA_V5` holds: `epoch_done`, `batch_in_epoch`, `Adam.t`, every parameter tensor
*with its Adam m/v*, BN running stats, and — in device mode — the conv Adam moments pulled back
from the GPU (they never live on the host otherwise). Size ≈ 553 MB for the 42M-parameter conv
stack, so keep a couple of GB free next to `exp_dir`; only one rolling file accumulates.

Two details make a mid-epoch resume exact rather than approximate:

* the batch order is a function of `(seed, epoch)`, not of the whole shuffle history, so the
  batches skipped after a resume are the same ones already trained on;
* Adam's `m`/`v` are restored on both sides (host parameters *and* the device conv state).
  Restoring only `t` restarts both moving averages from zero while the bias correction keeps
  dividing by `1 - beta^t ≈ 1`, so the first steps after a resume are effectively unnormalised
  and can throw the weights away — that is what the old `TRBA_V4` checkpoint did.

`TRBA_V4` files still load (weights, BN, `t`); the run says so explicitly instead of pretending
the moments were restored. If a checkpoint does not fit the current model (different `--hidden`,
different charset size), the loader reports the mismatch and the model is rebuilt from scratch —
a partially-applied file is never trained on.

## Recognising images with a trained checkpoint (`--infer`)

```bash
# каталог картинок → stdout; чекпоинт берётся из exp/best.bin
./target/release/trba-rust crops "" exp --charset charset.txt --img-w 512 --max-len 64 --infer

# CSV (первая колонка — пути, то есть годится val.csv) → TSV-файл
./target/release/trba-rust val.csv results.tsv exp --charset charset.txt --img-w 512 --infer

# конкретный чекпоинт и батч
./target/release/trba-rust crops out.tsv exp --charset charset.txt --infer \
    --resume exp/checkpoint_epoch012_loss3.4210.bin --batch-size 16
```

In `--infer` mode the positional arguments mean: `[0]` — one image, a directory of images, or a
CSV/TSV/TXT whose first column holds paths (so `train.csv`/`val.csv` work unchanged); `[1]` — the
results file, one `path<TAB>text` per line (empty string or nothing at all → stdout); `[2]` —
`exp_dir`, the same slot as in training. The checkpoint is `--resume PATH`, else
`<exp_dir>/best.bin`, else the newest `checkpoint_*.bin` in `exp_dir`. A failed load is fatal:
recognising with half a checkpoint is worse than an error.

Preprocessing and decoding are exactly the validation ones — aspect-preserving resize, white
canvas, `(p/255*2-1)`, int8 with scale 1/127, CNN → BiLSTM → greedy attention decode — so the text
matches what training reported. `--charset/--img-h/--img-w/--max-len/--hidden` must match the
checkpoint; a mismatch is reported instead of silently producing garbage. Unreadable files are
skipped with a warning and counted separately, and images are batched by `--batch-size`.

This is the piece the per-scribe loop needs: fine-tune on one scribe's crops and check the result
without leaving the binary (and later without Python at all).

## Layout convention: `[B, T, C]` outside the CNN

The CNN works in NCHW and hands the encoder `feat [B, T, 512]` (`T = img_w / 8`, mean over the
remaining height). The BiLSTM stack, the attention decoder and CTC all read and write `[B, T, ·]`,
and `cnn.backward` expects `d_feat` in the same layout. Inside `rnn.rs` the per-direction traces are
`[T, B, ·]` — the natural order for a time loop — but they never cross the module boundary.

The test `bilstm_batch_items_do_not_mix_forward_or_backward` pins this down: an item inside a batch
must produce exactly the output *and* the input gradient that it produces on its own (`b = 1`).

## Where the batch time goes (`TRBA_PROFILE=1`)

```bash
TRBA_PROFILE=1 ./target/release/trba-rust train.csv val.csv exp --batch-size 8 --img-w 512
```

At the end of every epoch a per-batch breakdown goes to stderr (format illustrated with made-up
numbers):

```
[profile] эпоха 1: 8 батч(ей), 1070.4 мс/батч | CPU 902.1 мс (84%), GPU 151.0 мс (14%), PCIe 17.3 мс (2%)
   img_h2d         2.31 мс/батч   0.2%  [pcie] загрузка int8-батча на GPU
   cnn_fwd        41.20 мс/батч   3.8%  [gpu]  CNN forward: int8 IMMA-ядра
   feat_d2h        7.10 мс/батч   0.7%  [pcie] выгрузка feat [B,T,512] + sync
   rnn_fwd       212.44 мс/батч  19.8%  [cpu]  BiLSTM forward (2 слоя x 2 направления)
   rnn_bwd       486.02 мс/батч  45.4%  [cpu]  BiLSTM backward
   cnn_bwd       102.55 мс/батч   9.6%  [gpu]  CNN backward (int8) + sync
   clip_adam      31.18 мс/батч   2.9%  [cpu]  clip по норме + Adam по host-параметрам
   adam_dev        5.02 мс/батч   0.5%  [gpu]  Adam по 42.15M conv-весам (GPU) + requant
   [int8] CNN forward : 14.196 GMAC/батч за 41.20 мс -> 345 GMAC/s (690 GOPS)
   [int8] CNN backward: 28.392 GMAC/батч за 102.55 мс -> 277 GMAC/s (554 GOPS)
```

Why this exists: only the CNN runs on the GPU. The BiLSTM, the attention decoder, CTC and Adam for
the non-conv parameters are scalar Rust on the host, and their cost grows with `batch × T`
(`T = img_w / 8`). That is why `nvidia-smi` can show 9–17 % utilisation with a nearly empty VRAM:
the card is not slow, it is waiting for the host. Doubling `img_w` doubles the host work, which is
exactly what the `sec/batch` column of `--autotune` shows.

How to read it:

* **CPU ≫ GPU** (the usual case here) → the fix is on the host side: parallelise the RNN/attention
  over the batch dimension (rayon), and only then raise the batch size. Until the host part is
  parallel, a bigger batch costs proportionally more host time, so images/second stays flat while
  VRAM stays empty.
* **GPU ≫ CPU** → compare the `[int8]` lines with the IMMA peak, `SM × 1024 MAC/clock × clock`
  (56 SM @ 1.4 GHz ≈ 40 TMAC/s ≈ 80 TOPS). A few hundred GMAC/s means the GEMM runs far below
  peak (small tiles, low occupancy) and is worth optimising; tens of TMAC/s means it is fine.
* **PCIe large** → see the PCIe section; a PCIe 2.0 x4 link gives ~2 GB/s.

The profiler calls `cudaStreamSynchronize` at every phase boundary — kernel launches are
asynchronous, so without it GPU time would be attributed to the next phase. The attribution is
honest, the profiled run itself is slightly slower, and nothing is measured unless
`TRBA_PROFILE=1`.

### Proving that INT8 uses the tensor cores

Three independent checks, cheapest first:

1. **At startup** the backend announces the path it picked:

   ```
   [trba] int8 GEMM: WMMA m16n16k16 s8*s8->s32 (тензорные ядра, IMMA) | cc 7.5 | SM 56 | выбран автоматически
   ```

   `launch_gemm_int8` takes the WMMA path when `cc ≥ 7.2` (Turing and newer) and the `__dp4a`
   kernel otherwise: DP4A here is a *fallback for pre-Turing cards*, not the training path.

2. **A/B on your own card** — `TRBA_INT8_GEMM=dp4a` forces the CUDA-core fallback,
   `TRBA_INT8_GEMM=wmma` forces the tensor-core path. Run both with `TRBA_PROFILE=1` and compare
   `cnn_fwd`/`cnn_bwd` and `s/batch`. If the numbers are the same, the tensor cores are not doing
   the work; the ratio is also a direct measure of how much INT8/IMMA buys you.

3. **In the compiled binary**:

   ```bash
   cuobjdump -sass target/release/build/trba-rust-*/out/libtrba_cuda.a | grep -c IMMA
   ```

   The PTX produced for `compute_75` contains 8 ×
   `wmma.mma.sync.aligned.row.col.m16n16k16.s32.s8.s8.s32` (plus `wmma.load.*.s8` /
   `wmma.store.d.*.s32`) inside `gemm_int8_wmma_kernel`, and no `dp4a` there at all — all 23
   `dp4a` instructions live in `gemm_int8_dp4a_kernel`, which an `sm_75` device never dispatches.

`launch_gemm_fp16` is declared in `src/backend.rs` but never called: the fp16 GEMM is not part of
the training path (and its PTX is the f32-emulated WMMA form, i.e. CUDA cores, not tensor cores).

## Параллелизм CPU-части (rayon) — `src/rnn.rs`, `src/attn.rs`, `src/qnet.rs`

На PCIe 2.0 x4 свёртки уезжают на GPU, и узким местом становится хостовая часть:
в профиле реального прогона (batch 32, 64×256, hidden 256, 41 шаг декодера)
`CPU 11006 мс из 12066 мс/батч (91%)`, из них `rnn_bwd` 50.0%, `attn_fwd` 22.6%,
`attn_bwd` 11.0%, `rnn_fwd` 7.3%. Теперь эти стадии распараллелены rayon.

**Порядок суммирования сохранён, поэтому числа не меняются.** Параллелятся только
те регионы, где записи не пересекаются:

* `bwd_dir` разбит на три региона: градиенты вентилей — по образцам батча;
  градиенты весов — по строкам `o` (строке принадлежат `g_w_ih[o·d..]`,
  `g_w_hh[o·h..]`, `g_b_*[o]`, а суммирование по образцам идёт внутри строки в
  прежнем порядке); `dx`/`dh_next` — снова по образцам. Это заодно убирает
  поток по памяти: раньше каждый образец проходился по всему блоку градиентов
  (~3 МБ при hidden=256), теперь строка градиента живёт в кэше, пока по ней
  суммируют все образцы, — трафик падает примерно в `batch_size` раз;
* в `attn.rs` параллельны `cell_gates`, tanh+score (по парам образец×позиция),
  softmax, context, one-hot/`cell_in`, активация вентилей, перестановка
  `[steps,B,V] → [B,steps,V]`, а в `backward` — все регионы, кроме `score.g_w`:
  этот аккумулятор общий для всех (образец, позиция), поэтому он параллелится по
  `k`, а не по образцам, иначе порядок суммирования не сохранить;
* `LinearF::forward` параллелен по строкам, а новый `backward_rows_par` заменяет
  `rows` последовательных вызовов `backward_row` двумя проходами (градиенты весов
  параллельно по `o`, `dx` параллельно по строкам) — объём арифметики тот же;
* `par_min(ops)` задаёт порог для `with_min_len`: при ops < 2^16 регион
  выполняется последовательно в вызывающем потоке. Без порога на мелких батчах
  (`--infer`, smoke-проверки) split/join стоил дороже самой работы: +19…30% к
  `attn_fwd` на одном потоке.

Число потоков — `RAYON_NUM_THREADS` (по умолчанию все ядра). Побитовая
независимость от числа потоков проверена: чекпоинт после одного шага обучения из
одного стартового чекпоинта совпадает по md5 при `RAYON_NUM_THREADS=1` и `=2`
(подробности и таблицы замеров — `BUGFIX_REPORT.md` §18).

Там же описаны два бага, найденные при распараллеливании: квадратичный
пересчёт `d_alpha`/`dot` внутри цикла по позициям в `attn.backward`
(O(t²·c) вместо O(t·c) плюс по аллокации на каждую пару (шаг, образец)) и
неверная раскладка `cell_in` в `forward_train` — контекст внимания всех образцов
писался в слот нулевого образца (пропущено `+ bi*(c+v)`), из-за чего при
batch > 1 обучение расходилось с декодером и ONNX-графом, где контекст
раскладывался правильно.

## BiLSTM on the GPU (`TRBA_GPU_RNN=1`)

By default only the CNN runs on the card; the BiLSTM is scalar Rust on the host and is the
single biggest term in the batch time (`rnn_fwd` + `rnn_bwd` in the profile, ~181 ms per batch at
`b=2, T=16`, ~314 ms at `b=1, T=64`). `TRBA_GPU_RNN=1` moves it to the device.

```bash
TRBA_GPU_RNN=1 TRBA_PROFILE=1 ./target/release/trba-rust train.csv val.csv exp \
    --img-w 512 --batch-size 8 --smoke 20
```

Stage 1 is a hybrid, and the split is deliberate:

* **on the GPU** — both directions of both LSTM layers: `lstm_fwd_step_kernel` (a warp per
  `(batch, output)`, four `__shfl_down_sync` reductions per step), `lstm_bwd_cell_kernel`,
  `lstm_bwd_rec_kernel`, and three weight-gradient kernels launched once per direction after the
  time loop (`lstm_wgrad_ih_kernel`, `lstm_wgrad_hh_kernel`, `lstm_bgrad_kernel`);
* **on the host** — the projection `cat -> y` and its backward. It is a single GEMM with no
  recurrence, so it is cheap, and both paths now share the same code (`cat_from_h`,
  `proj_forward`, `proj_backward_dcat`, `proj_grads`, `split_dcat`).

What that buys on the data path: `feat` from `cnn.forward` is handed straight to
`rnn.forward_device` and `d_feat` goes straight into `cnn.backward` — neither is ever downloaded
or uploaded. Only `enc` (for attention/CTC) and `dy` cross the link, ~0.13 MB at `b=2, T=16`
instead of ~200 MB in host mode.

What it costs: the LSTM weights go up and their gradients come down every batch —
10.5 MB + 10.5 MB for `hidden=256` with two layers and two directions, so **~21 MB per batch**
(measured with `TRBA_PCIE_COUNTER=1`: +20.5 MB per batch). On PCIe 2.0 x4 that is ~13 ms, against
the 181-314 ms of host BiLSTM it replaces, and unlike the host cost it does not grow with
`batch × T` — at `b=8` the saving is ~95 % of the RNN time. In the default configuration, where
the conv weights and their Adam state already live on the device (0.64 MB per batch), those
21 MB become the dominant PCIe consumer; stage 2 makes the LSTM weights, gradients and optimizer
state device-resident the same way and removes them.

Conventions the kernels rely on (identical to the host path, which is why the tests transfer):
`x`/`dx` are `[B, T, D]`; `gates` is `[T, B, 4H]` post-activation; `c`/`h`/`dh_out` are
`[T, B, H]` in **slot order**; `c_prev`/`h_prev` are read from slot-1 of the same trace (slot 0
means zeros), so there are no separate state buffers, no races and no atomics. Kernels take
single-direction pointers plus a `rev` flag and are launched per direction, which keeps
`slot -> tt = rev ? T-1-slot : slot` in exactly one place. Gate order is PyTorch's `(i, f, g, o)`.

The flag is off by default. Verification:

```bash
cargo test --release device_bilstm_matches_host_bilstm -- --test-threads=1   # enc, dx and every gradient
cargo test --release -- --test-threads=1                                     # 36/36
```

`device_bilstm_matches_host_bilstm` compares the device path against the host path for `enc`, `dx`
and all of `g_w_ih`, `g_w_hh`, `g_b_ih`, `g_b_hh` (both directions, both layers) plus the
projection gradients, at a relative tolerance of `1e-4` (fp32 summation order differs: warp
reduction vs a sequential loop). Without a GPU it exercises the CPU mirrors in
`cuda/cpu_backend.cpp`; on the card the same test exercises the real kernels. Training was also
compared end to end from an identical checkpoint: host path `loss 3.2462 (attn 3.1772 ctc 3.4218)`,
device path `loss 3.2463 (attn 3.1773 ctc 3.4219)` (the ~1e-4 gap is fp32 reassociation: the
weight-gradient kernels sum with four independent accumulators instead of one dependent chain).

SM occupancy: the forward kernel launches `B*H` warps (65 536 threads at `b=8, hidden=256`) and the
weight-gradient kernels launch `4H*D` / `4H*H` threads, so those fill all 56 SMs. The two per-slot
backward kernels are bounded by the recurrence itself — one step has exactly `B*H` independent
units of work — so they occupy `B*H/256` and `B*(D+H)/256` blocks: 8 and 24 at `b=8`, 32 and 128
at `b=32`. A bigger batch fills the card; filling it at a small batch needs a parallel scan over
time, which is a later stage.

Do not read speed from a CPU-backend run: there the device path is scalar mirror code and is
*slower* than the host path. It checks correctness, not performance.

## Muon instead of Adam

Matrices are optimised with **momentum-free Muon** (`src/conv2d.rs::muon_update` semantics, now
used everywhere), vectors — biases and BN `gamma`/`beta` — stay on Adam, for which Muon degenerates
into normalised SGD. Per matrix `[rows, cols]`:

```text
scale  = min( sqrt(min(rows,cols)) / ||g||_F , 10 )
lr_eff = lr * sqrt(max(rows,cols))          # autoscale, TRBA_MUON_AUTOSCALE=0 disables
w     -= lr_eff * scale * g ;  w *= 1 - lr*wd   # weight decay is decoupled
```

The autoscale is not cosmetic: since `n = rows*cols`, the per-element step magnitude works out to
`lr` — the same order as Adam. Without it the step would be 23-32x smaller (for 1024x512) and
training would crawl.

The conv weights (42.15M, device-resident) go through the same maths on the GPU:
`muon_step_f32_kernel` computes the scale from a device-side f64 norm scalar, so **no byte returns
to the host and no sync is needed**. Muon keeps no state, therefore `m`/`v` are not allocated at
all: **-338 MB of VRAM**, and checkpoints shrank from 553 324 344 to **184 591 952 bytes** (3x
smaller), which matters with `--ckpt-every-batch`.

The global `clip_grad_norm_(5.0)` runs only for the first `--clip-warmup` steps (default 500):
after that the Muon normalisation with its cap bounds the step, and skipping the clip also removes
one device sync per batch. `Adam::sum_sq` and `Adam::scale_grads` are parallel and stay
bit-compatible with the device-side sum (the existing pipeline test compares them at 1e-12).

Measured on `clip_adam` (sandbox, 2 cores, `b=2, img_w=128`, conv weights on the host — the worst
case; in the default configuration the conv weights are on the device and the host part is much
smaller):

| configuration | `clip_adam` ms/batch |
|---|---|
| Adam as it was (f64 per element, single thread, clip always) | **392.17** |
| Adam, but parallel (`TRBA_OPT=adam`) | 177.30 |
| **Muon fp32, clip during warmup** | **60.32** |
| **Muon fp32, clip off (steady state)** | **40.37** |
| MuonQ int8/128, clip off | 121.03 |

That is 392 -> 40 ms, 9.7x, on 2 cores; the parallel part scales with cores, so the absolute
numbers on your machine will be lower and the ratio similar.

### MuonQ is a regulariser here, not a speedup

`TRBA_MUON_Q=1` quantises the gradient to int8 with a scale per `TRBA_MUON_Q_BLOCK` (default 128)
elements, `max|g|/127`, half-away rounding. `||g||_F^2` is then computed as `sum(s_b^2 * sum(q^2))`
with the inner sum in **i64** — exactly, so the norm no longer depends on fp32 summation order.
Quality is checked by `muon_q_block128_tracks_fp32_muon`: cosine between the fp32 and int8 update
directions is 0.999994 on a 37x259 matrix with one block deliberately 40x larger than the rest
(per-tensor scaling breaks on that shape, per-block does not).

But on the host MuonQ is **slower** than fp32 Muon (140.85 vs 60.32 ms/batch), and the reason is
concrete: the gradient already sits in RAM as fp32, so quantising adds two passes (block max, int8
store) and the cheaper final read does not pay for them. The "less memory, more cache hits" argument
applies when the gradient is *stored or transported* in int8 rather than quantised in place — and
this project has exactly one such place, the important one: PCIe. With stage 2 of the GPU-RNN plan
the LSTM weight gradients travel device->host, 10.5 MB per batch; as int8 that is 2.6 MB, so MuonQ
turns from overhead into ~8 MB per batch of savings (~5 ms on PCIe 2.0 x4). The quantisation noise
as a regulariser stands regardless of transport.

So: `TRBA_MUON_Q=1` is off by default, switch it on deliberately and compare CER.

```bash
cargo test --release muon -- --test-threads=1     # 3 tests: formula, MuonQ, device kernel
TRBA_OPT=adam TRBA_PROFILE=1 ./target/release/trba-rust ...   # A/B against the old optimiser
```

If the loss rises instead of falling, the first things to change are `TRBA_MUON_CAP` (e.g. down to
1.0) and a longer clip (`--clip-warmup 5000`).

## Debugging a GPU fault

`TRBA_CUDA_DEBUG_SYNC=1` synchronises after every launch and memcpy and attributes the fault
to the launcher that caused it:

```bash
TRBA_CUDA_DEBUG_SYNC=1 ./target/release/trba-rust train.csv --smoke 2 --batch-size 4 --img-w 256
# [CUDA FATAL] cuda/kernels.cu:611: the kernel/memcpy launched just above faulted:
#              an illegal memory access was encountered
```

Without it the same fault surfaces wherever CUDA next happens to touch the driver — a
`cudaFree` or a `cudaMemcpyAsync` hundreds of launches later, which is how it ends up
looking like the memory manager is broken. It costs a few × in speed, so use it to locate a
crash, not for training. `compute-sanitizer --tool memcheck ./target/release/trba-rust …`
gives the same answer with the exact kernel and address.

Low-RAM boxes: every unit test builds the full 42M-parameter model, so run
`cargo test --release -- --test-threads=1` if the parallel run gets OOM-killed.

## Checking kernel logic without a GPU

`tools/kernel_logic_check.cpp` re-implements the tiling, the bounds guards and the barrier
schedule of the CUDA kernels on the CPU and compares them against a naive reference
(16 checks, ~2 s, needs only g++). It catches the class of bug the CPU backend cannot see:
uncovered output tiles, reads past the padded operands, divergent `__syncthreads()`.

```bash
make -f tools/Makefile logic    # CPU-side index arithmetic
make -f tools/Makefile cuda     # just compile cuda/kernels.cu (nvcc, no GPU needed)
```

## Toolkit notes

* glibc ≥ 2.41 (Debian 13, Ubuntu 25.10+) declares `sinpi`/`cospi` in a way that CUDA ≤ 12.9
  rejects in the host pass. `build.rs` detects the failure and retries `nvcc` with
  `-Xcompiler -U_GNU_SOURCE`; nothing in this project uses those functions.
* The static runtime is `libcudart_static.a` (there is no `libcudart.a`), and it needs
  `libculibos.a`. `TRBA_CUDA_SHARED_RT=1` links `libcudart.so` instead.
* `TRBA_CUDA_ARCH` accepts a list (`"75;86;89"`); one PTX image is embedded for the newest
  entry so unseen GPUs can be JITted. Without it `build.rs` asks `nvidia-smi`, and failing
  that builds a 75/86/89 fatbin.

---

## Экспорт в ONNX (fp32 и INT8-QDQ) — `src/onnx.rs`

Экспорт идёт из тех же весов, что и `--infer`, поэтому граф можно сверить
побайтово. Сериализатор protobuf собственный, Python/torch не нужны.

```bash
cargo run --release -- imgs.csv "" exp/ --charset cs.txt --img-h 32 --img-w 128 \
    --hidden 256 --max-len 16 --export-onnx model.onnx --onnx-ref exp/onnxref

# INT8-QDQ (QuantizeLinear/DequantizeLinear по шкалам QAT) — для тензорных ядер
cargo run --release -- imgs.csv "" exp/ --charset cs.txt --export-onnx model_int8.onnx \
    --onnx-int8 --onnx-calib 64 --onnx-ref exp/onnxref
```

Флаги: `--onnx-layout nhwc|nchw` (по умолчанию `nhwc` — совпадает с тем, как
`load_image_q` реально кладёт пиксели), `--onnx-int8`, `--onnx-no-decoder`
(энкодер+CTC), `--onnx-ref DIR`, `--onnx-debug`, `--onnx-calib N`.

| граф | узлов | размер |
|---|---|---|
| fp32, энкодер | 188 | 181.4 МБ |
| fp32, энкодер + декодер | 641 | 184.2 МБ |
| INT8 QDQ | 272 (28 пар Q/DQ) | **55.0 МБ (3.3×)** |

Вход/выход: `input [batch,32,128,3]` → `feat [batch,16,512]` →
`enc [batch,16,256]` → `ctc_logits` + `logits [batch,max_len+1,C]` + `pred`.
BatchNorm свёрнут в Conv, batch динамический (`dim_param`), attention-декодер
развёрнут с автокорректной обратной связью через `OneHot`.

Сверка `tools/check_onnx_export.py exp/onnxref model.onnx charset.txt`:
numpy ↔ onnxruntime 2.9e-7…8.1e-7 по блокам; Rust(int8 QAT) ↔ onnxruntime —
CTC argmax 64/64, логиты декодера argmax 68/68; на случайных весах текст
совпадает буквально (проверка авторегрессионного цикла). Для QDQ-графа порог
другой: `rel ≈ 8.6e-2` при `cos 0.99993` — это нормальное поведение int8, а не
ошибка экспорта.

---

## MoPE — смесь предобученных экспертов (по ZAYA1-8B) — `src/moe.rs`

Отдельная реализация, существующую модель не переписывает. Источник:
ZAYA1-8B Technical Report, arXiv:2605.05365v1 (Zyphra), §II-A1…A3, §VI.
Эксперт здесь — **целая предобученная модель** на своём писаре/уставе;
две модели под одним роутером = два писаря, 256 моделей = 256 писарей.

Перенос терминов: токен ↔ строка рукописи, residual stream ↔ mean⊕max пул
признаков CNN (`d_in = 1024` из одного прогона опорной CNN). Дословно
перенесены уравнения роутера (1)–(4) с EDA `r += γ·r_prev`, PID-балансировка
(5) `∇b_e = p_e − 1/E` через AdamW с контролем `H(p)/ln E`, learned residual
scaling (6) `α·x + β`, CCA со сжатием запросов 2× и KV 8×, и Markovian RSA
(N кандидатов → T раундов по C ≤ N хвостов длиной τ, `T=0` → Best-of-N,
`C=1` → Delethink, штатно (16,4,2)).

```bash
# 1) конвертировать чужую предобученную модель в бандл эксперта
python3 tools/mope_import.py trba_base_g1.onnx --out base.mope \
        --charset trba_base_g1.txt --config trba_base_g1.json --merge-charset

# 2) или выгрузить свой чекпоинт trba-rust в тот же формат
cargo run --release -- imgs.csv "" exp/ --charset cs.txt \
        --mope-export-bundle kurrent.mope

# 3) Franken-MoE: эксперты разного происхождения, геометрии и словаря
cargo run --release -- imgs.csv labels.txt exp/ \
    --charset /media/korziner/14ext4/trba/trba_kurrent/charset.txt \
    --mope --mope-experts base.mope,kurrent.mope \
    --mope-char-counts /media/korziner/14ext4/trba/trba_kurrent/train.csv \
    --mope-min-freq 3 --mope-charset-max 256 --mope-charset-out merged.txt \
    --mope-n 2 --mope-c 2 --mope-t 1 --mope-tau 4 --mope-cache 8 \
    --mope-save-router exp/router.bin
```

Флаги: `--mope-experts a.mope,b.bin,…` (бандлы `MOPEXP02` и чекпоинты trba-rust
можно смешивать), `--mope-{n,c,t,tau}` — RSA, `--mope-topk`, `--mope-temperature`,
`--mope-topp`, `--mope-beta`, `--mope-router-r`, `--mope-{lr,wd,balance-lr}`,
`--mope-pid-{b1,b2,eps}`, `--mope-cache` (сколько экспертов резидентно),
`--mope-save-router/--mope-load-router`, `--mope-limit`.

Общий словарь: `<PAD> <SOS> <EOS>` всегда на 0..2; символ входит при суммарной
частоте ≥ `--mope-min-freq` (3 или 7); без статистики символы не теряются; при
превышении `--mope-charset-max` отсекаются наименее частотные. Строки CTC-головы
и генератора переносятся в общий словарь, чужие строки обнуляются: эксперт не
может выдать символ, которого не было в его разметке, и роутер это видит.
Разные размерности (hidden, число слоёв BiLSTM, размер входа) дружатся
обучаемыми адаптерами, тождественными при совпадении размеров; каждый эксперт
считает в своей геометрии.

Память (честная арифметика): эксперт ≈ 45M параметров = 180 МБ fp32 /
**45 МБ int8**. 256 экспертов = 11.5 ГБ int8 — на 10 ГБ карту не помещается,
поэтому int8-хранилище в хосте, а в VRAM резидентно `--mope-cache` штук с LRU;
подмена одного эксперта ≈ 28 мс по PCIe 2.0 x4. 8–16 экспертов входят спокойно.

Канал переноса знаний: роутер обучается на сигнале «лучший из всех моделей»
(`targets_from_losses`/`targets_from_best`/`targets_from_rsa` — softmax(−loss/T),
one-hot лучшего, кредит экспертам, чьи кандидаты попали в промпты и финал),
а агрегатор подмешивает свой контекст в память декодера дополнительным шагом,
поэтому его градиент даёт существующий attention-декодер.

Стадия обучения на harness (в ZAYA1-8B она обязательная) собрана в
`--mope-train` — см. следующий раздел. Ограничение конвертера прежнее:
`trba_lite_*` (depthwise CNN) отклоняется с объяснением, чтобы не раздувать
37 МБ в сотни МБ плотными свёртками.

## Franken-MoPE: дообучение после конвертации — `--mope-train`

Ответ на вопрос «создал два `.mope` — что делать дальше». Дальше одна команда
дообучает **всю надстройку** над замороженными экспертами и кладёт её в один
файл, который инференс подхватывает целиком.

| что учится | зачем | параметров (2 эксперта, словарь 97) |
|---|---|---|
| роутер: `W_down`, γ, MLP, `bias` | выбирать писаря «от всех моделей беря лучшее» | 394 245 |
| PID-балансировка загрузки (ур. 5) | не сваливаться в одного эксперта | состояние `m`,`v`,`t` |
| агрегатор: token/segment/position-эмбеддинги, CCA (сжатие Q 2×, KV 8×), два Res-scale `α·x+β` (ур. 6) | собрать промпт из хвостов кандидатов и улучшить ответ | 293 760 |
| адаптеры размерностей `feat_ad`, `ctx_ad` | дружить экспертов с разным `hidden`/`feat_dim` | 535 712 (тождественные не учатся и не тратят время) |

Не учится ничего из самих экспертов: 86 181 188 параметров остаются в int8
ровно такими, как пришли из `.mope`, оптимизатор по `Model` не шагает никогда.

Учитель — настоящая разметка из `train.csv`, а не скоры собственных кандидатов.
Цель роутера: `softmax(−CE_учителя/T)` по экспертам (`--mope-target soft`, по
умолчанию) или one-hot лучшего (`hard`). Именно поэтому перенос знаний перестаёт
быть самооценкой — сигнал приходит снаружи.

### Полный цикл

```bash
D=/media/korziner/14ext4/trba/trba_kurrent

# a) конвертация: чужая ONNX/PyTorch модель → .mope
python3 tools/mope_import.py trba_base_g1.onnx --out base.mope \
        --charset trba_base_g1.txt --config trba_base_g1.json \
        --merge-charset --char-counts-csv $D/train.csv
# свой чекпоинт trba-rust → .mope (тот же формат MOPEXP02)
cargo run --release -- $D/train.csv "" exp/ --charset $D/charset.txt \
        --resume exp/checkpoint_last.bin --img-h 64 --img-w 256 \
        --mope-export-bundle kurrent.mope

# b) ДООБУЧЕНИЕ роутера и всей надстройки (эксперты заморожены)
cargo run --release -- $D/train.csv $D/val.csv exp/ --charset $D/charset.txt \
    --mope --mope-train --mope-experts base.mope,kurrent.mope \
    --mope-char-counts $D/train.csv --mope-min-freq 3 --mope-charset-max 256 \
    --epochs 3 --mope-target soft --mope-lr 3e-4 --mope-agg-lr 3e-4 \
    --mope-balance-lr 1e-3 --mope-n 4 --mope-c 2 --mope-tau 8 \
    --mope-cache 8 --mope-save-franken exp/franken.bin

# c) инференс на выученном состоянии (Best-of-N + Markovian RSA)
cargo run --release -- $D/val.csv "" exp/ --charset $D/charset.txt \
    --mope --mope-experts base.mope,kurrent.mope --mope-franken exp/franken.bin \
    --mope-char-counts $D/train.csv --mope-min-freq 3 --mope-charset-max 256 \
    --mope-n 4 --mope-c 2 --mope-t 2 --mope-tau 8 --mope-cache 8
```

Продолжить обучение с сохранённого состояния — тот же шаг (b) плюс
`--mope-franken exp/franken.bin`: подхватятся словарь, веса, PID и Adam-моменты,
а счётчик шагов продолжится (проверено: 12 шагов → 24, лосс агрегатора пошёл
вниз с того места, где остановился: 4.5333 → 4.5005 → 4.4938).

`--mope-char-counts`, `--mope-min-freq` и `--mope-charset-max` в (b) и (c)
обязаны совпадать: от них зависит объединённый словарь, а значит размеры роутера
и агрегатора. При расхождении программа не падает: печатает обе цифры, сообщает
о несовпадении размеров и работает с тем, что было.

### Один файл состояния — контейнер `MOPEFR01`

`--mope-save-franken` пишет 9.60 МБ (2 эксперта, словарь 97): словарь, роутер
(`W_down`, γ, MLP, `bias`), PID (`m`, `v`, `t`), агрегатор целиком (эмбеддинги,
CCA, оба Res-scale), адаптеры признаков и контекста по числу экспертов и
состояние Adam агрегатора. До этого `save_aggregator` не вызывался никогда,
адаптеры не сериализовались вовсе, и обучать их было некуда сохранить — теперь
артефакт один, и инференс читает его целиком. Побитовость сохранения покрыта
тестом `franken_state_roundtrips_bitwise`, порядок тензоров Adam — тестом
`aggregator_adam_covers_every_trainable_tensor` (16 тензоров, сумма размеров
равна `params()`, меняются только тензоры с градиентом).

### Что печатает обучение

```
🎓 дообучение Franken-MoPE: 6 обучающих строк (пропущено 0), 6 контрольных, 9 шагов декодера, 2 эпох
   учатся: роутер (lr 0.0003, цель soft) · PID-балансировка (lr 0.001) ·
           агрегатор+CCA+Res-scale (lr 0.0003) · адаптеры размерностей (1 шт. обучаемых)
   эксперты ЗАМОРОЖЕНЫ: 86181188 параметров в int8, их веса оптимизатором не трогаются
Эпоха 1/2 | 12 с | роутер 0.7857 | агрегатор 4.5733 (6 шагов) | выбор роутера 4.5732 | оракул 4.5679 | попадание в оракула 50.0% | H(p)/ln E 0.918
   📏 контроль (6 строк): оракул 4.5679 | выбор роутера 4.5796 | разрыв +0.0117 | совпадение с оракулом 16.7%
```

* **роутер** — CE против цели «лучший из всех моделей»; для 2 экспертов
  равномерное угадывание даёт ln 2 = 0.693;
* **агрегатор** — CE агрегированного ответа против настоящей разметки;
* **выбор роутера / оракул** — CE выбранного эксперта против CE лучшего:
  разрыв и есть цена ошибки маршрутизации, главная метрика всей затеи;
* **попадание в оракула** — доля строк, где роутер выбрал именно лучшего;
* **H(p)/ln E** — нормированная энтропия загрузки (1.0 = равномерно, Fig. 4
  отчёта ZAYA1); PID держит её высокой, итоговый `bias` печатается отдельно.

### Память и скорость

Материализованный эксперт — fp32-веса, градиенты и Adam-моменты свёрток,
≈700 МБ на 43M параметров, поэтому пик памяти = `--mope-cache` × модель.
Раньше `ExpertCache::get` сначала создавал нового эксперта и только потом
вытеснял старого, из-за чего пик был `cap + 1`: при `--mope-cache 1` в памяти
жили два эксперта сразу. Замер в песочнице (2 ядра, 2 ГБ): пик RSS 1515 МБ и
OOM-kill на 4 строках → после исправления 908 МБ и прогон проходит, RSS
не растёт от образца к образцу. На 10 ГБ CMP 50HX это разница между 13 и 14
резидентными экспертами, в хосте — между «прошёл» и «убит».

Шаг обучения — проход по всем экспертам (энкодер + teacher-forced декодер),
плюс C хвостов и один агрегированный проход; при подмене экспертов это дорого,
поэтому на обучении ставьте `--mope-cache` не меньше числа экспертов.

**Сколько стоит эпоха (проекция, не замер на вашей карте).** Дороже всего —
последовательные декоды: на шаг обучения их `E` (teacher-forced, по одному на
эксперта) + `N` (кандидаты) + `C` (хвосты) + 1 (агрегированный). При `E=2,
N=4, C=2` это 9 декодов на строку. Замеренная ранее скорость `--infer` на CMP
50HX — 4.81 картинки/с, то есть ≈0.21 с на один жадный декод в геометрии
32×128; отсюда ≈1.5–1.9 с на строку и **≈90–110 часов на эпоху по всем 214049
строкам** `train.csv`. Практичный вариант: учить на подвыборке (`--mope-limit
20000` — теперь это явный, предупреждаемый лимит, ≈8–11 часов) или удешевить
шаг (`--mope-n 2 --mope-c 1` — Delethink, ≈4 декода на строку, вдвое-втрое
быстрее). В песочнице тот же шаг на двух ядрах CPU стоил ≈4 с (замер: 47.5 с
на 12 шагов с `--mope-cache 1`, где заметную долю съедают подмены экспертов).

### Поведение, которое стоит знать

* **Инференс больше не доучивает роутер по умолчанию.** Исторически `--mope`
  шагал Adam'ом роутера и PID прямо во время распознавания, потому что другой
  цели, кроме скоров собственных кандидатов, не было. Теперь при загруженном
  состоянии роутер и PID **заморожены**: прогон воспроизводим (два прогона с
  одним `--seed` дают идентичные тексты и одинаковый лосс), а выученная на
  разметке политика не размывается сигналом без учителя. Прежнее поведение —
  `--mope-adapt`; без загруженного файла всё как раньше.
* **Лосс роутера в отчёте инференса и в отчёте обучения — разные величины**:
  в инференсе цель строится по скорам кандидатов (учителя там нет, `--infer`
  его не читает), в обучении — по CE настоящей разметки. Сравнивать их между
  собой нельзя, в подписи это теперь сказано явно.
* **`--mope-limit`** по умолчанию 4 — «быстрый просмотр» для инференса. В
  `--mope-train` дефолт не применяется (учим на всём датасете), а явно заданный
  лимит сопровождается предупреждением.
* **EDA (γ·r_prev) не задействована**: один образ = одно решение роутера,
  последовательности состояний роутера нет, поэтому γ остаётся нулевым и
  градиента не получает; отчёт честно печатает `γ=0.000`.
* **Эксперты действительно не меняются**: после обучения md5 обоих `.mope`
  совпадает с исходным, а жадные кандидаты Best-of-N в прогоне с
  `--mope-franken` и без него побитово одинаковы — совпадают и тексты, и скоры
  до четвёртого знака.
* **Замер из песочницы** (6 синтетических строк, два игрушечных эксперта
  32×128 с hidden 64 и 96, CPU-бэкенд, 2 потока): роутер 0.8216 → 0.7332 →
  0.7088 → 0.6993 за 4 эпохи, агрегатор 4.5791 → 4.5726 → 4.5621 → 4.5031.
  Контроль здесь — те же 6 строк, что и обучение, поэтому его цифры **не**
  оценка обобщения; на настоящем датасете `train.csv` и `val.csv` разделены.
  Абсолютные значения близки к ln 97 = 4.575, потому что игрушечные эксперты
  текст почти не читают: замер доказывает работу plumbing'а, а не качество.

---

---

## Постепенный рост геометрии — `--resume`, `--grow-ladder`, `--inspect-ckpt`

Обученную на `32×128` модель можно продолжить на `64×256` (и сделать
выразительнее: `hidden 256 → 384`, третий слой BiLSTM), **переиспользуя веса**.
Свёртки, BN, SE и BiLSTM от размера картинки не зависят — формы весов
определяют только `hidden`, `classes`, `rnn_layers` и выход CNN, поэтому рост
разрешения переносится бесплатно (138 тензоров из 138 копируются как есть), а
рост `hidden` делается хирургией из `src/surgery.rs` по правилам
Net2Net/Net2WiderNet: новые строки — дубликаты существующих, новые столбцы —
нули (`--surgery-eps 0`, выход сети сохраняется побитово) либо малый шум
(`--surgery-eps 0.01` по умолчанию — новые ячейки сразу получают градиент).

```bash
D=/media/korziner/14ext4/trba/trba_kurrent

# что в чекпоинте и как он ляжет в новую геометрию (мгновенно, без обучения)
cargo run --release -- $D/train.csv "" exp/ \
    --inspect-ckpt exp/checkpoint_last.bin --img-h 64 --img-w 256 --max-len 40

# одна ступень роста обычным --resume
cargo run --release -- $D/train.csv $D/val.csv exp/ --epochs 20 \
    --resume exp/checkpoint_last.bin --img-h 64 --img-w 256 --max-len 40

# лестница ступеней одной командой: каждая продолжает предыдущую
cargo run --release -- $D/train.csv $D/val.csv exp/ --epochs 30 \
    --grow-ladder "48x192:5,64x256:10,64x256h384:15"
# слепок каждой ступени: exp/checkpoint_stage01_48x192h256.bin …

# рост выразительности без роста разрешения
cargo run --release -- $D/train.csv $D/val.csv exp/ \
    --grow-ladder "32x128h384:10,32x128h512L3:10"
```

Спецификация ступени: `HxW[hNNN][LNN][mNN]:эпохи` (`h` — hidden, `L` — слоёв
BiLSTM, `m` — max_len); ступень наследует предыдущую. Каждая ступень идёт
отдельным процессом: память прошлой геометрии гарантированно освобождена, а
падение ступени прерывает лестницу, чтобы рост не продолжился из неполных весов.

При любом изменении геометрии счётчик эпох и шагов оптимизатора сбрасывается,
поэтому `--epochs N` — это бюджет **ступени**, а warmup и bias-correction Adam
отрабатывают заново; моменты тензоров, скопированных без изменений,
переносятся как есть, а у изменённых обнуляются. Если геометрия совпала и
обучать нечего, об этом говорится прямо.

Формат чекпоинта **V6** хранит геометрию и имена тензоров; **V5/V4 читаются**:
имена восстанавливаются по порядку манифеста, а геометрия выводится из форм
(`ctc.b` → classes, `attn.h2h.b` → hidden, число `rnn*.proj.b` → слои,
`rnn0.f.w_ih / 4h` → feat_dim). Разрешение в V4/V5 не записывалось, и на формы
весов оно не влияет.

Замерено: рост `hidden 64 → 96` с `--surgery-eps 0` даёт **побитово те же**
компоненты лосса на том же батче (attn 4.9369, ctc 8.8665), хотя параметров
стало вдвое больше; с `eps = 0.05` дрейф ~1e-4. Рост входа `32×128 → 64×256` —
138 тензоров скопировано, 0 изменено.

Рекомендации по ступеням (проверено A/B, см. `BUGFIX_REPORT.md` §17.1): ступени
роста разрешения делайте короткими (`32×128 → 48×192 → 64×256`), бюджет ступени
— не менее 10–20 эпох, `max_len` растите вместе с `img_w` (`32x128m8 →
64x256m16`), чтобы плотность кадров на символ не менялась скачком. Контроль форы:
лосс **первой** эпохи новой ступени должен начинаться ниже, чем у прогона с нуля
в той же геометрии. Adam-моменты при смене геометрии не переносятся — иначе
поправка на смещение `m/(1-β1^t)` при сброшенном `t` сделала бы первый шаг в ~9
раз крупнее обычного.

---

## Рецепт 8. Два предобученных эксперта → MoPE на вашей CUDA-машине (sm_75)

В `experts/` лежат **два настоящих эксперта**, обученных на разных подмножествах
`dh-unibe/image-text_bullinger-autoren-lines` (строки авторов Bullinger). Оба —
с узким энкодером `--feat-dim 128` (каналы 16/32/64/64/128/128, 2.63M conv-весов
против 42.15M у исторической ширины 512), геометрия 32×160, max_len 40, hidden 64,
2 эпохи, batch 4:

| файл | обучающих строк | свой словарь | int8 | после `zstd -22` |
|---|---|---|---|---|
| `experts/bull_a.mope.zst` | 200 (seed 7, loss 3.1359) | 64 токена | 2.93 МБ | 2.93 МБ (1.001×) |
| `experts/bull_b.mope.zst` | 400 (seed 11, loss 2.9507) | 68 токенов | 2.93 МБ | 2.93 МБ (1.001×) |
| `experts/franken.bin.zst` | результат связки (50 строк, 2 эпохи) | общий 70 | 2.87 МБ | 2.53 МБ (1.133×) |

Для сравнения: те же эксперты при исторической ширине 512 весили 43.00 МБ каждый
(fp32-двойник 171.7 МБ), связка — 9.56 МБ, обучение A занимало 574 с вместо 58 с,
B — 1174 с вместо 115 с. То есть `--feat-dim 128` даёт **14.7× меньше места и
10× меньше времени** при сопоставимом лоссе на этих объёмах данных (3.1359 против
3.1076 у A, 2.9507 против 2.8288 у B).

Сжатие int8-контейнера `MOPEBI01` даёт 1.001×: энтропия квантованных весов
7.99 бит/байт, нулей 0.40 % — сжимать нечего. Размер экономит сам int8 (ровно 4×
против fp32), а не архиватор. `franken.bin` сжимается до 1.133× — в нём fp32
веса роутера/агрегатора и состояния Adam.

### 8.1 Распаковать и собрать под sm_75

```bash
cd ~/Downloads/195a.ZIP/trba-rust      # или ~/deb/INT8/trba-rust
zstd -d -k experts/bull_a.mope.zst experts/bull_b.mope.zst experts/franken.bin.zst
TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release
```

### 8.2 Связать два эксперта в MoPE

Обучаются только роутер, PID-балансировка, агрегатор (CCA + Res-scale) и адаптеры;
эксперты заморожены. Обратите внимание на `--feat-dim 128` — он обязан совпадать
с геометрией экспертов:

```bash
D=data/bull40
target/release/trba-rust \
  $D/mope_train.csv $D/mope_val.csv exp_mope \
  --charset $D/charset_all.txt --img-h 32 --img-w 160 --max-len 40 --hidden 64 \
  --feat-dim 128 \
  --mope --mope-train \
  --mope-experts experts/bull_a.mope,experts/bull_b.mope \
  --mope-char-counts $D/a_train.csv,$D/b_train.csv \
  --mope-min-freq 1 --mope-charset-max 256 \
  --epochs 2 --mope-limit 20 --mope-target soft \
  --mope-n 4 --mope-c 2 --mope-tau 8 --mope-cache 2 \
  --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
  --mope-save-franken experts/franken.bin --seed 7
```

Словари экспертов **разные** (64 и 68 токенов) — это рабочий случай: программа
печатает `⇄ эксперт 1 отличается от 0: словарь 68 против 64 токенов`, строит общий
словарь (70) и держит каждого эксперта в его собственной нумерации, а непокрытые
символы оплачиваются через `moe::penalized_ce` (штраф `ln(classes)`).

Проверенный прогон (2 ядра CPU, 50 строк, 2 эпохи, 40 шагов) — **3.9 с**:

```
🔤 общий словарь: 70 токенов (порог частоты 1, предел 256); выброшено по экспертам: [0, 0]
🧠 MoPE: 2 экспертов → int8 за 0.0 с (2 МБ/шт, 2 907 152 параметров)
Эпоха 1/2 | роутер 0.7207 | агрегатор 3.8666 | Эпоха 2/2 | роутер 0.6996 | агрегатор 3.8181
💾 Franken-MoPE: experts/franken.bin (2.87 МБ)
```

На CMP 50HX та же связка при ширине 512 заняла 13.2 с (роутер 0.6583→0.6131,
попадание в оракула 95→100 %, IMMA `WMMA m16n16k16`, 56 SM, 0.09 ГБ из 10 ГБ).

Стоимость на полном датасете: при E=2, N=4, C=2, T=2 один шаг — 9 проходов
декодера, поэтому на 214 049 строках эпоха идёт десятки часов. Рабочий режим —
`--mope-limit 2000…20000` либо `--mope-n 2 --mope-c 1`.

### 8.3 Инференс готовой связкой

Контейнер `MOPEFR02` хранит геометрию раундов RSA, поэтому `--mope-n/-c/-t/-tau`
можно не передавать — они подставятся из файла:

```bash
target/release/trba-rust $D/mope_val.csv "" exp_inf \
  --charset $D/charset_all.txt --img-h 32 --img-w 160 --max-len 40 --hidden 64 \
  --feat-dim 128 \
  --mope --mope-experts experts/bull_a.mope,experts/bull_b.mope \
  --mope-franken experts/franken.bin --seed 7 --mope-limit 8
```

Проверено: `🔀 геометрия раундов из файла: N=4 C=2 T=2 β=40 τ=8 temperature=1
(свои RSA-флаги не заданы)` — и никакого предупреждения о C·τ. Если свои флаги
всё же заданы, они побеждают, а программа печатает сравнение с файлом.
Файлы старой версии `MOPEFR01` читаются, но геометрию приходится задавать флагами
(программа скажет об этом явно).

Распознавание при этом осмысленным не будет: эксперты обучены на 200 и 400 строках
за 2 эпохи, это демонстрация механики MoPE, а не рабочая модель письма.

### 8.4 `--feat-dim` — ширина энкодера

Все размеры выводятся из одного числа: `SEResNetQ::widths(fd)` даёт
`[fd/8, fd/4, fd/2, fd/2, fd, fd]`, при fd=512 это историческая архитектура
64/128/256/256/512/512. Ширина хранится в геометрии чекпоинта и в `ExpertSpec`,
поэтому `--resume`, рост по `--grow-ladder` и MoPE подхватывают её сами.

| `--feat-dim` | conv-весов | 8 изображений, 2 батча (2 ядра CPU) | статус |
|---|---|---|---|
| 512 | 42.15M | 21.3 с | историческая ширина |
| 256 | 10.54M | 5.3 с | работает |
| 128 | 2.63M | 1.3 с | работает, поставочные эксперты |

Раньше fd<512 падал с SIGSEGV: в `SEResNetQ::forward`/`backward` размеры
стебельных активаций были зашиты как `b * 64 * h * w`, `b * 128 * h * w` и
`128` в вызовах maxpool — это каналы исторической ширины. Локализовано по стеку
в gdb (`thread apply all bt`: поток OpenMP не показывает вызывающего, а основной
поток показывает `qnet.rs:1104 relu_quant_owned ← qnet.rs:1551 forward`).
Теперь там `self.c0.out_c` / `self.c1.out_c`; разбор — `BUGFIX_REPORT.md` §20.11–20.12.

### 8.5 `--build-charset` — словарь из CSV без внешнего конвертера

```bash
target/release/trba-rust --build-charset train.csv,val.csv --charset charset.txt
```

Формат результата ровно тот, что читает `load_charset`: `<PAD>`, `<SOS>`, `<EOS>`
и далее по одному символу на строку в порядке кодовых точек. Строки разбираются
тем же `parse_csv_line`, что и при обучении, а заголовок вида `filename,text`
распознаётся и пропускается — иначе символы слова «filename» молча попали бы в
словарь. Несколько CSV перечисляются через запятую (общий словарь для связки).

### 8.6 `TRBA_AVX` — уровень векторизации CPU-бэкенда

```bash
TRBA_AVX=1 RUSTFLAGS="-C target-feature=+avx" cargo build --release       # AVX1, 128 бит
TRBA_AVX=2 RUSTFLAGS="-C target-feature=+avx2,+fma" cargo build --release  # AVX2+FMA
```

`TRBA_AVX` добавляет `-mavx` / `-mavx2 -mfma` к компиляции `cuda/cpu_backend.cpp`;
Rust-часть собирается тем же уровнем через `RUSTFLAGS` (build script не вправе
менять флаги rustc, кроме `-L`/`-l`). Замер: SSE2 `.text` 1 761 980 Б / 22.6 с на
батч → AVX1 1 772 668 Б (+0.61 %) / 20.2 с → AVX2 1 791 292 Б (+1.66 %) / 19.0 с.
Подробности и таблица соответствия INT8-приёмам эталонной статьи — §21 отчёта.

### 8.7 Если нужны полноразмерные эксперты (fd=512)

Та же команда обучения без `--feat-dim` (на GPU минуты):

```bash
D=data/bull40
target/release/trba-rust $D/a_train.csv $D/val_a.csv exp_a --charset $D/charset_a.txt \
  --img-h 32 --img-w 160 --max-len 40 --hidden 64 --batch-size 4 --epochs 2 --no-resume --seed 7
target/release/trba-rust $D/a_train.csv "" exp_a --charset $D/charset_a.txt \
  --img-h 32 --img-w 160 --max-len 40 --hidden 64 --mope-export-bundle experts/bull_a.mope --mope-int8
# то же для B: b_train.csv, val_b.csv, charset_b.txt, --seed 11
```

Не смешивайте: `franken.bin`, обученный на fd=512-экспертах (роутер 1024→256),
не подойдёт к fd=128-экспертам (роутер 256→256) — программа обнаружит
несоответствие и откажется подставлять состояние, а не испортит вывод молча.

---

## Рецепт 9. Продолжение MoPE на других датасетах (YeniseiGovReports-HWR, русский)

### 9.1 Что показал прогон на CMP 50HX (sm_75, 56 SM)

Связка из рецепта 8 на GPU заняла **13.2 с** (40 шагов) против 56 с на 2 ядрах CPU,
int8-GEMM шёл через `WMMA m16n16k16 s8*s8->s32` (IMMA), эксперты резидентно
0.09 ГБ из 10 ГБ. Инференс 20 строк — 8.9 с после прогрева (0.4–0.5 с/строка).

Два дефекта, которые видны в том логе:

1. **Подсказка после `--mope-save-franken` была неполной**: она печатала
   `--mope-n --mope-c --mope-t`, но не `--mope-tau`, поэтому инференс уходил на
   дефолты `N=16 C=4 τ=4` и получал `⚠️ агрегатор обучен на промпте C=2·τ=8,
   а запрошено C=4·τ=4` — агрегатор резал хвосты кандидатов не так, как его учили.
   Исправлено: подсказка печатает `--mope-tau` и `--mope-temperature 0`.
   Глубокая причина — контейнер `MOPEFR01` хранит вместимость агрегатора
   (`max_c`, `max_tau`), но не сам `RsaCfg`, поэтому геометрию раундов приходится
   передавать флагами. Перенос `RsaCfg` в контейнер — следующий шаг (`MOPEFR02`).
2. **`--mope-min-freq` по умолчанию 3**, а в рецепте 8 связка строилась с
   `--mope-min-freq 1`. На этом прогоне не сказалось (общий словарь берётся из
   franken-файла), но при пересборке связки флаг надо повторять, иначе словарь
   получится другим.

### 9.2 Почему тексты в выводе — «eee» и каша

Эксперты обучены на **200 и 400 строках** за 2 эпохи (loss 3.11 и 2.83) — это
демонстрационные эксперты: они выучили частотный символ и паузу, а не письмо.
`Best-of-16: expB «eee…» score -2.03` на всех строках и `агрегация улучшила скор
в 0/20` — честное следствие, а не баг связки. Механика MoPE (роутер, PID-баланс,
агрегатор, адаптеры, разные словари) при этом отработала полностью. Чтобы получить
распознавание, нужно обучить экспертов на настоящем объёме — дальше про Енисей.

### 9.3 Енисейские рапорты: от labels.csv до связки

Всё делает `scripts/run_yenisei_mope.sh` (переменные `R`, `N`, `BS`); конвертер —
`tools/yenisei_import.py`. Почему конвертер обязателен:

* trba-rust читает `path,text` **без заголовка** (`parse_csv_line`), а в
  `labels.csv` заголовок `filename,text` есть — он стал бы строкой с картинкой
  `filename`;
* пути разрешаются **относительно каталога CSV** (`load_csv`), а в `labels.csv`
  имена без `img/`;
* неизвестные символы из текста выбрасываются, а текст длиннее `--max-len`
  **обрезается, и строка не пропускается** — молчаливая порча разметки, поэтому
  фильтр (пустые, короче 2, длиннее 40, отсутствующие картинки) делается в
  конвертере и печатается счётчиками;
* charset trba-rust сам не строит: формат — `<PAD>`, `<SOS>`, `<EOS>` и далее по
  одному символу на строку (так устроены `data/bull40/charset_*.txt`).

Порядок шагов и зачем каждый:

| шаг | команда | зачем |
|---|---|---|
| 1 | `tools/yenisei_import.py --root $R --max-len 40` | CSV + charset, счётчики брака |
| 2 | обучение на 500 строках, 1 эпоха | замер с/строку, чтобы не запускать вслепую |
| 3 | обучение эксперта C на N строках, `--epochs 2` | настоящий эксперт; `--resume` режет длинное обучение на части (моменты Adam в чекпоинте) |
| 4 | `--mope-export-bundle experts/yen_c.mope --mope-int8` | контейнер `MOPEBI01`, 4× меньше fp32 |
| 5 | `--mope --mope-train --mope-experts experts/bull_b.mope,experts/yen_c.mope` | связка двух разных датасетов и двух разных словарей |
| 6 | то же + `--mope-franken experts/franken_yen.bin` | **продолжение** с выученного состояния: подставляются роутер, PID, агрегатор, адаптеры и состояния Adam (признак тёплого старта — «шагов обучения 40» и loss роутера ~0.61, а не ~0.66) |
| 7 | инференс с `--mope-n 4 --mope-c 2 --mope-t 2 --mope-tau 8 --mope-temperature 0` | полный набор RSA-флагов, без предупреждения о C·τ |

### 9.4 Правила сочетания экспертов

* **Геометрия одинакова у всех связываемых экспертов**, включая `--feat-dim`:
  у поставочных `experts/bull_*.mope` это 128, значит и вашего эксперта он должен
  быть 128 (иначе роутер получит пул другой ширины и состояние не подставится). Входные картинки
  кодируются одной геометрией из командной строки, поэтому `--img-h/--img-w`
  обязаны совпадать со спеком каждого эксперта; `--max-len` должен быть
  ≤ `max_len` каждого из них (иначе позиционные эмбеддинги декодера вылезут
  за границу). Препроцессинг — RGB → resize с сохранением пропорций → белый
  холст, поэтому кадр 32×160 годится и буллинговской строке 1720×200, и
  енисейскому слову 30×22 (оно просто займёт левую часть кадра).
* **Словари могут отличаться** — каждый эксперт живёт в своей нумерации, общий
  словарь строится из частот (`--mope-char-counts`) и ограничивается
  `--mope-charset-max`; непокрытые символы оплачиваются через
  `moe::penalized_ce` (штраф `ln(classes)`).
* **`--charset` в командной строке должен покрывать тексты обучающих строк
  роутера**, а не словари экспертов. Для смешанных строк обоих датасетов
  соберите объединённый словарь, оставив `<PAD>`, `<SOS>`, `<EOS>` первыми
  тремя строками.
* **Стоимость.** При E=2, N=4, C=2, T=2 один шаг — 9 проходов декодера, поэтому
  на 214 049 строках эпоха идёт десятки часов даже на GPU. Рабочий режим —
  `--mope-limit 2000…20000` либо `--mope-n 2 --mope-c 1`.

### 9.5 Разбор реального прогона на Енисее: почему распознавание было плохим

Прогон `run_yenisei_mope.sh` на CMP 50HX дал `CER 516.8% → 91.7%` и вывод без
кириллицы. Причины по порядку важности:

1. **`--max-len 40` при длине слов p50 = 5.** Декодер проходит все 40 шагов,
   ранний стоп не срабатывает, пока EOS не выучен, поэтому гипотеза в ~8 раз
   длиннее эталона. CER = edit_distance / len(эталон) и **не ограничен сверху**:
   вставки дают больше 100 %. Это не ошибка метрики, а сигнал о неподходящей
   геометрии. Теперь программа печатает средние длины рядом с CER и пояснение,
   а `tools/yenisei_import.py` считает процентили правильно (раньше аккумулятор
   не сбрасывался между p50/p90/p99 и p99 выходил меньше p50). Правильный
   `--max-len` для Енисея — 16…24, и CSV нужно перегенерировать тем же значением:
   строки длиннее `--max-len` конвертер отбрасывает, а загрузчик trba-rust
   обрезает молча.
2. **Общий словарь потерял 6 символов, включая дореформенные** — `+ І Ц Ы і Ѣ`.
   `--mope-char-counts` указывал на первые 20 000 строк, а словарь эксперта был
   построен по всем 109 570: редкие символы в подмножество не попали, получили
   частоту 0 и были отсечены порогом `--mope-min-freq 1`. Ноль здесь — «не
   подтверждено этим корпусом», а не «редкий». Теперь такие токены помечаются
   непроверенными (`u64::MAX/2`) и сохраняются: эксперт не теряет символы, которые
   умеет выдавать. Проверка: на корпусе из 20 строк 21 и 25 токенов получили ноль,
   словарь остался полным объединением (70 токенов, `выброшено по экспертам: [0, 0]`).
3. **Инференс пересчитал общий словарь иначе и отверг состояние**: при обучении
   было `--mope-min-freq 1 --mope-char-counts …` (144 токена), а в команде
   инференса этих флагов не было (150 токенов) ⇒ `⚠️ размеры не совпали …
   работаем с тем, что было` ⇒ роутер и агрегатор остались случайными, отсюда
   `⚠️ агрегатор не обучен` и мусорные раунды RSA. После правки 2 словарь
   устойчив (полное объединение) независимо от корпуса, но флаги словаря всё
   равно нужно повторять — `scripts/mope_menu.sh` делает это сам.
4. **Кириллицы в выводе не было, потому что роутер всегда выбирал эксперта 0**
   (Bullinger, `загрузка экспертов: [50.0, 0.0]`, `s(top-1) = 1.0000`): словарь
   немецкого эксперта кириллицы не содержит в принципе. Причина — пункт 3
   (случайный роутер) плюс 2 эпохи обучения самого енисейского эксперта:
   `acc 0.1%`, CER 91.7 %. Для внятного качества нужны десятки эпох на 109 570
   строках, а не 2 эпохи на 20 000.

Интерактивный помощник вместо линейного скрипта: `bash scripts/mope_menu.sh`
(неинтерактивно — `WHAT=3 GEO=2 FD=1 ROWS=3 MODE=2 bash scripts/mope_menu.sh`).

### 9.6 Корзины по длине: эксперты с разным `--max-len` под одним роутером

Раньше MoPE декодировал всех экспертов одной глобальной длиной (`--max-len`), а
позиционные эмбеддинги декодера у каждого эксперта свои — поэтому смешивать
можно было только экспертов с одинаковым `max_len`. Теперь длина прогона
вычисляется на эксперта: `moe::expert_steps(spec.max_len, global_steps)` берёт
собственный `max_len` эксперта, ограниченный сверху глобальным (длиннее эталона
гипотеза не нужна — CER уходит за 100 %), и применяется в трёх местах:
teacher-forced прогон `mope_forward_all`, раунды RSA при обучении и оба
декодирования в инференсе (кандидаты и агрегирующий раунд). В логе появляется
`📏 длина прогона по экспертам: [8, 16] шагов (потолок --max-len 16)`.

Разная ширина `--img-w` у экспертов работала и раньше: картинка грузится и
кодируется по `sp.img_h`/`sp.img_w` каждого эксперта отдельно.

Зачем: при длине слов p50 = 5 и `--max-len 40` декодер делал 40 шагов на каждое
слово — примерно 8× вычислений впустую на паддинге, плюс CER > 100 % из-за
гипотез длиннее эталона. Корзины 8/12/16/24 убирают и то и другое, а роутер
получает честную интерпретируемую задачу — выбрать эксперта по длине слова.

Готовый цикл: `BUCKETS="8 12 16 24" EPOCHS=10 FD=128 bash scripts/run_len_buckets.sh`.
Словарь строится ОДИН на все корзины и по ПОЛНОМУ корпусу (`--build-charset`),
CSV каждой корзины сохраняется и используется как корпус для частот, связка
берёт потолок по самой длинной корзине, инференс повторяет флаги словаря.
Проверено в песочнице на двух корзинах 8 и 16 (fd=128, `charset_all.txt`):
обучение, экспорт `MOPEBI01` (2 935 399 и 2 935 402 Б) и связка прошли с rc=0,
различие геометрии честно напечатано (`max_len 16 против 8`).

### 9.7 Корзины по длине: ~36 экспертов на длинах 4…40 под одним роутером

Идея: не один эксперт на `--max-len 40`, а по эксперту на диапазон длин. Слово из
5 символов у эксперта с `max_len 40` требует 40 шагов декодера — примерно 8×
вычислений на паддинге, и именно эти шаги дают CER > 100 %. Корзина 5…6 тратит
шесть шагов. Заодно роутер получает честную интерпретируемую задачу: выбрать
эксперта по длине слова.

**Что обязано совпадать у всех корзин, а что может различаться**

| параметр | можно различать | почему |
|---|---|---|
| `--max-len` | ✅ да | длина прогона считается на эксперта: `moe::expert_steps(spec.max_len, global)` (§20.18) |
| `--img-w` | ✅ да | картинка грузится и кодируется по `sp.img_h`/`sp.img_w` каждого эксперта |
| словарь | ✅ да | у каждого своя нумерация, непокрытые символы платят `penalized_ce` |
| `--hidden` | ✅ да | декодер свой у каждого эксперта |
| `--feat-dim` | ❌ **нет** | роутеру подаётся признак **первого** эксперта (`out.feat0` при `ei == 0`), ширина пула равна `feat_dim`, вход роутера `2×feat_dim`. У fd=512 это 1024, у fd=128 — 256: состояние не подставится и роутер останется случайным |
| `--img-h` | ❌ нет | при `img_h < 32` появляются NaN |

Отсюда практический вывод про ваш существующий `experts/yen_c.mope` (fd=512,
`max_len 40`, 43 МБ): смешать его с корзинами можно, но тогда **все** корзины
должны быть fd=512 — это 43 МБ × 36 ≈ 1.5 ГБ бандлов и подмена по PCIe на каждом
шаге. Разумнее пересобрать корзины на fd=128 (2.93 МБ × 36 ≈ 105 МБ), а
`yen_c.mope` оставить отдельным одно-экспертным эталоном для сравнения.

Порядок экспертов в `--mope-experts` имеет смысл: первым лучше ставить корзину
средней длины, а не самую короткую, поскольку роутер видит признак именно его.

**Правило `--mope-tau ≤ β/2`.** β — бюджет раунда RSA, берётся как максимум
`max_len` по экспертам; τ — сколько последних символов каждого кандидата уходит в
промпт агрегатора. Промпт из `C×τ` токенов должен помещаться в бюджет раунда
вместе с ответом, отсюда половина. При самой длинной корзине 40 это τ ≤ 20, при
потолке 17 — τ ≤ 8; в скрипте τ=4, то есть безопасно при любом β ≥ 8.

**Три схемы наполнения корзин** (`tools/len_buckets.py --scheme`):

- `auto` — смежные диапазоны, в каждом не меньше `--min-rows` строк. Корзин
  получится меньше 37, зато каждая плотная и обучается быстро. **Рекомендуется.**
- `exact` — ровно по одной длине 4, 5, 6, … 40: до 37 экспертов. Длинные корзины
  жидкие или пустые (у Енисея max длины 32, поэтому 33…40 будут пропущены), а
  эксперт на 20 строках не обучится.
- `cum` — корзина L видит все строки длиной ≤ L. Последняя корзина видит весь
  датасет и обучается дольше всех, то есть экономии не получается.

Корзина никогда не должна содержать строк длиннее своей верхней границы:
загрузчик обрезает их молча. Заимствовать можно только короткие строки — поэтому
`auto` и расширяет диапазон вниз, а не вверх.

**Запуск**

```bash
# сначала посмотреть план, ничего не обучая (пункт 5 меню, вариант 4)
bash scripts/mope_menu.sh                     # WHAT=5 → SCHEME=4 (только план)
# затем полный цикл: 36 экспертов + один франкен
SCHEME=auto MIN_ROWS=1000 LO=4 HI=40 EPOCHS=10 FD=128 bash scripts/run_len_buckets.sh
# или по одной длине на эксперта
SCHEME=exact LO=4 HI=40 EPOCHS=6 FD=128 bash scripts/run_len_buckets.sh
```

Скрипт делает: полный корпус и **один** словарь на все корзины (`--build-charset`
по полному train+val — иначе корзины разъедутся по vocab, а частоты для
`--mope-min-freq` окажутся неполными, §20.15); разбивку на корзины с планом в
`buckets_plan.tsv`; обучение каждой корзины **на своих строках и на контроле своей
длины** (иначе CER корзины измеряется на чужих длинах и снова уходит за 100 %);
экспорт в `MOPEBI01`; одну связку с потолком по самой длинной корзине; инференс с
теми же флагами словаря.

**Стоимость.** Шаг обучения связки делает по teacher-forced прогону на каждого
эксперта, поэтому при 36 корзинах держите `--mope-limit 200…2000` и
`--mope-cache 4…6` (резидентно живут только кэшированные бандлы, остальные
подменяются по PCIe). В логе связки ищите `📏 длина прогона по экспертам:
[8, 9, 11, 15, 16, 17] шагов (потолок --max-len 17)` — это значит, что корзины
смешались и каждый эксперт декодирует свою длину.

**Проверено в песочнице** (2 ядра CPU, fd=128): 6 корзин `exact` на длинах 8, 9,
11, 15, 16, 17 с разной шириной кадра 128/160/192/256/256/256 — обучение и
экспорт всех шести rc=0 (бандлы по 2 935 414 Б), связка rc=0 с честным
перечислением отличий (`⇄ отличается от 0: вход 32×160 против 32×128`,
`max_len 9 против 8`), инференс rc=0 на роутере из шести экспертов
(`загрузка экспертов: [0.0, 5.0, 0.0, 0.0, 0.0, 0.0]`, `побед Best-of-N:
[0, 5, 0, 0, 0, 0]`, `подмен экспертов 2 | 1.9 с`). Тестов **86**.
