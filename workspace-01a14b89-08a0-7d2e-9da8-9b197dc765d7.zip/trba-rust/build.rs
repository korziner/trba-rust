// build.rs — compiles the native backend and links it into the Rust binaries.
//
// Two backends, same `extern "C"` surface:
//   * cuda/kernels.cu      via nvcc      (default when a CUDA toolkit is found)
//   * cuda/cpu_backend.cpp via the C++ compiler (fallback / TRBA_FORCE_CPU=1)
//
// Everything is linked *statically*, so the old
// `LD_LIBRARY_PATH=cuda/ ./target/release/trba-rust` dance is gone.

use std::path::{Path, PathBuf};
use std::process::Command;

fn env_flag(name: &str) -> bool {
    matches!(
        std::env::var(name).unwrap_or_default().to_ascii_lowercase().as_str(),
        "1" | "true" | "yes" | "on"
    )
}

fn find_nvcc() -> Option<PathBuf> {
    if let Ok(p) = std::env::var("TRBA_NVCC") {
        let path = PathBuf::from(&p);
        if path.is_file() {
            return Some(path);
        }
    }
    if let Ok(p) = std::env::var("CUDA_PATH") {
        let cand = PathBuf::from(p).join("bin").join("nvcc");
        if cand.is_file() {
            return Some(cand);
        }
    }
    for root in ["/usr/local/cuda", "/opt/cuda"] {
        let cand = Path::new(root).join("bin").join("nvcc");
        if cand.is_file() {
            return Some(cand);
        }
    }
    // Last resort: whatever is on PATH.
    let out = Command::new("sh")
        .args(["-c", "command -v nvcc"])
        .output()
        .ok()?;
    if out.status.success() {
        let s = String::from_utf8_lossy(&out.stdout).trim().to_string();
        if !s.is_empty() {
            return Some(PathBuf::from(s));
        }
    }
    None
}

/// Compute capabilities to embed.  Overridable with TRBA_CUDA_ARCH="75;86".
fn target_archs() -> Vec<String> {
    if let Ok(spec) = std::env::var("TRBA_CUDA_ARCH") {
        let v: Vec<String> = spec
            .split(|c: char| c == ';' || c == ',' || c.is_whitespace())
            .filter(|s| !s.is_empty())
            .map(|s| s.trim().to_string())
            .collect();
        if !v.is_empty() {
            return v;
        }
    }
    // Ask the driver when there is one — that is always the right answer for
    // the machine actually doing the training.
    if let Ok(out) = Command::new("nvidia-smi")
        .args(["--query-gpu=compute_cap", "--format=csv,noheader"])
        .output()
    {
        if out.status.success() {
            let first = String::from_utf8_lossy(&out.stdout)
                .lines()
                .next()
                .unwrap_or("")
                .trim()
                .replace('.', "");
            if !first.is_empty() && first.chars().all(|c| c.is_ascii_digit()) {
                return vec![first];
            }
        }
    }
    // Otherwise ship a fatbin covering Turing..Blackwell consumer parts.
    // (TRBA is trained on a single machine; a fatbin keeps the repo portable.)
    vec!["75".into(), "86".into(), "89".into()]
}

/// Numeric order: `"100" < "89"` lexicographically, and `iter().max()` on
/// strings picked the wrong "newest" architecture as soon as Blackwell (sm_100)
/// entered the list.
fn arch_num(a: &str) -> u32 {
    a.parse::<u32>().unwrap_or(0)
}

fn gencode_flags(archs: &[String]) -> Vec<String> {
    let mut g = Vec::new();
    for a in archs {
        g.push(format!("-gencode=arch=compute_{a},code=sm_{a}"));
    }
    // PTX for the newest target so the driver can JIT for GPUs we did not know
    // about at build time.  Exactly once — the previous code pushed it twice
    // (`iter().max()` and `last()`), bloating the fatbin with a duplicate.
    if let Some(last) = archs.iter().max_by_key(|a| arch_num(a)) {
        g.push(format!("-gencode=arch=compute_{last},code=compute_{last}"));
    }
    g
}

/// `ar crus` the object into a static library the linker can consume.
fn archive(out_dir: &Path, obj: &Path, lib: &Path) -> Result<(), String> {
    let ar = std::env::var("AR").unwrap_or_else(|_| "ar".into());
    // Run inside out_dir and pass bare file names: `ar` stores whatever path
    // it is given in the archive member header, and a long or absolute member
    // name makes rustc reject the archive ("Unsupported archive identifier").
    let obj_name = obj.file_name().ok_or("bad object path")?;
    let lib_name = lib.file_name().ok_or("bad library path")?;
    // `ar r` updates members in place; a stale or truncated archive from an
    // earlier failed build would otherwise poison the result.
    let _ = std::fs::remove_file(lib);
    let out = Command::new(&ar)
        .arg("crus")
        .arg(lib_name)
        .arg(obj_name)
        .current_dir(out_dir)
        .output()
        .map_err(|e| format!("failed to run {ar}: {e}"))?;
    if !out.status.success() {
        eprintln!("{}", String::from_utf8_lossy(&out.stderr));
        return Err(format!("{ar} failed to create {}", lib.display()));
    }
    Ok(())
}

fn build_cuda(out_dir: &Path, nvcc: &Path) -> Result<(), String> {
    let archs = target_archs();
    println!("cargo:warning=trba-rust: building CUDA backend for arch {}", archs.join(", "));
    let gencode = gencode_flags(&archs);

    let obj = out_dir.join("kernels.o");

    // glibc >= 2.41 declares sinpi/cospi/sinpif/cospif (ISO C23 math) with a
    // dynamic exception specification, while CUDA <= 12.9 declares them
    // `noexcept(true)`; the host pass then dies with
    //   "exception specification is incompatible with that of previous function"
    // Debian's g++ defines _GNU_SOURCE by default, which is what pulls those
    // declarations in.  Undefining it hides them again — nothing in this
    // project uses sinpi/cospi.  Try the plain command line first so toolchains
    // that do not need it are untouched.
    let mut last_err = String::from("nvcc did not run");
    for extra_host_flags in ["", "-U_GNU_SOURCE"] {
        let mut cmd = Command::new(nvcc);
        cmd.arg("-O3")
            .arg("--std=c++17")
            .arg("-Xcompiler")
            .arg(if extra_host_flags.is_empty() {
                "-fPIC,-O3,-Wall".to_string()
            } else {
                format!("-fPIC,-O3,-Wall,{extra_host_flags}")
            })
            .arg("--expt-relaxed-constexpr")
            .arg("-lineinfo")
            .arg("-c")
            .arg("cuda/kernels.cu")
            .arg("-o")
            .arg(&obj);
        for g in &gencode {
            cmd.arg(g);
        }

        let out = cmd.output().map_err(|e| format!("failed to run nvcc: {e}"))?;
        if out.status.success() {
            if !extra_host_flags.is_empty() {
                println!(
                    "cargo:warning=trba-rust: nvcc needed host flag {extra_host_flags} (glibc 2.41+ / CUDA <= 12.9)"
                );
            }
            last_err.clear();
            break;
        }
        last_err = String::from_utf8_lossy(&out.stderr).to_string();
        eprintln!("{last_err}");
    }
    if !last_err.is_empty() {
        return Err("nvcc failed to compile cuda/kernels.cu".into());
    }
    archive(out_dir, &obj, &out_dir.join("libtrba_cuda.a"))?;

    // cudart lives in the toolkit; prefer the static one so the binary is
    // self-contained.
    let toolkit_lib = nvcc
        .parent()
        .and_then(|p| p.parent())
        .map(|p| p.join("lib64"))
        .filter(|p| p.exists());
    if let Some(dir) = &toolkit_lib {
        println!("cargo:rustc-link-search=native={}", dir.display());
    }
    if let Ok(extra) = std::env::var("TRBA_CUDA_LIB") {
        for d in extra.split(':') {
            if !d.is_empty() {
                println!("cargo:rustc-link-search=native={d}");
            }
        }
    }
    println!("cargo:rustc-link-search=native={}", out_dir.display());
    println!("cargo:rustc-link-lib=static=trba_cuda");
    if env_flag("TRBA_CUDA_SHARED_RT") {
        println!("cargo:rustc-link-lib=dylib=cudart");
    } else {
        // The toolkit ships `libcudart_static.a` — there is no `libcudart.a`,
        // so `-lstatic=cudart` fails at link time ("unable to find library
        // -lcudart") and build.rs falls back to the CPU backend.  The static
        // runtime also needs libculibos.a for its pthread/rt/dl helpers.
        println!("cargo:rustc-link-lib=static=cudart_static");
        println!("cargo:rustc-link-lib=static=culibos");
    }
    println!("cargo:rustc-link-lib=dylib=stdc++");
    println!("cargo:rustc-link-lib=dylib=m");
    println!("cargo:rustc-link-lib=dylib=dl");
    println!("cargo:rustc-link-lib=dylib=rt");
    println!("cargo:rustc-link-lib=dylib=pthread");
    Ok(())
}

fn build_cpu(out_dir: &Path) -> Result<(), String> {
    println!("cargo:warning=trba-rust: building CPU fallback backend (no CUDA)");
    let cxx = std::env::var("CXX").unwrap_or_else(|_| "g++".into());
    let obj = out_dir.join("cpu_backend.o");
    let lib = out_dir.join("libtrba_cpu.a");

    // TRBA_AVX=1 — AVX1 (128-битный VEX), TRBA_AVX=2 — AVX2+FMA (256 бит).
    // Без переменной gcc сам выбирает базовый x86-64 уровень (SSE2): это
    // единственная сборка, которая гарантированно запускается на любой машине.
    // Для PCIe-2.0 x4 Turing (CMP 50HX) компактность кода важнее ширины
    // вектора: 256-битные формы вдвое длиннее, а int8-GEMM упирается в
    // пропускную способность памяти, а не в FLOPs.  Rust-часть собирается
    // тем же уровнем через RUSTFLAGS="-C target-feature=+avx" (build script
    // не вправе менять rustc-флаги, кроме -L/-l).
    let avx = std::env::var("TRBA_AVX").unwrap_or_default();
    let cpu_flags: &[&str] = match avx.as_str() {
        "1" => &["-mavx"],
        "2" | "3" => &["-mavx2", "-mfma"],
        _ => &[],
    };
    if !cpu_flags.is_empty() {
        println!("cargo::warning=CPU-бэкенд собран с {}", cpu_flags.join(" "));
    }

    let compile = |openmp: bool| -> Result<std::process::Output, String> {
        let mut cmd = Command::new(&cxx);
        cmd.arg("-O3")
            .arg("-std=c++17")
            .arg("-fPIC")
            .arg("-Wall")
            .args(cpu_flags)
            .arg("-c")
            .arg("cuda/cpu_backend.cpp")
            .arg("-o")
            .arg(&obj);
        if openmp {
            cmd.arg("-fopenmp");
        }
        cmd.output().map_err(|e| format!("failed to run {cxx}: {e}"))
    };

    let mut openmp = true;
    let out = compile(true)?;
    if !out.status.success() {
        // Retry without OpenMP (clang without libomp, exotic toolchains, ...).
        let out2 = compile(false)?;
        if !out2.status.success() {
            eprintln!("{}", String::from_utf8_lossy(&out.stderr));
            eprintln!("{}", String::from_utf8_lossy(&out2.stderr));
            return Err(format!("{cxx} failed to compile cuda/cpu_backend.cpp"));
        }
        openmp = false;
        println!("cargo:warning=trba-rust: WARNING - {cxx} rejected -fopenmp, the CPU \
backend is being built SINGLE-THREADED. First 15 lines of the compiler error:");
        for line in String::from_utf8_lossy(&out.stderr).lines().take(15) {
            println!("cargo:warning=  | {line}");
        }
    }
    if openmp {
        println!("cargo:rustc-link-lib=dylib=gomp");
    }
    archive(out_dir, &obj, &lib)?;

    println!("cargo:rustc-link-search=native={}", out_dir.display());
    println!("cargo:rustc-link-lib=static=trba_cpu");
    println!("cargo:rustc-link-lib=dylib=stdc++");
    println!("cargo:rustc-link-lib=dylib=m");
    println!("cargo:rustc-link-lib=dylib=pthread");
    Ok(())
}

fn main() {
    println!("cargo:rerun-if-changed=cuda/kernels.cu");
    println!("cargo:rerun-if-changed=cuda/cpu_backend.cpp");
    println!("cargo:rerun-if-changed=build.rs");
    println!("cargo:rerun-if-env-changed=TRBA_FORCE_CPU");
    println!("cargo:rerun-if-env-changed=TRBA_AVX");
    println!("cargo:rerun-if-env-changed=TRBA_CUDA_ARCH");
    println!("cargo:rerun-if-env-changed=TRBA_NVCC");
    println!("cargo:rerun-if-env-changed=TRBA_CUDA_LIB");
    println!("cargo:rerun-if-env-changed=TRBA_CUDA_SHARED_RT");
    println!("cargo:rerun-if-env-changed=TRBA_REQUIRE_CUDA");
    println!("cargo:rerun-if-env-changed=CUDA_PATH");

    let out_dir = PathBuf::from(std::env::var("OUT_DIR").expect("OUT_DIR"));

    // Set TRBA_REQUIRE_CUDA=1 to turn "nvcc missing / CUDA compile failed" into
    // a hard build error.  Without it this script silently links the CPU
    // backend, which is exactly how a machine can train for hours on the CPU
    // while everyone believes the GPU build is running.  `cargo:warning=` lines
    // are easy to scroll past.
    let require_cuda = env_flag("TRBA_REQUIRE_CUDA");
    let nvcc = if env_flag("TRBA_FORCE_CPU") { None } else { find_nvcc() };

    if env_flag("TRBA_FORCE_CPU") {
        println!("cargo:warning=trba-rust: TRBA_FORCE_CPU set -> CPU backend, the binary will report backend 'cpu'");
        build_cpu(&out_dir).unwrap_or_else(|e| panic!("{e}"));
        return;
    }

    let nvcc = match nvcc {
        Some(p) => p,
        None => {
            let msg = "no CUDA toolkit found (looked at TRBA_NVCC, CUDA_PATH, /usr/local/cuda, /opt/cuda, PATH)";
            if require_cuda {
                panic!("TRBA_REQUIRE_CUDA=1 but {msg}");
            }
            println!("cargo:warning=trba-rust: {msg} -> building the CPU backend instead");
            build_cpu(&out_dir).unwrap_or_else(|e| panic!("{e}"));
            return;
        }
    };

    match build_cuda(&out_dir, &nvcc) {
        Ok(()) => {
            println!("cargo:warning=trba-rust: CUDA backend built with {}", nvcc.display());
        }
        Err(why) => {
            if require_cuda {
                panic!("TRBA_REQUIRE_CUDA=1 but the CUDA build failed: {why}");
            }
            println!("cargo:warning=trba-rust: ==================== CUDA BUILD FAILED ====================");
            println!("cargo:warning=trba-rust: {why}");
            println!("cargo:warning=trba-rust: falling back to the CPU backend - the binary will run, but on CPU");
            println!("cargo:warning=trba-rust: set TRBA_REQUIRE_CUDA=1 to make this a hard error");
            println!("cargo:warning=trba-rust: ===========================================================");
            build_cpu(&out_dir).unwrap_or_else(|e| panic!("{e}"));
        }
    }
}
