//! Оптимизатор: **Muon (momentum-free) для матриц, Adam для векторов**.
//!
//! Почему так. Исходный `Adam::step` считал каждый элемент в f64 (10 кастов,
//! `sqrt`, `/`), одним потоком, и отдельно от него шёл ещё один полный проход
//! `global_norm` — тоже f64-скалярный. На ~4M хостовых параметров это
//! 392 мс/батч (7.4 % шага). Muon из `conv2d.rs::muon_update` устроен иначе:
//! у него **нет состояния** (массивов m/v нет вовсе), считается он в f32,
//! `par_iter`-ом, и на матрицу нужно два прохода — норма и axpy.
//!
//! Шаг для матрицы `[rows, cols]`:
//!
//! ```text
//! scale   = min( sqrt(min(rows,cols)) / ||g||_F ,  cap )      // cap = 10, как в conv2d.rs
//! lr_eff  = lr * sqrt(max(rows,cols))                          // автомасштаб (modded-nanogpt)
//! w      -= lr_eff * scale * g  +  lr * wd * w                 // weight decay decoupled
//! ```
//!
//! Без автомасштаба шаг Muon на элемент был бы в `sqrt(max_dim)` раз меньше
//! adam'овского (для 1024×512 — в 32 раза), поэтому он включён по умолчанию.
//!
//! Векторы (bias, BN gamma/beta) остаются на Adam: для них `min_dim = 1` и Muon
//! вырождается в нормированный SGD, а BN-гейты так обучать не принято.
//!
//! `TRBA_MUON_Q=1` включает **MuonQ**: градиент матрицы квантуется в int8
//! блоками по `TRBA_MUON_Q_BLOCK` (дефолт 128) элементов, шкала блока —
//! `max|g|/127`. Норма считается по целым `q` в i64 (точно, без fp32-
//! катастрофического сокращения), шаг читает int8. Два следствия: шум
//! квантования работает как регуляризатор, а транспорт/хранение градиента
//! дешевеет в 4 раза — это станет важным, когда градиенты поедут через PCIe
//! (стадия 2 GPU-RNN: 10.5 МБ/батч -> 2.6 МБ).
//!
//! `TRBA_OPT=adam` возвращает прежний Adam для всех параметров (сравнение A/B),
//! `TRBA_CLIP_WARMUP=N` / `--clip-warmup N` — сколько первых шагов считается
//! глобальный clip (дальше нормировка Muon ограничивает шаг сама).

use rayon::prelude::*;
use std::collections::HashMap;

/// Пара (param, grad) + форма. Тренер собирает список один раз за шаг из
/// непересекающихся полей структур.
pub struct ParamRef {
    pub name: String,
    pub p: *mut f32,
    pub g: *mut f32,
    pub len: usize,
    /// `Some((rows, cols))` для матриц (идут по Muon), `None` для векторов
    /// (идут по Adam). `rows * cols == len`.
    pub shape: Option<(usize, usize)>,
}

// The trainer is single-threaded between optimiser steps.
unsafe impl Send for ParamRef {}
// Muon-ветка читает `p`/`g` из параллельных rayon-задач; параметры в списке
// не пересекаются (это инвариант `params_filtered`), поэтому гонки нет.
unsafe impl Sync for ParamRef {}

/// Настройки Muon. Читаются из окружения один раз (`MuonSpec::from_env`).
#[derive(Clone, Copy, Debug)]
pub struct MuonSpec {
    /// Включён ли Muon для матриц (false => весь Adam, как раньше).
    pub on: bool,
    /// Кап масштаба `sqrt(min_dim)/||g||_F`: защита от огромного шага на
    /// почти нулевом градиенте. 10.0 — как в `conv2d.rs::muon_update`.
    pub cap: f32,
    /// `lr_eff = lr * sqrt(max(rows, cols))`.
    pub autoscale: bool,
    /// 0 = fp32-градиент; >0 = MuonQ с размером блока (обычно 128).
    pub q_block: usize,
}

impl Default for MuonSpec {
    fn default() -> Self {
        Self { on: true, cap: 10.0, autoscale: true, q_block: 0 }
    }
}

impl MuonSpec {
    pub fn from_env() -> Self {
        let mut s = Self::default();
        let v = |k: &str| std::env::var(k).unwrap_or_default();
        if v("TRBA_OPT").eq_ignore_ascii_case("adam") {
            s.on = false;
        }
        if let Ok(x) = v("TRBA_MUON_CAP").parse::<f32>() {
            if x > 0.0 {
                s.cap = x;
            }
        }
        if v("TRBA_MUON_AUTOSCALE") == "0" {
            s.autoscale = false;
        }
        if v("TRBA_MUON_Q") == "1" {
            s.q_block = v("TRBA_MUON_Q_BLOCK").parse::<usize>().unwrap_or(128).max(1);
        }
        s
    }

    /// Одна строка в лог: что именно включено.
    pub fn banner(&self) -> String {
        if !self.on {
            return "оптимизатор: Adam для всех параметров (TRBA_OPT=adam)".to_string();
        }
        let q = if self.q_block > 0 {
            format!(", MuonQ int8 блоками по {}", self.q_block)
        } else {
            String::new()
        };
        let a = if self.autoscale { ", lr·sqrt(max_dim)" } else { "" };
        format!(
            "оптимизатор: Muon (momentum-free) для матриц{}{} + Adam для векторов, cap {}",
            a, q, self.cap
        )
    }
}

/// Обёртка для rayon: `*mut f32` не `Send`, поэтому список (p, g, m, v, len)
/// приходится завернуть. Это безопасно по тому же инварианту, что и `ParamRef`:
/// параметры в списке не пересекаются, между шагами тренер однопоточен.
struct AdamRef(*mut f32, *mut f32, *mut f32, *mut f32, usize);
unsafe impl Send for AdamRef {}
unsafe impl Sync for AdamRef {}

pub struct Adam {
    pub t: usize,
    pub beta1: f32,
    pub beta2: f32,
    pub eps: f32,
    /// Настройки Muon (матрицы). См. заголовок файла.
    pub muon: MuonSpec,
    /// Сколько первых шагов применяется глобальный clip по норме. 0 = никогда.
    pub clip_warmup: usize,
    m: HashMap<String, Vec<f32>>,
    v: HashMap<String, Vec<f32>>,
}

impl Adam {
    pub fn new() -> Self {
        Self {
            t: 0,
            beta1: 0.9,
            beta2: 0.999,
            eps: 1e-8,
            muon: MuonSpec::from_env(),
            clip_warmup: std::env::var("TRBA_CLIP_WARMUP")
                .ok()
                .and_then(|s| s.parse().ok())
                .unwrap_or(500),
            m: HashMap::new(),
            v: HashMap::new(),
        }
    }

    /// Нужен ли глобальный clip на этом шаге. До шага `t` ещё не увеличен,
    /// поэтому сравнение с `clip_warmup` идёт по текущему счётчику.
    pub fn clip_needed(&self) -> bool {
        self.t < self.clip_warmup
    }

    /// Сумма квадратов градиентов — параллельно, но **побитово как раньше**:
    /// каждое слагаемое в f64, порядок сложения внутри чанка последовательный.
    /// Тест `device_conv_optimizer_pipeline_matches_host_pipeline` сравнивает
    /// эту сумму с устройством с точностью 1e-12, поэтому f32-накопление здесь
    /// недопустимо; параллельность даёт только дерево по чанкам.
    /// Вклад свёрточных весов приходит отдельно одним f64 с устройства
    /// (`Scratch::read_grad_sq`).
    pub fn sum_sq(params: &[ParamRef]) -> f64 {
        params
            .par_iter()
            .map(|pr| {
                let g = unsafe { std::slice::from_raw_parts(pr.g, pr.len) };
                g.par_chunks(1 << 16)
                    .map(|c| c.iter().fold(0.0f64, |a, &x| a + x as f64 * x as f64))
                    .sum::<f64>()
            })
            .sum()
    }

    pub fn global_norm(params: &[ParamRef]) -> f64 {
        Self::sum_sq(params).sqrt()
    }

    /// Применить множитель clip ко всем градиентам (параллельно, f32).
    pub fn scale_grads(params: &[ParamRef], f: f32) {
        if !(f < 1.0) {
            return;
        }
        params.par_iter().for_each(|pr| {
            let g = unsafe { std::slice::from_raw_parts_mut(pr.g, pr.len) };
            for x in g.iter_mut() {
                *x *= f;
            }
        });
    }

    /// Adam moments of a named parameter.  `None` until the first step allocates
    /// them.  Checkpoints persist these: a resume that restores `t` but not `m`/`v`
    /// restarts both moving averages from zero while the bias correction keeps
    /// dividing by `1 - beta^t ~= 1`, so the first steps after a resume are
    /// effectively unnormalised and can throw the weights away.
    ///
    /// У матриц в режиме Muon моментов нет вовсе: они в этот словарь не
    /// попадают, и чекпоинт худеет на 2 массива параметра.
    pub fn moment(&self, name: &str) -> (Option<&Vec<f32>>, Option<&Vec<f32>>) {
        (self.m.get(name), self.v.get(name))
    }

    /// Restore moments read from a checkpoint (see `moment`). Моменты матриц из
    /// старого чекпоинта принимаются и просто не используются.
    pub fn set_moment(&mut self, name: &str, m: Vec<f32>, v: Vec<f32>) {
        self.m.insert(name.to_string(), m);
        self.v.insert(name.to_string(), v);
    }

    /// How many parameters currently have moment state — printed on resume so a
    /// checkpoint that predates moment saving is visibly incomplete.
    pub fn moment_count(&self) -> usize {
        self.m.len()
    }

    /// Bias-correction divisors for the current `t`.  Call *after* `step` to get
    /// the ones this step used; the device-side Adam for the conv weights needs
    /// exactly the same values.
    pub fn bias_correction(&self) -> (f64, f64) {
        (
            1.0 - self.beta1.powi(self.t as i32) as f64,
            1.0 - self.beta2.powi(self.t as i32) as f64,
        )
    }

    /// Один шаг: матрицы по Muon, векторы по Adam. `clip` уже применён к
    /// градиентам тренером (`scale_grads`); `wd` — L2 для Adam-ветки и
    /// decoupled для Muon-ветки.
    pub fn step(&mut self, params: &[ParamRef], lr: f32, wd: f32) {
        self.t += 1;
        let muon = self.muon;

        // --- векторы: Adam ---------------------------------------------------
        // Состояние распределяется и вынимаются сырые указатели ДО
        // параллельной части: `&mut self.m` внутрь rayon-задач не отдать.
        let bc1 = 1.0 - self.beta1.powi(self.t as i32) as f64;
        let bc2 = 1.0 - self.beta2.powi(self.t as i32) as f64;
        let (b1, b2, eps) = (self.beta1, self.beta2, self.eps);
        let mut vec_refs: Vec<AdamRef> = Vec::new();
        for pr in params.iter() {
            if muon.on && pr.shape.is_some() {
                continue;
            }
            let m = self.m.entry(pr.name.clone()).or_insert_with(|| vec![0.0; pr.len]);
            let v = self.v.entry(pr.name.clone()).or_insert_with(|| vec![0.0; pr.len]);
            vec_refs.push(AdamRef(pr.p, pr.g, m.as_mut_ptr(), v.as_mut_ptr(), pr.len));
        }
        vec_refs.par_iter().for_each(|r| unsafe {
            adam_vec(r.0, r.1, r.2, r.3, r.4, lr, wd, b1, b2, eps, bc1, bc2);
        });

        if !muon.on {
            return;
        }

        // --- матрицы: Muon ---------------------------------------------------
        // Внешний параллелизм — по матрицам (их десятки, размеры 0.1–3M
        // элементов); внутренние проходы последовательные, их векторизует LLVM.
        // Вложенный rayon здесь только мешал бы: задачи слишком мелкие.
        let cap = muon.cap;
        let autoscale = muon.autoscale;
        let qb = muon.q_block;
        params.par_iter().for_each_init(
            || (Vec::<i8>::new(), Vec::<f32>::new()),
            |(qs, scales), pr| {
                let (rows, cols) = match pr.shape {
                    Some(s) => s,
                    None => return,
                };
                let p = unsafe { std::slice::from_raw_parts_mut(pr.p, pr.len) };
                let g = unsafe { std::slice::from_raw_parts(pr.g, pr.len) };
                let min_dim = rows.min(cols) as f32;
                let max_dim = rows.max(cols) as f32;
                let lr_eff = if autoscale { lr * max_dim.sqrt() } else { lr };
                let dec = 1.0f32 - lr * wd; // decoupled weight decay
                if qb > 0 {
                    muon_step_q(p, g, rows * cols, qb, min_dim, lr_eff, dec, cap, qs, scales);
                } else {
                    muon_step_f32(p, g, min_dim, lr_eff, dec, cap);
                }
            },
        );
    }
}

/// Adam для одного вектора. Арифметика **ровно та же, что была** (каждый
/// элемент в f64, те же касты) — её сравнивают с устройством побитово два теста
/// (`device_adam_matches_opt_rs`, `device_conv_optimizer_pipeline_matches_host_pipeline`).
/// Ускорение здесь только от параллелизма по параметрам; выигрыш по скорости
/// даёт Muon-ветка, куда ушли все матрицы (это ~99 % элементов).
/// Семантика PyTorch: `wd` добавляется к градиенту как L2.
#[allow(clippy::too_many_arguments)]
unsafe fn adam_vec(
    p: *mut f32,
    g: *mut f32,
    m: *mut f32,
    v: *mut f32,
    len: usize,
    lr: f32,
    wd: f32,
    b1: f32,
    b2: f32,
    eps: f32,
    bc1: f64,
    bc2: f64,
) {
    let p = std::slice::from_raw_parts_mut(p, len);
    let g = std::slice::from_raw_parts(g, len);
    let m = std::slice::from_raw_parts_mut(m, len);
    let v = std::slice::from_raw_parts_mut(v, len);
    for i in 0..len {
        let gi = g[i] as f64 + wd as f64 * p[i] as f64;
        m[i] = (b1 as f64 * m[i] as f64 + (1.0 - b1 as f64) * gi) as f32;
        v[i] = (b2 as f64 * v[i] as f64 + (1.0 - b2 as f64) * gi * gi) as f32;
        let mh = m[i] as f64 / bc1;
        let vh = v[i] as f64 / bc2;
        p[i] -= (lr as f64 * mh / (vh.sqrt() + eps as f64)) as f32;
    }
}

/// Muon для одной матрицы, fp32-градиент: норма и шаг за два прохода.
fn muon_step_f32(p: &mut [f32], g: &[f32], min_dim: f32, lr_eff: f32, dec: f32, cap: f32) {
    let mut sq = 0.0f32;
    for &x in g {
        sq += x * x;
    }
    let frob = sq.sqrt().max(1e-8);
    let scale = (min_dim.sqrt() / frob).min(cap);
    let step = lr_eff * scale;
    for (pi, gi) in p.iter_mut().zip(g.iter()) {
        let u = *pi * dec - step * gi;
        *pi = if u.is_finite() { u } else { 0.0 };
    }
}

/// MuonQ: градиент квантуется в int8 блоками по `qb` элементов, шкала блока —
/// `max|g|/127`. `||g||_F^2` считается как `Σ s_b^2 · Σ q^2` — внутренняя сумма
/// целочисленная (i64), поэтому точность нормы не зависит от порядка сложения.
/// `qs`/`scales` — рабочий буфер вызывающего (rayon `for_each_init` держит по
/// одному на поток), расширяется на месте и переиспользуется между шагами.
fn muon_step_q(
    p: &mut [f32],
    g: &[f32],
    n: usize,
    qb: usize,
    min_dim: f32,
    lr_eff: f32,
    dec: f32,
    cap: f32,
    qs: &mut Vec<i8>,
    scales: &mut Vec<f32>,
) {
    let nb = n.div_ceil(qb);
    qs.clear();
    qs.resize(n, 0);
    scales.clear();
    scales.resize(nb, 0.0);

    // 1) квантование: шкала = max|g| в блоке / 127, round-half-away (как в
    //    остальном коде проекта, а не half-to-even из CUDA rintf)
    for b in 0..nb {
        let lo = b * qb;
        let hi = (lo + qb).min(n);
        let blk = &g[lo..hi];
        let mut mx = 0.0f32;
        for &x in blk {
            let a = x.abs();
            if a > mx {
                mx = a;
            }
        }
        let s = mx / 127.0;
        scales[b] = s;
        if s <= 0.0 {
            for q in qs[lo..hi].iter_mut() {
                *q = 0;
            }
            continue;
        }
        let inv = 127.0 / mx;
        for (q, &x) in qs[lo..hi].iter_mut().zip(blk.iter()) {
            let t = x * inv;
            let r = if t >= 0.0 { (t + 0.5) as i32 } else { -((0.5 - t) as i32) };
            *q = r.clamp(-127, 127) as i8;
        }
    }

    // 2) норма по целым q, затем сумма s_b^2 * sum_q2 в f64
    let mut frob_sq = 0.0f64;
    for b in 0..nb {
        let lo = b * qb;
        let hi = (lo + qb).min(n);
        let mut acc = 0i64;
        for &q in &qs[lo..hi] {
            let qi = q as i64;
            acc += qi * qi;
        }
        let s = scales[b] as f64;
        frob_sq += s * s * acc as f64;
    }
    let frob = (frob_sq.sqrt() as f32).max(1e-8);
    let scale = (min_dim.sqrt() / frob).min(cap);
    let step = lr_eff * scale;

    // 3) шаг читает int8 (1 байт на элемент вместо 4)
    for b in 0..nb {
        let lo = b * qb;
        let hi = (lo + qb).min(n);
        let sstep = step * scales[b];
        for (pi, &q) in p[lo..hi].iter_mut().zip(qs[lo..hi].iter()) {
            let u = *pi * dec - sstep * (q as f32);
            *pi = if u.is_finite() { u } else { 0.0 };
        }
    }
}
