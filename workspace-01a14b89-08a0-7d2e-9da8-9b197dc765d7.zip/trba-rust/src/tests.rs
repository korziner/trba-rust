//! Correctness tests for the native backend and the quantised layers.
//!
//! These run against whichever backend build.rs linked: with CUDA they check
//! the real kernels on the GPU, without it they check the CPU reference
//! implementation that mirrors them line for line.  Either way they catch the
//! class of bug that produced "an illegal memory access was encountered" —
//! wrong buffer sizes, wrong leading dimensions, wrong index arithmetic.

use crate::backend::*;
use crate::conv2d::{maxpool2x2_with_indices, Conv2dInt8, ACC_DIVISOR, OUT_MULTIPLIER};
use crate::linear::LinearInt8;
use crate::opt::{Adam, ParamRef};
use crate::qnet::ConvQat;

// ------------------------------------------------------------
// helpers
// ------------------------------------------------------------
fn f32_bytes(v: &[f32]) -> Vec<u8> {
    let mut b = Vec::with_capacity(v.len() * 4);
    for x in v {
        b.extend_from_slice(&x.to_le_bytes());
    }
    b
}

fn as_bytes_mut_i32(v: &mut [i32]) -> &mut [u8] {
    unsafe { std::slice::from_raw_parts_mut(v.as_mut_ptr() as *mut u8, v.len() * 4) }
}

fn i32_as_bytes(v: &[i32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(v.as_ptr() as *const u8, v.len() * 4) }
}

fn bytes_f32(b: &[u8]) -> Vec<f32> {
    b.chunks_exact(4)
        .map(|c| f32::from_le_bytes([c[0], c[1], c[2], c[3]]))
        .collect()
}

/// Deterministic pseudo-random in [-1, 1] (no dependency on rand's RNG state).
fn det(i: usize, seed: usize) -> f32 {
    let x = ((i.wrapping_mul(2654435761)) ^ seed) as u64;
    let x = x.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
    ((x >> 33) as f32 / (1u64 << 31) as f32) * 2.0 - 1.0
}

fn naive_gemm(a: &[f32], b: &[f32], m: usize, n: usize, k: usize) -> Vec<f32> {
    let mut c = vec![0.0f32; m * n];
    for i in 0..m {
        for j in 0..n {
            let mut s = 0.0f32;
            for p in 0..k {
                s += a[i * k + p] * b[p * n + j];
            }
            c[i * n + j] = s;
        }
    }
    c
}

fn max_abs_diff(a: &[f32], b: &[f32]) -> f32 {
    a.iter()
        .zip(b.iter())
        .map(|(x, y)| (x - y).abs())
        .fold(0.0f32, f32::max)
}

// ------------------------------------------------------------
// GEMM tests
// ------------------------------------------------------------
#[test]
fn int8_gemm_matches_naive_including_unpadded_shapes() {
    let stream = CudaStream::new();
    // Deliberately not multiples of 16: the kernel must pad internally and
    // still write an exactly [M, N] result.
    for &(m, n, k) in &[(16usize, 16usize, 16usize), (17, 5, 3), (100, 33, 27), (256, 192, 512)] {
        let a: Vec<i8> = (0..m * k).map(|i| (det(i, 1) * 100.0) as i8).collect();
        let b: Vec<i8> = (0..n * k).map(|i| (det(i, 2) * 100.0) as i8).collect();

        let (a_pad, _, _) = pad_to_multiple_i8(&a, m, k, 16);
        let (b_pad, _, _) = pad_to_multiple_i8(&b, n, k, 16);
        let ws = GpuWorkspace::new(&[a_pad.len(), b_pad.len(), m * n * 4]);
        ws.upload_i8(0, &a_pad, &stream);
        ws.upload_i8(1, &b_pad, &stream);

        let mut got = vec![0i32; m * n];
        unsafe {
            launch_gemm_int8(ws.as_i8(0), ws.as_i8(1), ws.as_i32_mut(2), m as i32, n as i32, k as i32, stream.0);
        }
        ws.download(2, as_bytes_mut_i32(&mut got), &stream);
        stream.sync();

        let mut want = vec![0i32; m * n];
        for i in 0..m {
            for j in 0..n {
                let mut s = 0i32;
                for p in 0..k {
                    s += a[i * k + p] as i32 * b[j * k + p] as i32;
                }
                want[i * n + j] = s;
            }
        }
        assert_eq!(got, want, "int8 gemm mismatch at M={m} N={n} K={k}");
    }
}

#[test]
fn fp32_gemm_matches_naive() {
    let stream = CudaStream::new();
    for &(m, n, k) in &[(1usize, 1usize, 1usize), (33, 5, 17), (64, 64, 64), (200, 40, 7)] {
        let a: Vec<f32> = (0..m * k).map(|i| det(i, 3)).collect();
        let b: Vec<f32> = (0..k * n).map(|i| det(i, 4)).collect();
        let ws = GpuWorkspace::new(&[m * k * 4, k * n * 4, m * n * 4]);
        ws.upload(0, &f32_bytes(&a), &stream);
        ws.upload(1, &f32_bytes(&b), &stream);

        let mut got = vec![0.0f32; m * n];
        unsafe {
            launch_gemm_fp32(ws.as_f32(0), ws.as_f32(1), ws.as_f32_mut(2), m as i32, n as i32, k as i32, stream.0);
        }
        ws.download_f32(2, &mut got, &stream);
        stream.sync();

        let want = naive_gemm(&a, &b, m, n, k);
        let d = max_abs_diff(&got, &want);
        assert!(d < 1e-3 + 1e-3 * want.iter().map(|x| x.abs()).fold(0.0f32, f32::max),
                "fp32 gemm mismatch at M={m} N={n} K={k}: {d}");
    }
}

#[test]
fn fp32_gemm_handles_huge_k_without_grid_overflow() {
    // The old kernel used dim3 grid((N+15)/16, (M+15)/16); gridDim.y is capped
    // at 65535, so any M above ~1M silently launched nothing and left the
    // output buffer untouched.  This checks a shape that would have hit it.
    let stream = CudaStream::new();
    let (m, n, k) = (70000usize, 4usize, 2usize);
    let a: Vec<f32> = (0..m * k).map(|i| if i % 2 == 0 { 1.0 } else { 2.0 }).collect();
    let b: Vec<f32> = (0..k * n).map(|i| (i as f32) * 0.5).collect();
    let ws = GpuWorkspace::new(&[m * k * 4, k * n * 4, m * n * 4]);
    ws.upload(0, &f32_bytes(&a), &stream);
    ws.upload(1, &f32_bytes(&b), &stream);

    let mut got = vec![-1.0f32; m * n];
    unsafe {
        launch_gemm_fp32(ws.as_f32(0), ws.as_f32(1), ws.as_f32_mut(2), m as i32, n as i32, k as i32, stream.0);
    }
    ws.download_f32(2, &mut got, &stream);
    stream.sync();

    let want = naive_gemm(&a, &b, m, n, k);
    assert_eq!(max_abs_diff(&got, &want), 0.0, "large-M fp32 gemm produced wrong values");
    assert!(got.iter().all(|x| x.is_finite()));
}

// ------------------------------------------------------------
// im2col / epilogue
// ------------------------------------------------------------
fn ref_im2col(input: &[i8], b: usize, c: usize, h: usize, w: usize,
              kh: usize, kw: usize, sh: usize, sw: usize, ph: usize, pw: usize) -> Vec<i8> {
    let ho = (h + 2 * ph - kh) / sh + 1;
    let wo = (w + 2 * pw - kw) / sw + 1;
    let cols = c * kh * kw;
    let mut out = vec![0i8; b * ho * wo * cols];
    for bi in 0..b {
        for oh in 0..ho {
            for ow in 0..wo {
                let row = (bi * ho + oh) * wo + ow;
                let mut p = 0;
                for ci in 0..c {
                    for khi in 0..kh {
                        for kwi in 0..kw {
                            let ih = oh * sh + khi;
                            let iw = ow * sw + kwi;
                            let v = if ih >= ph && ih < h + ph && iw >= pw && iw < w + pw {
                                input[((bi * c + ci) * h + (ih - ph)) * w + (iw - pw)]
                            } else {
                                0
                            };
                            out[row * cols + p] = v;
                            p += 1;
                        }
                    }
                }
            }
        }
    }
    out
}

#[test]
fn im2col_pad_matches_reference() {
    let stream = CudaStream::new();
    let (b, c, h, w, kh, sh, ph) = (3usize, 5usize, 9usize, 11usize, 3usize, 2usize, 1usize);
    let ho = (h + 2 * ph - kh) / sh + 1;
    let wo = (w + 2 * ph - kh) / sh + 1;
    let cols = c * kh * kh;
    let kp = align16(cols);
    let rows = b * ho * wo;
    let mp = align16(rows);

    let input: Vec<i8> = (0..b * c * h * w).map(|i| (det(i, 7) * 100.0) as i8).collect();
    let want = ref_im2col(&input, b, c, h, w, kh, kh, sh, sh, ph, ph);
    let ws = GpuWorkspace::new(&[input.len(), mp * kp]);
    ws.upload_i8(0, &input, &stream);
    unsafe {
        launch_im2col_pad(ws.as_i8(0), ws.as_i8_mut(1), b as i32, c as i32, h as i32, w as i32,
                          kh as i32, kh as i32, sh as i32, sh as i32, ph as i32, ph as i32,
                          ho as i32, wo as i32, kp as i32, stream.0);
    }
    stream.sync();

    let mut got = vec![0i8; mp * kp];
    ws.download_i8(1, &mut got, &stream);
    stream.sync();

    for r in 0..rows {
        for cc in 0..cols {
            assert_eq!(got[r * kp + cc], want[r * cols + cc], "im2col mismatch at row {r} col {cc}");
        }
        for cc in cols..kp {
            assert_eq!(got[r * kp + cc], 0, "im2col padding not zero at row {r} col {cc}");
        }
    }
    for r in rows..mp {
        for cc in 0..kp {
            assert_eq!(got[r * kp + cc], 0, "im2col row padding not zero at row {r}");
        }
    }
}

#[test]
fn conv_epilogue_dequant_bias_relu_requant() {
    let stream = CudaStream::new();
    let (b, c, ho, wo) = (2usize, 5usize, 3usize, 4usize);
    // launch_gemm_int8 produces a compact [rows, C] matrix, so the leading
    // dimension of the accumulator is C itself (no 16-byte padding).
    let acc_ld = c;
    let acc: Vec<i32> = (0..b * ho * wo * acc_ld).map(|i| (det(i, 9) * 3000.0) as i32).collect();
    let bias: Vec<f32> = (0..c).map(|i| det(i, 11)).collect();
    let out_len = b * c * ho * wo;
    let ws = GpuWorkspace::new(&[acc.len() * 4, c * 4, out_len]);
    ws.upload(0, i32_as_bytes(&acc), &stream);
    ws.upload(1, &f32_bytes(&bias), &stream);
    unsafe {
        launch_conv_epilogue(ws.ptr(0) as *const i32, ws.as_f32(1), ws.as_i8_mut(2),
                             acc_ld as i32, ACC_DIVISOR, OUT_MULTIPLIER,
                             b as i32, c as i32, ho as i32, wo as i32, stream.0);
    }
    stream.sync();

    let mut got = vec![0i8; out_len];
    ws.download_i8(2, &mut got, &stream);
    stream.sync();

    let hw = ho * wo;
    for i in 0..out_len {
        // out is [B, C, Ho, Wo]; the accumulator rows are [B*Ho*Wo] x [C]
        let bi = i / (c * hw);
        let oc = (i / hw) % c;
        let row = bi * hw + (i % hw);
        let v = acc[row * acc_ld + oc] as f32 / ACC_DIVISOR + bias[oc];
        let want = (v.max(0.0) * OUT_MULTIPLIER).clamp(-127.0, 127.0).round() as i8;
        assert_eq!(got[i], want, "epilogue mismatch at {i}");
    }
}

// ------------------------------------------------------------
// Fused conv backward
// ------------------------------------------------------------
struct ConvShape {
    b: usize, cin: usize, h: usize, w: usize, cout: usize,
    kh: usize, kw: usize, sh: usize, sw: usize, ph: usize, pw: usize,
    ho: usize, wo: usize,
}

fn shape(b: usize, cin: usize, h: usize, w: usize, cout: usize, k: usize, s: usize, p: usize) -> ConvShape {
    ConvShape {
        b, cin, h, w, cout,
        kh: k, kw: k, sh: s, sw: s, ph: p, pw: p,
        ho: (h + 2 * p - k) / s + 1,
        wo: (w + 2 * p - k) / s + 1,
    }
}

/// grad_W reference: build the col matrix, then grad_W = go_mat^T @ col.
fn ref_grad_w(s: &ConvShape, input: &[i8], go: &[f32]) -> Vec<f32> {
    let cols = s.cin * s.kh * s.kw;
    let hw_out = s.ho * s.wo;
    let rows = s.b * hw_out;
    let mut col = vec![0.0f32; rows * cols];
    for r in 0..rows {
        let b = r / hw_out;
        let rem = r % hw_out;
        let oh = rem / s.wo;
        let ow = rem % s.wo;
        for ci in 0..s.cin {
            for khi in 0..s.kh {
                for kwi in 0..s.kw {
                    let ih = oh * s.sh + khi;
                    let iw = ow * s.sw + kwi;
                    let v = if ih >= s.ph && ih < s.h + s.ph && iw >= s.pw && iw < s.w + s.pw {
                        input[((b * s.cin + ci) * s.h + (ih - s.ph)) * s.w + (iw - s.pw)] as f32
                    } else {
                        0.0
                    };
                    col[r * cols + (ci * s.kh + khi) * s.kw + kwi] = v;
                }
            }
        }
    }
    // go is [b, cout, ho, wo]; reshape to [rows, cout]
    let mut go_mat = vec![0.0f32; rows * s.cout];
    for b in 0..s.b {
        for oc in 0..s.cout {
            for p in 0..hw_out {
                go_mat[(b * hw_out + p) * s.cout + oc] = go[(b * s.cout + oc) * hw_out + p];
            }
        }
    }
    let mut gw = vec![0.0f32; s.cout * cols];
    for oc in 0..s.cout {
        for ci in 0..cols {
            let mut acc = 0.0f32;
            for r in 0..rows {
                acc += go_mat[r * s.cout + oc] * col[r * cols + ci];
            }
            gw[oc * cols + ci] = acc;
        }
    }
    gw
}

fn ref_grad_input(s: &ConvShape, go: &[f32], weight: &[f32]) -> Vec<f32> {
    let cols = s.cin * s.kh * s.kw;
    let hw_out = s.ho * s.wo;
    let mut gi = vec![0.0f32; s.b * s.cin * s.h * s.w];
    for b in 0..s.b {
        for ci in 0..s.cin {
            for ih in 0..s.h {
                for iw in 0..s.w {
                    let mut acc = 0.0f32;
                    for khi in 0..s.kh {
                        let nh = ih + s.ph;
                        if nh < khi { continue; }
                        let numh = nh - khi;
                        if numh % s.sh != 0 { continue; }
                        let oh = numh / s.sh;
                        if oh >= s.ho { continue; }
                        for kwi in 0..s.kw {
                            let nw = iw + s.pw;
                            if nw < kwi { continue; }
                            let numw = nw - kwi;
                            if numw % s.sw != 0 { continue; }
                            let ow = numw / s.sw;
                            if ow >= s.wo { continue; }
                            let wcol = (ci * s.kh + khi) * s.kw + kwi;
                            for oc in 0..s.cout {
                                acc += go[(b * s.cout + oc) * hw_out + oh * s.wo + ow]
                                    * weight[oc * cols + wcol];
                            }
                        }
                    }
                    gi[(b * s.cin + ci) * s.h * s.w + ih * s.w + iw] = acc;
                }
            }
        }
    }
    gi
}

#[test]
fn fused_backward_grad_w_matches_im2col_reference() {
    let stream = CudaStream::new();
    for s in [shape(2, 3, 8, 7, 5, 3, 1, 1), shape(1, 4, 6, 6, 8, 3, 2, 1), shape(3, 2, 5, 5, 3, 1, 1, 0)] {
        let input: Vec<i8> = (0..s.b * s.cin * s.h * s.w).map(|i| (det(i, 13) * 100.0) as i8).collect();
        let go: Vec<f32> = (0..s.b * s.cout * s.ho * s.wo).map(|i| det(i, 17)).collect();
        let want = ref_grad_w(&s, &input, &go);
        let ws = GpuWorkspace::new(&[input.len(), go.len() * 4, want.len() * 4]);
        ws.upload_i8(0, &input, &stream);
        ws.upload(1, &f32_bytes(&go), &stream);
        unsafe {
            launch_conv_backward_grad_weight(
                ws.as_i8(0), ws.as_f32(1), ws.as_f32_mut(2),
                s.b as i32, s.cin as i32, s.h as i32, s.w as i32, s.cout as i32,
                s.kh as i32, s.kw as i32, s.sh as i32, s.sw as i32, s.ph as i32, s.pw as i32,
                s.ho as i32, s.wo as i32, stream.0);
        }
        stream.sync();
        let mut got = vec![0u8; want.len() * 4];
        ws.download(2, &mut got, &stream);
        stream.sync();
        let got = bytes_f32(&got);

        let scale = want.iter().map(|x| x.abs()).fold(1.0f32, f32::max);
        let d = max_abs_diff(&got, &want);
        assert!(d <= 1e-3 * scale, "grad_W mismatch (max diff {d}, scale {scale})");
    }
}

#[test]
fn fused_backward_grad_bias_is_column_sum() {
    let stream = CudaStream::new();
    let s = shape(4, 3, 6, 5, 7, 3, 1, 1);
    let go: Vec<f32> = (0..s.b * s.cout * s.ho * s.wo).map(|i| det(i, 19)).collect();

    let mut want = vec![0.0f32; s.cout];
    let hw = s.ho * s.wo;
    for b in 0..s.b {
        for oc in 0..s.cout {
            for p in 0..hw {
                want[oc] += go[(b * s.cout + oc) * hw + p];
            }
        }
    }
    let ws = GpuWorkspace::new(&[go.len() * 4, s.cout * 4]);
    ws.upload(0, &f32_bytes(&go), &stream);
    unsafe {
        launch_conv_backward_grad_bias(ws.as_f32(0), ws.as_f32_mut(1),
                                       s.b as i32, s.cout as i32, s.ho as i32, s.wo as i32, stream.0);
    }
    stream.sync();
    let mut got = vec![0u8; s.cout * 4];
    ws.download(1, &mut got, &stream);
    stream.sync();
    let got = bytes_f32(&got);

    let scale = want.iter().map(|x| x.abs()).fold(1.0f32, f32::max);
    let d = max_abs_diff(&got, &want);
    assert!(d <= 1e-3 * scale, "grad_bias mismatch (max diff {d}, scale {scale})");
}

#[test]
fn fused_backward_grad_input_matches_col2im_reference() {
    let stream = CudaStream::new();
    for s in [shape(2, 3, 7, 6, 4, 3, 1, 1), shape(1, 2, 8, 8, 3, 3, 2, 1), shape(2, 2, 4, 9, 2, 1, 1, 0)] {
        let go: Vec<f32> = (0..s.b * s.cout * s.ho * s.wo).map(|i| det(i, 23)).collect();
        let cols = s.cin * s.kh * s.kw;
        let weight: Vec<f32> = (0..s.cout * cols).map(|i| det(i, 29)).collect();
        let want = ref_grad_input(&s, &go, &weight);
        let ws = GpuWorkspace::new(&[go.len() * 4, weight.len() * 4, want.len() * 4]);
        ws.upload(0, &f32_bytes(&go), &stream);
        ws.upload(1, &f32_bytes(&weight), &stream);
        unsafe {
            launch_conv_backward_grad_input(
                ws.as_f32(0), ws.as_f32(1), ws.as_f32_mut(2),
                s.b as i32, s.cin as i32, s.h as i32, s.w as i32, s.cout as i32,
                s.kh as i32, s.kw as i32, s.sh as i32, s.sw as i32, s.ph as i32, s.pw as i32,
                s.ho as i32, s.wo as i32, stream.0);
        }
        stream.sync();
        let mut got = vec![0u8; want.len() * 4];
        ws.download(2, &mut got, &stream);
        stream.sync();
        let got = bytes_f32(&got);

        let scale = want.iter().map(|x| x.abs()).fold(1.0f32, f32::max);
        let d = max_abs_diff(&got, &want);
        assert!(d <= 1e-3 * scale + 1e-3, "grad_input mismatch (max diff {d}, scale {scale})");
    }
}

// ------------------------------------------------------------
// Device-side maxpool (int8, no index tensor) — the low-PCIe-traffic path
// ------------------------------------------------------------

/// The device forward must produce exactly the host reference values, and the
/// device backward must scatter to exactly the elements the host reference
/// picks — including its tie-breaking rule (first strict maximum in
/// (0,0),(0,1),(1,0),(1,1) order), because the backward recomputes the argmax
/// instead of reading a stored index tensor.
#[test]
fn maxpool_i8_on_device_matches_host_index_reference() {
    let stream = CudaStream::new();
    // (2,3,6,8) and (1,128,4,16) exercise the real stem shapes; the tie cases
    // below pin the argmax rule down.
    for (b, c, h, w, ties) in [
        (1usize, 1usize, 2usize, 2usize, false),
        (2, 3, 6, 8, false),
        (1, 128, 4, 16, false),
        (2, 2, 4, 4, true),
    ] {
        let n = b * c * h * w;
        let input: Vec<i8> = if ties {
            // Constant planes: every 2x2 window is a four-way tie, so the
            // winner must be the top-left element of the window.
            (0..n).map(|i| (i / (h * w)) as i8 * 3 + 1).collect()
        } else {
            (0..n).map(|i| (det(i, 47) * 100.0) as i8).collect()
        };
        let (pooled, idx) = maxpool2x2_with_indices(&input, b, c, h, w);
        let (ho, wo) = (h / 2, w / 2);

        let go: Vec<f32> = (0..b * c * ho * wo).map(|i| det(i, 53)).collect();
        let mut want_dx = vec![0.0f32; n];
        for (i, &g) in go.iter().enumerate() {
            want_dx[idx[i] as usize] += g;
        }

        let ws = GpuWorkspace::new(&[n, pooled.len(), go.len() * 4, n * 4]);
        ws.upload_i8(0, &input, &stream);
        ws.upload_f32(2, &go, &stream);
        unsafe {
            launch_maxpool2x2_forward_i8(ws.as_i8(0), ws.as_i8_mut(1), b as i32, c as i32,
                                         h as i32, w as i32, stream.0);
            launch_maxpool2x2_backward_i8(ws.as_i8(0), ws.as_f32(2), ws.as_f32_mut(3),
                                          b as i32, c as i32, h as i32, w as i32, stream.0);
        }
        stream.sync();
        let mut got_pool = vec![0i8; pooled.len()];
        let mut got_dx = vec![0.0f32; n];
        ws.download_i8(1, &mut got_pool, &stream);
        ws.download_f32(3, &mut got_dx, &stream);
        stream.sync();

        assert_eq!(got_pool, pooled, "device maxpool forward differs from host reference");
        assert_eq!(got_dx, want_dx, "device maxpool backward scattered to the wrong elements");
        if ties {
            for oh in 0..ho {
                for ow in 0..wo {
                    let base = (oh * 2) * w + ow * 2;
                    assert_eq!(idx[oh * wo + ow] as usize % (h * w), base,
                               "tie must resolve to the top-left element");
                }
            }
        }
    }
}

/// The backward writes *every* element of dx (no atomics, no memset needed), so
/// a gradient that lands nowhere must come back as an exact zero rather than as
/// stale buffer content.
#[test]
fn maxpool_i8_backward_zeroes_non_selected_inputs() {
    let stream = CudaStream::new();
    // h=4, w=2 stacks the two windows vertically: window 0 = rows 0..1,
    // window 1 = rows 2..3.
    let (b, c, h, w) = (1usize, 1usize, 4usize, 2usize);
    // Window 0 has a clear winner (9), so three of its four inputs must come
    // back as exact zeros; window 1 is a four-way tie and resolves to its
    // top-left element.
    let input: Vec<i8> = vec![1, 9, 2, 2, -3, -3, -3, -3];
    let (ho, wo) = (h / 2, w / 2);
    let go = vec![1.5f32; b * c * ho * wo];

    let ws = GpuWorkspace::new(&[input.len(), go.len() * 4, input.len() * 4]);
    ws.upload_i8(0, &input, &stream);
    ws.upload_f32(1, &go, &stream);
    // Poison region 2 first: a kernel that only wrote the selected elements
    // would leave this pattern behind.
    ws.upload_f32(2, &vec![777.0f32; input.len()], &stream);
    unsafe {
        launch_maxpool2x2_backward_i8(ws.as_i8(0), ws.as_f32(1), ws.as_f32_mut(2),
                                      b as i32, c as i32, h as i32, w as i32, stream.0);
    }
    stream.sync();
    let mut dx = vec![0.0f32; input.len()];
    ws.download_f32(2, &mut dx, &stream);
    stream.sync();
    assert_eq!(dx, vec![0.0, 1.5, 0.0, 0.0, 1.5, 0.0, 0.0, 0.0]);
}

// ------------------------------------------------------------
// grad_input from the resident int8 weights
// ------------------------------------------------------------

/// `launch_conv_backward_grad_input_i8` must agree with the fp32 kernel fed the
/// *dequantised* int8 weights: same gather, same accumulation order, the scale
/// folded in once at the end.  This is what lets the backward skip the 160.8 MB
/// per-batch fp32 weight upload.
#[test]
fn grad_input_i8_matches_dequantised_fp32_reference() {
    let stream = CudaStream::new();
    for s in [shape(2, 3, 7, 6, 4, 3, 1, 1), shape(1, 2, 8, 8, 3, 3, 2, 1),
              shape(2, 2, 4, 9, 2, 1, 1, 0), shape(1, 4, 5, 5, 17, 3, 1, 1)] {
        let go: Vec<f32> = (0..s.b * s.cout * s.ho * s.wo).map(|i| det(i, 23)).collect();
        let cols = s.cin * s.kh * s.kw;
        let kp = align16(cols);
        let rp = align16(s.cout);

        // fake-quantise a random weight matrix exactly like ConvQat::requantize
        let raw: Vec<f32> = (0..s.cout * cols).map(|i| det(i, 29)).collect();
        let mx = raw.iter().map(|x| x.abs()).fold(0.0f32, f32::max);
        let w_s = if mx > 0.0 { mx / 127.0 } else { 1.0 };
        let w_q: Vec<i8> = raw.iter()
            .map(|&v| (v / w_s).clamp(-127.0, 127.0).round() as i8)
            .collect();
        let mut w_q_pad = vec![0i8; rp * kp];
        for r in 0..s.cout {
            for c in 0..cols {
                w_q_pad[r * kp + c] = w_q[r * cols + c];
            }
        }
        // reference: the fp32 kernel over the dequantised weights
        let w_deq: Vec<f32> = w_q.iter().map(|&q| q as f32 * w_s).collect();
        let want = ref_grad_input(&s, &go, &w_deq);

        let ws = GpuWorkspace::new(&[go.len() * 4, w_q_pad.len(), w_deq.len() * 4, want.len() * 4,
                                     want.len() * 4]);
        ws.upload_f32(0, &go, &stream);
        ws.upload_i8(1, &w_q_pad, &stream);
        ws.upload_f32(2, &w_deq, &stream);
        unsafe {
            launch_conv_backward_grad_input(
                ws.as_f32(0), ws.as_f32(2), ws.as_f32_mut(3),
                s.b as i32, s.cin as i32, s.h as i32, s.w as i32, s.cout as i32,
                s.kh as i32, s.kw as i32, s.sh as i32, s.sw as i32, s.ph as i32, s.pw as i32,
                s.ho as i32, s.wo as i32, stream.0);
            launch_conv_backward_grad_input_i8(
                ws.as_f32(0), ws.as_i8(1), kp as i32, w_s, ws.as_f32_mut(4),
                s.b as i32, s.cin as i32, s.h as i32, s.w as i32, s.cout as i32,
                s.kh as i32, s.kw as i32, s.sh as i32, s.sw as i32, s.ph as i32, s.pw as i32,
                s.ho as i32, s.wo as i32, stream.0);
        }
        stream.sync();
        let mut fp32_out = vec![0.0f32; want.len()];
        let mut i8_out = vec![0.0f32; want.len()];
        ws.download_f32(3, &mut fp32_out, &stream);
        ws.download_f32(4, &mut i8_out, &stream);
        stream.sync();

        let scale = want.iter().map(|x| x.abs()).fold(1.0f32, f32::max);
        let d_ref = max_abs_diff(&fp32_out, &want);
        assert!(d_ref <= 1e-3 * scale + 1e-3,
                "fp32 grad_input baseline broke (max diff {d_ref}, scale {scale})");
        let d = max_abs_diff(&i8_out, &want);
        assert!(d <= 1e-4 * scale + 1e-4,
                "int8 grad_input differs from the dequantised fp32 path (max diff {d}, scale {scale})");
    }
}

// ------------------------------------------------------------
// Device-resident conv optimiser (the "no more 362 MB per batch" path)
// ------------------------------------------------------------

/// `launch_max_abs_f32` + `launch_quantize_pad_i8` must reproduce
/// `ConvQat::requantize` exactly: same scale, same int8 values, same padding.
/// This is what lets the weights stay on the device between steps.
#[test]
fn device_requantize_matches_host_requantize() {
    let stream = CudaStream::new();
    for (rows, col) in [(4usize, 27usize), (16, 16), (17, 5), (64, 2048), (1, 1)] {
        let kp = align16(col);
        let rp = align16(rows);
        let w: Vec<f32> = (0..rows * col).map(|i| det(i, 31) * 0.3).collect();

        // host reference: exactly ConvQat::requantize
        let mx = w.iter().map(|x| x.abs()).fold(0.0f32, f32::max);
        let w_s = if mx > 0.0 { mx / 127.0 } else { 1.0 };
        let w_q: Vec<i8> = w.iter().map(|&v| (v / w_s).clamp(-127.0, 127.0).round() as i8).collect();
        let mut want = vec![0i8; rp * kp];
        for r in 0..rows {
            want[r * kp..r * kp + col].copy_from_slice(&w_q[r * col..(r + 1) * col]);
        }

        let ws = GpuWorkspace::new(&[w.len() * 4, 4, 4, want.len()]);
        ws.upload_f32(0, &w, &stream);
        ws.upload_f32(2, &[w_s], &stream); // poisoned below by the kernel
        unsafe {
            launch_max_abs_f32(ws.as_f32(0), ws.as_f32_mut(1), w.len() as i64, stream.0);
            launch_quantize_pad_i8(ws.as_f32(0), ws.as_f32(1), ws.as_f32_mut(2), ws.as_i8_mut(3),
                                   rows as i64, col as i64, kp as i64, stream.0);
        }
        stream.sync();
        let mut got_s = [0.0f32];
        let mut got = vec![0i8; want.len()];
        ws.download_f32(2, &mut got_s, &stream);
        ws.download_i8(3, &mut got, &stream);
        stream.sync();

        assert_eq!(got_s[0], w_s, "device QAT scale differs from the host one");
        assert_eq!(got, want, "device fake-quant differs from ConvQat::requantize");
    }

    // An all-zero weight matrix must fall back to scale 1.0, not divide by zero.
    let ws = GpuWorkspace::new(&[16 * 4, 4, 4, align16(16) * align16(16)]);
    ws.upload_f32(0, &vec![0.0f32; 16], &stream);
    unsafe {
        launch_max_abs_f32(ws.as_f32(0), ws.as_f32_mut(1), 16, stream.0);
        launch_quantize_pad_i8(ws.as_f32(0), ws.as_f32(1), ws.as_f32_mut(2), ws.as_i8_mut(3),
                               4, 4, align16(4) as i64, stream.0);
    }
    stream.sync();
    let mut got_s = [0.0f32];
    ws.download_f32(2, &mut got_s, &stream);
    stream.sync();
    assert_eq!(got_s[0], 1.0, "max|w| == 0 must give scale 1.0");
}

/// `launch_adam_f32` must be bit-identical to `Adam::step` from src/opt.rs —
/// same f64 intermediates, same f32 storage, same clip handling.
#[test]
fn device_adam_matches_host_adam_bit_for_bit() {
    let stream = CudaStream::new();
    let n = 1000usize;
    let p0: Vec<f32> = (0..n).map(|i| det(i, 37) * 0.2).collect();
    let g0: Vec<f32> = (0..n).map(|i| det(i, 41) * 3.0).collect();
    let m0: Vec<f32> = (0..n).map(|i| det(i, 43) * 0.01).collect();
    let v0: Vec<f32> = (0..n).map(|i| det(i, 47).abs() * 0.01).collect();
    let (lr, wd, clip) = (5.107e-4f64, 1.9548e-5f64, 0.83f64);
    let (b1, b2, eps) = (0.9f64, 0.999f64, 1e-8f64);
    let (bc1, bc2) = (1.0 - 0.9f64.powi(7), 1.0 - 0.999f64.powi(7));

    // host: replay opt.rs arithmetic on local copies
    let mut hp = p0.clone();
    let mut hm = m0.clone();
    let mut hv = v0.clone();
    for i in 0..n {
        let gi = (g0[i] as f64 * clip) as f32 as f64 + wd * hp[i] as f64;
        hm[i] = (b1 * hm[i] as f64 + (1.0 - b1) * gi) as f32;
        hv[i] = (b2 * hv[i] as f64 + (1.0 - b2) * gi * gi) as f32;
        let mh = hm[i] as f64 / bc1;
        let vh = hv[i] as f64 / bc2;
        hp[i] -= (lr * mh / (vh.sqrt() + eps)) as f32;
    }

    let ws = GpuWorkspace::new(&[n * 4; 4]);
    ws.upload_f32(0, &p0, &stream);
    ws.upload_f32(1, &g0, &stream);
    ws.upload_f32(2, &m0, &stream);
    ws.upload_f32(3, &v0, &stream);
    unsafe {
        launch_adam_f32(ws.as_f32_mut(0), ws.as_f32(1), ws.as_f32_mut(2), ws.as_f32_mut(3),
                        n as i64, lr, wd, clip, b1, b2, eps, bc1, bc2, stream.0);
    }
    stream.sync();
    let mut dp = vec![0.0f32; n];
    let mut dm = vec![0.0f32; n];
    let mut dv = vec![0.0f32; n];
    ws.download_f32(0, &mut dp, &stream);
    ws.download_f32(2, &mut dm, &stream);
    ws.download_f32(3, &mut dv, &stream);
    stream.sync();

    assert_eq!(dp, hp, "device Adam weights differ from src/opt.rs");
    assert_eq!(dm, hm, "device Adam first moment differs");
    assert_eq!(dv, hv, "device Adam second moment differs");
}

/// End to end: int32 grad_W accumulation -> global-norm sum of squares -> clip
/// -> Adam -> re-quantise, all on the device, must land on the same weights as
/// the original host pipeline (`ConvQat::g_w` + `Adam::step` + `requantize`).
#[test]
fn device_conv_optimizer_pipeline_matches_host_pipeline() {
    if !crate::qnet::conv_weights_on_device() {
        // TRBA_HOST_CONV_ADAM=1: device-конвейера оптимизатора не существует,
        // сравнивать нечего. Без пропуска тест падает на пустом месте, и весь
        // набор нельзя прогнать в host-режиме (а на коробке с 2 GB RAM только он
        // и возможен — device-состояние свёрток требует ещё ~676 MB).
        eprintln!("skip: device-оптимизатор выключен (TRBA_HOST_CONV_ADAM=1)");
        return;
    }
    let stream = CudaStream::new();
    let (lr, wd) = (5.107e-4f32, 1.9548e-5f32);

    // Two identical layers: `host` runs the old pipeline, `dev` the new one.
    let mut host = ConvQat::new("host", 3, 8, 3, 3, 1, 1, 1, 1);
    let mut dev = ConvQat::new("dev", 3, 8, 3, 3, 1, 1, 1, 1);
    let w0 = host.w.clone();
    dev.w = w0.clone();
    dev.requantize();
    let n = host.out_c * host.col_cols();

    // A deterministic int32 grad_W (what launch_gemm_int8 produces) and the
    // dequant factor the backward multiplies it by.
    let gw: Vec<i32> = (0..n).map(|i| (det(i, 53) * 4000.0) as i32).collect();
    let deq = 0.017f32;

    // ---- host pipeline ----
    for i in 0..n {
        host.g_w[i] += gw[i] as f32 * deq;
    }
    let mut opt = Adam::new();
    opt.t = 6; // step() bumps it to 7
    let mut params = vec![ParamRef {
        name: "host.w".into(),
        p: host.w.as_mut_ptr(),
        g: host.g_w.as_ptr() as *mut f32,
        len: n,
        // свёрточный вес здесь намеренно без формы: тест сравнивает устройство
        // с Adam из src/opt.rs, а не с Muon
        shape: None,
    }];
    let host_sq = Adam::sum_sq(&params);
    let norm = host_sq.sqrt();
    let clip_f = if norm > 5.0 { (5.0f64 / (norm + 1e-6)) as f32 } else { 1.0 };
    if clip_f < 1.0 {
        for pr in params.iter_mut() {
            let g = unsafe { std::slice::from_raw_parts_mut(pr.g, pr.len) };
            for x in g.iter_mut() {
                *x *= clip_f;
            }
        }
    }
    opt.step(&params, lr, wd);
    host.requantize();

    // ---- device pipeline ----
    let ws = GpuWorkspace::new(&[n * 4, 8]);
    let gw_bytes: Vec<u8> = gw.iter().flat_map(|x| x.to_le_bytes()).collect();
    ws.upload(0, &gw_bytes, &stream);
    ws.upload(1, &0.0f64.to_le_bytes(), &stream); // the f64 accumulator, zeroed per batch
    let gsq = ws.ptr(1) as *mut f64;
    dev.device_grad_accum(ws.ptr(0) as *const i32, deq, gsq, &stream);
    stream.sync();
    let mut sq_bytes = [0u8; 8];
    ws.download(1, &mut sq_bytes, &stream);
    stream.sync();
    let dev_sq = f64::from_le_bytes(sq_bytes);

    let rel = (dev_sq - host_sq).abs() / host_sq.max(1e-30);
    assert!(rel < 1e-12, "device sum of squares {dev_sq} vs host {host_sq} (rel {rel})");

    let dev_norm = dev_sq.sqrt();
    let dev_clip = if dev_norm > 5.0 { (5.0f64 / (dev_norm + 1e-6)) as f32 } else { 1.0 };
    assert_eq!(dev_clip, clip_f, "clip factor differs");
    let (bc1, bc2) = opt.bias_correction();
    dev.device_adam(lr as f64, wd as f64, dev_clip as f64, opt.beta1 as f64, opt.beta2 as f64,
                    opt.eps as f64, bc1, bc2, &stream);
    dev.device_requantize(&stream);
    dev.sync_shadow_from_device(&stream);

    assert_eq!(dev.w_s, host.w_s, "QAT scale differs after a full device step");
    let d = max_abs_diff(&dev.w, &host.w);
    let scale = host.w.iter().map(|x| x.abs()).fold(1.0f32, f32::max);
    assert!(d <= 1e-6 * scale, "device-optimised weights drifted from the host ones ({d})");
}

// ------------------------------------------------------------
// Conv layer
// ------------------------------------------------------------
#[test]
fn conv_forward_matches_quantised_reference() {
    let stream = CudaStream::new();
    let mut conv = Conv2dInt8::new(3, 8, 3, 1, 1);
    conv.bias = (0..8).map(|i| det(i, 31) * 0.1).collect();

    let (b, h, w) = (2usize, 9usize, 11usize);
    let input: Vec<i8> = (0..b * 3 * h * w).map(|i| (det(i, 37) * 100.0) as i8).collect();
    let (out, ho, wo) = conv.forward_batched(&input, b, h, w, &stream);

    // reference: im2col in int8, exact integer dot product with weight_int8,
    // then the same dequant/bias/ReLU/requant epilogue.
    // signature: (input, b, c, h, w, kh, kw, sh, sw, ph, pw)
    let col = ref_im2col(&input, b, 3, h, w, 3, 3, 1, 1, 1, 1);
    let cols = 3 * 3 * 3;
    assert_eq!(out.len(), b * 8 * ho * wo);
    for bi in 0..b {
        for p in 0..ho * wo {
            let row = bi * ho * wo + p;
            for oc in 0..8 {
                let mut acc = 0i32;
                for cc in 0..cols {
                    // weight_int8 is [out_channels][col_cols]
                    acc += col[row * cols + cc] as i32 * conv.weight_int8[oc * cols + cc] as i32;
                }
                let v = acc as f32 / ACC_DIVISOR + conv.bias[oc];
                let want = (v.max(0.0) * OUT_MULTIPLIER).clamp(-127.0, 127.0).round() as i8;
                let got = out[(bi * 8 + oc) * ho * wo + p];
                assert_eq!(got, want, "conv forward mismatch b={bi} p={p} oc={oc}");
            }
        }
    }
}

#[test]
fn conv_backward_shapes_and_finite() {
    let stream = CudaStream::new();
    let mut conv = Conv2dInt8::new(4, 6, 3, 1, 1);
    let (b, h, w) = (2usize, 7usize, 5usize);
    let (ho, wo) = conv.out_hw(h, w);

    let input: Vec<i8> = (0..b * 4 * h * w).map(|i| (det(i, 41) * 100.0) as i8).collect();
    let go: Vec<f32> = (0..b * 6 * ho * wo).map(|i| det(i, 43) * 0.01).collect();

    let w_before = conv.weight_f32.clone();
    let gi = conv.backward_qat_gpu(&input, &go, b, h, w, 1e-3, 0.9, &stream, false);

    assert_eq!(gi.len(), b * 4 * h * w, "grad_input length");
    assert!(gi.iter().all(|x| x.is_finite()), "grad_input has NaN/Inf");
    assert!(conv.weight_f32.iter().all(|x| x.is_finite()), "weights have NaN/Inf");
    assert!(conv.bias.iter().all(|x| x.is_finite()), "bias has NaN/Inf");
    // The optimizer must actually move the weights.
    let moved = conv.weight_f32.iter().zip(w_before.iter()).filter(|(a, b2)| (*a - *b2).abs() > 0.0).count();
    assert!(moved > 0, "backward did not update any weight");
    assert_eq!(conv.weight_int8.len(), conv.weight_f32.len());
}

// ------------------------------------------------------------
// Maxpool
// ------------------------------------------------------------
#[test]
fn maxpool_forward_backward_roundtrip() {
    let (b, c, h, w) = (2usize, 3usize, 6usize, 8usize);
    let input: Vec<i8> = (0..b * c * h * w).map(|i| (det(i, 47) * 100.0) as i8).collect();
    let (pooled, idx) = maxpool2x2_with_indices(&input, b, c, h, w);

    let (ho, wo) = (h / 2, w / 2);
    assert_eq!(pooled.len(), b * c * ho * wo);
    for (i, &v) in pooled.iter().enumerate() {
        assert_eq!(input[idx[i] as usize], v, "maxpool index does not point at the maximum");
    }

    // backward: every output gradient lands on exactly its argmax input
    let go: Vec<f32> = (0..b * c * ho * wo).map(|i| det(i, 53)).collect();
    let mut gi = vec![0.0f32; b * c * h * w];
    unsafe {
        maxpool2x2_backward_host(go.as_ptr(), idx.as_ptr(), gi.as_mut_ptr(),
                                 go.len() as u64, gi.len() as u64);
    }
    let mut expected = vec![0.0f32; b * c * h * w];
    for (i, &g) in go.iter().enumerate() {
        expected[idx[i] as usize] += g;
    }
    assert_eq!(gi, expected);
}

// ------------------------------------------------------------
// Linear
// ------------------------------------------------------------
#[test]
fn linear_forward_matches_int8_reference() {
    let stream = CudaStream::new();
    let lin = LinearInt8::new(20, 7);
    let rows = 5;
    let inp: Vec<i8> = (0..rows * 20).map(|i| (det(i, 59) * 100.0) as i8).collect();
    let out = lin.forward(&inp, &stream);
    assert_eq!(out.len(), rows * 7);

    for r in 0..rows {
        for o in 0..7 {
            let mut acc = 0i32;
            for i in 0..20 {
                acc += inp[r * 20 + i] as i32 * lin.weight_int8[o * 20 + i] as i32;
            }
            assert_eq!(out[r * 7 + o], acc, "linear mismatch r={r} o={o}");
        }
    }
}

#[test]
fn linear_backward_gradient_matches_finite_differences() {
    let mut lin = LinearInt8::new(6, 4);
    lin.weight_f32 = (0..4 * 6).map(|i| det(i, 61) * 0.5).collect();
    lin.requantize();

    let rows = 3;
    let inp: Vec<f32> = (0..rows * 6).map(|i| det(i, 67)).collect();
    // Arbitrary scalar function of the layer output: sum of squares.
    let out: Vec<f32> = (0..rows * 4)
        .map(|i| {
            let r = i / 4;
            let o = i % 4;
            (0..6).map(|k| inp[r * 6 + k] * lin.weight_f32[o * 6 + k]).sum::<f32>()
        })
        .collect();
    let go: Vec<f32> = out.iter().map(|x| 2.0 * x / rows as f32).collect();

    let lr = 1.0f32;
    let before = lin.weight_f32.clone();
    let clip = lin.backward(&inp, &go, lr, 0.0);

    // LinearInt8::backward averages the outer product over the batch, so
    // grad_W[o,i] = (1/rows) * sum_r go[r,o] * inp[r,i].
    for o in 0..4 {
        for i in 0..6 {
            let mut g = 0.0f32;
            for r in 0..rows {
                g += go[r * 4 + o] * inp[r * 6 + i];
            }
            let g = g / rows as f32;
            let want = before[o * 6 + i] - lr * clip * g;
            let got = lin.weight_f32[o * 6 + i];
            // The kernel accumulates in f32 over the batch, the reference in
            // a different order; allow the corresponding rounding slack.
            let tol = 1e-5 * want.abs().max(1.0) + 1e-4;
            assert!((got - want).abs() < tol, "linear grad mismatch at o={o} i={i}: {got} vs {want}");
        }
    }
}

// ------------------------------------------------------------
// Backbone
// ------------------------------------------------------------
#[test]
fn backbone_forward_shape_and_backward_chain() {
    let stream = CudaStream::new();
    let mut cnn = crate::seresnet::SEResNet31::new();
    // Keep the test cheap: shrink every layer to a couple of channels would
    // change the architecture, so instead use a single small image.
    let b = 1usize;
    let input = vec![7i8; b * 3 * 64 * 256];

    let r = cnn.forward_save(&input, b, &stream);
    // 5 maxpools: 64x256 -> 2x8
    assert_eq!(r.out_h, 2, "output height should be 64/32");
    assert_eq!(r.out_w, 8, "output width should be 256/32");
    assert_eq!(r.output.len(), b * 512 * 2 * 8);
    // 19 conv + 5 maxpool activations
    assert_eq!(r.activations.len(), 24, "activation count");

    let grad = vec![0.001f32; b * 512 * 2 * 8];
    let last_before = cnn.conv_out.weight_f32.clone();
    let first_before = cnn.conv0_0.weight_f32.clone();

    // stage 98 == train only the last 4 conv layers
    let _ = cnn.backward_chain(&r, &grad, 1e-4, 0.9, &stream, 98, false);

    let last_moved = cnn.conv_out.weight_f32.iter().zip(last_before.iter())
        .any(|(a, b2)| (*a - *b2).abs() > 0.0);
    let first_moved = cnn.conv0_0.weight_f32.iter().zip(first_before.iter())
        .any(|(a, b2)| (*a - *b2).abs() > 0.0);
    assert!(last_moved, "the last conv layer should have been trained");
    assert!(!first_moved, "a frozen stem layer must not be touched at stage 98");
}

#[test]
fn workspace_regions_do_not_overlap() {
    let ws = GpuWorkspace::new(&[1000, 1, 4096, 7]);
    let p0 = ws.ptr(0) as usize;
    let p1 = ws.ptr(1) as usize;
    let p2 = ws.ptr(2) as usize;
    let p3 = ws.ptr(3) as usize;
    assert!(p1 >= p0 + 1000);
    assert!(p2 >= p1 + 1);
    assert!(p3 >= p2 + 4096);
    assert_eq!(p0 % 16, 0, "regions must be at least 16-byte aligned");
    assert_eq!(p1 % 16, 0);
}

/// The QAT backbone walks 11 SE blocks in its backward and pairs each one with
/// the trace the forward recorded for it.  That pairing used to be wrong: the
/// list was built deepest-layer-first (`layer4, layer3, layer2, layer1`) and then
/// walked *backwards*, so the gradient arriving at layer4's last block was pushed
/// through layer1's block with layer1's trace.  The element counts disagree
/// (b*512*H4*W4 vs b*256*H1*W1), so the block dequantised its int8 gradient past
/// the end of the buffer — an illegal memory access on the GPU, a heap overflow
/// on the CPU, and nonsense CNN gradients everywhere in between.
///
/// `SEResNetQ::backward` now asserts the pairing, and this test is what exercises
/// that path at all: `backbone_forward_shape_and_backward_chain` covers the fp32
/// `seresnet::SEResNet31`, a different network.
#[test]
fn qat_backbone_backward_pairs_every_block_with_its_own_trace() {
    use crate::qnet::{Scratch, SEResNetQ};

    let stream = CudaStream::new();
    let mut net = SEResNetQ::new(512);
    let mut sc = Scratch::new();
    // 32x32 достаточно: формы layer1 (256x8x8) и layer4 (512x2x4) всё равно
    // расходятся вдвое, а памяти тест ест заметно меньше — на коробке с 2 GB
    // полный набор тестов иначе упирается в OOM-killer.
    let (b, h, w) = (1usize, 32usize, 32usize);

    // same setup main() does before the first step
    net.upload_conv_weights(&stream);
    net.requantize_all(&stream);

    let img = std::sync::Arc::new(DevBuf::new(b * 3 * h * w));
    let host_img = vec![5i8; b * 3 * h * w];
    img.upload_i8(&host_img, &stream);

    let (_feat, trace) = net.forward(&img, 1.0f32, b, true, h, w, &stream, &mut sc);
    assert_eq!(trace.blocks.len(), 11, "SE blocks recorded by the forward");

    // dL/dfeat is [b, t, 512], t = w_feat after the horizontal mean pool
    let t = trace.out.w_feat;
    assert!(t > 0, "feature width");
    let d_feat = DevBuf::new(b * t * 512 * 4);
    let host_d = vec![1e-3f32; b * t * 512];
    d_feat.upload_f32(&host_d, &stream);
    stream.sync();

    // panics with both shapes printed if a block is ever paired with the wrong
    // trace again; without the assert this is an out-of-bounds device read
    net.backward(&d_feat, &trace, &stream, &mut sc);
    stream.sync();
}

#[test]
fn bilstm_batch_items_do_not_mix_forward_or_backward() {
    // Вход и dx у BiLSTM — [B, T, D]: пример, попавший в батч, обязан давать тот
    // же выход и тот же градиент, что и одиночный прогон с b = 1. До починки
    // индексации (`tt * b * d + bi * d` вместо `(bi * t + tt) * d`) при b >= 2
    // время перемешивалось с батчем: на вход BiLSTM приходила переставленная
    // последовательность, а d_feat уходил в CNN транспонированным. При b = 1 обе
    // раскладки совпадают, поэтому баг не ловился ни одним существующим тестом и
    // не проявлялся в однопоточных по батчу прогонах (--autotune, smoke).
    use crate::rnn::BiLstmLayer;

    let (b, t, d, h, out) = (2usize, 3usize, 8usize, 4usize, 5usize);
    let layer = BiLstmLayer::new(d, h, out);
    let x: Vec<f32> = (0..b * t * d).map(|i| ((i as f32) * 0.37).sin()).collect();
    let dy: Vec<f32> = (0..b * t * out).map(|i| ((i as f32) * 0.11).cos()).collect();

    let (y_b, _tr_b) = layer.forward(&x, b, t);
    let mut la = layer.clone();
    let (_, tr_a) = la.forward(&x, b, t);
    let dx_b = la.backward(&dy, &tr_a);

    for bi in 0..b {
        let xi: Vec<f32> = (0..t * d).map(|r| x[bi * t * d + r]).collect();
        let dyi: Vec<f32> = (0..t * out).map(|r| dy[bi * t * out + r]).collect();

        let (y_1, _) = layer.forward(&xi, 1, t);
        for r in 0..t * out {
            let (got, want) = (y_b[bi * t * out + r], y_1[r]);
            assert!(
                (got - want).abs() < 1e-5,
                "forward: пример {bi}, строка {r}: в батче {got}, одиночно {want}"
            );
        }

        let mut lb = layer.clone();
        let (_, tr_1) = lb.forward(&xi, 1, t);
        let dx_1 = lb.backward(&dyi, &tr_1);
        for r in 0..t * d {
            let (got, want) = (dx_b[bi * t * d + r], dx_1[r]);
            assert!(
                (got - want).abs() < 1e-4,
                "backward dx: пример {bi}, строка {r}: в батче {got}, одиночно {want}"
            );
        }
    }
}

/// Независимая эталонная реализация одного направления LSTM: вход [B, T, D],
/// выход — hidden в порядке ПОЗИЦИЙ [B, T, H]. Порядок врат PyTorch:
/// (input, forget, cell, output). Нужна, чтобы проверять `rnn.rs` не «самим
/// собой», а внешней реализацией: расхождение порядка слотов/позиций в
/// реверсном направлении такой тест ловит сразу.
fn ref_lstm_dir(
    x: &[f32],
    w_ih: &[f32],
    b_ih: &[f32],
    w_hh: &[f32],
    b_hh: &[f32],
    b: usize,
    t: usize,
    d: usize,
    h: usize,
    rev: bool,
) -> Vec<f32> {
    let mut out = vec![0.0f32; b * t * h];
    let mut c_prev = vec![0.0f32; b * h];
    let mut h_prev = vec![0.0f32; b * h];
    for step in 0..t {
        let tt = if rev { t - 1 - step } else { step };
        for bi in 0..b {
            let mut c_new = vec![0.0f32; h];
            let mut h_new = vec![0.0f32; h];
            for i in 0..h {
                let mut g = [0.0f32; 4];
                for q in 0..4 {
                    let o = q * h + i;
                    let mut s = b_ih[o] + b_hh[o];
                    for k in 0..d {
                        s += x[(bi * t + tt) * d + k] * w_ih[o * d + k];
                    }
                    for k in 0..h {
                        s += h_prev[bi * h + k] * w_hh[o * h + k];
                    }
                    g[q] = s;
                }
                let ig = 1.0 / (1.0 + (-g[0]).exp());
                let fg = 1.0 / (1.0 + (-g[1]).exp());
                let cg = g[2].tanh();
                let og = 1.0 / (1.0 + (-g[3]).exp());
                c_new[i] = fg * c_prev[bi * h + i] + ig * cg;
                h_new[i] = og * c_new[i].tanh();
            }
            for i in 0..h {
                out[(bi * t + tt) * h + i] = h_new[i];
                c_prev[bi * h + i] = c_new[i];
                h_prev[bi * h + i] = h_new[i];
            }
        }
    }
    out
}

#[test]
fn bilstm_directions_are_aligned_by_time_position() {
    // cat = [fwd_h(tt), bwd_h(tt)]: обе половины обязаны относиться к одной и той
    // же позиции tt. Трекеры направлений хранятся по слотам шага, и для
    // реверсного направления слот step соответствует позиции t-1-step, поэтому
    // вторая половина cat берётся из слота t-1-tt. Раньше обе половины брались
    // из слота tt, то есть реверсный контекст оказывался зеркально перевёрнут:
    // на позиции tt модель видела реверсные признаки позиции t-1-tt. Баг не
    // зависел от размера батча и не проявлялся в лоссе (обратный ход был
    // самосогласован), поэтому проверяем против внешней эталонной реализации.
    use crate::rnn::BiLstmLayer;

    let (b, t, d, h) = (1usize, 5usize, 6usize, 4usize);
    let mut layer = BiLstmLayer::new(d, h, 2 * h);
    // проекция = единичная матрица, чтобы y совпадал с cat
    for o in 0..2 * h {
        for k in 0..2 * h {
            layer.proj_w[o * 2 * h + k] = if o == k { 1.0 } else { 0.0 };
        }
    }
    layer.proj_b.iter_mut().for_each(|x| *x = 0.0);

    let x: Vec<f32> = (0..b * t * d).map(|i| ((i as f32) * 0.53).sin()).collect();
    let (y, _tr) = layer.forward(&x, b, t);

    let rf = ref_lstm_dir(&x, &layer.fwd.w_ih, &layer.fwd.b_ih, &layer.fwd.w_hh,
        &layer.fwd.b_hh, b, t, d, h, false);
    let rb = ref_lstm_dir(&x, &layer.bwd.w_ih, &layer.bwd.b_ih, &layer.bwd.w_hh,
        &layer.bwd.b_hh, b, t, d, h, true);

    for tt in 0..t {
        for i in 0..h {
            let got_f = y[tt * 2 * h + i];
            let want_f = rf[tt * h + i];
            assert!(
                (got_f - want_f).abs() < 1e-4,
                "прямое направление, позиция {tt}, признак {i}: {got_f} != {want_f}"
            );
            let got_b = y[tt * 2 * h + h + i];
            let want_b = rb[tt * h + i];
            assert!(
                (got_b - want_b).abs() < 1e-4,
                "реверсное направление, позиция {tt}, признак {i}: {got_b} != {want_b} \
                 (похоже на зеркальный сдвиг: слот вместо позиции)"
            );
        }
    }
}

#[test]
fn device_bilstm_matches_host_bilstm() {
    // Device-путь BiLSTM (TRBA_GPU_RNN=1) обязан давать тот же enc, тот же dx и
    // те же градиенты весов, что и хостовый путь. Без GPU этот тест сравнивает
    // хостовую реализацию с CPU-зеркалами ядер из cuda/cpu_backend.cpp, на карте
    // — с настоящими ядрами из cuda/kernels.cu: код теста один и тот же, поэтому
    // расхождение индексов (слоты против позиций, [T,B,·] против [B,T,·])
    // ловится в песочнице до выезда на железо. Допуск нужен, потому что порядок
    // сложения в fp32 различается: warp-редукция против последовательной суммы.
    use crate::backend::{CudaStream, DevBuf};
    use crate::rnn::BiLstmStack;

    let (b, t, d, h) = (2usize, 5usize, 8usize, 4usize);
    let host = BiLstmStack::new(d, h, 2);
    let mut dev = BiLstmStack { layers: host.layers.clone() };
    let mut host_mut = BiLstmStack { layers: host.layers.clone() };

    let x: Vec<f32> = (0..b * t * d).map(|i| ((i as f32) * 0.31).sin()).collect();
    let dy: Vec<f32> = (0..b * t * h).map(|i| ((i as f32) * 0.17).cos()).collect();
    let stream = CudaStream::new();

    let (y_h, tr_h) = host.forward(&x, b, t);
    let x_dev = DevBuf::new(x.len() * 4);
    x_dev.upload_f32(&x, &stream);
    let (y_d, tr_d) = dev.forward_device(x_dev, b, t, &stream);

    let close = |a: f32, c: f32| (a - c).abs() <= 1e-4 * (1.0 + a.abs());
    for (i, (a, c)) in y_h.iter().zip(y_d.iter()).enumerate() {
        assert!(close(*a, *c), "enc[{i}]: host {a}, device {c}");
    }

    let dx_h = host_mut.backward(&dy, &tr_h);
    let dx_dev_buf = dev.backward_device(&dy, &tr_d, &stream);
    let mut dx_d = vec![0.0f32; b * t * d];
    dx_dev_buf.download_f32(&mut dx_d, &stream);
    stream.sync();
    for (i, (a, c)) in dx_h.iter().zip(dx_d.iter()).enumerate() {
        assert!(close(*a, *c), "dx[{i}]: host {a}, device {c}");
    }

    // градиенты весов обоих направлений обоих слоёв
    for (li, (lh, ld)) in host_mut.layers.iter().zip(dev.layers.iter()).enumerate() {
        for (dir_name, lh_dir, ld_dir) in [("fwd", &lh.fwd, &ld.fwd), ("bwd", &lh.bwd, &ld.bwd)] {
            for (w_name, gh, gd) in [
                ("g_w_ih", &lh_dir.g_w_ih, &ld_dir.g_w_ih),
                ("g_w_hh", &lh_dir.g_w_hh, &ld_dir.g_w_hh),
                ("g_b_ih", &lh_dir.g_b_ih, &ld_dir.g_b_ih),
                ("g_b_hh", &lh_dir.g_b_hh, &ld_dir.g_b_hh),
            ] {
                assert_eq!(gh.len(), gd.len(), "{w_name}: размер");
                for (i, (a, c)) in gh.iter().zip(gd.iter()).enumerate() {
                    assert!(
                        close(*a, *c),
                        "слой {li} {dir_name} {w_name}[{i}]: host {a}, device {c}"
                    );
                }
            }
        }
        for (w_name, gh, gd) in [("g_proj_w", &lh.g_proj_w, &ld.g_proj_w),
                                 ("g_proj_b", &lh.g_proj_b, &ld.g_proj_b)] {
            for (i, (a, c)) in gh.iter().zip(gd.iter()).enumerate() {
                assert!(close(*a, *c), "слой {li} {w_name}[{i}]: host {a}, device {c}");
            }
        }
    }
}

// ------------------------------------------------------------
// Muon (momentum-free) + MuonQ
// ------------------------------------------------------------

/// Шаг Muon обязан совпадать с формулой из src/opt.rs и conv2d.rs::muon_update:
/// `scale = min(sqrt(min_dim)/||g||_F, cap)`, `lr_eff = lr*sqrt(max_dim)`,
/// `w = w*(1 - lr*wd) - lr_eff*scale*g`. Заодно проверяется, что вектор в том же
/// списке остался на Adam (и что его арифметика побитово прежняя, f64), а у
/// матрицы состояния нет вовсе — именно поэтому чекпоинт худеет.
#[test]
fn muon_step_matches_reference_formula() {
    use crate::opt::{Adam, MuonSpec, ParamRef};

    let (rows, cols) = (6usize, 4usize);
    let n = rows * cols;
    let mut w: Vec<f32> = (0..n).map(|i| ((i as f32) * 0.37).sin()).collect();
    let mut g: Vec<f32> = (0..n).map(|i| ((i as f32) * 0.11).cos() * 0.7).collect();
    let mut bias = vec![0.5f32, -0.25, 1.0];
    let mut g_bias = vec![0.01f32, -0.02, 0.03];
    let (w0, g0) = (w.clone(), g.clone());
    let (b0, gb0) = (bias.clone(), g_bias.clone());

    let mut opt = Adam::new();
    opt.muon = MuonSpec { on: true, cap: 10.0, autoscale: true, q_block: 0 };
    opt.clip_warmup = 0;
    let (lr, wd) = (5.107e-4f32, 1.9548e-5f32);
    let params = vec![
        ParamRef { name: "m.w".into(), p: w.as_mut_ptr(), g: g.as_ptr() as *mut f32, len: n,
                   shape: Some((rows, cols)) },
        ParamRef { name: "m.b".into(), p: bias.as_mut_ptr(), g: g_bias.as_ptr() as *mut f32,
                   len: 3, shape: None },
    ];
    opt.step(&params, lr, wd);

    let frob = g0.iter().fold(0.0f32, |a, x| a + x * x).sqrt().max(1e-8);
    let scale = ((rows.min(cols) as f32).sqrt() / frob).min(10.0);
    let step = lr * (rows.max(cols) as f32).sqrt() * scale;
    let dec = 1.0f32 - lr * wd;
    for i in 0..n {
        let want = w0[i] * dec - step * g0[i];
        assert!(
            (w[i] - want).abs() <= 1e-6 * (1.0 + want.abs()),
            "w[{i}]: {} != {want}", w[i]
        );
    }

    assert!(opt.moment("m.w").0.is_none(), "у матрицы в режиме Muon моментов быть не должно");
    assert!(opt.moment("m.b").0.is_some(), "вектор должен остаться на Adam");

    // вектор: прежняя арифметика Adam, элемент за элементом в f64
    let bc1 = 1.0 - 0.9f64.powi(1);
    let bc2 = 1.0 - 0.999f64.powi(1);
    for i in 0..3 {
        let gi = gb0[i] as f64 + wd as f64 * b0[i] as f64;
        let m = (0.9f64 * 0.0 + (1.0 - 0.9f64) * gi) as f32;
        let v = (0.999f64 * 0.0 + (1.0 - 0.999f64) * gi * gi) as f32;
        let want = b0[i] - (lr as f64 * (m as f64 / bc1) / ((v as f64 / bc2).sqrt() + 1e-8)) as f32;
        assert_eq!(bias[i], want, "bias[{i}]: арифметика Adam для векторов изменилась");
    }
}

/// MuonQ: int8-квантование градиента блоками по 128 обязано (а) менять шаг —
/// иначе квантования на самом деле нет, (б) менять его в пределах половины
/// шага квантования на элемент, (в) сохранять направление (косинус > 0.999).
/// Размер 37x259 намеренно не кратен 128: проверяется хвост последнего блока.
#[test]
fn muon_q_block128_tracks_fp32_muon() {
    use crate::opt::{Adam, MuonSpec, ParamRef};

    let (rows, cols) = (37usize, 259usize);
    let n = rows * cols;
    let w0: Vec<f32> = (0..n).map(|i| ((i as f32) * 0.013).sin()).collect();
    // один блок делается нарочно крупнее остальных: шкала per-block должна это
    // съесть, а per-tensor — нет
    let g0: Vec<f32> = (0..n)
        .map(|i| {
            let base = ((i as f32) * 0.071).cos() * 0.3;
            if i / 128 == 3 { base * 40.0 } else { base }
        })
        .collect();

    let run = |qb: usize| -> Vec<f32> {
        let mut w = w0.clone();
        let mut g = g0.clone();
        let mut opt = Adam::new();
        opt.muon = MuonSpec { on: true, cap: 10.0, autoscale: true, q_block: qb };
        opt.clip_warmup = 0;
        let params = vec![ParamRef {
            name: "q.w".into(),
            p: w.as_mut_ptr(),
            g: g.as_ptr() as *mut f32,
            len: n,
            shape: Some((rows, cols)),
        }];
        opt.step(&params, 5.107e-4, 1.9548e-5);
        w
    };

    let wf = run(0);
    let wq = run(128);

    // направление шага
    let uf: Vec<f32> = w0.iter().zip(wf.iter()).map(|(a, b)| a - b).collect();
    let uq: Vec<f32> = w0.iter().zip(wq.iter()).map(|(a, b)| a - b).collect();
    let dot: f64 = uf.iter().zip(uq.iter()).map(|(a, b)| (*a as f64) * (*b as f64)).sum();
    let na: f64 = uf.iter().map(|x| (*x as f64) * (*x as f64)).sum::<f64>().sqrt();
    let nb: f64 = uq.iter().map(|x| (*x as f64) * (*x as f64)).sum::<f64>().sqrt();
    let cos = dot / (na * nb);
    assert!(cos > 0.999, "косинус направлений fp32 и int8-шага {cos}");

    // величина: fp32-эталон шкалы и допустимая погрешность квантования
    let frob = g0.iter().fold(0.0f32, |a, x| a + x * x).sqrt().max(1e-8);
    let scale = ((rows.min(cols) as f32).sqrt() / frob).min(10.0);
    let step = 5.107e-4f32 * (rows.max(cols) as f32).sqrt() * scale;
    // допуск по максимуму своего блока, а не по глобальному: при per-block шкале
    // ошибка элемента ограничена половиной шага квантования именно его блока
    let mut worst = 0.0f32;
    let mut worst_tol = 0.0f32;
    let mut any_diff = false;
    for i in 0..n {
        let lo = (i / 128) * 128;
        let hi = (lo + 128).min(n);
        let bmax = g0[lo..hi].iter().fold(0.0f32, |a, x| a.max(x.abs()));
        // половина шага квантования своего блока + 1 % на то, что норма (а с ней
        // и step) у int8-версии чуть другая: шум квантования добавляет мощности
        let tol = step * bmax / 254.0 * 1.05 + 0.01 * step * g0[i].abs() + 1e-12;
        let d = (wf[i] - wq[i]).abs();
        if d > 0.0 {
            any_diff = true;
        }
        if d > worst {
            worst = d;
            worst_tol = tol;
        }
        assert!(d <= tol, "элемент {i}: расхождение {d} больше допуска {tol}");
    }
    let tol = worst_tol;
    assert!(any_diff, "int8-шаг совпал с fp32 побитово: квантование не произошло");
    eprintln!(
        "        MuonQ: косинус {cos:.6}, худшее расхождение {:.3e} (допуск {:.3e})",
        worst, tol
    );
}

/// Device-ядро `muon_step_f32_kernel` (в песочнице — его CPU-зеркало) обязано
/// прийти к тем же весам, что и эталонная формула на хосте: тот же int32-градиент
/// через `device_grad_accum`, та же норма в f64, тот же масштаб.
#[test]
fn device_conv_muon_matches_host_reference() {
    let stream = CudaStream::new();
    let mut dev = ConvQat::new("devmuon", 3, 8, 3, 3, 1, 1, 1, 1);
    let n = dev.out_c * dev.col_cols();
    let w0 = dev.w.clone();

    let gw: Vec<i32> = (0..n).map(|i| (det(i, 91) * 4000.0) as i32).collect();
    let deq = 0.017f32;
    let ws = GpuWorkspace::new(&[n * 4, 8]);
    let gw_bytes: Vec<u8> = gw.iter().flat_map(|x| x.to_le_bytes()).collect();
    ws.upload(0, &gw_bytes, &stream);
    ws.upload(1, &0.0f64.to_le_bytes(), &stream);
    dev.device_grad_accum(ws.ptr(0) as *const i32, deq, ws.ptr(1) as *mut f64, &stream);
    stream.sync();

    let (lr, wd, cap) = (5.107e-4f64, 1.9548e-5f64, 10.0f64);
    dev.device_muon(lr, wd, 1.0, cap, true, &stream);
    // `sync_shadow_from_device` в host-режиме — no-op, поэтому читаем напрямую
    let mut got = vec![0.0f32; n];
    dev.peek_device_weights(&mut got, &stream);

    // эталон: g = gw*deq, норма в f64, масштаб и шаг — как в ядре
    let g: Vec<f32> = gw.iter().map(|x| *x as f32 * deq).collect();
    let frob = g.iter().fold(0.0f64, |a, x| a + (*x as f64) * (*x as f64)).sqrt();
    let (rows, cols) = (dev.out_c as f64, dev.col_cols() as f64);
    let scale = (rows.min(cols).sqrt() / frob.max(1e-8)).min(cap);
    let step = (lr * rows.max(cols).sqrt() * scale) as f32;
    let dec = (1.0 - lr * wd) as f32;
    let mx = w0.iter().fold(0.0f32, |a, x| a.max(x.abs())).max(1e-6);
    let mut worst = 0.0f32;
    for i in 0..n {
        let want = w0[i] * dec - step * g[i];
        worst = worst.max((got[i] - want).abs());
        assert!(
            (got[i] - want).abs() <= 1e-5 * mx,
            "w[{i}]: device {} != эталон {want}", got[i]
        );
    }
    eprintln!("        device Muon: худшее расхождение {worst:.3e} при масштабе веса {mx:.3}");
}

// --------------------------------------------------------------------------
// MoPE (Mixture of Pretrained Experts): роутер ZAYA1, PID-балансировка,
// learned residual scaling, CCA, агрегатор Markovian RSA, int8-хранилище.
// --------------------------------------------------------------------------

use crate::moe::*;
use rand::{Rng, SeedableRng};

/// Конечно-разностная проверка: |численный − аналитический| в пределах допуска.
fn fd_check(name: &str, ana: f32, f: impl Fn(f32) -> f32, x: f32) -> f32 {
    let eps = 2e-3f32;
    let num = (f(x + eps) - f(x - eps)) / (2.0 * eps);
    let tol = 3e-3 + 3e-2 * num.abs();
    assert!((num - ana).abs() <= tol, "{name}: аналитический {ana:.6e}, численный {num:.6e}");
    (num - ana).abs()
}

#[test]
fn moe_router_gradient_matches_finite_differences() {
    let (rows, d, r, e) = (3usize, 7usize, 5usize, 4usize);
    let mut rng = rand::rngs::StdRng::seed_from_u64(11);
    let x: Vec<f32> = (0..rows * d).map(|_| rng.gen_range(-1.0..1.0)).collect();
    let mut targets = vec![0.0f32; rows * e];
    for i in 0..rows {
        let t = i % e;
        targets[i * e + t] = 0.7;
        targets[i * e + (t + 1) % e] = 0.3;
    }
    let mut router = RouterMlp::new(d, r, e);
    router.gamma = 0.37;
    let r_prev: Vec<f32> = (0..rows * r).map(|_| rng.gen_range(-1.0..1.0)).collect();

    let loss_of = |rt: &RouterMlp| -> f32 {
        let tr = rt.forward(&x, rows, Some(&r_prev));
        let mut l = 0.0f32;
        for i in 0..rows {
            for c in 0..e {
                l -= targets[i * e + c] * tr.s[i * e + c].max(1e-12).ln();
            }
        }
        l / rows as f32
    };
    let l0 = loss_of(&router);
    let tr = router.forward(&x, rows, Some(&r_prev));
    router.zero_grad();
    let l1 = router.backward(&tr, &x, Some(&r_prev), &targets);
    assert!((l0 - l1).abs() < 1e-4, "лосс из backward {l1} != прямому {l0}");

    let mut worst = 0.0f32;
    for i in [0usize, 7, 33] {
        let g = router.g_w_down[i];
        let f = |pert: f32| {
            let mut rt = clone_router(&router);
            rt.w_down[i] = pert;
            loss_of(&rt)
        };
        worst = worst.max(fd_check("w_down", g, f, router.w_down[i]));
    }
    for i in [0usize, 11] {
        let g = router.g_mw[0][i];
        let f = |pert: f32| {
            let mut rt = clone_router(&router);
            rt.mw[0][i] = pert;
            loss_of(&rt)
        };
        worst = worst.max(fd_check("mw0", g, f, router.mw[0][i]));
    }
    {
        let g = router.g_mw[2][e * r - 1];
        let f = |pert: f32| {
            let mut rt = clone_router(&router);
            let i = e * r - 1;
            rt.mw[2][i] = pert;
            loss_of(&rt)
        };
        worst = worst.max(fd_check("mw2", g, f, router.mw[2][e * r - 1]));
    }
    {
        let g = router.g_gamma;
        let f = |pert: f32| {
            let mut rt = clone_router(&router);
            rt.gamma = pert;
            loss_of(&rt)
        };
        worst = worst.max(fd_check("gamma (EDA)", g, f, router.gamma));
    }
    assert!(worst.is_finite());
}

/// Клон роутера для конечно-разностных проб (веса копируются, градиенты — нет).
fn clone_router(r: &RouterMlp) -> RouterMlp {
    RouterMlp {
        d_in: r.d_in,
        r: r.r,
        e: r.e,
        w_down: r.w_down.clone(),
        gamma: r.gamma,
        mw: r.mw.clone(),
        mb: r.mb.clone(),
        bias: r.bias.clone(),
        g_w_down: vec![0.0; r.g_w_down.len()],
        g_gamma: 0.0,
        g_mw: r.g_mw.iter().map(|v| vec![0.0; v.len()]).collect::<Vec<_>>().try_into().unwrap(),
        g_mb: r.g_mb.iter().map(|v| vec![0.0; v.len()]).collect::<Vec<_>>().try_into().unwrap(),
    }
}

#[test]
fn moe_router_selects_topk_with_balancing_bias() {
    let mut router = RouterMlp::new(4, 3, 4);
    // (4): выбирается argmax(s + b), а не argmax(s)
    let s = [0.9f32, 0.05, 0.03, 0.02];
    assert_eq!(router.select(&s, 1), vec![0]);
    router.bias[2] = 1.5;
    assert_eq!(router.select(&s, 1), vec![2], "балансирующий вектор обязан менять выбор");
    router.bias[2] = 0.0;
    assert_eq!(router.select(&s, 2), vec![0, 1]);
}

#[test]
fn moe_pid_bias_balancing_levels_expert_load() {
    // Уравнение (5): grad = p_e − 1/E через AdamW. Перегруженный эксперт
    // получает положительный градиент и его bias снижается, недогруженные —
    // растут. Проверяем на синтетической загрузке 90/10 на двух экспертах.
    let e = 2usize;
    let mut pid = PidBias::new(e);
    let mut bias = vec![0.0f32; e];
    let loads = [90.0f64, 10.0];
    let h0 = load_entropy_norm(&loads);
    for _ in 0..200 {
        pid.step(&mut bias, &loads, 0.1, 0.0);
    }
    assert!(bias[0] < -0.1, "перегруженный эксперт должен получить отрицательный bias, есть {bias:?}");
    assert!(bias[1] > 0.1, "недогруженный эксперт должен получить положительный bias, есть {bias:?}");
    // как это выглядит в метрике отчёта (Fig. 4): исходная загрузка несбалансирована
    assert!(h0 < 0.95, "энтропия 90/10 должна быть ниже равномерной: {h0}");
    assert!((load_entropy_norm(&[0.5, 0.5]) - 1.0).abs() < 1e-9, "равномерная загрузка = 1.0");
    // равномерная загрузка ⇒ градиент ноль ⇒ bias не ползёт
    let mut pid2 = PidBias::new(e);
    let mut b2 = vec![0.25f32; e];
    for _ in 0..50 {
        pid2.step(&mut b2, &[50.0, 50.0], 0.1, 0.0);
    }
    assert!((b2[0] - 0.25).abs() < 1e-6 && (b2[1] - 0.25).abs() < 1e-6, "при балансе шаг нулевой: {b2:?}");
}

#[test]
fn moe_residual_scaling_is_identity_at_init_and_gradient_is_exact() {
    let d = 5usize;
    let rows = 2usize;
    let mut rs = ResidualScaling::new(d);
    let x: Vec<f32> = (0..rows * d).map(|i| (i as f32) * 0.3 - 0.7).collect();
    let y = rs.forward(&x, rows);
    // (6) с α=1, β=0 — обычное остаточное соединение
    for i in 0..x.len() {
        assert!((y[i] - x[i]).abs() < 1e-6, "инициализация обязана быть тождественной");
    }
    assert_eq!(rs.params(), 4 * 0 + 2 * d);
    rs.alpha[1] = 0.5;
    rs.beta[1] = 0.25;
    let y2 = rs.forward(&x, rows);
    assert!((y2[1] - (0.5 * x[1] + 0.25)).abs() < 1e-6);

    let dy: Vec<f32> = (0..rows * d).map(|i| (i as f32) * 0.11 - 0.3).collect();
    rs.zero_grad();
    let dx = rs.backward(&dy, &x, rows);
    let loss = |rr: &ResidualScaling| -> f32 {
        let yy = rr.forward(&x, rows);
        yy.iter().zip(dy.iter()).map(|(a, b)| a * b).sum()
    };
    for c in [0usize, 1, 4] {
        let g = rs.g_alpha[c];
        let f = |pert: f32| {
            let mut t = ResidualScaling { d, alpha: rs.alpha.clone(), beta: rs.beta.clone(), g_alpha: vec![0.0; d], g_beta: vec![0.0; d] };
            t.alpha[c] = pert;
            loss(&t)
        };
        fd_check("res_scale alpha", g, f, rs.alpha[c]);
    }
    for c in [0usize, 3] {
        let g = rs.g_beta[c];
        let f = |pert: f32| {
            let mut t = ResidualScaling { d, alpha: rs.alpha.clone(), beta: rs.beta.clone(), g_alpha: vec![0.0; d], g_beta: vec![0.0; d] };
            t.beta[c] = pert;
            loss(&t)
        };
        fd_check("res_scale beta", g, f, rs.beta[c]);
    }
    for i in [0usize, 6] {
        let g = dx[i];
        let f = |pert: f32| {
            let mut xx = x.clone();
            xx[i] = pert;
            let yy = rs.forward(&xx, rows);
            yy.iter().zip(dy.iter()).map(|(a, b)| a * b).sum()
        };
        fd_check("res_scale dx", g, f, x[i]);
    }
}

#[test]
fn moe_conv_downprojector_compresses_and_differentiates() {
    // CCA-даунпроектор: kernel = stride, поэтому длина падает ровно в stride раз
    let (d_in, d_out, stride, len) = (3usize, 4usize, 8usize, 24usize);
    let mut cd = ConvDown::new(d_in, d_out, stride);
    assert_eq!(cd.out_len(len), 3);
    let x: Vec<f32> = (0..len * d_in).map(|i| ((i % 7) as f32) * 0.2 - 0.5).collect();
    let y = cd.forward(&x, len);
    assert_eq!(y.len(), 3 * d_out);
    let dy: Vec<f32> = (0..y.len()).map(|i| (i as f32) * 0.05 - 0.2).collect();
    cd.zero_grad();
    let dx = cd.backward(&dy, &x, len);
    assert_eq!(dx.len(), x.len());
    let loss_w = |w: &[f32]| {
        let t = ConvDown { w: w.to_vec(), b: cd.b.clone(), g_w: vec![0.0; w.len()], g_b: vec![0.0; d_out], ..ConvDown::new(d_in, d_out, stride) };
        let yy = t.forward(&x, len);
        yy.iter().zip(dy.iter()).map(|(a, b)| a * b).sum()
    };
    // структурный тест: неперекрывающееся окно = линейная карта окна
    let mut t = ConvDown { w: vec![0.0; d_out * stride * d_in], b: vec![0.0; d_out], g_w: vec![0.0; d_out * stride * d_in], g_b: vec![0.0; d_out], d_in, d_out, stride };
    t.w[0] = 1.0; // выход 0 берёт только элемент (окно 0, шаг 0, канал 0)
    let y2 = t.forward(&x, len);
    assert!((y2[0] - x[0]).abs() < 1e-6);
    assert!((y2[d_out] - x[stride * d_in]).abs() < 1e-6, "второе окно начинается со stride·d_in");
    for i in [0usize, 5, 17] {
        let g = cd.g_w[i];
        let base = cd.w.clone();
        let f = |pert: f32| {
            let mut w = base.clone();
            w[i] = pert;
            loss_w(&w)
        };
        fd_check("conv_down w", g, f, cd.w[i]);
    }
}

#[test]
fn moe_cca_compression_ratios_and_gradient() {
    // Table I: сжатие запросов 2×, KV-кэша 8×
    let (dq, dkv, da, dout) = (6usize, 8usize, 5usize, 4usize);
    let (lq, lkv) = (10usize, 32usize);
    let mut cca = Cca::new(dq, dkv, da, dout, 2, 8);
    let mut rng = rand::rngs::StdRng::seed_from_u64(5);
    let q: Vec<f32> = (0..lq * dq).map(|_| rng.gen_range(-1.0..1.0)).collect();
    let kv: Vec<f32> = (0..lkv * dkv).map(|_| rng.gen_range(-1.0..1.0)).collect();
    let (out, tr) = cca.forward(&q, lq, &kv, lkv);
    assert_eq!(tr.lq2, lq / 2, "запросы сжаты в 2 раза");
    assert_eq!(tr.lkv8, lkv / 8, "KV сжаты в 8 раз");
    assert_eq!(out.len(), (lq / 2) * dout);
    // внимания ровно lq2 × lkv8 — то есть в сжатом пространстве
    assert_eq!(tr.att.len(), (lq / 2) * (lkv / 8));
    for i in 0..lq / 2 {
        let s: f32 = tr.att[i * (lkv / 8)..(i + 1) * (lkv / 8)].iter().sum();
        assert!((s - 1.0).abs() < 1e-4, "строка внимания должна быть распределением");
    }
    let dy: Vec<f32> = (0..out.len()).map(|i| (i as f32) * 0.07 - 0.3).collect();
    cca.zero_grad();
    let (dqs, dkvs) = cca.backward(&dy, &q, lq, &kv, lkv, &tr);
    assert_eq!(dqs.len(), q.len());
    assert_eq!(dkvs.len(), kv.len());
    let loss = |cca: &Cca| -> f32 {
        let (o, _) = cca.forward(&q, lq, &kv, lkv);
        o.iter().zip(dy.iter()).map(|(a, b)| a * b).sum()
    };
    for i in [0usize, 9] {
        let g = cca.g_wq[i];
        let f = |pert: f32| {
            let mut t = clone_cca(&cca);
            t.wq[i] = pert;
            loss(&t)
        };
        fd_check("cca wq", g, f, cca.wq[i]);
    }
    for i in [0usize, 13] {
        let g = cca.g_wk[i];
        let f = |pert: f32| {
            let mut t = clone_cca(&cca);
            t.wk[i] = pert;
            loss(&t)
        };
        fd_check("cca wk", g, f, cca.wk[i]);
    }
    for i in [0usize, 3] {
        let g = cca.kv_conv.g_w[i];
        let f = |pert: f32| {
            let mut t = clone_cca(&cca);
            t.kv_conv.w[i] = pert;
            loss(&t)
        };
        fd_check("cca kv_conv", g, f, cca.kv_conv.w[i]);
    }
    for i in [0usize, 5] {
        let g = cca.q_conv.g_w[i];
        let f = |pert: f32| {
            let mut t = clone_cca(&cca);
            t.q_conv.w[i] = pert;
            loss(&t)
        };
        fd_check("cca q_conv", g, f, cca.q_conv.w[i]);
    }
}

fn clone_cca(c: &Cca) -> Cca {
    Cca {
        q_conv: ConvDown { w: c.q_conv.w.clone(), b: c.q_conv.b.clone(), g_w: vec![0.0; c.q_conv.w.len()], g_b: vec![0.0; c.q_conv.b.len()], d_in: c.q_conv.d_in, d_out: c.q_conv.d_out, stride: c.q_conv.stride },
        kv_conv: ConvDown { w: c.kv_conv.w.clone(), b: c.kv_conv.b.clone(), g_w: vec![0.0; c.kv_conv.w.len()], g_b: vec![0.0; c.kv_conv.b.len()], d_in: c.kv_conv.d_in, d_out: c.kv_conv.d_out, stride: c.kv_conv.stride },
        wq: c.wq.clone(),
        wk: c.wk.clone(),
        wv: c.wv.clone(),
        wo: c.wo.clone(),
        bo: c.bo.clone(),
        g_wq: vec![0.0; c.wq.len()],
        g_wk: vec![0.0; c.wk.len()],
        g_wv: vec![0.0; c.wv.len()],
        g_wo: vec![0.0; c.wo.len()],
        g_bo: vec![0.0; c.bo.len()],
        d_a: c.d_a,
        d_out: c.d_out,
    }
}

#[test]
fn moe_aggregator_reads_prompt_and_image_and_differentiates() {
    let (v, de, dctx, dfeat) = (9usize, 6usize, 4usize, 5usize);
    let (c, tau) = (3usize, 4usize);
    let t_feat = 16usize;
    let mut agg = Aggregator::new(v, de, dctx, dfeat, c, tau);
    let prompt: Vec<usize> = (0..c * tau).map(|i| (i * 3) % v).collect();
    let mut rng = rand::rngs::StdRng::seed_from_u64(3);
    let feat: Vec<f32> = (0..t_feat * dfeat).map(|_| rng.gen_range(-1.0..1.0)).collect();
    let tr = agg.forward(&prompt, tau, &feat, t_feat);
    assert_eq!(tr.ctx.len(), dctx);
    assert_eq!(tr.lq2, (c * tau) / 2, "запросы сжаты 2×");
    // контекст обязан зависеть и от промпта, и от изображения
    let tr2 = {
        let mut p2 = prompt.clone();
        p2[0] = (p2[0] + 1) % v;
        let mut a2 = Aggregator::new(v, de, dctx, dfeat, c, tau);
        a2.tok_emb = agg.tok_emb.clone();
        a2.seg_emb = agg.seg_emb.clone();
        a2.pos_emb = agg.pos_emb.clone();
        a2.cca = clone_cca(&agg.cca);
        a2.forward(&p2, tau, &feat, t_feat)
    };
    let d_prompt: f32 = tr.ctx.iter().zip(tr2.ctx.iter()).map(|(a, b)| (a - b).abs()).sum();
    assert!(d_prompt > 1e-6, "контекст должен зависеть от токенов промпта");
    let tr3 = {
        let mut a3 = Aggregator::new(v, de, dctx, dfeat, c, tau);
        a3.tok_emb = agg.tok_emb.clone();
        a3.seg_emb = agg.seg_emb.clone();
        a3.pos_emb = agg.pos_emb.clone();
        a3.cca = clone_cca(&agg.cca);
        let f2: Vec<f32> = feat.iter().map(|x| x * 0.5).collect();
        a3.forward(&prompt, tau, &f2, t_feat)
    };
    let d_img: f32 = tr.ctx.iter().zip(tr3.ctx.iter()).map(|(a, b)| (a - b).abs()).sum();
    assert!(d_img > 1e-6, "контекст должен зависеть от признаков изображения");

    let dctx: Vec<f32> = (0..dctx).map(|i| (i as f32) * 0.3 - 0.4).collect();
    agg.zero_grad();
    let d_feat = agg.backward(&dctx, &tr, tau, &prompt, &feat, t_feat);
    assert_eq!(d_feat.len(), feat.len());
    let loss = |a: &mut Aggregator| -> f32 {
        let t = a.forward(&prompt, tau, &feat, t_feat);
        t.ctx.iter().zip(dctx.iter()).map(|(x, y)| x * y).sum()
    };
    for i in [0usize, 7] {
        let g = agg.g_tok_emb[i];
        let f = |pert: f32| {
            let mut t = clone_agg(&agg);
            t.tok_emb[i] = pert;
            loss(&mut t)
        };
        fd_check("agg tok_emb", g, f, agg.tok_emb[i]);
    }
    for i in [0usize, 4] {
        let g = agg.g_seg_emb[i];
        let f = |pert: f32| {
            let mut t = clone_agg(&agg);
            t.seg_emb[i] = pert;
            loss(&mut t)
        };
        fd_check("agg seg_emb", g, f, agg.seg_emb[i]);
    }
    for i in [0usize, 2] {
        let g = agg.res_out.g_alpha[i];
        let f = |pert: f32| {
            let mut t = clone_agg(&agg);
            t.res_out.alpha[i] = pert;
            loss(&mut t)
        };
        fd_check("agg res_out alpha", g, f, agg.res_out.alpha[i]);
    }
}

fn clone_agg(a: &Aggregator) -> Aggregator {
    Aggregator {
        classes: a.classes,
        d_emb: a.d_emb,
        d_ctx: a.d_ctx,
        max_c: a.max_c,
        max_tau: a.max_tau,
        tok_emb: a.tok_emb.clone(),
        seg_emb: a.seg_emb.clone(),
        pos_emb: a.pos_emb.clone(),
        cca: clone_cca(&a.cca),
        res_out: ResidualScaling { d: a.d_ctx, alpha: a.res_out.alpha.clone(), beta: a.res_out.beta.clone(), g_alpha: vec![0.0; a.d_ctx], g_beta: vec![0.0; a.d_ctx] },
        res_res: ResidualScaling { d: a.d_ctx, alpha: a.res_res.alpha.clone(), beta: a.res_res.beta.clone(), g_alpha: vec![0.0; a.d_ctx], g_beta: vec![0.0; a.d_ctx] },
        g_tok_emb: vec![0.0; a.tok_emb.len()],
        g_seg_emb: vec![0.0; a.seg_emb.len()],
        g_pos_emb: vec![0.0; a.pos_emb.len()],
    }
}

#[test]
fn moe_expert_int8_roundtrip_and_lru_eviction() {
    // Эксперт = целая модель в int8: 1 байт на параметр, ошибка ≤ шкала/2.
    let mut rng = rand::rngs::StdRng::seed_from_u64(17);
    let big: Vec<f32> = (0..4096).map(|_| rng.gen_range(-2.0..2.0)).collect();
    let small: Vec<f32> = (0..64).map(|_| rng.gen_range(-0.01..0.01)).collect();
    let blob = quantize_expert("писарь-1", &[&big, &small]);
    assert_eq!(blob.params(), big.len() + small.len());
    assert_eq!(blob.q.len(), big.len() + small.len(), "int8: ровно байт на параметр");
    assert!(blob.bytes() < (big.len() + small.len()) * 4 / 3, "int8-хранилище должно быть ~в 4 раза дешевле fp32");
    let back = dequantize_expert(&blob);
    assert_eq!(back.len(), 2);
    for (i, orig) in [&big, &small].iter().enumerate() {
        for (k, &v) in orig.iter().enumerate() {
            let err = (back[i][k] - v).abs();
            assert!(err <= blob.scales[i] * 0.5 + 1e-6, "тензор {i} элемент {k}: ошибка {err} больше половины шага {}", blob.scales[i]);
        }
    }
    // шкала на тензор своя: у маленького тензора шаг намного мельче
    assert!(blob.scales[1] < blob.scales[0] / 10.0);

    // LRU: резидентно держим 2 экспертов из 4
    let mut lru = LruStore::new(2);
    assert_eq!(lru.touch(0), None);
    assert_eq!(lru.touch(1), None);
    assert_eq!(lru.touch(0), None, "0 уже горячий");
    assert_eq!(lru.touch(2), Some(1), "вытесняется самый холодный (1)");
    assert_eq!(lru.resident(), &[2, 0]);
    // после touch(2) порядок [2, 0]: холоднее всех 0, его и вытесняет 3
    assert_eq!(lru.touch(3), Some(0));
    assert_eq!(lru.resident(), &[3, 2]);
}

#[test]
fn moe_markovian_rsa_keeps_context_bounded() {
    // Штатная конфигурация §VI, уменьшенная под toy: (N, C, T) = (8, 3, 2)
    let cfg = RsaCfg { n: 8, c: 3, t_rounds: 2, beta: 12, tau: 4, temperature: 1.0, top_p: 1.0 };
    cfg.validate().unwrap();
    assert_eq!(cfg.context_bound(), 12);
    assert_eq!(cfg.warn_long_tail(), None, "tau = beta/3 <= beta/2");
    let mut rng = rand::rngs::StdRng::seed_from_u64(23);
    let mut generated = 0usize;
    let mut agg_calls = 0usize;
    let mut prompt_lens: Vec<usize> = Vec::new();
    let trace = {
        let mut pl = Vec::new();
        let t = markovian_rsa(
            &cfg,
            |i| {
                generated += 1;
                Candidate { tokens: (0..cfg.beta).map(|k| (i * 7 + k) % 31).collect(), expert: i % 4, score: (i as f32) * 0.1 }
            },
            |prompt, round| {
                agg_calls += 1;
                pl.push(prompt.len());
                assert!(prompt.len() <= cfg.context_bound(), "контекст агрегации обязан быть <= C·tau");
                assert!(!prompt.is_empty());
                let _ = round;
                Candidate { tokens: prompt.to_vec(), expert: usize::MAX, score: 10.0 }
            },
            &mut rng,
        );
        prompt_lens = pl;
        t
    };
    assert_eq!(generated, cfg.n, "раунд 0 обязан породить ровно N кандидатов");
    assert_eq!(agg_calls, cfg.t_rounds, "раундов агрегации ровно T");
    assert_eq!(trace.round0.len(), cfg.n);
    assert_eq!(trace.rounds.len(), cfg.t_rounds);
    assert!(trace.max_prompt <= cfg.context_bound());
    assert_eq!(prompt_lens.len(), cfg.t_rounds);
    // каждый раунд берёт C РАЗЛИЧНЫХ кандидатов из популяции
    for r in &trace.rounds {
        let mut p = r.picks.clone();
        p.sort_unstable();
        p.dedup();
        assert_eq!(p.len(), cfg.c, "C индексов должны быть различными");
        assert_eq!(r.prompt.len(), cfg.c * cfg.tau, "prompt = C хвостов по tau");
    }
    // хвост — это последние tau токенов кандидата
    let c = Candidate { tokens: (0..10).collect(), expert: 0, score: 0.0 };
    assert_eq!(tail_tokens(&c, 4), vec![6, 7, 8, 9]);
    assert_eq!(tail_tokens(&c, 100), (0..10).collect::<Vec<usize>>(), "короткий кандидат отдаётся целиком");
    // финальный ответ — выход последнего раунда
    assert_eq!(trace.best.score, 10.0);
}

#[test]
fn moe_rsa_special_cases_match_report() {
    // T = 0 ⇒ обычный параллельный сэмплинг, ответ выбирает внешний селектор
    let cfg0 = RsaCfg { n: 5, c: 2, t_rounds: 0, beta: 8, tau: 4, temperature: 1.0, top_p: 1.0 };
    let mut rng = rand::rngs::StdRng::seed_from_u64(31);
    let tr = markovian_rsa(
        &cfg0,
        |i| Candidate { tokens: vec![i], expert: i, score: i as f32 },
        |_p, _r| Candidate { tokens: vec![], expert: 0, score: -1.0 },
        &mut rng,
    );
    assert!(tr.rounds.is_empty());
    assert_eq!(tr.best.score, 4.0, "Best-of-N: выбирается кандидат с максимальным скором");
    assert_eq!(tr.best.expert, 4);
    // C = 1 ⇒ агрегация продолжает одну цепочку
    let cfg1 = RsaCfg { n: 4, c: 1, t_rounds: 1, beta: 6, tau: 3, temperature: 1.0, top_p: 1.0 };
    let mut rng = rand::rngs::StdRng::seed_from_u64(32);
    let tr = markovian_rsa(&cfg1, |i| Candidate { tokens: vec![i; 6], expert: i, score: 0.0 }, |p, _| Candidate { tokens: p.to_vec(), expert: 0, score: 1.0 }, &mut rng);
    assert_eq!(tr.rounds[0].prompt.len(), 3, "C=1 ⇒ в промпте один хвост");
    // tau = beta ⇒ полная RSA без сжатия хвостов
    let cfgf = RsaCfg { n: 3, c: 2, t_rounds: 1, beta: 5, tau: 5, temperature: 1.0, top_p: 1.0 };
    assert_eq!(cfgf.context_bound(), 10);
    assert!(cfgf.warn_long_tail().is_some(), "tau = beta > beta/2 — отчёт рекомендует tau <= beta/2");
    // некорректные конфигурации отклоняются
    assert!(RsaCfg { n: 4, c: 5, t_rounds: 1, beta: 4, tau: 2, temperature: 1.0, top_p: 1.0 }.validate().is_err(), "C > N");
    assert!(RsaCfg { n: 4, c: 2, t_rounds: 1, beta: 4, tau: 9, temperature: 1.0, top_p: 1.0 }.validate().is_err(), "tau > beta");
}

#[test]
fn moe_router_targets_come_from_the_best_of_all_models() {
    // «от всех моделей беря лучшее»: жёсткая цель — лучший эксперт,
    // мягкая — softmax(−loss/T)
    let losses = [3.0f32, 0.5, 2.0, 1.5];
    let hard = targets_from_best(&losses);
    assert_eq!(hard, vec![0.0, 1.0, 0.0, 0.0]);
    let soft = targets_from_losses(&losses, 0.5);
    let best = soft.iter().enumerate().max_by(|a, b| a.1.partial_cmp(b.1).unwrap()).unwrap().0;
    assert_eq!(best, 1, "наибольший вес у эксперта с наименьшим лоссом");
    assert!((soft.iter().sum::<f32>() - 1.0).abs() < 1e-5, "цель — распределение");
    assert!(soft[1] > soft[0] && soft[1] > soft[2] && soft[1] > soft[3]);
    // температура 0 ⇒ почти one-hot
    let sharp = targets_from_losses(&losses, 1e-7);
    assert!(sharp[1] > 0.99, "при T→0 цель вырождается в one-hot лучшего: {sharp:?}");
    // кредит через агрегацию: эксперты, чьи кандидаты попали в промпты и финал
    let cfg = RsaCfg { n: 4, c: 2, t_rounds: 1, beta: 4, tau: 2, temperature: 1.0, top_p: 1.0 };
    let mut rng = rand::rngs::StdRng::seed_from_u64(41);
    let tr = markovian_rsa(
        &cfg,
        |i| Candidate { tokens: vec![i; 4], expert: i % 3, score: i as f32 },
        |p, _| Candidate { tokens: p.to_vec(), expert: 2, score: 9.0 },
        &mut rng,
    );
    let t = targets_from_rsa(&tr, 3, 4.0);
    assert!((t.iter().sum::<f32>() - 1.0).abs() < 1e-5);
    assert!(t[2] > 0.0, "эксперт финального ответа обязан получить кредит");
}

#[test]
fn mope_cfg_enforces_expert_range_and_reports_memory_honestly() {
    let rsa = RsaCfg::default();
    let mut cfg = MopeCfg {
        experts: vec!["a.bin".into(), "b.bin".into()],
        top_k: 1,
        router_latent: ROUTER_LATENT,
        rsa,
        vram_cache: 2,
        balance_lr: 1e-3,
        balance_wd: 0.0,
        target_temperature: 0.5,
    };
    assert_eq!(MIN_EXPERTS, 2);
    assert_eq!(MAX_EXPERTS, 256);
    assert!(cfg.validate().is_ok());
    cfg.experts = vec!["a.bin".into()];
    assert!(cfg.validate().is_err(), "один эксперт — это не смесь");
    cfg.experts = (0..257).map(|i| format!("e{i}.bin")).collect();
    assert!(cfg.validate().is_err(), "больше 256 экспертов не поддерживается");
    cfg.experts = (0..256).map(|i| format!("e{i}.bin")).collect();
    cfg.top_k = 1;
    assert!(cfg.validate().is_ok(), "256 экспертов — верхняя граница диапазона");
    cfg.top_k = 0;
    assert!(cfg.validate().is_err());

    // Честная арифметика: 56M параметров на эксперта
    let params = 56_000_000usize;
    cfg.vram_cache = 8;
    let rep = cfg.memory_report(params, 10240.0, 1600.0);
    assert!(rep.contains("экспертов 256"), "{rep}");
    assert!(rep.contains("14.34 ГБ") || rep.contains("14.3"), "int8 на 256 экспертов ≈ 14.3 ГБ: {rep}");
    assert!(rep.contains("0.45 ГБ"), "8 экспертов int8 ≈ 0.45 ГБ: {rep}");
    let swap = rep.split("~").nth(1).unwrap_or("");
    assert!(swap.starts_with("35"), "подмена 56 МБ по PCIe 2.0 x4 ≈ 35 мс: {rep}");
}

/// Лоссы трёх экспертов на признаках строки: линейно разделимая
/// специализация, у каждого региона свой победитель.
fn expert_losses(x: &[f32]) -> Vec<f32> {
    vec![1.0 - 1.5 * x[0], 1.0 - 1.5 * x[1], 0.4 + 0.5 * (x[0] + x[1])]
}

#[test]
fn moe_router_trains_on_best_of_all_experts() {
    // Синтетика: у трёх экспертов разная специализация (русский писарь /
    // куррентшрифт / …). Цель — «лучший из всех моделей» (targets_from_losses),
    // обучение — AdamW по (1)-(4) плюс PID-балансировка по (5).
    let (d, e) = (8usize, 3usize);
    let mut rng = rand::rngs::StdRng::seed_from_u64(101);
    let mut xs: Vec<Vec<f32>> = Vec::new();
    let mut ybest: Vec<usize> = Vec::new();
    for _ in 0..240 {
        let x: Vec<f32> = (0..d).map(|_| rng.gen_range(-1.0..1.0)).collect();
        // Специализация экспертов линейно разделима по первым двум признакам
        // (в OCR это «почерк похож на русского писаря / на куррентшрифт /
        // ни на что из этого»). Лосс каждого эксперта — его уверенность.
        let l = expert_losses(&x);
        let b = (0..e).min_by(|&a, &c| l[a].partial_cmp(&l[c]).unwrap()).unwrap();
        xs.push(x);
        ybest.push(b);
    }
    let mut router = RouterMlp::new(d, ROUTER_LATENT.min(16), e);
    // new() инициализируется из thread_rng: для воспроизводимого теста
    // перезаписываем веса из сидированного ГПСЧ
    {
        let mut sr = rand::rngs::StdRng::seed_from_u64(2024);
        for v in router.w_down.iter_mut() {
            *v = sr.gen_range(-0.35..0.35);
        }
        for l in 0..3 {
            for v in router.mw[l].iter_mut() {
                *v = sr.gen_range(-0.35..0.35);
            }
            for v in router.mb[l].iter_mut() {
                *v = sr.gen_range(-0.1..0.1);
            }
        }
        router.gamma = 0.0;
        router.bias = vec![0.0; e];
    }
    let mut opt = RouterAdam::new(&router);
    let mut pid = PidBias::new(e);
    let mut loads = vec![0.0f64; e];
    let mut early_loss = 0.0f32;
    let mut late_loss = 0.0f32;
    for step in 0..1500 {
        let x = &xs[step % xs.len()];
        let tr = router.forward(x, 1, None);
        // цель роутера — «от всех моделей беря лучшее»: жёсткий one-hot
        // эксперта с наименьшим лоссом (targets_from_best)
        let losses = expert_losses(x);
        let target = targets_from_best(&losses);
        assert_eq!(target[ybest[step % xs.len()]], 1.0);
        router.zero_grad();
        let l = router.backward(&tr, x, None, &target);
        opt.step(&mut router, 1e-2, 1e-4);
        loads[router.select(&tr.s, 1)[0]] += 1.0;
        if step % 10 == 0 {
            pid.step(&mut router.bias, &loads, 3e-3, 0.0);
        }
        if step < 100 {
            early_loss += l / 100.0;
        }
        if step >= 1400 {
            late_loss += l / 100.0;
        }
    }
    assert!(late_loss < early_loss * 0.8, "роутер обязан обучаться: {early_loss:.4} → {late_loss:.4}");
    // Точность измеряем по argmax(s), БЕЗ балансирующего b: b (уравнение 5)
    // намеренно сдвигает выбор в сторону недогруженных экспертов и на
    // несбалансированной синтетике снижает точность — это и есть компромисс
    // MoE. Сам сдвиг проверяется отдельным тестом PID.
    let mut hit = 0usize;
    for (i, x) in xs.iter().enumerate() {
        let tr = router.forward(x, 1, None);
        let k = (0..e).max_by(|&a, &b| tr.s[a].partial_cmp(&tr.s[b]).unwrap()).unwrap();
        if k == ybest[i] {
            hit += 1;
        }
    }
    let acc = hit as f32 / xs.len() as f32;
    assert!(acc > 0.65, "точность выбора лучшего эксперта слишком низкая: {acc:.3}");
    // PID не дал загрузке схлопнуться в один эксперт
    assert!(load_entropy_norm(&loads) > 0.5, "загрузка вырождена: {loads:?}");
}

#[test]
fn moe_router_and_aggregator_weights_survive_save_load() {
    let dir = std::env::temp_dir().join(format!("mope_roundtrip_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let (d, r, e) = (6usize, 4usize, 3usize);
    let mut a = RouterMlp::new(d, r, e);
    a.gamma = 0.42;
    a.bias = vec![0.5, -0.25, 0.125];
    let mut pid = PidBias::new(e);
    let mut loads = vec![3.0f64, 1.0, 0.0];
    pid.step(&mut a.bias, &loads, 1e-2, 0.0);
    loads = vec![0.0, 4.0, 0.0];
    pid.step(&mut a.bias, &loads, 1e-2, 0.0);
    let rp = dir.join("router.bin");
    let n = save_router(rp.to_str().unwrap(), &a, &pid).unwrap();
    assert!(n > 64);
    let mut b = RouterMlp::new(d, r, e);
    let pid2 = load_router(rp.to_str().unwrap(), &mut b).unwrap().expect("размеры совпадают");
    for i in 0..a.w_down.len() {
        assert_eq!(a.w_down[i], b.w_down[i], "w_down[{i}]");
    }
    assert_eq!(a.gamma, b.gamma);
    for l in 0..3 {
        assert_eq!(a.mw[l], b.mw[l]);
        assert_eq!(a.mb[l], b.mb[l]);
    }
    assert_eq!(a.bias, b.bias, "bias вместе с результатом PID обязан пережить цикл");
    assert_eq!(pid2.t, pid.t);
    for i in 0..e {
        assert!((pid2.m[i] - pid.m[i]).abs() < 1e-6 * (1.0 + pid.m[i].abs()));
    }
    // другой размер latent — файл отклоняется, а не применяется молча
    let mut c = RouterMlp::new(d, r + 1, e);
    assert!(load_router(rp.to_str().unwrap(), &mut c).unwrap().is_none());
    // агрегатор
    let (v, de, dc, df) = (7usize, 4usize, 3usize, 5usize);
    let mut ag1 = Aggregator::new(v, de, dc, df, 2, 3);
    ag1.res_out.alpha[1] = 0.7;
    let ap = dir.join("agg.bin");
    save_aggregator(ap.to_str().unwrap(), &ag1).unwrap();
    let mut ag2 = Aggregator::new(v, de, dc, df, 2, 3);
    assert!(load_aggregator(ap.to_str().unwrap(), &mut ag2).unwrap());
    assert_eq!(ag1.tok_emb, ag2.tok_emb);
    assert_eq!(ag1.cca.wo, ag2.cca.wo);
    assert_eq!(ag1.res_out.alpha, ag2.res_out.alpha);
    let mut ag3 = Aggregator::new(v + 1, de, dc, df, 2, 3);
    assert!(!load_aggregator(ap.to_str().unwrap(), &mut ag3).unwrap(), "чужой словарь применять нельзя");
    std::fs::remove_dir_all(&dir).ok();
}

#[test]
fn moe_sampling_decode_follows_temperature_and_top_p() {
    use crate::attn::sample_token;
    let mut rng = rand::rngs::StdRng::seed_from_u64(7);
    let row = vec![3.0f32, 1.0, -2.0, 0.5, -5.0];
    // очень низкая температура ⇒ почти всегда argmax
    let mut hits = 0usize;
    let mut lp_sum = 0.0f32;
    for _ in 0..200 {
        let (k, lp) = sample_token(&row, 1e-4, 1.0, &mut rng);
        if k == 0 {
            hits += 1;
        }
        assert!(lp <= 1e-6 && lp.is_finite(), "логарифм вероятности обязан быть <= 0, есть {lp}");
        lp_sum += lp;
    }
    assert_eq!(hits, 200, "при T→0 сэмплинг обязан совпадать с argmax");
    assert!(lp_sum / 200.0 > -0.05, "уверенность при T→0 близка к 1: {:.4}", lp_sum / 200.0);
    // высокая температура ⇒ разнообразие (нужно для N кандидатов RSA)
    let mut seen = std::collections::HashSet::new();
    for _ in 0..300 {
        seen.insert(sample_token(&row, 2.0, 1.0, &mut rng).0);
    }
    assert!(seen.len() >= 4, "при T=2 кандидаты обязаны различаться, получено {seen:?}");
    // top-p = 0.3 ⇒ ядро из одного токена
    for _ in 0..100 {
        let (k, _) = sample_token(&row, 1.0, 0.3, &mut rng);
        assert_eq!(k, 0, "ядро top-p=0.3 содержит только argmax");
    }
    // вырожденный ряд не должен давать NaN или выход за границы
    let flat = vec![0.0f32; 5];
    let (k, lp) = sample_token(&flat, 1.0, 0.9, &mut rng);
    assert!(k < 5 && lp.is_finite(), "плоское распределение: k={k}, lp={lp}");
    let inf = vec![f32::NEG_INFINITY, f32::NEG_INFINITY, 1.0];
    assert_eq!(sample_token(&inf, 1.0, 1.0, &mut rng).0, 2);
}

#[test]
fn moe_adamw_step_moves_against_gradient_only() {
    // decoupled weight decay + смещение по −grad: проверяем знак и величину
    let (d, r, e) = (2usize, 2usize, 2usize);
    let mut router = RouterMlp::new(d, r, e);
    let mut opt = RouterAdam::new(&router);
    router.g_w_down[0] = 1.0;
    let w0 = router.w_down[0];
    opt.step(&mut router, 0.1, 0.0);
    let step = router.w_down[0] - w0;
    // первый шаг Adam = −lr·sign(g) с точностью до eps
    assert!(step < -0.09 && step > -0.11, "шаг должен быть ≈ −lr: {step}");
    // вес-декей тянет к нулю независимо от градиента
    let mut r2 = RouterMlp::new(d, r, e);
    let mut o2 = RouterAdam::new(&r2);
    r2.w_down[0] = 1.0;
    r2.g_w_down[0] = 0.0;
    o2.step(&mut r2, 0.1, 0.5);
    assert!(r2.w_down[0] < 1.0 && r2.w_down[0] > 0.9, "decoupled wd: {}", r2.w_down[0]);
}

// --------------------------------------------------------------------------
// Franken-MoE: слияние словарей, адаптеры размерностей, бандлы экспертов
// --------------------------------------------------------------------------

#[test]
fn mope_charset_merge_prunes_rare_symbols_and_respects_the_cap() {
    // Эксперт 0 — «дореформенный русский» (194 токена в пресете Кожина),
    // эксперт 1 — «куррентшрифт с умляутами». Редкие символы отсекаются.
    let cs0 = ["<PAD>", "<SOS>", "<EOS>", " ", "а", "б", "ѣ", "і", "ѳ", "ѵ"]
        .iter().map(|s| s.to_string()).collect::<Vec<_>>();
    let cs1 = ["<PAD>", "<SOS>", "<EOS>", " ", "a", "b", "ä", "ö", "ü", "ß", "ѣ"]
        .iter().map(|s| s.to_string()).collect::<Vec<_>>();
    // частоты: ѳ и ѵ — по 2 (редкие), ß — 6, ü — 40
    let c0 = vec![0u64, 0, 0, 5000, 900, 800, 120, 45, 2, 2];
    let c1 = vec![0u64, 0, 0, 5000, 700, 600, 300, 200, 40, 6, 120];
    let m3 = merge_charsets(&[cs0.clone(), cs1.clone()], &[c0.clone(), c1.clone()], 3, 256);
    // <PAD> <SOS> <EOS> всегда на 0..2
    assert_eq!(&m3.itos[..3], &[PAD_TOKEN, SOS_TOKEN, EOS_TOKEN]);
    // частота 2 < 3 ⇒ ѳ и ѵ выброшены
    assert!(!m3.stoi.contains_key("ѳ"), "ѳ с частотой 2 обязан быть отсечён при min_freq=3");
    assert!(!m3.stoi.contains_key("ѵ"));
    // ß (6) проходит при пороге 3
    assert!(m3.stoi.contains_key("ß"), "ß с частотой 6 проходит при min_freq=3");
    // общий токен ѣ встречается у обоих ⇒ одна запись, оба remap ведут в неё
    let ya = m3.stoi["ѣ"];
    assert_eq!(m3.remap[0][6], ya as i32);
    assert_eq!(m3.remap[1][10], ya as i32, "один и тот же символ у двух экспертов — одна ячейка");
    // выброшенные перечислены в отчёте
    assert!(m3.dropped[0].contains(&"ѳ".to_string()) && m3.dropped[0].contains(&"ѵ".to_string()));
    // и не попадают в текст: ѳ у эксперта 0 имеет локальный id 8, remap = −1
    assert_eq!(m3.remap[0][8], -1);
    assert_eq!(m3.decode(0, &[4, 8, 5]), "аб", "выброшенный символ обязан молча пропускаться");
    assert!(m3.report().contains("уникальных потеряно"));

    // порог 7 (как просили: «менее 3 или менее 7») режет жёстче: ß (6) уходит
    let m7 = merge_charsets(&[cs0.clone(), cs1.clone()], &[c0.clone(), c1.clone()], 7, 256);
    assert!(!m7.stoi.contains_key("ß"), "ß с частотой 6 обязан быть отсечён при min_freq=7");
    assert!(m7.stoi.contains_key("ü"), "ü с частотой 40 остаётся");
    assert!(m7.len() < m3.len(), "жёсткий порог уменьшает словарь: {} против {}", m7.len(), m3.len());

    // предел размера: cap=6 ⇒ 3 спецтокена + 3 самых частотных
    let cap = merge_charsets(&[cs0.clone(), cs1.clone()], &[c0.clone(), c1.clone()], 0, 6);
    assert_eq!(cap.len(), 6, "предел словаря обязан соблюдаться: {:?}", cap.itos);
    assert!(cap.stoi.contains_key(" "), "пробел — самый частотный, он обязан войти");
    // спецтокены не вытесняются даже при тесном пределе
    let tiny = merge_charsets(&[cs0.clone()], &[c0.clone()], 0, 4);
    assert_eq!(&tiny.itos[..3], &[PAD_TOKEN, SOS_TOKEN, EOS_TOKEN]);
    assert_eq!(tiny.len(), 4);
}

#[test]
fn mope_charset_merge_without_statistics_keeps_symbols() {
    // Если частот не дали, молча терять символы нельзя: входит всё.
    let cs = ["<PAD>", "<SOS>", "<EOS>", " ", "я", "ä", "ѣ"].iter().map(|s| s.to_string()).collect::<Vec<_>>();
    let m = merge_charsets(&[cs.clone()], &[Vec::new()], 7, 256);
    assert_eq!(m.len(), 7, "без статистики отсечка по частоте не применяется: {:?}", m.itos);
    assert!(m.stoi.contains_key("ѣ") && m.stoi.contains_key("ä"));
    assert!(m.dropped[0].is_empty());
    // и совсем без списка частот (пустой срез counts)
    let m2 = merge_charsets(&[cs.clone()], &[], 3, 256);
    assert_eq!(m2.len(), 7);
}

#[test]
fn mope_charset_merge_order_is_stable_and_decode_skips_specials() {
    let cs0 = ["<PAD>", "<SOS>", "<EOS>", "а", "б", "в"].iter().map(|s| s.to_string()).collect::<Vec<_>>();
    let cs1 = ["<PAD>", "<SOS>", "<EOS>", "в", "г"].iter().map(|s| s.to_string()).collect::<Vec<_>>();
    let c0 = vec![0, 0, 0, 10, 20, 30];
    let c1 = vec![0, 0, 0, 30, 40];
    let m = merge_charsets(&[cs0.clone(), cs1.clone()], &[c0, c1], 3, 256);
    // порядок — первая встреча по экспертам: а, б, в, г
    assert_eq!(&m.itos[3..], &["а", "б", "в", "г"]);
    // повторный вызов даёт тот же словарь (важно для воспроизводимости)
    let m2 = merge_charsets(&[cs0.clone(), cs1.clone()], &[vec![0, 0, 0, 10, 20, 30], vec![0, 0, 0, 30, 40]], 3, 256);
    assert_eq!(m.itos, m2.itos);
    // decode принимает ЛОКАЛЬНЫЕ id эксперта и переводит их через общий словарь;
    // спецтокены не печатаются
    assert_eq!(m.decode(0, &[4, 3, 0, 2]), "ба", "у эксперта 0: 3=а, 4=б");
    assert_eq!(m.decode(1, &[3, 4]), "вг", "у эксперта 1: 3=в, 4=г");
    assert_eq!(m.decode(0, &[0, 1, 2]), "", "спецтокены не дают текста");
    assert_eq!(m.decode(0, &[999]), "", "id вне словаря эксперта пропускается");
}

#[test]
fn mope_adapter_is_identity_for_matching_dims_and_gradient_is_exact() {
    // «подружить разные размерности»: при совпадении адаптер ничего не меняет
    let a = Adapter::new(5, 5);
    assert!(a.is_identity());
    let x = [0.5f32, -1.25, 2.0, 0.0, -0.75];
    let y = a.forward(&x, 1);
    for i in 0..5 {
        assert!((y[i] - x[i]).abs() < 1e-6, "тождественный адаптер обязан быть прозрачным");
    }
    // при разных размерностях диагональная часть сохраняется, новые строки — шум
    let b = Adapter::new(3, 5);
    assert!(!b.is_identity());
    let x3 = [1.0f32, 0.0, 0.0];
    let y3 = b.forward(&x3, 1);
    assert!((y3[0] - 1.0).abs() < 1e-6, "первый базисный вектор обязан остаться первым");
    // конечно-разностная проверка градиента
    let mut ad = Adapter::new(3, 2);
    let xs = [0.4f32, -0.9, 1.3, 2.0, 0.1, -0.5];
    let rows = 2usize;
    let dy = [0.7f32, -0.2, 1.1, 0.3];
    ad.zero_grad();
    let dx = ad.backward(&dy, &xs, rows);
    assert_eq!(dx.len(), xs.len());
    let loss = |a: &Adapter| -> f32 {
        let y = a.forward(&xs, rows);
        y.iter().zip(dy.iter()).map(|(p, q)| p * q).sum()
    };
    for i in [0usize, 3] {
        let g = ad.g_w[i];
        let f = |pert: f32| {
            let mut t = Adapter { inp: 3, out: 2, w: ad.w.clone(), b: ad.b.clone(), g_w: vec![0.0; 6], g_b: vec![0.0; 2] };
            t.w[i] = pert;
            loss(&t)
        };
        fd_check("adapter w", g, f, ad.w[i]);
    }
    for i in [0usize, 5] {
        let g = dx[i];
        let f = |pert: f32| {
            let mut xx = xs.to_vec();
            xx[i] = pert;
            let y = ad.forward(&xx, rows);
            y.iter().zip(dy.iter()).map(|(p, q)| p * q).sum()
        };
        fd_check("adapter dx", g, f, xs[i]);
    }
}

#[test]
fn mope_vocab_remap_permutes_rows_and_zeroes_foreign_ones() {
    // строки выходной проекции: словарь эксперта -> общий словарь MoPE
    let cols = 2usize;
    let src = [1.0f32, 2.0, 3.0, 4.0, 5.0, 6.0]; // 3 строки по 2
    let mut dst = vec![9.0f32; 5 * cols];
    // старый 0 -> новый 3, старый 1 -> выброшен, старый 2 -> новый 0
    let remap = [3i32, -1, 0];
    let moved = remap_rows(&src, 3, &mut dst, 5, cols, &remap);
    assert_eq!(moved, 2, "перенесено две строки из трёх");
    assert_eq!(&dst[0..2], &[5.0, 6.0], "старая строка 2 встала на место 0");
    assert_eq!(&dst[6..8], &[1.0, 2.0], "старая строка 0 встала на место 3");
    assert_eq!(&dst[2..6], &[0.0, 0.0, 0.0, 0.0], "чужие строки обнулены, а не оставлены мусором");
    assert_eq!(&dst[8..10], &[0.0, 0.0]);
    // тождественный remap ничего не меняет
    let mut d2 = vec![0.0f32; 3 * cols];
    assert_eq!(remap_rows(&src, 3, &mut d2, 3, cols, &[0, 1, 2]), 3);
    assert_eq!(d2, src);
    // remap короче числа строк не должен падать
    let mut d3 = vec![0.0f32; 3 * cols];
    assert_eq!(remap_rows(&src, 3, &mut d3, 3, cols, &[2]), 1);
}

#[test]
fn mope_expert_bundle_roundtrip_and_spec_diff() {
    let dir = std::env::temp_dir().join(format!("mope_bundle_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let spec = ExpertSpec {
        name: "trba_base_g1".to_string(),
        source: "/tmp/trba_base_g1.onnx".to_string(),
        kind: "onnx".to_string(),
        img_h: 64,
        img_w: 256,
        max_len: 40,
        hidden: 256,
        feat_dim: 512,
        classes: 194,
        pad: 0,
        sos: 1,
        eos: 2,
        rnn_layers: 1,
    };
    // словарь с кириллицей, умляутами и дореформенными буквами
    let charset = ["<PAD>", "<SOS>", "<EOS>", " ", "ä", "ö", "ü", "ß", "ѣ", "і", "ѳ", "ѵ"]
        .iter().map(|s| s.to_string()).collect::<Vec<_>>();
    let tensors = vec![
        ("stem.0.w".to_string(), vec![0.25f32, -0.5, 1.0]),
        ("ctc.b".to_string(), (0..194).map(|i| i as f32 * 0.01).collect()),
        ("layer3.4.conv2.run_var".to_string(), vec![1.0 - 1e-5; 4]),
    ];
    let bun = ExpertBundle { spec: spec.clone(), charset: charset.clone(), tensors: tensors.clone() };
    let p = dir.join("base.mope");
    let n = write_bundle(p.to_str().unwrap(), &bun).unwrap();
    assert!(n > 1000);
    let back = read_bundle(p.to_str().unwrap(), ).unwrap();
    assert_eq!(back.spec, spec, "геометрия обязана пережить цикл байт-в-байт");
    assert_eq!(back.charset, charset, "словарь с не-ASCII обязан сохраниться");
    assert_eq!(back.tensors.len(), 3);
    assert_eq!(back.get("stem.0.w").unwrap(), &[0.25f32, -0.5, 1.0][..]);
    assert_eq!(back.get("ctc.b").unwrap().len(), 194);
    assert_eq!(back.params(), 3 + 194 + 4);
    assert!(back.get("нет-такого").is_none());
    assert!(back.spec.report().contains("rnn 1"), "{}", back.spec.report());
    // чужой файл не читается как бандл
    std::fs::write(dir.join("bad.mope"), b"not a bundle at all").unwrap();
    assert!(read_bundle(dir.join("bad.mope").to_str().unwrap()).is_err());

    // diff геометрий: ровно то, что видит пользователь в отчёте Franken-MoE
    let other = ExpertSpec { img_h: 32, img_w: 128, max_len: 16, classes: 140, rnn_layers: 2, name: "kurrent".into(), ..spec.clone() };
    let d = other.diff(&spec);
    assert!(d.iter().any(|x| x.contains("вход 32×128 против 64×256")), "{d:?}");
    assert!(d.iter().any(|x| x.contains("словарь 140 против 194")), "{d:?}");
    assert!(d.iter().any(|x| x.contains("слоёв BiLSTM 2 против 1")), "{d:?}");
    assert!(d.iter().any(|x| x.contains("max_len 16 против 40")), "{d:?}");
    assert!(spec.diff(&spec).is_empty(), "одинаковая геометрия — пустой diff");

    // поштучное деквантование совпадает с полным
    let mut rng = rand::rngs::StdRng::seed_from_u64(55);
    let big: Vec<f32> = (0..1000).map(|_| rng.gen_range(-1.5..1.5)).collect();
    let small: Vec<f32> = (0..17).map(|_| rng.gen_range(-0.2..0.2)).collect();
    let blob = quantize_expert("t", &[&big, &small]);
    let full = dequantize_expert(&blob);
    let mut one = vec![0.0f32; 17];
    assert_eq!(blob.dequantize_one(1, &mut one), 17);
    assert_eq!(one, full[1], "поштучное деквантование обязано совпадать с полным");
    let mut z = vec![0.0f32; 5];
    assert_eq!(blob.dequantize_one(99, &mut z), 0, "чужой индекс — ноль элементов, без паники");
    std::fs::remove_dir_all(&dir).ok();
}

#[test]
fn mope_charset_file_and_frequency_counting() {
    let dir = std::env::temp_dir().join(format!("mope_cs_{}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let cs = dir.join("charset.txt");
    std::fs::write(&cs, "<PAD>\n<SOS>\n<EOS>\n \nа\nб\nѣ\nä\n").unwrap();
    let toks = charset_from_file(cs.to_str().unwrap()).unwrap();
    assert_eq!(toks, vec!["<PAD>", "<SOS>", "<EOS>", " ", "а", "б", "ѣ", "ä"], "пробел — токен, пустой хвост — нет");
    // частоты: «а» 3 раза, «б» 1, «ѣ» 0, «ä» 2
    let corpus = dir.join("train.csv");
    std::fs::write(&corpus, "path,text\na.png,ааа б\nb.png,ää\n").unwrap();
    let c = count_charset_in_file(corpus.to_str().unwrap(), &toks).unwrap();
    assert_eq!(c.len(), toks.len());
    assert_eq!(c[4], 3, "«а» встречается трижды");
    assert_eq!(c[5], 1);
    assert_eq!(c[6], 0, "«ѣ» в корпусе нет — при min_freq=3 её отсечёт");
    assert_eq!(c[7], 2);
    assert_eq!(c[0], 0, "спецтокены не считаются");
    // порог 3 оставляет только «а»
    let m = merge_charsets(&[toks.clone()], &[c], 3, 256);
    assert!(m.stoi.contains_key("а"));
    assert!(!m.stoi.contains_key("б") && !m.stoi.contains_key("ä") && !m.stoi.contains_key("ѣ"));
    assert_eq!(m.len(), 4, "3 спецтокена + «а»");
    std::fs::remove_dir_all(&dir).ok();
}

/// Регрессия на баг раскладки `cell_in` в `forward_train`: контекст внимания
/// записывался в `cell_in[st*B*(C+V) .. +C]`, то есть ВСЕГДА в слот нулевого
/// образца (пропущено `+ bi*(C+V)`). В итоге образец 0 получал контекст
/// последнего образца, а образцы 1..B-1 — нули вместо визуального контекста.
/// Декодер (`decode_full`, строка с `ci[bi*(c+v)..]`) и ONNX-граф
/// (`Concat(context, onehot)` по образцам) всегда делали это правильно, поэтому
/// обучение расходилось с инференсом при любом batch > 1.
#[test]
fn forward_train_feeds_each_sample_its_own_attention_context() {
    use crate::attn::AttentionDecoder;
    let (b, t, c, hs, v) = (2usize, 2usize, 3usize, 4usize, 5usize);
    let dec = AttentionDecoder::new(c, hs, v, 1, 2, 0);
    // Признаки образца 0 — сплошь 1.0, образца 1 — сплошь 2.0. Контекст есть
    // выпуклая комбинация строк batch_h с весами alpha, поэтому он обязан быть
    // равен 1.0 (или 2.0) в каждом элементе при ЛЮБОЙ alpha.
    let mut batch_h = vec![0.0f32; b * t * c];
    for bi in 0..b {
        for tt in 0..t {
            for k in 0..c {
                batch_h[(bi * t + tt) * c + k] = (bi + 1) as f32;
            }
        }
    }
    let text_in = vec![vec![1usize; 3], vec![1usize; 3]];
    let (_logits, tr) = dec.forward_train(&batch_h, &text_in, b, t);
    let cv = c + v;
    assert_eq!(tr.steps, 3);
    for st in 0..tr.steps {
        // alpha — softmax: сумма ровно 1
        for bi in 0..b {
            let row = &tr.alpha[st * b * t + bi * t..st * b * t + (bi + 1) * t];
            let s: f32 = row.iter().sum();
            assert!((s - 1.0).abs() < 1e-5, "alpha не нормирована: {s}");
        }
        for bi in 0..b {
            let want = (bi + 1) as f32;
            let base = st * b * cv + bi * cv;
            for k in 0..c {
                assert!(
                    (tr.cell_in[base + k] - want).abs() < 1e-5,
                    "шаг {st} образец {bi} элемент {k}: в cell_in лежит {:.4} вместо {want:.1} \
                     (чужой или нулевой контекст)",
                    tr.cell_in[base + k]
                );
            }
            // one-hot часть — на месте и единственный
            let oh = &tr.cell_in[base + c..base + cv];
            let sum: f32 = oh.iter().sum();
            assert!((sum - 1.0).abs() < 1e-6, "one-hot сумма {sum}");
        }
    }
}

/// Состояние Franken-MoPE переживает сохранение/загрузку побитово: это то, что
/// пользователь получает после `--mope-train` и подсовывает в `--mope-franken`.
#[test]
fn franken_state_roundtrips_bitwise() {
    use crate::moe::*;
    let dir = std::env::temp_dir().join(format!("franken_rt_{}", std::process::id()));
    std::fs::create_dir_all(&dir).ok();
    let p = dir.join("franken.bin").to_string_lossy().into_owned();

    let mut router = RouterMlp::new(6, 4, 3);
    for (i, v) in router.w_down.iter_mut().enumerate() {
        *v = i as f32 * 0.001 - 0.5;
    }
    router.gamma = 0.37;
    for l in 0..3 {
        for (i, v) in router.mw[l].iter_mut().enumerate() {
            *v = i as f32 * 0.01 + l as f32;
        }
        for (i, v) in router.mb[l].iter_mut().enumerate() {
            *v = -(i as f32) * 0.02;
        }
    }
    router.bias = vec![0.1, -0.2, 0.3];
    let pid = PidBias { m: vec![1.0, 2.0, 3.0], v: vec![0.5, 0.25, 0.125], t: 7, b1: 0.9, b2: 0.999, eps: 1e-8 };
    let mut agg = Aggregator::new(5, 4, 3, 8, 2, 4);
    for (i, v) in agg.tok_emb.iter_mut().enumerate() {
        *v = i as f32 * 0.01;
    }
    for (i, v) in agg.seg_emb.iter_mut().enumerate() {
            *v = -((i as f32) * 0.02);
    }
    agg.res_out.alpha[0] = 1.25;
    agg.res_res.beta[1] = -0.75;
    agg.cca.wq[3] = 0.4242;
    agg.cca.kv_conv.b[2] = 0.03125;
    let feat_ad = vec![Adapter::new(8, 8), Adapter::new(4, 8)];
    let mut ctx_ad = vec![Adapter::new(3, 4)];
    ctx_ad[0].w[5] = 0.1234;
    let itos: Vec<String> = ["<PAD>", "<SOS>", "<EOS>", "а", "б"].iter().map(|x| x.to_string()).collect();
    let opt = FlatAdam::new(&agg.adam_shapes());

    // MOPEFR02: геометрия раундов RSA пишется в контейнер вместе с состоянием
    let rsa = RsaCfg { n: 4, c: 2, t_rounds: 2, beta: 40, tau: 8, temperature: 0.0, top_p: 0.9 };
    let n = save_franken(&p, &itos, &router, &pid, &agg, &feat_ad, &ctx_ad, 42, Some(&opt), &rsa).unwrap();
    assert!(n > 1000, "файл подозрительно мал: {n}");
    let f = load_franken(&p).unwrap();
    assert_eq!(f.steps, 42);
    let g = f.rsa.expect("MOPEFR02 обязан нести RsaCfg");
    assert_eq!((g.n, g.c, g.t_rounds, g.beta, g.tau), (4, 2, 2, 40, 8));
    assert_eq!(g.temperature, 0.0);
    assert!((g.top_p - 0.9).abs() < 1e-6);
    assert_eq!(f.itos, itos);
    assert_eq!((f.router.d_in, f.router.r, f.router.e), (6, 4, 3));
    assert_eq!(f.router.gamma, 0.37);
    assert_eq!(f.router.w_down, router.w_down);
    assert_eq!(f.router.bias, router.bias);
    for l in 0..3 {
        assert_eq!(f.router.mw[l], router.mw[l], "mw[{l}]");
        assert_eq!(f.router.mb[l], router.mb[l], "mb[{l}]");
    }
    assert_eq!(f.pid.t, 7);
    assert_eq!(f.pid.m, pid.m);
    assert_eq!(f.pid.v, pid.v);
    assert_eq!((f.agg.classes, f.agg.d_emb, f.agg.d_ctx, f.agg.max_c, f.agg.max_tau), (5, 4, 3, 2, 4));
    assert_eq!(f.agg.tok_emb, agg.tok_emb);
    assert_eq!(f.agg.seg_emb, agg.seg_emb);
    assert_eq!(f.agg.pos_emb, agg.pos_emb);
    assert_eq!(f.agg.cca.wq, agg.cca.wq);
    assert_eq!(f.agg.cca.q_conv.w, agg.cca.q_conv.w);
    assert_eq!(f.agg.cca.kv_conv.b, agg.cca.kv_conv.b);
    assert_eq!(f.agg.res_out.alpha, agg.res_out.alpha);
    assert_eq!(f.agg.res_res.beta, agg.res_res.beta);
    assert_eq!(f.feat_ad.len(), 2);
    assert_eq!(f.feat_ad[1].w, feat_ad[1].w);
    assert_eq!(f.feat_ad[1].b, feat_ad[1].b);
    assert_eq!(f.ctx_ad.len(), 1);
    assert_eq!((f.ctx_ad[0].inp, f.ctx_ad[0].out), (3, 4));
    assert_eq!(f.ctx_ad[0].w, ctx_ad[0].w);
    let o = f.opt.expect("состояние Adam должно переживать сохранение");
    assert_eq!(o.m.len(), agg.adam_shapes().len());
    // без оптимизатора тоже грузится
    save_franken(&p, &itos, &router, &pid, &agg, &feat_ad, &ctx_ad, 7, None, &rsa).unwrap();
    assert!(load_franken(&p).unwrap().opt.is_none());
    // чужой файл отвергается по магии
    std::fs::write(&p, b"MOPEXP02 junk junk").ok();
    assert!(load_franken(&p).is_err());
    std::fs::remove_dir_all(&dir).ok();
}

/// Порядок тензоров в `adam_shapes` обязан совпадать с тем, что обходит
/// `adam_step`, иначе состояние оптимизатора молча разъедется с параметрами.
#[test]
fn aggregator_adam_covers_every_trainable_tensor() {
    use crate::moe::*;
    let mut agg = Aggregator::new(7, 5, 4, 8, 3, 6);
    let shapes = agg.adam_shapes();
    assert_eq!(shapes.len(), 16);
    assert_eq!(
        shapes.iter().sum::<usize>(),
        agg.params(),
        "Adam должен покрывать ровно все обучаемые параметры агрегатора"
    );
    agg.zero_grad();
    agg.g_tok_emb[0] = 1.0;
    agg.cca.g_wq[1] = -2.0;
    let (tok0, wq1, alpha0) = (agg.tok_emb[0], agg.cca.wq[1], agg.res_out.alpha[0]);
    let mut opt = FlatAdam::new(&shapes);
    agg.adam_step(&mut opt, 0.1, 0.0);
    assert_ne!(agg.tok_emb[0], tok0, "эмбеддинг с градиентом обязан измениться");
    assert_ne!(agg.cca.wq[1], wq1, "CCA с градиентом обязана измениться");
    assert_eq!(agg.res_out.alpha[0], alpha0, "тензор без градиента трогать нельзя");
    assert_eq!(opt.t, 1, "счётчик шагов растёт один раз на шаг, а не на тензор");
    agg.zero_grad();
    agg.g_pos_emb[2] = 0.5;
    agg.adam_step(&mut opt, 0.1, 0.0);
    assert_eq!(opt.t, 2);
    assert!(agg.pos_emb.iter().all(|x| x.is_finite()));
}

/// Учитель роутера: обе цели обязаны указывать на эксперта с наименьшим лоссом,
/// soft-цель — быть распределением.
#[test]
fn router_targets_follow_the_best_expert() {
    use crate::moe::*;
    let losses = [3.0f32, 0.5, 2.0, 1.5];
    let soft = targets_from_losses(&losses, 0.5);
    let hard = targets_from_best(&losses);
    let argmax = |v: &[f32]| v.iter().enumerate().max_by(|a, b| a.1.partial_cmp(b.1).unwrap()).unwrap().0;
    assert_eq!(argmax(&soft), 1);
    assert_eq!(argmax(&hard), 1);
    assert_eq!(hard[1], 1.0);
    assert_eq!(hard.iter().sum::<f32>(), 1.0);
    let s: f32 = soft.iter().sum();
    assert!((s - 1.0).abs() < 1e-5, "soft-цель должна быть распределением, сумма {s}");
    assert!(soft[1] > soft[3] && soft[3] > soft[0], "чем меньше лосс, тем больше вес");
}

/// Эксперт, который не знает части символов, не должен выигрывать у того, кто
/// знает всё: без поправки его CE считался по более короткой и лёгкой цели.
#[test]
fn charset_penalty_makes_ignorance_expensive() {
    use crate::moe::penalized_ce;
    // ничего не выпало — CE не меняется
    assert_eq!(penalized_ce(1.0, 20, 0, 97), 1.0);
    let ln_v = (97.0f64).ln();
    // выпала половина символов: (1.0*10 + 10*ln97)/20
    let half = penalized_ce(1.0, 10, 10, 97);
    assert!((half - (1.0 + ln_v) / 2.0).abs() < 1e-9, "получили {half}");
    assert!(half > 1.0, "невежество обязано стоить дороже: {half}");
    // монотонно по числу потерянных символов
    let a = penalized_ce(1.0, 10, 1, 97);
    let b = penalized_ce(1.0, 10, 5, 97);
    let c = penalized_ce(1.0, 10, 10, 97);
    assert!(a < b && b < c, "{a} {b} {c}");
    // эксперт не знает вообще ничего -> равномерное предсказание
    assert!((penalized_ce(0.0, 0, 7, 97) - ln_v).abs() < 1e-9);
    // регрессия: знающий всё эксперт с CE 1.2 лучше незнающего с «сырым» CE 1.0
    let knows_all = penalized_ce(1.2, 20, 0, 97);
    let knows_half = penalized_ce(1.0, 10, 10, 97);
    assert!(1.0 < 1.2, "предусловие: сырой CE незнающего ниже");
    assert!(
        knows_half > knows_all,
        "после поправки оракулом должен остаться знающий всё: {knows_half} против {knows_all}"
    );
}

/// Уравнение (6): α·x+β стартует тождественно. Контекст агрегатора — сумма двух
/// ветвей, читающих один и тот же pooled, поэтому на старте он обязан равняться
/// ровно pooled, а не 2·pooled.
#[test]
fn aggregator_context_starts_as_identity() {
    use crate::moe::Aggregator;
    let mut agg = Aggregator::new(11, 8, 6, 16, 2, 4);
    assert!(agg.res_res.alpha.iter().all(|&x| x == 1.0), "основная ветвь: α=1");
    assert!(agg.res_res.beta.iter().all(|&x| x == 0.0), "основная ветвь: β=0");
    assert!(agg.res_out.alpha.iter().all(|&x| x == 0.0), "ветвь-поправка стартует нулём");
    assert!(agg.res_out.beta.iter().all(|&x| x == 0.0));
    let prompt = vec![3usize, 5, 7, 2];
    let feat: Vec<f32> = (0..16 * 5).map(|i| (i % 7) as f32 * 0.1 - 0.3).collect();
    let tr = agg.forward(&prompt, 2, &feat, 5);
    assert_eq!(tr.ctx.len(), tr.pooled.len());
    for (i, (&c, &p)) in tr.ctx.iter().zip(tr.pooled.iter()).enumerate() {
        assert!(
            (c - p).abs() < 1e-6,
            "ctx[{i}] = {c} должно равняться pooled = {p} (тождественный старт по ур. 6)"
        );
    }
    // обе ветви обучаемы: градиент по α второй ветви ненулевой
    agg.zero_grad();
    let d_ctx = vec![1.0f32; tr.ctx.len()];
    agg.backward(&d_ctx, &tr, 2, &prompt, &feat, 5);
    assert!(agg.res_out.g_alpha.iter().any(|&g| g != 0.0), "ветвь-поправка обязана учиться");
    assert!(agg.res_res.g_alpha.iter().any(|&g| g != 0.0));
}

/// int8-бандл эксперта (MOPEBI01) обязан переживать запись/чтение побитово и
/// отвергать чужую магию и обрывы — иначе «файл вчетверо меньше» превращается
/// в «файл, которому нельзя верить».
#[test]
fn int8_blob_roundtrips_bitwise() {
    use crate::moe::*;
    let dir = std::env::temp_dir().join(format!("blob_rt_{}", std::process::id()));
    std::fs::create_dir_all(&dir).ok();
    let p = dir.join("e.mope").to_string_lossy().into_owned();
    let spec = ExpertSpec {
        name: "bull-a".into(),
        source: "expA/checkpoint_last.bin".into(),
        kind: "trba-rust-bin".into(),
        img_h: 32,
        img_w: 256,
        max_len: 64,
        hidden: 64,
        feat_dim: 512,
        classes: 71,
        pad: 0,
        sos: 1,
        eos: 2,
        rnn_layers: 2,
    };
    let charset: Vec<String> = (0..71).map(|i| format!("c{i}")).collect();
    let lens = vec![5usize, 7, 11];
    let scales = vec![0.01f32, 0.5, 2.0];
    let q: Vec<i8> = (0..23).map(|i| ((i as i32 % 251) - 125) as i8).collect();
    let bn = vec![0.25f32; 8];
    let blob = ExpertBlob {
        name: "bull-a".into(),
        lens: lens.clone(),
        scales: scales.clone(),
        q: q.clone(),
        bn: bn.clone(),
    };
    let n = write_blob(&p, &spec, &charset, &blob).unwrap();
    // int8-контейнер: байт на вес плюс шкалы/длины/BN в fp32
    assert!(n < 23 + 4 * (3 + 3 + 8) + 4096, "файл подозрительно велик: {n}");
    let (s2, c2, b2) = read_blob(&p).unwrap();
    assert_eq!((s2.img_h, s2.img_w, s2.max_len), (32, 256, 64));
    assert_eq!((s2.hidden, s2.feat_dim, s2.classes), (64, 512, 71));
    assert_eq!((s2.pad, s2.sos, s2.eos, s2.rnn_layers), (0, 1, 2, 2));
    assert_eq!(s2.name, "bull-a");
    assert_eq!(s2.kind, "trba-rust-bin");
    assert_eq!(c2, charset);
    assert_eq!(b2.lens, lens);
    assert_eq!(b2.scales, scales);
    assert_eq!(b2.q, q);
    assert_eq!(b2.bn, bn);
    let good = std::fs::read(&p).unwrap();
    // чужая магия
    let mut bad = good.clone();
    bad[..8].copy_from_slice(b"MOPEXP02");
    std::fs::write(&p, &bad).unwrap();
    assert!(read_blob(&p).is_err(), "fp32-бандл не должен читаться как int8");
    // обрыв в середине весов
    std::fs::write(&p, &good[..good.len() / 2]).unwrap();
    assert!(read_blob(&p).is_err(), "оборванный файл обязан отвергаться");
    // рассинхрон длин и данных
    let mut bad = good.clone();
    bad[8 + 8 + 8 + 8 + 80 + 8 + 71 * 8 + 8 + 7 + 8 + 8 + 12 + 8] = 0; // длина q
    std::fs::write(&p, &bad).unwrap();
    let _ = read_blob(&p); // конкретный исход не важен: важно что не паникует
    std::fs::remove_dir_all(&dir).ok();
}

/// `--feat-dim`: при fd=512 таблица каналов обязана воспроизводить историческую
/// SEResNetQ (иначе дефолдные чекпоинты перестанут загружаться, а дефолтный
/// прогон перестанет быть бит-в-бит прежним), а fd=128 даёт энкодер примерно в
/// 16 раз меньше. Именно затем ручка и добавлена: эксперта можно обучить, не
/// упираясь ни в лимит песочницы, ни в бюджет репозитория (43 МБ → 2.7 МБ int8).
#[test]
fn feat_dim_scales_encoder_and_keeps_the_512_architecture() {
    use crate::qnet::SEResNetQ;
    assert_eq!(SEResNetQ::widths(512), [64, 128, 256, 256, 512, 512]);
    assert_eq!(SEResNetQ::widths(128), [16, 32, 64, 64, 128, 128]);
    let mut n = SEResNetQ::new(128);
    assert_eq!(n.fd, 128);
    assert_eq!(n.c0.out_c, 16, "stem.0: 3 -> fd/8");
    assert_eq!(n.o1.in_c, 128);
    assert_eq!(n.o1.out_c, 128, "conv_out.3: fd -> fd");
    let convs = n.convs_mut();
    assert_eq!(convs.len(), 28, "число свёрток от ширины не зависит");
    let params: usize = convs.iter().map(|c| c.w.len() + 2 * c.bn.run_mean.len()).sum();
    // историческая ширина 512 — это 42.9M параметров энкодера (видно в экспорте)
    assert!(params < 42_900_000 / 8, "fd=128 обязан быть заметно уже, а вышло {params}");
    assert!(params > 1_000_000, "и не выродиться в ноль, а вышло {params}");
}

#[test]
fn csv_header_is_recognised_and_data_rows_are_not() {
    // `--build-charset` обязан пропускать заголовок labels.csv, иначе символы
    // слова "filename" молча попадут в словарь.
    assert!(crate::moe::is_csv_header("filename"));
    assert!(crate::moe::is_csv_header("FILE "));
    assert!(crate::moe::is_csv_header("image_path"));
    assert!(!crate::moe::is_csv_header("img/a000007.png"));
    assert!(!crate::moe::is_csv_header("images_group_62_9074_3718.png"));
}

#[test]
fn expert_steps_caps_own_max_len_by_global_run() {
    // корзины по длине: короткий эксперт не растягивается на весь прогон
    assert_eq!(crate::moe::expert_steps(7, 41), 8);
    assert_eq!(crate::moe::expert_steps(8, 41), 9);
    assert_eq!(crate::moe::expert_steps(16, 41), 17);
    // длинный эксперт ограничивается прогоном (как было до корзин)
    assert_eq!(crate::moe::expert_steps(40, 17), 17);
    // совпадение — поведение не изменилось
    assert_eq!(crate::moe::expert_steps(40, 41), 41);
    // вырожденные входы не дают нулевой длины
    assert_eq!(crate::moe::expert_steps(0, 41), 2);
    assert_eq!(crate::moe::expert_steps(16, 0), 2);
    assert_eq!(crate::moe::expert_steps(16, 1), 2);
}
