//! Attention decoder, mirroring the reference `AttentionCell` /
//! `AttentionDecoder` (teacher-forced training forward + greedy decode).
//!
//! ```text
//! proj_H = i2h(batch_H)                   [B, T, Hs]   (no bias)
//! e      = score(tanh(proj_H + h2h(h)))   [B, T, 1]    (score: no bias)
//! alpha  = softmax(e, dim=1)
//! context= sum_t alpha_t * H_t            [B, C]
//! (h,c)  = LSTMCell([context, onehot], (h,c))
//! logits = generator(h)
//! ```

use crate::qnet::{par_min, LinearF};
use rayon::prelude::*;

pub struct AttentionDecoder {
    pub i2h: LinearF,
    pub h2h: LinearF,
    pub score: LinearF,
    pub w_ih: Vec<f32>, // [4Hs, C+V]
    pub b_ih: Vec<f32>,
    pub w_hh: Vec<f32>, // [4Hs, Hs]
    pub b_hh: Vec<f32>,
    pub g_w_ih: Vec<f32>,
    pub g_b_ih: Vec<f32>,
    pub g_w_hh: Vec<f32>,
    pub g_b_hh: Vec<f32>,
    pub generator: LinearF,
    pub hidden: usize,
    pub classes: usize,
    pub ctx: usize,
    pub sos: usize,
    pub eos: usize,
    #[allow(dead_code)]
    pub pad: usize,
}

pub struct AttnTrace {
    pub batch_h: Vec<f32>,
    pub proj_h: Vec<f32>,  // [B, T, Hs]
    pub tanh_e: Vec<f32>,  // [steps, B, T, Hs]
    pub alpha: Vec<f32>,   // [B, T] per step? -> [steps, B, T]
    pub onehots: Vec<f32>, // [steps, B, V]
    pub cell_in: Vec<f32>, // [steps, B, C+V]
    pub gates: Vec<f32>,   // [steps, B, 4Hs] post-activation
    pub hs: Vec<f32>,      // [steps, B, Hs]
    pub cs: Vec<f32>,      // [steps, B, Hs]
    pub b: usize,
    pub t: usize,
    pub steps: usize,
}

impl AttentionDecoder {
    pub fn new(ctx: usize, hidden: usize, classes: usize, sos: usize, eos: usize, pad: usize) -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let lim_ih = (6.0 / (ctx + classes + 4 * hidden) as f32).sqrt();
        let lim_hh = (6.0 / (hidden + 4 * hidden) as f32).sqrt();
        Self {
            i2h: LinearF::new(ctx, hidden, false),
            h2h: LinearF::new(hidden, hidden, true),
            score: LinearF::new(hidden, 1, false),
            w_ih: (0..4 * hidden * (ctx + classes)).map(|_| rng.gen_range(-lim_ih..lim_ih)).collect(),
            b_ih: vec![0.0; 4 * hidden],
            w_hh: (0..4 * hidden * hidden).map(|_| rng.gen_range(-lim_hh..lim_hh)).collect(),
            b_hh: vec![0.0; 4 * hidden],
            g_w_ih: vec![0.0; 4 * hidden * (ctx + classes)],
            g_b_ih: vec![0.0; 4 * hidden],
            g_w_hh: vec![0.0; 4 * hidden * hidden],
            g_b_hh: vec![0.0; 4 * hidden],
            generator: LinearF::new(hidden, classes, true),
            hidden,
            classes,
            ctx,
            sos,
            eos,
            pad,
        }
    }

    pub fn zero_grad(&mut self) {
        self.i2h.zero_grad();
        self.h2h.zero_grad();
        self.score.zero_grad();
        self.generator.zero_grad();
        for v in [&mut self.g_w_ih, &mut self.g_b_ih, &mut self.g_w_hh, &mut self.g_b_hh] {
            v.iter_mut().for_each(|x| *x = 0.0);
        }
    }

    fn cell_gates(&self, ci: &[f32], h: &[f32], b: usize) -> Vec<f32> {
        let (hs, cv) = (self.hidden, self.ctx + self.classes);
        let mut g = vec![0.0f32; b * 4 * hs];
        // По образцам батча параллельно: каждый bi считает свои 4*hs вентилей,
        // а порядок суммирования по k внутри вентиля не меняется.
        g.par_chunks_mut(4 * hs)
            .with_min_len(par_min(b * 4 * hs * (cv + hs)))
            .enumerate().for_each(|(bi, grow)| {
            let cir = &ci[bi * cv..(bi + 1) * cv];
            let hr = &h[bi * hs..(bi + 1) * hs];
            for o in 0..4 * hs {
                let wi = &self.w_ih[o * cv..(o + 1) * cv];
                let mut s = self.b_ih[o] + self.b_hh[o];
                for k in 0..cv {
                    s += cir[k] * wi[k];
                }
                let wh = &self.w_hh[o * hs..(o + 1) * hs];
                for k in 0..hs {
                    s += hr[k] * wh[k];
                }
                grow[o] = s;
            }
        });
        g
    }

    /// Teacher-forced forward; `text_in[bi][st]` = token fed at step st.
    /// Returns logits [B, steps, V].
    pub fn forward_train(&self, batch_h: &[f32], text_in: &[Vec<usize>], b: usize, t: usize) -> (Vec<f32>, AttnTrace) {
        let (hs, c, v) = (self.hidden, self.ctx, self.classes);
        let steps = text_in[0].len();
        let proj_h = self.i2h.forward(batch_h, b * t);
        let mut h = vec![0.0f32; b * hs];
        let mut cc = vec![0.0f32; b * hs];
        let mut gates_all = vec![0.0f32; steps * b * 4 * hs];
        let mut hs_all = vec![0.0f32; steps * b * hs];
        let mut cs_all = vec![0.0f32; steps * b * hs];
        let mut alpha_all = vec![0.0f32; steps * b * t];
        let mut tanh_all = vec![0.0f32; steps * b * t * hs];
        let mut onehots = vec![0.0f32; steps * b * v];
        let mut cell_in = vec![0.0f32; steps * b * (c + v)];
        let mut out_hid = vec![0.0f32; steps * b * hs];

        for st in 0..steps {
            let proj_hh = self.h2h.forward(&h, b);
            let mut e = vec![0.0f32; b * t];
            let tn = &mut tanh_all[st * b * t * hs..(st + 1) * b * t * hs];
            // Пары (образец, позиция) независимы: tanh и скалярное произведение
            // со score считаются параллельно по r = bi*t + tt.
            {
                let sc = &self.score.w;
                tn.par_chunks_mut(hs)
                    .zip(e.par_chunks_mut(1))
                    .with_min_len(par_min(b * t * 2 * hs))
                    .enumerate()
                    .for_each(|(r, (tnr, er))| {
                        let bi = r / t;
                        let pr = &proj_h[r * hs..(r + 1) * hs];
                        let hh = &proj_hh[bi * hs..(bi + 1) * hs];
                        for k in 0..hs {
                            tnr[k] = (pr[k] + hh[k]).tanh();
                        }
                        let mut s = 0.0;
                        for k in 0..hs {
                            s += tnr[k] * sc[k];
                        }
                        er[0] = s;
                    });
            }
            let alpha = &mut alpha_all[st * b * t..(st + 1) * b * t];
            alpha.par_chunks_mut(t)
                .with_min_len(par_min(b * t * 4))
                .enumerate().for_each(|(bi, arow)| {
                let row = &e[bi * t..(bi + 1) * t];
                let mx = row.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
                let ex: Vec<f32> = row.iter().map(|&x| (x - mx).exp()).collect();
                let s: f32 = ex.iter().sum();
                arow.copy_from_slice(&ex.iter().map(|&x| x / s).collect::<Vec<f32>>());
            });
            let mut context = vec![0.0f32; b * c];
            context.par_chunks_mut(c)
                .with_min_len(par_min(b * t * c * 2))
                .enumerate().for_each(|(bi, ctx)| {
                for tt in 0..t {
                    let a = alpha[bi * t + tt];
                    if a == 0.0 {
                        continue;
                    }
                    let bh = &batch_h[(bi * t + tt) * c..(bi * t + tt + 1) * c];
                    for k in 0..c {
                        ctx[k] += a * bh[k];
                    }
                }
            });
            {
                let oi = &mut onehots[st * b * v..(st + 1) * b * v];
                let ci_all = &mut cell_in[st * b * (c + v)..(st + 1) * b * (c + v)];
                oi.par_chunks_mut(v)
                    .zip(ci_all.par_chunks_mut(c + v))
                    .with_min_len(par_min(b * (c + v)))
                    .enumerate()
                    .for_each(|(bi, (oh, cio))| {
                        oh[text_in[bi][st]] = 1.0;
                        cio[..c].copy_from_slice(&context[bi * c..(bi + 1) * c]);
                        cio[c..].copy_from_slice(oh);
                    });
            }
            let ci = &cell_in[st * b * (c + v)..(st + 1) * b * (c + v)];
            let pre = self.cell_gates(ci, &h, b);
            let gr = &mut gates_all[st * b * 4 * hs..(st + 1) * b * 4 * hs];
            gr.par_chunks_mut(4 * hs)
                .zip(cc.par_chunks_mut(hs))
                .zip(h.par_chunks_mut(hs))
                .with_min_len(par_min(b * hs * 8))
                .enumerate()
                .for_each(|(bi, ((g, c_o), h_o))| {
                    let pr = &pre[bi * 4 * hs..(bi + 1) * 4 * hs];
                    for i in 0..hs {
                        let ig = 1.0 / (1.0 + (-pr[i]).exp());
                        let fg = 1.0 / (1.0 + (-pr[hs + i]).exp());
                        let cg = pr[2 * hs + i].tanh();
                        let og = 1.0 / (1.0 + (-pr[3 * hs + i]).exp());
                        let cnew = fg * c_o[i] + ig * cg;
                        g[i] = ig;
                        g[hs + i] = fg;
                        g[2 * hs + i] = cg;
                        g[3 * hs + i] = og;
                        c_o[i] = cnew;
                        h_o[i] = og * cnew.tanh();
                    }
                });
            hs_all[st * b * hs..(st + 1) * b * hs].copy_from_slice(&h);
            cs_all[st * b * hs..(st + 1) * b * hs].copy_from_slice(&cc);
            out_hid[st * b * hs..(st + 1) * b * hs].copy_from_slice(&h);
        }
        let logits_sb = self.generator.forward(&out_hid, steps * b);
        let mut l2 = vec![0.0f32; b * steps * v];
        // Перестановка [steps,B,V] -> [B,steps,V]: параллельно по bi.
        l2.par_chunks_mut(steps * v)
            .with_min_len(par_min(b * steps * v))
            .enumerate().for_each(|(bi, row)| {
            for st in 0..steps {
                row[st * v..(st + 1) * v]
                    .copy_from_slice(&logits_sb[(st * b + bi) * v..(st * b + bi + 1) * v]);
            }
        });
        (
            l2,
            AttnTrace {
                batch_h: batch_h.to_vec(),
                proj_h,
                tanh_e: tanh_all,
                alpha: alpha_all,
                onehots,
                cell_in,
                gates: gates_all,
                hs: hs_all,
                cs: cs_all,
                b,
                t,
                steps,
            },
        )
    }

    /// `d_logits` [B, steps, V] -> d(batch_h) [B, T, C]
    ///
    /// Всё распараллелено rayon так, чтобы порядок суммирования каждого
    /// аккумулятора не менялся — результат побитово совпадает с прежней
    /// последовательной версией. Заодно убран квадратичный пересчёт: раньше
    /// `d_alpha[0..t]` и `dot` считались заново внутри цикла по `tt`
    /// (O(t^2*c) на образец), теперь один раз на (шаг, образец).
    pub fn backward(&mut self, d_logits: &[f32], tr: &AttnTrace) -> Vec<f32> {
        let (b, t, steps) = (tr.b, tr.t, tr.steps);
        let (hs, c, v) = (self.hidden, self.ctx, self.classes);
        let cv = c + v;

        // --- generator: все steps*b строк одним батчем вместо steps*b вызовов
        // backward_row. Порядок строк r = st*b + bi тот же, что был.
        let mut dy_g = vec![0.0f32; steps * b * v];
        dy_g.par_chunks_mut(v)
            .with_min_len(par_min(steps * b * v))
            .enumerate().for_each(|(r, row)| {
            let st = r / b;
            let bi = r % b;
            row.copy_from_slice(&d_logits[(bi * steps + st) * v..(bi * steps + st + 1) * v]);
        });
        let d_out_hid = self.generator.backward_rows_par(&tr.hs, &dy_g, steps * b);

        let zeros = vec![0.0f32; b * hs];
        let mut dh_next = vec![0.0f32; b * hs];
        let mut dc_next = vec![0.0f32; b * hs];
        let mut d_proj_h = vec![0.0f32; b * t * hs];
        let mut d_batch_h = vec![0.0f32; b * t * c];

        for st in (0..steps).rev() {
            let gates = &tr.gates[st * b * 4 * hs..(st + 1) * b * 4 * hs];
            let ci = &tr.cell_in[st * b * cv..(st + 1) * b * cv];
            let c_prev: &[f32] = if st == 0 { &zeros } else { &tr.cs[(st - 1) * b * hs..st * b * hs] };
            let h_prev: &[f32] = if st == 0 { &zeros } else { &tr.hs[(st - 1) * b * hs..st * b * hs] };
            let ccur = &tr.cs[st * b * hs..(st + 1) * b * hs];
            let d_oh = &d_out_hid[st * b * hs..(st + 1) * b * hs];

            // --- Регион A: градиенты вентилей (параллельно по bi)
            let mut dgates = vec![0.0f32; b * 4 * hs];
            dgates
                .par_chunks_mut(4 * hs)
                .zip(dc_next.par_chunks_mut(hs))
                .with_min_len(par_min(b * hs * 12))
                .enumerate()
                .for_each(|(bi, (dg, dcn))| {
                    let g = &gates[bi * 4 * hs..(bi + 1) * 4 * hs];
                    let cc = &ccur[bi * hs..(bi + 1) * hs];
                    let cp = &c_prev[bi * hs..(bi + 1) * hs];
                    let dhn = &dh_next[bi * hs..(bi + 1) * hs];
                    let doh = &d_oh[bi * hs..(bi + 1) * hs];
                    for i in 0..hs {
                        let ig = g[i];
                        let fg = g[hs + i];
                        let cg = g[2 * hs + i];
                        let og = g[3 * hs + i];
                        let tc = cc[i].tanh();
                        let dh = doh[i] + dhn[i];
                        let dc = dh * og * (1.0 - tc * tc) + dcn[i] * fg;
                        dg[i] = dc * cg * ig * (1.0 - ig);
                        dg[hs + i] = dc * cp[i] * fg * (1.0 - fg);
                        dg[2 * hs + i] = dc * ig * (1.0 - cg * cg);
                        dg[3 * hs + i] = dh * tc * og * (1.0 - og);
                        dcn[i] = dc;
                    }
                });

            // --- Регион B1: градиенты весов клетки. Строке o принадлежат
            // g_w_ih[o*cv..], g_w_hh[o*hs..] и g_b_*[o]; суммирование по bi
            // идёт в прежнем порядке, поэтому числа те же.
            let mut dh_prev = vec![0.0f32; b * hs];
            let mut d_cellin = vec![0.0f32; b * cv];
            {
                let it = self
                    .g_w_ih
                    .par_chunks_mut(cv)
                    .zip(self.g_w_hh.par_chunks_mut(hs))
                    .zip(self.g_b_ih.par_iter_mut())
                    .zip(self.g_b_hh.par_iter_mut())
                    .with_min_len(par_min(4 * hs * b * (cv + hs)));
                it.enumerate().for_each(|(o, (((gih, ghh), gbi), gbh))| {
                    for bi in 0..b {
                        let dv = dgates[bi * 4 * hs + o];
                        if dv == 0.0 {
                            continue;
                        }
                        *gbi += dv;
                        *gbh += dv;
                        let cir = &ci[bi * cv..(bi + 1) * cv];
                        for k in 0..cv {
                            gih[k] += dv * cir[k];
                        }
                        let hp = &h_prev[bi * hs..(bi + 1) * hs];
                        for k in 0..hs {
                            ghh[k] += dv * hp[k];
                        }
                    }
                });
            }
            // --- Регион B2: d_cellin и dh_prev — параллельно по bi (веса только
            // читаются, порядок суммирования по o прежний).
            {
                let w_ih = &self.w_ih;
                let w_hh = &self.w_hh;
                d_cellin
                    .par_chunks_mut(cv)
                    .zip(dh_prev.par_chunks_mut(hs))
                    .with_min_len(par_min(b * 4 * hs * (cv + hs)))
                    .enumerate()
                    .for_each(|(bi, (dci, dhp))| {
                        let dg = &dgates[bi * 4 * hs..(bi + 1) * 4 * hs];
                        for o in 0..4 * hs {
                            let dv = dg[o];
                            if dv == 0.0 {
                                continue;
                            }
                            let wi = &w_ih[o * cv..(o + 1) * cv];
                            for k in 0..cv {
                                dci[k] += dv * wi[k];
                            }
                            let wh = &w_hh[o * hs..(o + 1) * hs];
                            for k in 0..hs {
                                dhp[k] += dv * wh[k];
                            }
                        }
                    });
            }

            // --- P1: d_alpha и dot — по одному разу на (шаг, образец); здесь же
            // градиент по batch_h из контекста. Параллельно по bi.
            let mut d_alpha_all = vec![0.0f32; b * t];
            let mut dot_all = vec![0.0f32; b];
            {
                let it = d_alpha_all
                    .par_chunks_mut(t)
                    .zip(dot_all.par_chunks_mut(1))
                    .zip(d_batch_h.par_chunks_mut(t * c))
                    .with_min_len(par_min(b * t * c * 3));
                it.enumerate().for_each(|(bi, ((da, dot), dbh))| {
                    let dctx = &d_cellin[bi * c..bi * c + c];
                    let alpha = &tr.alpha[st * b * t + bi * t..st * b * t + (bi + 1) * t];
                    for tt in 0..t {
                        let bh = &tr.batch_h[(bi * t + tt) * c..(bi * t + tt + 1) * c];
                        let mut s = 0.0;
                        for k in 0..c {
                            s += dctx[k] * bh[k];
                        }
                        da[tt] = s;
                        let a = alpha[tt];
                        for k in 0..c {
                            dbh[tt * c + k] += a * dctx[k];
                        }
                    }
                    let mut dv = 0.0;
                    for tt in 0..t {
                        dv += alpha[tt] * da[tt];
                    }
                    dot[0] = dv;
                });
            }
            // --- P2a: d_proj_h — параллельно по bi (свой непрерывный кусок t*hs).
            {
                let scw = &self.score.w;
                d_proj_h.par_chunks_mut(t * hs)
                    .with_min_len(par_min(b * t * hs * 3))
                    .enumerate().for_each(|(bi, dph)| {
                    let alpha = &tr.alpha[st * b * t + bi * t..st * b * t + (bi + 1) * t];
                    let da = &d_alpha_all[bi * t..(bi + 1) * t];
                    let dot = dot_all[bi];
                    for tt in 0..t {
                        let de = alpha[tt] * (da[tt] - dot);
                        if de == 0.0 {
                            continue;
                        }
                        let trow =
                            &tr.tanh_e[st * b * t * hs + (bi * t + tt) * hs..st * b * t * hs + (bi * t + tt + 1) * hs];
                        let dphr = &mut dph[tt * hs..(tt + 1) * hs];
                        for k in 0..hs {
                            dphr[k] += de * scw[k] * (1.0 - trow[k] * trow[k]);
                        }
                    }
                });
            }
            // --- P2b: score.g_w общий для всех (bi, tt), поэтому параллелим по k:
            // каждому k принадлежит свой score.g_w[k], а суммирование по (bi, tt)
            // идёт в прежнем порядке.
            self.score.g_w.par_iter_mut()
                .with_min_len(par_min(hs * b * t * 2))
                .enumerate().for_each(|(k, gk)| {
                for bi in 0..b {
                    let alpha = &tr.alpha[st * b * t + bi * t..st * b * t + (bi + 1) * t];
                    let da = &d_alpha_all[bi * t..(bi + 1) * t];
                    let dot = dot_all[bi];
                    for tt in 0..t {
                        let de = alpha[tt] * (da[tt] - dot);
                        if de == 0.0 {
                            continue;
                        }
                        *gk += de * tr.tanh_e[st * b * t * hs + (bi * t + tt) * hs + k];
                    }
                }
            });
            // --- P3: d proj_hh — параллельно по bi, затем h2h одним батчем
            // (b строк вместо b вызовов backward_row).
            let mut dprojhh = vec![0.0f32; b * hs];
            {
                let scw = &self.score.w;
                dprojhh.par_chunks_mut(hs)
                    .with_min_len(par_min(b * t * hs * 4))
                    .enumerate().for_each(|(bi, dphh)| {
                    let alpha = &tr.alpha[st * b * t + bi * t..st * b * t + (bi + 1) * t];
                    let da = &d_alpha_all[bi * t..(bi + 1) * t];
                    let dot = dot_all[bi];
                    for tt in 0..t {
                        let de = alpha[tt] * (da[tt] - dot);
                        if de == 0.0 {
                            continue;
                        }
                        let trow =
                            &tr.tanh_e[st * b * t * hs + (bi * t + tt) * hs..st * b * t * hs + (bi * t + tt + 1) * hs];
                        for k in 0..hs {
                            dphh[k] += de * scw[k] * (1.0 - trow[k] * trow[k]);
                        }
                    }
                });
            }
            let dx_hh = self.h2h.backward_rows_par(h_prev, &dprojhh, b);
            dh_prev
                .par_iter_mut()
                .zip(dx_hh.par_iter())
                .with_min_len(par_min(b * hs))
                .for_each(|(d, x)| *d += *x);
            dh_next = dh_prev;
        }
        // --- i2h: b*t строк одним батчем вместо b*t последовательных вызовов.
        let dx_i2h = self.i2h.backward_rows_par(&tr.batch_h, &d_proj_h, b * t);
        d_batch_h
            .par_iter_mut()
            .zip(dx_i2h.par_iter())
            .with_min_len(par_min(b * t * c))
            .for_each(|(d, x)| *d += *x);
        d_batch_h
    }

    /// Greedy decode; returns token ids per sample (EOS stripped).
    pub fn greedy_decode(&self, batch_h: &[f32], b: usize, t: usize, max_len: usize) -> Vec<Vec<usize>> {
        self.greedy_decode_full(batch_h, b, t, max_len, true).0
    }

    /// Тот же greedy-декод, но возвращает ещё и логиты каждого шага
    /// `[steps, B, V]`. При `early_stop = false` отрабатываются все
    /// `max_len + 1` шагов даже после EOS — ровно так устроен развёрнутый
    /// ONNX-граф (статический, без раннего стопа, см. `src/onnx.rs`), поэтому
    /// эталон для сверки с onnxruntime берётся отсюда. Поведение
    /// `greedy_decode` не изменилось: он вызывает этот метод с early_stop.
    /// Жадное декодирование с записью всех логитов (нужно для сверки ONNX).
    pub fn greedy_decode_full(
        &self,
        batch_h: &[f32],
        b: usize,
        t: usize,
        max_len: usize,
        early_stop: bool,
    ) -> (Vec<Vec<usize>>, Vec<f32>) {
        let (o, l, _) =
            self.decode_full::<rand::rngs::StdRng>(batch_h, b, t, max_len, early_stop, 0.0, 1.0, None);
        (o, l)
    }

    /// Единый движок декодирования. `temperature <= 0` или `rng == None` —
    /// жадный argmax (прежнее поведение, бит-в-бит); иначе сэмплинг с
    /// температурой и ядром top-p. Сэмплинг нужен MoPE: N разнообразных
    /// кандидатов раунда 0 в Markovian RSA получаются только из него.
    ///
    /// Возвращает: токены, логиты всех шагов `[steps, B, V]` (step-major, как
    /// читает `tools/check_onnx_export.py`) и средний логарифм вероятности
    /// выбранных токенов — это уверенность, которой RSA сравнивает кандидатов
    /// в режиме Best-of-N.
    pub fn decode_full<R: rand::Rng + ?Sized>(
        &self,
        batch_h: &[f32],
        b: usize,
        t: usize,
        max_len: usize,
        early_stop: bool,
        temperature: f32,
        top_p: f32,
        mut rng: Option<&mut R>,
    ) -> (Vec<Vec<usize>>, Vec<f32>, Vec<f32>) {
        let (hs, c, v) = (self.hidden, self.ctx, self.classes);
        let proj_h = self.i2h.forward(batch_h, b * t);
        let mut h = vec![0.0f32; b * hs];
        let mut cc = vec![0.0f32; b * hs];
        let mut targets = vec![self.sos; b];
        let mut out = vec![Vec::new(); b];
        let mut logits_all: Vec<f32> = Vec::with_capacity((max_len + 1) * b * v);
        let mut logp_sum = vec![0.0f32; b];
        let mut steps = vec![0usize; b];
        for _ in 0..max_len + 1 {
            let proj_hh = self.h2h.forward(&h, b);
            let mut e = vec![0.0f32; b * t];
            for bi in 0..b {
                for tt in 0..t {
                    let r = bi * t + tt;
                    let mut s = 0.0;
                    for k in 0..hs {
                        let z = (proj_h[r * hs + k] + proj_hh[bi * hs + k]).tanh();
                        s += z * self.score.w[k];
                    }
                    e[r] = s;
                }
            }
            let mut context = vec![0.0f32; b * c];
            for bi in 0..b {
                let row = &e[bi * t..(bi + 1) * t];
                let mx = row.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
                let ex: Vec<f32> = row.iter().map(|&x| (x - mx).exp()).collect();
                let s: f32 = ex.iter().sum();
                for tt in 0..t {
                    let a = ex[tt] / s;
                    if a == 0.0 {
                        continue;
                    }
                    for k in 0..c {
                        context[bi * c + k] += a * batch_h[(bi * t + tt) * c + k];
                    }
                }
            }
            let mut ci = vec![0.0f32; b * (c + v)];
            for bi in 0..b {
                ci[bi * (c + v)..bi * (c + v) + c].copy_from_slice(&context[bi * c..(bi + 1) * c]);
                ci[bi * (c + v) + c + targets[bi]] = 1.0;
            }
            let pre = self.cell_gates(&ci, &h, b);
            for bi in 0..b {
                for i in 0..hs {
                    let ig = 1.0 / (1.0 + (-pre[bi * 4 * hs + i]).exp());
                    let fg = 1.0 / (1.0 + (-pre[bi * 4 * hs + hs + i]).exp());
                    let cg = pre[bi * 4 * hs + 2 * hs + i].tanh();
                    let og = 1.0 / (1.0 + (-pre[bi * 4 * hs + 3 * hs + i]).exp());
                    let cnew = fg * cc[bi * hs + i] + ig * cg;
                    cc[bi * hs + i] = cnew;
                    h[bi * hs + i] = og * cnew.tanh();
                }
            }
            let logits = self.generator.forward(&h, b);
            logits_all.extend_from_slice(&logits);
            let mut all_eos = true;
            for bi in 0..b {
                let row = &logits[bi * v..(bi + 1) * v];
                // argmax либо сэмплинг; возвращаем и логарифм вероятности
                // выбранного токена (для скора кандидата в RSA).
                let (best, lp) = match rng.as_mut() {
                    Some(r) if temperature > 0.0 => sample_token(row, temperature, top_p, *r),
                    _ => {
                        let mut k = 0usize;
                        let mut bv = f32::NEG_INFINITY;
                        for (j, &x) in row.iter().enumerate() {
                            if x > bv {
                                bv = x;
                                k = j;
                            }
                        }
                        let mx = row.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
                        let mut z = 0.0f32;
                        for &x in row.iter() {
                            z += (x - mx).exp();
                        }
                        (k, row[k] - mx - z.max(1e-12).ln())
                    }
                };
                logp_sum[bi] += lp;
                steps[bi] += 1;
                if best == self.eos {
                    all_eos &= true;
                } else {
                    all_eos = false;
                    out[bi].push(best);
                }
                targets[bi] = best;
            }
            if all_eos && early_stop {
                break;
            }
        }
        let mean_lp: Vec<f32> = (0..b).map(|i| logp_sum[i] / steps[i].max(1) as f32).collect();
        (out, logits_all, mean_lp)
    }
}

/// Выбор токена: температура + ядро top-p (nucleus). `temperature <= 0` не
/// обрабатывается здесь — вызывающий код в этом случае идёт по argmax.
/// Возвращает индекс токена и логарифм его вероятности в ИСХОДНОМ
/// распределении (не в усечённом), чтобы скоры кандидатов были сравнимы.
pub(crate) fn sample_token<R: rand::Rng + ?Sized>(row: &[f32], temperature: f32, top_p: f32, rng: &mut R) -> (usize, f32) {
    let v = row.len();
    let mx = row.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
    let mut scaled: Vec<f32> = row.iter().map(|&x| ((x - mx) / temperature.max(1e-6)).exp()).collect();
    let mut z: f32 = scaled.iter().sum();
    if !(z > 0.0) || !z.is_finite() {
        scaled = vec![1.0; v];
        z = v as f32;
    }
    // log p исходного распределения
    let log_p = |k: usize| row[k] - mx - z.ln();
    if top_p >= 1.0 {
        let mut u = rng.gen::<f32>() * z;
        let mut acc = 0.0f32;
        for k in 0..v {
            acc += scaled[k];
            if u <= acc || k + 1 == v {
                return (k, log_p(k));
            }
        }
        let _ = &mut u;
        return (v - 1, log_p(v - 1));
    }
    // ядро top-p: сортируем по убыванию, режем по накопленной массе
    let mut idx: Vec<usize> = (0..v).collect();
    idx.sort_by(|&a, &b| scaled[b].partial_cmp(&scaled[a]).unwrap_or(std::cmp::Ordering::Equal));
    let mut acc = 0.0f32;
    let mut keep: Vec<usize> = Vec::new();
    for &k in &idx {
        keep.push(k);
        acc += scaled[k];
        if acc >= top_p {
            break;
        }
    }
    let kz: f32 = keep.iter().map(|&k| scaled[k]).sum();
    let mut u = rng.gen::<f32>() * kz;
    for (n, &k) in keep.iter().enumerate() {
        acc = scaled[k];
        u -= acc;
        if u <= 0.0 || n + 1 == keep.len() {
            return (k, log_p(k));
        }
    }
    let last = *keep.last().unwrap_or(&(v - 1));
    (last, log_p(last))
}
