//! Host fp32 Bidirectional LSTM stack, mirroring the reference encoder
//! `nn.Sequential(BidirectionalLSTM(512,256,256), BidirectionalLSTM(256,256,256))`
//! where `BidirectionalLSTM = nn.LSTM(bidirectional=True) + nn.Linear(2H, D)`.
//!
//! PyTorch gate order is (input, forget, cell, output).

use crate::qnet::par_min;
use rayon::prelude::*;

#[derive(Clone)]
pub struct LstmDir {
    pub w_ih: Vec<f32>, // [4H, D]
    pub b_ih: Vec<f32>,
    pub w_hh: Vec<f32>, // [4H, H]
    pub b_hh: Vec<f32>,
    pub g_w_ih: Vec<f32>,
    pub g_b_ih: Vec<f32>,
    pub g_w_hh: Vec<f32>,
    pub g_b_hh: Vec<f32>,
    pub d: usize,
    pub h: usize,
}

impl LstmDir {
    pub fn new(d: usize, h: usize) -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let lim_ih = (6.0 / (d + 4 * h) as f32).sqrt();
        let lim_hh = (6.0 / (h + 4 * h) as f32).sqrt();
        Self {
            w_ih: (0..4 * h * d).map(|_| rng.gen_range(-lim_ih..lim_ih)).collect(),
            b_ih: vec![0.0; 4 * h],
            w_hh: (0..4 * h * h).map(|_| rng.gen_range(-lim_hh..lim_hh)).collect(),
            b_hh: vec![0.0; 4 * h],
            g_w_ih: vec![0.0; 4 * h * d],
            g_b_ih: vec![0.0; 4 * h],
            g_w_hh: vec![0.0; 4 * h * h],
            g_b_hh: vec![0.0; 4 * h],
            d,
            h,
        }
    }
    pub fn zero_grad(&mut self) {
        self.g_w_ih.iter_mut().for_each(|x| *x = 0.0);
        self.g_b_ih.iter_mut().for_each(|x| *x = 0.0);
        self.g_w_hh.iter_mut().for_each(|x| *x = 0.0);
        self.g_b_hh.iter_mut().for_each(|x| *x = 0.0);
    }
}

#[derive(Clone)]
pub struct BiLstmLayer {
    pub fwd: LstmDir,
    pub bwd: LstmDir,
    pub proj_w: Vec<f32>, // [out, 2H]
    pub proj_b: Vec<f32>,
    pub g_proj_w: Vec<f32>,
    pub g_proj_b: Vec<f32>,
    pub h: usize,
    pub out: usize,
}

struct DirTrace {
    gates: Vec<f32>, // [T, B, 4H]
    c: Vec<f32>,     // [T, B, H]
    h: Vec<f32>,     // [T, B, H]
}

pub struct BiLstmTrace {
    x: Vec<f32>,           // [B, T, D]
    f_tr: DirTrace,
    b_tr: DirTrace,
    cat: Vec<f32>,         // [B, T, 2H]
    b: usize,
    t: usize,
}

impl BiLstmLayer {
    pub fn new(d: usize, h: usize, out: usize) -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let lim = (6.0 / (2 * h + out) as f32).sqrt();
        Self {
            fwd: LstmDir::new(d, h),
            bwd: LstmDir::new(d, h),
            proj_w: (0..out * 2 * h).map(|_| rng.gen_range(-lim..lim)).collect(),
            proj_b: vec![0.0; out],
            g_proj_w: vec![0.0; out * 2 * h],
            g_proj_b: vec![0.0; out],
            h,
            out,
        }
    }

    pub fn zero_grad(&mut self) {
        self.fwd.zero_grad();
        self.bwd.zero_grad();
        self.g_proj_w.iter_mut().for_each(|x| *x = 0.0);
        self.g_proj_b.iter_mut().for_each(|x| *x = 0.0);
    }

    fn run_dir(l: &LstmDir, x: &[f32], b: usize, t: usize, rev: bool) -> (Vec<f32>, DirTrace) {
        let h = l.h;
        let d = l.d;
        let mut gates = vec![0.0f32; t * b * 4 * h];
        let mut cs = vec![0.0f32; t * b * h];
        let mut hs = vec![0.0f32; t * b * h];
        let mut c_prev = vec![0.0f32; b * h];
        let mut h_prev = vec![0.0f32; b * h];
        for step in 0..t {
            let tt = if rev { t - 1 - step } else { step };
            let gr = &mut gates[step * b * 4 * h..(step + 1) * b * 4 * h];
            // gates = x @ W_ih^T + b_ih + h_prev @ W_hh^T + b_hh
            //
            // x — это [B, T, D]: именно так CNN отдаёт feat («dequant -> mean over
            // H -> [B, W, C]»), так следующий слой получает y предыдущего и так
            // attention/CTC читают enc (`batch_h[(bi * t + tt) * c + k]`).
            // Прежняя индексация `tt * b * d + bi * d` предполагала [T, B, D] и
            // при b >= 2 перемешивала время с батчем: шаг tt читал строки
            // bi = 0..b из моментов tt*b..tt*b+b-1, то есть на вход BiLSTM
            // приходила переставленная последовательность, а dx уходил в CNN
            // транспонированным. При b = 1 обе раскладки совпадают, поэтому баг
            // не проявлялся ни в тестах, ни в падениях.
            gr.par_chunks_mut(4 * h).enumerate().for_each(|(bi, row)| {
                let xr = &x[(bi * t + tt) * d..(bi * t + tt + 1) * d];
                for o in 0..4 * h {
                    let wi = &l.w_ih[o * d..(o + 1) * d];
                    let mut s = l.b_ih[o] + l.b_hh[o];
                    for k in 0..d {
                        s += xr[k] * wi[k];
                    }
                    let wh = &l.w_hh[o * h..(o + 1) * h];
                    for k in 0..h {
                        s += h_prev[bi * h + k] * wh[k];
                    }
                    row[o] = s;
                }
            });
            // Активация вентилей: по образцам батча параллельно (exp/tanh —
            // трансцендентные, а записи у каждого bi свои).
            let cs_r = &mut cs[step * b * h..(step + 1) * b * h];
            let hs_r = &mut hs[step * b * h..(step + 1) * b * h];
            gr.par_chunks_mut(4 * h)
                .zip(cs_r.par_chunks_mut(h))
                .zip(hs_r.par_chunks_mut(h))
                .with_min_len(par_min(b * h * 8))
                .enumerate()
                .for_each(|(bi, ((g, c_o), h_o))| {
                    for i in 0..h {
                        let gi = g[i];
                        let gf = g[h + i];
                        let gg = g[2 * h + i];
                        let go = g[3 * h + i];
                        let ig = 1.0 / (1.0 + (-gi).exp());
                        let fg = 1.0 / (1.0 + (-gf).exp());
                        let cg = gg.tanh();
                        let og = 1.0 / (1.0 + (-go).exp());
                        let c = fg * c_prev[bi * h + i] + ig * cg;
                        let hh = og * c.tanh();
                        g[i] = ig;
                        g[h + i] = fg;
                        g[2 * h + i] = cg;
                        g[3 * h + i] = og;
                        c_o[i] = c;
                        h_o[i] = hh;
                    }
                });
            c_prev.copy_from_slice(&cs[step * b * h..(step + 1) * b * h]);
            h_prev.copy_from_slice(&hs[step * b * h..(step + 1) * b * h]);
        }
        (hs.clone(), DirTrace { gates, c: cs, h: hs })
    }

    /// `x` [B, T, D] -> `y` [B, T, out]
    pub fn forward(&self, x: &[f32], b: usize, t: usize) -> (Vec<f32>, BiLstmTrace) {
        let h = self.h;
        let (_hf, f_tr) = Self::run_dir(&self.fwd, x, b, t, false);
        let (_hb, b_tr) = Self::run_dir(&self.bwd, x, b, t, true);
        // hf/hb хранятся по СЛОТАМ шага: run_dir пишет hs[step * b * h + ...].
        // Для прямого направления слот == позиция tt, для реверсного слот step
        // обрабатывает позицию tt = t - 1 - step, то есть hidden реверсного
        // направления для позиции tt лежит в слоте t - 1 - tt.
        //
        // Раньше оба направления брались из слота tt, поэтому вторая половина
        // cat оказывалась зеркально перевёрнутой во времени: на позиции tt
        // внимание и CTC видели реверсный контекст позиции t-1-tt. Прямое
        // направление от этого не страдало, обратный ход был самосогласован
        // (он индексировал трейсы теми же слотами), поэтому обучение шло и баг
        // не проявлялся ни в лоссе, ни в падениях — только в качестве модели:
        // двунаправленный контекст склеивался из неверных половин.
        let cat = cat_from_h(&f_tr.h, &b_tr.h, b, t, h);
        let y = proj_forward(&cat, &self.proj_w, &self.proj_b, b * t, self.out);
        (y, BiLstmTrace { x: x.to_vec(), f_tr, b_tr, cat, b, t })
    }

    /// `dy` [B, T, out]; returns dx [B, T, D]
    pub fn backward(&mut self, dy: &[f32], tr: &BiLstmTrace) -> Vec<f32> {
        let (b, t, h) = (tr.b, tr.t, self.h);
        let d = self.fwd.d;
        // projection backward
        let dcat = proj_backward_dcat(dy, &self.proj_w, b * t, 2 * h, self.out);
        proj_grads(
            dy,
            &tr.cat,
            &mut self.g_proj_w,
            &mut self.g_proj_b,
            b * t,
            2 * h,
            self.out,
        );
        // split dcat into per-direction [T, B, H] в СЛОТНОМ порядке (bwd_dir
        // читает dh_out[step * b * h + ...], а step — это слот). Зеркально
        // правке в forward: градиент реверсного направления для слота step
        // приходит из позиции tt = t - 1 - step.
        let (dh_f, dh_b) = split_dcat(&dcat, b, t, h);
        let dx1 = Self::bwd_dir(&mut self.fwd, &dh_f, tr, false);
        let dx2 = Self::bwd_dir(&mut self.bwd, &dh_b, tr, true);
        let mut dx = vec![0.0f32; b * t * d];
        dx.par_iter_mut()
            .zip(dx1.par_iter())
            .zip(dx2.par_iter())
            .with_min_len(par_min(b * t * d))
            .for_each(|((o, a), b2)| *o = *a + *b2);
        dx
    }

    fn bwd_dir(l: &mut LstmDir, dh_out: &[f32], tr: &BiLstmTrace, rev: bool) -> Vec<f32> {
        let (b, t, h) = (tr.b, tr.t, l.h);
        let d = l.d;
        let trc = if rev { &tr.b_tr } else { &tr.f_tr };
        let mut dx = vec![0.0f32; t * b * d];
        let mut dc_next = vec![0.0f32; b * h];
        let mut dh_next = vec![0.0f32; b * h];
        for step in (0..t).rev() {
            let tt = if rev { t - 1 - step } else { step };
            let gr = &trc.gates[step * b * 4 * h..(step + 1) * b * 4 * h];
            let cr = &trc.c[step * b * h..(step + 1) * b * h];
            // h_prev / c_prev
            let (h_prev, c_prev): (Vec<f32>, Vec<f32>) = if step == 0 {
                (vec![0.0; b * h], vec![0.0; b * h])
            } else {
                (
                    trc.h[(step - 1) * b * h..step * b * h].to_vec(),
                    trc.c[(step - 1) * b * h..step * b * h].to_vec(),
                )
            };
            let mut dgates = vec![0.0f32; b * 4 * h];
            // Регион A — градиенты вентилей. По образцам батча параллельно:
            // dgates/dc_next/dh_next у каждого bi свои, а порядок операций
            // внутри образца не меняется, поэтому числа те же побитово.
            let dh_row = &dh_out[step * b * h..(step + 1) * b * h];
            dgates
                .par_chunks_mut(4 * h)
                .zip(dc_next.par_chunks_mut(h))
                .zip(dh_next.par_chunks_mut(h))
                .with_min_len(par_min(b * h * 12))
                .enumerate()
                .for_each(|(bi, ((dg, dcn), dhn))| {
                    for i in 0..h {
                        let ig = gr[bi * 4 * h + i];
                        let fg = gr[bi * 4 * h + h + i];
                        let cg = gr[bi * 4 * h + 2 * h + i];
                        let og = gr[bi * 4 * h + 3 * h + i];
                        let c = cr[bi * h + i];
                        let tc = c.tanh();
                        let dh = dh_row[bi * h + i] + dhn[i];
                        let dc = dh * og * (1.0 - tc * tc) + dcn[i] * fg;
                        dg[i] = dc * cg * ig * (1.0 - ig);
                        dg[h + i] = dc * c_prev[bi * h + i] * fg * (1.0 - fg);
                        dg[2 * h + i] = dc * ig * (1.0 - cg * cg);
                        dg[3 * h + i] = dh * tc * og * (1.0 - og);
                        dcn[i] = dc;
                        dhn[i] = 0.0; // consumed below via W_hh
                    }
                });
            // dx = dgates @ W_ih ; dh_prev = dgates @ W_hh ; weight grads
            // tr.x и dx — [B, T, D], см. комментарий в run_dir: CNN ждёт
            // градиент признака ровно в этой раскладке.
            // Регион B — градиенты весов направления. Параллельно по строкам o:
            // строке o принадлежат g_w_ih[o*d..], g_w_hh[o*h..] и g_b_*[o],
            // поэтому записи не пересекаются, а суммирование по bi идёт в том же
            // порядке (0..b) — результат побитово прежний. Это самый горячий цикл
            // обучения: в профиле rnn_bwd занимал 50% времени батча.
            {
                let it = l
                    .g_w_ih
                    .par_chunks_mut(d)
                    .zip(l.g_w_hh.par_chunks_mut(h))
                    .zip(l.g_b_ih.par_iter_mut())
                    .zip(l.g_b_hh.par_iter_mut())
                    .with_min_len(par_min(4 * h * b * (d + h)));
                it.enumerate().for_each(|(o, (((gi, gh), gbi), gbh))| {
                    for bi in 0..b {
                        let dv = dgates[bi * 4 * h + o];
                        if dv == 0.0 {
                            continue;
                        }
                        *gbi += dv;
                        *gbh += dv;
                        let xr = &tr.x[(bi * t + tt) * d..(bi * t + tt + 1) * d];
                        for k in 0..d {
                            gi[k] += dv * xr[k];
                        }
                        let hp = &h_prev[bi * h..(bi + 1) * h];
                        for k in 0..h {
                            gh[k] += dv * hp[k];
                        }
                    }
                });
            }
            // Регион C — dx и dh_next: веса только читаются, записи у каждого bi
            // свои, поэтому параллельно по bi. dx адресован [B, T, D], нужный срез
            // лежит внутри чанка своего bi — unsafe не требуется.
            {
                let w_ih = &l.w_ih;
                let w_hh = &l.w_hh;
                dx.par_chunks_mut(t * d)
                    .zip(dh_next.par_chunks_mut(h))
                    .with_min_len(par_min(b * 4 * h * (d + h)))
                    .enumerate()
                    .for_each(|(bi, (dxrow, dhn))| {
                        let dxr = &mut dxrow[tt * d..tt * d + d];
                        let dg = &dgates[bi * 4 * h..(bi + 1) * 4 * h];
                        for k in 0..d {
                            let mut s = 0.0;
                            for o in 0..4 * h {
                                s += dg[o] * w_ih[o * d + k];
                            }
                            dxr[k] = s;
                        }
                        for k in 0..h {
                            let mut s = 0.0;
                            for o in 0..4 * h {
                                s += dg[o] * w_hh[o * h + k];
                            }
                            dhn[k] = s;
                        }
                    });
            }
        }
        dx
    }
}

pub struct BiLstmStack {
    pub layers: Vec<BiLstmLayer>,
}

impl BiLstmStack {
    /// reference: 2 layers, hidden 256, first input = cnn out (512)
    pub fn new(in_dim: usize, hidden: usize, n_layers: usize) -> Self {
        let mut layers = Vec::new();
        for i in 0..n_layers {
            let d = if i == 0 { in_dim } else { hidden };
            layers.push(BiLstmLayer::new(d, hidden, hidden));
        }
        Self { layers }
    }
    pub fn zero_grad(&mut self) {
        for l in &mut self.layers {
            l.zero_grad();
        }
    }
    pub fn forward(&self, x: &[f32], b: usize, t: usize) -> (Vec<f32>, Vec<BiLstmTrace>) {
        let mut cur = x.to_vec();
        let mut traces = Vec::new();
        for l in &self.layers {
            let (y, tr) = l.forward(&cur, b, t);
            cur = y;
            traces.push(tr);
        }
        (cur, traces)
    }
    pub fn backward(&mut self, dy: &[f32], traces: &[BiLstmTrace]) -> Vec<f32> {
        let mut cur = dy.to_vec();
        for (l, tr) in self.layers.iter_mut().zip(traces.iter()).rev() {
            cur = l.backward(&cur, tr);
        }
        cur
    }
}

// ===========================================================================
// Общие хелперы проекции. Их используют и хостовый путь, и device-путь, поэтому
// расхождение между путями возможно только внутри LSTM-направлений — ровно там,
// где его и ищет тест device_bilstm_matches_host_bilstm.
// ===========================================================================

use crate::backend::{
    launch_lstm_bgrad, launch_lstm_bwd_cell, launch_lstm_bwd_rec, launch_lstm_fwd_step,
    launch_lstm_wgrad_hh, launch_lstm_wgrad_ih, CudaStream, DevBuf,
};

/// `cat [B, T, 2H]` из hidden обоих направлений. Трекеры направлений хранятся
/// по СЛОТАМ шага: у прямого слот совпадает с позицией tt, у реверсного hidden
/// позиции tt лежит в слоте `t-1-tt`.
fn cat_from_h(h_f: &[f32], h_b: &[f32], b: usize, t: usize, h: usize) -> Vec<f32> {
    let mut cat = vec![0.0f32; b * t * 2 * h];
    for tt in 0..t {
        let slot_b = t - 1 - tt;
        for bi in 0..b {
            cat[(bi * t + tt) * 2 * h..(bi * t + tt) * 2 * h + h]
                .copy_from_slice(&h_f[tt * b * h + bi * h..tt * b * h + (bi + 1) * h]);
            cat[(bi * t + tt) * 2 * h + h..(bi * t + tt + 1) * 2 * h]
                .copy_from_slice(&h_b[slot_b * b * h + bi * h..slot_b * b * h + (bi + 1) * h]);
        }
    }
    cat
}

/// `y [rows, out] = cat [rows, h2] @ proj_w^T + proj_b`
fn proj_forward(cat: &[f32], proj_w: &[f32], proj_b: &[f32], rows: usize, out: usize) -> Vec<f32> {
    let h2 = cat.len() / rows.max(1);
    let mut y = vec![0.0f32; rows * out];
    y.par_chunks_mut(out).enumerate().for_each(|(r, row)| {
        let cr = &cat[r * h2..(r + 1) * h2];
        for o in 0..out {
            let w = &proj_w[o * h2..(o + 1) * h2];
            let mut s = proj_b[o];
            for k in 0..h2 {
                s += cr[k] * w[k];
            }
            row[o] = s;
        }
    });
    y
}

/// `dcat [rows, h2] = dy [rows, out] @ proj_w`
fn proj_backward_dcat(
    dy: &[f32],
    proj_w: &[f32],
    rows: usize,
    h2: usize,
    out: usize,
) -> Vec<f32> {
    let mut dcat = vec![0.0f32; rows * h2];
    dcat.par_chunks_mut(h2).enumerate().for_each(|(r, row)| {
        let dyr = &dy[r * out..(r + 1) * out];
        for o in 0..out {
            let dv = dyr[o];
            if dv == 0.0 {
                continue;
            }
            for k in 0..h2 {
                row[k] += dv * proj_w[o * h2 + k];
            }
        }
    });
    dcat
}

/// `g_proj_w [out, h2] += dy^T @ cat`, `g_proj_b[out] += sum(dy)`
fn proj_grads(
    dy: &[f32],
    cat: &[f32],
    g_w: &mut [f32],
    g_b: &mut [f32],
    rows: usize,
    h2: usize,
    out: usize,
) {
    // Параллельно по строкам o матрицы градиента: строке o принадлежат
    // g_w[o*h2..] и g_b[o]. Суммирование по r идёт в прежнем порядке, поэтому
    // результат побитово тот же, что и в последовательной версии.
    g_w.par_chunks_mut(h2)
        .zip(g_b.par_iter_mut())
        .with_min_len(par_min(rows * out * h2))
        .enumerate()
        .for_each(|(o, (gw, gb))| {
            for r in 0..rows {
                let dv = dy[r * out + o];
                if dv == 0.0 {
                    continue;
                }
                *gb += dv;
                let cr = &cat[r * h2..(r + 1) * h2];
                for k in 0..h2 {
                    gw[k] += dv * cr[k];
                }
            }
        });
}

/// `dcat [B, T, 2H]` -> `(dh_f, dh_b)` в СЛОТНОМ порядке `[T, B, H]`: `bwd_dir`
/// читает `dh_out[step * b * h + ...]`, где step — слот. Для реверсного
/// направления градиент слота step приходит из позиции `tt = t-1-step`.
fn split_dcat(dcat: &[f32], b: usize, t: usize, h: usize) -> (Vec<f32>, Vec<f32>) {
    let mut dh_f = vec![0.0f32; t * b * h];
    let mut dh_b = vec![0.0f32; t * b * h];
    for tt in 0..t {
        let slot_b = t - 1 - tt;
        for bi in 0..b {
            dh_f[tt * b * h + bi * h..tt * b * h + (bi + 1) * h]
                .copy_from_slice(&dcat[(bi * t + tt) * 2 * h..(bi * t + tt) * 2 * h + h]);
            dh_b[slot_b * b * h + bi * h..slot_b * b * h + (bi + 1) * h]
                .copy_from_slice(&dcat[(bi * t + tt) * 2 * h + h..(bi * t + tt + 1) * 2 * h]);
        }
    }
    (dh_f, dh_b)
}

// ===========================================================================
// Device-путь BiLSTM (TRBA_GPU_RNN=1) — стадия 1 плана из BUGFIX_REPORT §11.2
//
// На GPU считаются оба направления LSTM: прямой проход (по одному запуску на
// слот на направление), обратный проход (элементная часть + проекции на слот) и
// градиенты весов (по одному запуску на направление на всю последовательность).
// Проекция `cat -> y` остаётся на хосте: она параллелится rayon и стоит ~4 мс,
// тогда как последовательная часть LSTM на хосте стоит сотни миллисекунд.
//
// feat из CNN при этом на хост НЕ скачивается: слой 0 получает `x_dev` прямо из
// `cnn.forward`, а `d_feat` уходит в `cnn.backward` устройством. Через PCIe
// ходят только hidden-трекеры (2 × T·B·H), dh (столько же), y следующего слоя и
// dx (B·T·D) — килобайты; основная статья трафика стадии 1 — веса направлений
// вверх и их градиенты вниз (~10.5 МБ в каждую сторону на 2 слоя при
// hidden=256, D=512), потому что Adam для RNN пока хостовый. Стадия 2
// (резидентные веса + device-Adam для RNN) убирает и их.
// ===========================================================================

/// `TRBA_GPU_RNN=1` — BiLSTM на устройстве вместо скалярного хостового пути.
pub fn gpu_rnn_enabled() -> bool {
    std::env::var("TRBA_GPU_RNN").as_deref() == Ok("1")
}

/// Веса, градиенты и трейсы одного направления на устройстве.
struct DirDev {
    w_ih: DevBuf,
    b_ih: DevBuf,
    w_hh: DevBuf,
    b_hh: DevBuf,
    g_w_ih: DevBuf,
    g_b_ih: DevBuf,
    g_w_hh: DevBuf,
    g_b_hh: DevBuf,
    gates: DevBuf, // [T, B, 4H] после активаций
    c: DevBuf,     // [T, B, H]
    h: DevBuf,     // [T, B, H]
    dgates: DevBuf,
    dh_next: DevBuf,
    dc_next: DevBuf,
}

impl DirDev {
    fn new(l: &LstmDir, b: usize, t: usize, stream: &CudaStream) -> Self {
        let (d, h) = (l.d, l.h);
        let up = |v: &[f32]| {
            let buf = DevBuf::new(v.len() * 4);
            buf.upload_f32(v, stream);
            buf
        };
        let zero = |n: usize| {
            let buf = DevBuf::new(n * 4);
            buf.upload_f32(&vec![0.0f32; n], stream);
            buf
        };
        DirDev {
            w_ih: up(&l.w_ih),
            b_ih: up(&l.b_ih),
            w_hh: up(&l.w_hh),
            b_hh: up(&l.b_hh),
            // градиенты пишутся ядрами с accumulate=0, поэтому не инициализируются
            g_w_ih: DevBuf::new(4 * h * d * 4),
            g_b_ih: DevBuf::new(4 * h * 4),
            g_w_hh: DevBuf::new(4 * h * h * 4),
            g_b_hh: DevBuf::new(4 * h * 4),
            gates: DevBuf::new(t * b * 4 * h * 4),
            c: DevBuf::new(t * b * h * 4),
            h: DevBuf::new(t * b * h * 4),
            dgates: DevBuf::new(t * b * 4 * h * 4),
            // dh_next/dc_next читаются на первом слоте обратного хода раньше,
            // чем будут записаны, — обязаны быть нулевыми
            dh_next: zero(b * h),
            dc_next: zero(b * h),
        }
    }

    /// Сброс рекуррентных состояний перед обратным ходом.
    fn reset_bwd_state(&self, b: usize, h: usize, stream: &CudaStream) {
        let zeros = vec![0.0f32; b * h];
        self.dh_next.upload_f32(&zeros, stream);
        self.dc_next.upload_f32(&zeros, stream);
    }
}

/// Трейс одного слоя device-пути: живёт между forward и backward.
pub struct DevLayerTrace {
    df: DirDev,
    db: DirDev,
    x_dev: DevBuf, // [B, T, D] вход слоя (нужен для grad_input и g_w_ih)
    dx_f: DevBuf,  // [B, T, D]
    dx_b: DevBuf,
    cat: Vec<f32>, // [B, T, 2H] на хосте — для проекции и её градиентов
    pub b: usize,
    pub t: usize,
}

impl BiLstmLayer {
    /// Один слой на устройстве: `x_dev [B, T, D]` -> `y [B, T, out]` (хост).
    fn forward_device(
        &self,
        x_dev: DevBuf,
        b: usize,
        t: usize,
        stream: &CudaStream,
    ) -> (Vec<f32>, DevLayerTrace) {
        let (d, h) = (self.fwd.d, self.fwd.h);
        let f = DirDev::new(&self.fwd, b, t, stream);
        let r = DirDev::new(&self.bwd, b, t, stream);
        for slot in 0..t {
            for (dir, rev) in [(&f, 0i64), (&r, 1i64)] {
                unsafe {
                    launch_lstm_fwd_step(
                        x_dev.as_f32(),
                        dir.w_ih.as_f32(),
                        dir.b_ih.as_f32(),
                        dir.w_hh.as_f32(),
                        dir.b_hh.as_f32(),
                        dir.gates.as_f32_mut(),
                        dir.c.as_f32_mut(),
                        dir.h.as_f32_mut(),
                        b as i64,
                        t as i64,
                        d as i64,
                        h as i64,
                        slot as i64,
                        rev,
                        stream.0,
                    )
                };
            }
        }
        let mut h_f = vec![0.0f32; t * b * h];
        let mut h_b = vec![0.0f32; t * b * h];
        f.h.download_f32(&mut h_f, stream);
        r.h.download_f32(&mut h_b, stream);
        stream.sync();

        let cat = cat_from_h(&h_f, &h_b, b, t, h);
        let y = proj_forward(&cat, &self.proj_w, &self.proj_b, b * t, self.out);
        let tr = DevLayerTrace {
            df: f,
            db: r,
            dx_f: DevBuf::new(b * t * d * 4),
            dx_b: DevBuf::new(b * t * d * 4),
            x_dev,
            cat,
            b,
            t,
        };
        (y, tr)
    }

    /// Обратный ход одного слоя на устройстве: `dy [B, T, out]` -> `dx [B, T, D]`.
    fn backward_device(
        &mut self,
        dy: &[f32],
        tr: &DevLayerTrace,
        stream: &CudaStream,
    ) -> Vec<f32> {
        let (b, t) = (tr.b, tr.t);
        let (d, h) = (self.fwd.d, self.fwd.h);

        // проекция — на хосте (те же хелперы, что и в хостовом пути)
        let dcat = proj_backward_dcat(dy, &self.proj_w, b * t, 2 * h, self.out);
        proj_grads(
            dy,
            &tr.cat,
            &mut self.g_proj_w,
            &mut self.g_proj_b,
            b * t,
            2 * h,
            self.out,
        );
        let (dh_f, dh_b) = split_dcat(&dcat, b, t, h);
        let dh_f_dev = DevBuf::new(t * b * h * 4);
        let dh_b_dev = DevBuf::new(t * b * h * 4);
        dh_f_dev.upload_f32(&dh_f, stream);
        dh_b_dev.upload_f32(&dh_b, stream);

        for (dir, dh_dev, dx_dev, rev) in [
            (&tr.df, &dh_f_dev, &tr.dx_f, 0i64),
            (&tr.db, &dh_b_dev, &tr.dx_b, 1i64),
        ] {
            dir.reset_bwd_state(b, h, stream);
            for slot in (0..t).rev() {
                unsafe {
                    launch_lstm_bwd_cell(
                        dh_dev.as_f32(),
                        dir.gates.as_f32(),
                        dir.c.as_f32(),
                        dir.dh_next.as_f32(),
                        dir.dc_next.as_f32(),
                        dir.dgates.as_f32_mut(),
                        dir.dc_next.as_f32_mut(),
                        b as i64,
                        h as i64,
                        slot as i64,
                        stream.0,
                    )
                };
                unsafe {
                    launch_lstm_bwd_rec(
                        dir.dgates.as_f32(),
                        dir.w_ih.as_f32(),
                        dir.w_hh.as_f32(),
                        dx_dev.as_f32_mut(),
                        dir.dh_next.as_f32_mut(),
                        b as i64,
                        t as i64,
                        d as i64,
                        h as i64,
                        slot as i64,
                        rev,
                        stream.0,
                    )
                };
            }
            // градиенты весов: по одному запуску на всю последовательность
            unsafe {
                launch_lstm_wgrad_ih(
                    dir.dgates.as_f32(),
                    tr.x_dev.as_f32(),
                    dir.g_w_ih.as_f32_mut(),
                    b as i64,
                    t as i64,
                    d as i64,
                    h as i64,
                    rev,
                    0,
                    stream.0,
                )
            };
            unsafe {
                launch_lstm_wgrad_hh(
                    dir.dgates.as_f32(),
                    dir.h.as_f32(),
                    dir.g_w_hh.as_f32_mut(),
                    b as i64,
                    t as i64,
                    h as i64,
                    0,
                    stream.0,
                )
            };
            unsafe {
                launch_lstm_bgrad(
                    dir.dgates.as_f32(),
                    dir.g_b_ih.as_f32_mut(),
                    dir.g_b_hh.as_f32_mut(),
                    b as i64,
                    t as i64,
                    h as i64,
                    0,
                    stream.0,
                )
            };
        }

        // градиенты весов — на хост (Adam для RNN пока хостовый, стадия 1)
        let mut tmp;
        tmp = vec![0.0f32; 4 * h * d];
        tr.df.g_w_ih.download_f32(&mut tmp, stream);
        self.fwd.g_w_ih.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h * h];
        tr.df.g_w_hh.download_f32(&mut tmp, stream);
        self.fwd.g_w_hh.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h];
        tr.df.g_b_ih.download_f32(&mut tmp, stream);
        self.fwd.g_b_ih.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h];
        tr.df.g_b_hh.download_f32(&mut tmp, stream);
        self.fwd.g_b_hh.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h * d];
        tr.db.g_w_ih.download_f32(&mut tmp, stream);
        self.bwd.g_w_ih.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h * h];
        tr.db.g_w_hh.download_f32(&mut tmp, stream);
        self.bwd.g_w_hh.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h];
        tr.db.g_b_ih.download_f32(&mut tmp, stream);
        self.bwd.g_b_ih.copy_from_slice(&tmp);
        tmp = vec![0.0f32; 4 * h];
        tr.db.g_b_hh.download_f32(&mut tmp, stream);
        self.bwd.g_b_hh.copy_from_slice(&tmp);

        // dx обоих направлений: отдельные буферы (иначе гонка на запись),
        // складываются на хосте после скачивания
        let mut dx_f = vec![0.0f32; b * t * d];
        let mut dx_b = vec![0.0f32; b * t * d];
        tr.dx_f.download_f32(&mut dx_f, stream);
        tr.dx_b.download_f32(&mut dx_b, stream);
        stream.sync();
        for (a, v) in dx_f.iter_mut().zip(dx_b.iter()) {
            *a += *v;
        }
        dx_f
    }
}

impl BiLstmStack {
    /// `x_dev [B, T, in_dim]` на устройстве -> `enc [B, T, hidden]` на хосте
    /// (attention и CTC пока хостовые) + трейсы для обратного хода.
    pub fn forward_device(
        &self,
        x_dev: DevBuf,
        b: usize,
        t: usize,
        stream: &CudaStream,
    ) -> (Vec<f32>, Vec<DevLayerTrace>) {
        let mut traces = Vec::new();
        let mut cur_dev = x_dev;
        let mut cur_host: Vec<f32> = Vec::new();
        for l in &self.layers {
            let (y, tr) = l.forward_device(cur_dev, b, t, stream);
            let next = DevBuf::new(y.len() * 4);
            next.upload_f32(&y, stream);
            cur_dev = next;
            cur_host = y;
            traces.push(tr);
        }
        (cur_host, traces)
    }

    /// `dy [B, T, hidden]` -> `d_feat [B, T, in_dim]` на устройстве (прямо в
    /// `cnn.backward`, без промежуточной выгрузки).
    pub fn backward_device(
        &mut self,
        dy: &[f32],
        traces: &[DevLayerTrace],
        stream: &CudaStream,
    ) -> DevBuf {
        let mut cur = dy.to_vec();
        for (l, tr) in self.layers.iter_mut().zip(traces.iter()).rev() {
            cur = l.backward_device(&cur, tr, stream);
        }
        let buf = DevBuf::new(cur.len() * 4);
        buf.upload_f32(&cur, stream);
        buf
    }
}
