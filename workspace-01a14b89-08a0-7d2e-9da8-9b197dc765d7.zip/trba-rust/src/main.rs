//! TRBA trainer (Rust + INT8 Tensor Cores), reference-faithful port of
//! `manuscript-ocr/recognizers/_trba/training/train.py`:
//!
//! * SEResNet31 CNN (INT8 fake-QAT GEMMs, fp32 BatchNorm/SE/residuals)
//! * 2-layer Bidirectional LSTM encoder
//! * attention decoder (teacher forcing) + CTC head
//! * loss = (1-w) * CE(attention, ignore <PAD>) + w * CTC, w decays 0.3 -> 0.03
//! * Adam + cosine LR + global grad-norm clip 5.0
//!
//! CSV format: `path,text` per line (paths relative to the CSV directory or
//! absolute); `charset.txt` next to the train CSV defines the vocabulary
//! (first three tokens must be <PAD> <SOS> <EOS>).

use std::io::{BufRead, BufReader};
use std::path::Path;
use std::sync::Arc;

use anyhow::{anyhow, Result};
use rand::seq::SliceRandom;
use rand::SeedableRng;
use trba_rust::surgery::{self, Geometry, SurgeryCfg};

use trba_rust::attn::AttentionDecoder;
use trba_rust::backend::*;
use trba_rust::ctc::ctc_loss_backward;
use trba_rust::opt::{Adam, ParamRef};
use trba_rust::qnet::{conv_weights_on_device, LinearF, Scratch, SEResNetQ};
use trba_rust::rnn::{gpu_rnn_enabled, BiLstmStack, BiLstmTrace, DevLayerTrace};

const CKPT_MAGIC: &[u8; 8] = b"TRBA_V5\n";
/// V6 = V5 + геометрия и имена тензоров: без них чекпоинт нельзя перенести в
/// другую геометрию (рост 32×128 → 64×256, hidden 256 → 384).
const CKPT_MAGIC_V6: &[u8; 8] = b"TRBA_V6\n";
/// Прежний формат: те же веса и BN-статистика, но без Adam-моментов и без
/// позиции внутри эпохи.  Читается, чтобы чекпоинты прошлых прогонов не
/// пропадали; пишется всегда V5.
const CKPT_MAGIC_V4: &[u8; 8] = b"TRBA_V4\n";
/// Примеры для `--help`: копируются целиком, пути — реальный датасет
/// куррентшрифта, поэтому подставлять ничего не нужно.
const HELP_EXAMPLES: &str = r#"
ПРИМЕРЫ (пути — датасет куррентшрифта; D можно заменить на свой)

  D=/media/korziner/14ext4/trba/trba_kurrent

  1. Дым за минуту — проверить, что карта и сборка живые:
       cargo run --release -- $D/train.csv $D/val.csv exp/ --smoke 8 --batch-size 2

  2. Полное обучение. После Ctrl-C, OOM-kill или падения драйвера тот же
     запуск продолжается с прерванного батча (rolling checkpoint_last.bin):
       cargo run --release -- $D/train.csv $D/val.csv exp/ \
           --epochs 100 --batch-size 32 --img-h 64 --img-w 256 --max-len 40

  3. Подбор (batch_size × ширина) под PCIe 2.0 x4 и 10 ГБ VRAM:
       cargo run --release -- $D/train.csv "" exp/ --autotune --autotune-trials 12

  4. Распознавание готовым чекпоинтом (вход — каталог, CSV или список):
       cargo run --release -- /path/to/imgs out.tsv exp/ --infer --img-h 64 --img-w 256

  5. ПОСТЕПЕННЫЙ РОСТ геометрии — веса переносятся, обучение не начинается с нуля.
     Свёртки, BN, SE и BiLSTM от размера картинки не зависят, поэтому рост
     32×128 → 64×256 бесплатный: меняется только число шагов T.
       a) что в чекпоинте и как он ляжет в новую геометрию:
            cargo run --release -- $D/train.csv "" exp/ \
                --inspect-ckpt exp/checkpoint_last.bin --img-h 64 --img-w 256 --max-len 40
       b) одна ступень роста обычным --resume:
            cargo run --release -- $D/train.csv $D/val.csv exp/ --epochs 20 \
                --resume exp/checkpoint_last.bin --img-h 64 --img-w 256 --max-len 40
       c) лестница ступеней одной командой (каждая продолжает предыдущую):
            cargo run --release -- $D/train.csv $D/val.csv exp/ --epochs 30 \
                --grow-ladder "48x192:5,64x256:10,64x256h384:15"
          слепок каждой ступени: exp/checkpoint_stage01_48x192h256.bin …
       d) рост выразительности без роста разрешения (ширина и глубина):
            --grow-ladder "32x128h384:10,32x128h512L3:10"
       e) побитовое сохранение выхода сети при росте hidden (новые ячейки
          при этом мёртвы — годится, чтобы только «примерить» размер):
            --surgery-eps 0

  6. Экспорт в ONNX: fp32 и INT8-QDQ (QuantizeLinear/DequantizeLinear по
     QAT-шкалам — так onnxruntime уходит в тензорные ядра):
       cargo run --release -- $D/val.csv "" exp/ --export-onnx model.onnx --onnx-ref exp/ref
       cargo run --release -- $D/val.csv "" exp/ --export-onnx m_i8.onnx --onnx-int8 --onnx-calib 64
       python3 tools/check_onnx_export.py exp/ref model.onnx $D/charset.txt

  7. MoPE / Franken-MoPE — смесь предобученных экспертов (один файл = один
     писарь/устав). ПОЛНЫЙ ЦИКЛ: конвертация → дообучение → инференс.
       a) конвертация чужих весов в .mope:
            python3 tools/mope_import.py trba_base_g1.onnx --out base.mope \
                --charset trba_base_g1.txt --config trba_base_g1.json \
                --merge-charset --char-counts-csv $D/train.csv
          свой чекпоинт trba-rust экспортируется тем же форматом:
            cargo run --release -- $D/train.csv "" exp/ \
                --resume exp/checkpoint_last.bin --img-h 64 --img-w 256 \
                --mope-export-bundle kurrent.mope
       b) ДООБУЧЕНИЕ после конвертации. Эксперты заморожены (их веса не
          меняются); учатся роутер, PID-балансировка загрузки, агрегатор вместе
          с CCA и Res-scale, и адаптеры размерностей. Учитель — настоящая
          разметка, цель роутера — «от всех моделей беря лучшее» (ур. 3–5 ZAYA1):
            cargo run --release -- $D/train.csv $D/val.csv exp/ --mope --mope-train \
                --mope-experts base.mope,kurrent.mope \
                --mope-char-counts $D/train.csv --mope-min-freq 3 --mope-charset-max 256 \
                --epochs 3 --mope-target soft --mope-lr 3e-4 --mope-agg-lr 3e-4 \
                --mope-balance-lr 1e-3 --mope-n 4 --mope-c 2 --mope-tau 8 \
                --mope-save-franken exp/franken.bin
          продолжить с сохранённого состояния — добавьте --mope-franken
          exp/franken.bin (словарь, размеры и состояние Adam подхватятся сами)
       c) инференс на выученном состоянии (Best-of-N и Markovian-RSA):
            cargo run --release -- $D/val.csv "" exp/ --mope \
                --mope-experts base.mope,kurrent.mope --mope-franken exp/franken.bin \
                --mope-char-counts $D/train.csv --mope-min-freq 3 --mope-charset-max 256 \
                --mope-n 4 --mope-c 2 --mope-t 2 --mope-tau 8 --mope-cache 8
       Важно: --mope-char-counts/--mope-min-freq/--mope-charset-max в (b) и (c)
       должны совпадать — от них зависит объединённый словарь, а значит и
       размеры роутера с агрегатором.

  8. Сборка под sm_75 с настоящим CUDA (без молчаливого fallback на CPU):
       TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release
       bash scripts/run_cuda_smoke.sh

ПЕРЕМЕННЫЕ ОКРУЖЕНИЯ
  TRBA_REQUIRE_CUDA=1     отказаться стартовать, если слинковался CPU-бэкенд
  TRBA_CUDA_ARCH=75       архитектура для nvcc (sm_75 = Turing: 2060/1650/CMP 50HX)
  TRBA_HOST_CONV_ADAM=1   Adam для свёрток на хосте (экономит VRAM/ОЗУ)
  TRBA_GPU_RNN=1          BiLSTM на GPU (56 SM вместо 4 ядер CPU)
  TRBA_PCIE_COUNTER=1     печатать объём трафика H2D/D2H на батч
  TRBA_INT8_GEMM=wmma|dp4a  способ считать int8-GEMM
  TRBA_FORCE_CPU=1        собрать/запустить на CPU (для тестов без карты)

"#;

/// Rolling-чекпоинт: пишется каждые `--ckpt-every-batch` батчей и в конце каждой
/// эпохи, всегда атомарно (tmp + rename), поэтому прерывание записи не портит
/// предыдущую версию. Именно из него прогон продолжается после перезапуска.
const CKPT_LAST: &str = "checkpoint_last.bin";

/// Что чекпоинт помнит кроме весов.
///
/// `epoch_done` — число *завершённых* эпох, `batch_in_epoch` — сколько батчей
/// следующей эпохи уже пройдено (0, если сохранение было на границе эпох).
/// Продолжение всегда начинается с `epoch_done + 1` и пропускает
/// `batch_in_epoch` батчей — правило одно и для середины эпохи, и для её конца.
// ---------------------------------------------------------------------------
// TRBA_PROFILE=1 — куда уходит время одного батча
//
// Зачем: на бумажной архитектуре только CNN выполняется на GPU, а BiLSTM,
// attention-декодер, CTC и Adam по host-параметрам считаются на CPU в скалярном
// Rust. Профиль показывает, какая фаза определяет s/batch и почему GPU при этом
// простаивает (низкий SM-utilization — это не дефект ядер, а ожидание хоста).
// ---------------------------------------------------------------------------

/// (короткое имя, описание, класс фазы: "pcie" | "gpu" | "cpu")
const PROF_PHASES: [(&str, &str, &str); 14] = [
    ("img_h2d",   "загрузка int8-батча на GPU",              "pcie"),
    ("cnn_fwd",   "CNN forward: int8 IMMA-ядра",             "gpu"),
    ("feat_d2h",  "выгрузка feat [B,T,512] + sync",          "pcie"),
    ("rnn_fwd",   "BiLSTM forward (2 слоя x 2 направления)", "cpu"),
    ("attn_fwd",  "attention-декодер forward",               "cpu"),
    ("ctc_fwd",   "CTC forward",                             "cpu"),
    ("loss",      "attention CE + CTC-лосс и d_logits/d_ctc","cpu"),
    ("attn_bwd",  "attention backward + zero_grad",          "cpu"),
    ("ctc_bwd",   "CTC backward",                            "cpu"),
    ("rnn_bwd",   "BiLSTM backward",                         "cpu"),
    ("dfeat_h2d", "загрузка d_feat [B,T,512] на GPU",        "pcie"),
    ("cnn_bwd",   "CNN backward (int8) + sync",              "gpu"),
    ("clip_adam", "clip по норме + Adam по host-параметрам", "cpu"),
    ("adam_dev",  "Adam по 42.15M conv-весам (GPU) + requant","gpu"),
];

/// Трейс BiLSTM: хостовый путь хранит Vec-трекеры, device-путь — буферы
/// устройства (они живут между forward и backward одного шага).
enum RnnTrace {
    Host(Vec<BiLstmTrace>),
    Dev(Vec<DevLayerTrace>),
}

struct Profiler {
    on: bool,
    /// TRBA_GPU_RNN=1: BiLSTM считается на устройстве, поэтому его фазы
    /// относятся к GPU, а выгрузки feat/d_feat не происходит. Без этого таблица
    /// врала бы о том, где именно время (cnn_fwd/cnn_bwd помечены [gpu] так же).
    dev_rnn: bool,
    acc: Vec<f64>,
    batches: usize,
    mark: std::time::Instant,
}

impl Profiler {
    fn new() -> Self {
        Profiler {
            on: std::env::var("TRBA_PROFILE").as_deref() == Ok("1"),
            dev_rnn: gpu_rnn_enabled(),
            acc: vec![0.0; PROF_PHASES.len()],
            batches: 0,
            mark: std::time::Instant::now(),
        }
    }

    /// Закрыть фазу `i` и начать следующую. В режиме профилирования перед
    /// отметкой делается stream.sync(): запуски ядер асинхронны, и без
    /// синхронизации GPU-время «протекает» в следующую фазу. Сама
    /// синхронизация замедляет профилируемый прогон (порядка нескольких
    /// миллисекунд на батч), поэтому режим выключен по умолчанию.
    fn hit(&mut self, i: usize, stream: &CudaStream) {
        if !self.on {
            return;
        }
        stream.sync();
        let now = std::time::Instant::now();
        self.acc[i] += now.duration_since(self.mark).as_secs_f64();
        self.mark = now;
    }

    /// Описание фазы с учётом device-RNN (см. поле `dev_rnn`).
    fn phase(&self, i: usize) -> (&'static str, &'static str, &'static str) {
        if self.dev_rnn {
            match i {
                2 => {
                    return ("feat_d2h", "выгрузки feat нет: буфер остаётся на GPU", "pcie")
                }
                3 => {
                    return (
                        "rnn_fwd",
                        "BiLSTM forward на GPU (2 слоя x 2 направления)",
                        "gpu",
                    )
                }
                9 => return ("rnn_bwd", "BiLSTM backward на GPU + градиенты весов", "gpu"),
                10 => {
                    return ("dfeat_h2d", "загрузки d_feat нет: буфер остаётся на GPU", "pcie")
                }
                _ => {}
            }
        }
        PROF_PHASES[i]
    }

    fn batch_done(&mut self) {
        if self.on {
            self.batches += 1;
        }
    }

    /// `cnn_macs` = (MAC forward, MAC backward), накопленные за все батчи отчёта.
    fn report_and_reset(&mut self, tag: &str, cnn_macs: (u64, u64)) {
        if !self.on || self.batches == 0 {
            return;
        }
        let n = self.batches as f64;
        let tot: f64 = self.acc.iter().sum();
        let (mut cpu, mut gpu, mut pcie) = (0.0f64, 0.0f64, 0.0f64);
        for i in 0..PROF_PHASES.len() {
            match self.phase(i).2 {
                "gpu" => gpu += self.acc[i],
                "pcie" => pcie += self.acc[i],
                _ => cpu += self.acc[i],
            }
        }
        eprintln!(
            "[profile] {tag}: {} батч(ей), {:.1} мс/батч | CPU {:.1} мс ({:.0}%),              GPU {:.1} мс ({:.0}%), PCIe {:.1} мс ({:.0}%)",
            self.batches,
            tot / n * 1e3,
            cpu / n * 1e3,
            if tot > 0.0 { cpu / tot * 100.0 } else { 0.0 },
            gpu / n * 1e3,
            if tot > 0.0 { gpu / tot * 100.0 } else { 0.0 },
            pcie / n * 1e3,
            if tot > 0.0 { pcie / tot * 100.0 } else { 0.0 },
        );
        for i in 0..PROF_PHASES.len() {
            let (name, desc, kind) = self.phase(i);
            let share = if tot > 0.0 { self.acc[i] / tot * 100.0 } else { 0.0 };
            eprintln!(
                "   {:<10} {:>8.2} мс/батч {:>5.1}%  [{}] {}",
                name,
                self.acc[i] / n * 1e3,
                share,
                kind,
                desc
            );
        }
        // Достигнутая производительность int8-GEMM: MAC из счётчиков ConvQat
        // делятся на время фаз cnn_fwd/cnn_bwd. Это ответ на вопрос «а тензорные
        // ядра вообще работают?»: если GMAC/s на порядки ниже пика IMMA, узкое
        // место не в GEMM, а в запусках/ожидании хоста.
        if cnn_macs.0 > 0 {
            let f_s = self.acc[1] / n;
            let b_s = self.acc[11] / n;
            let fm = cnn_macs.0 as f64 / n / 1e9;
            let bm = cnn_macs.1 as f64 / n / 1e9;
            eprintln!(
                "   [int8] CNN forward : {fm:.3} GMAC/батч за {:.2} мс -> {:.0} GMAC/s ({:.0} GOPS)",
                f_s * 1e3,
                if f_s > 0.0 { fm / f_s } else { 0.0 },
                if f_s > 0.0 { 2.0 * fm / f_s } else { 0.0 }
            );
            eprintln!(
                "   [int8] CNN backward: {bm:.3} GMAC/батч за {:.2} мс -> {:.0} GMAC/s ({:.0} GOPS)",
                b_s * 1e3,
                if b_s > 0.0 { bm / b_s } else { 0.0 },
                if b_s > 0.0 { 2.0 * bm / b_s } else { 0.0 }
            );
            eprintln!("   [int8] пик IMMA = SM x 1024 MAC/такт x частота (см. README, раздел TRBA_PROFILE)");
        }
        for x in self.acc.iter_mut() {
            *x = 0.0;
        }
        self.batches = 0;
        self.mark = std::time::Instant::now();
    }
}

#[derive(Clone, Copy, Debug, Default)]
pub struct CkptMeta {
    pub epoch_done: usize,
    pub batch_in_epoch: usize,
}

// ------------------------------------------------------------------ args --

struct Args {
    train_csv: String,
    val_csv: Option<String>,
    exp_dir: String,
    charset: Option<String>,
    batch: usize,
    epochs: usize,
    lr: f32,
    weight_decay: f32,
    img_h: usize,
    img_w: usize,
    max_len: usize,
    hidden: usize,
    /// `--feat-dim N`: ширина признака энкодера (512 по умолчанию — историческая
    /// архитектура SEResNetQ; таблица каналов `[fd/8, fd/4, fd/2, fd/2, fd, fd]`).
    /// Число параметров CNN растёт как fd², поэтому fd=128 даёт эксперта в 16 раз
    /// меньше (2.7M весов, ~2.7 МБ в int8 против 42.9M и 43 МБ) и обучает его
    /// в разы быстрее. Кратно 8; для int8-GEMM выгодно кратно 16. Должно совпадать
    /// при `--resume` (иначе формы весов не сойдутся — геометрия это проверяет).
    feat_dim: usize,
    /// true, если пользователь явно задал хотя бы один RSA-флаг: тогда его
    /// значения важнее геометрии, сохранённой в franken-файле (MOPEFR02).
    rsa_user_set: bool,
    /// `--build-charset a.csv,b.csv` — собрать словарь из текстов CSV и записать
    /// его в файл, указанный в `--charset`, после чего завершиться.
    build_charset: String,
    /// `--rnn-layers N`: число слоёв BiLSTM (2 по умолчанию). Отдельный флаг
    /// нужен потому, что предобученные чекпоинты бывают с одним слоем
    /// (`trba_base_g1`), и потому, что рост «выразительности» — это не только
    /// разрешение, но и глубина/ширина энкодера.
    rnn_layers: usize,
    /// `--surgery-eps X`: шум в новых столбцах при переносе весов в большую
    /// геометрию. 0 = побитовое сохранение выхода (новые ячейки мёртвы),
    /// 0.01 = выход уезжает на процент, зато новые ячейки сразу учатся.
    surgery_eps: f32,
    /// `--grow-ladder "48x192:3,64x256h384:5"`: постепенный рост геометрии —
    /// каждая ступень продолжает предыдущий чекпоинт, а не учится с нуля.
    grow_ladder: String,
    /// `--inspect-ckpt PATH`: что лежит в чекпоинте и как он перенесётся в
    /// текущую геометрию (ничего не обучает).
    inspect_ckpt: String,
    resume: Option<String>,
    no_resume: bool,
    ckpt_every: usize,
    /// `--ckpt-every-batch N`: rolling-чекпоинт каждые N батчей (0 = выключено)
    ckpt_every_batch: usize,
    /// `--clip-warmup N`: сколько первых шагов применяется глобальный clip по
    /// норме (0 = никогда). Дальше шаг ограничивает нормировка Muon.
    clip_warmup: usize,
    seed: u64,
    smoke: usize,
    eval_every: usize,
    /// `--autotune`: optuna-подобный подбор (batch_size, img_w), см. src/autotune.rs
    autotune: bool,
    /// `--infer`: распознавание готовым чекпоинтом вместо обучения
    infer: bool,
    /// `--export-onnx PATH`: выгрузить граф (CNN + BiLSTM + CTC-голова) в ONNX
    export_onnx: String,
    /// `--onnx-layout nhwc|nchw`: раскладка входа (см. src/onnx.rs)
    onnx_layout: String,
    /// `--onnx-int8`: QDQ-вариант графа по QAT-шкалам калибровочного прохода
    onnx_int8: bool,
    /// `--onnx-ref DIR`: записать input/feat/enc/logits для сверки с onnxruntime
    onnx_ref: String,
    /// `--onnx-debug`: дополнительные выходы графа (conv0/stem/enc)
    onnx_debug: bool,
    /// `--onnx-calib N`: сколько картинок взять на калибровку и сверку
    onnx_calib: usize,
    /// `--onnx-no-decoder`: не разворачивать attention-декодер (только энкодер + CTC)
    onnx_no_decoder: bool,
    // ---------------- MoPE: смесь предобученных экспертов (ZAYA1-8B) -------
    /// `--mope`: маршрутизация + Markovian RSA поверх предобученных чекпоинтов
    mope: bool,
    /// `--mope-experts a.bin,b.bin`: по одному чекпоинту на писаря (2..256)
    mope_experts: String,
    /// `--mope-n N`: кандидатов раунда 0 (Best-of-N)
    mope_n: usize,
    /// `--mope-c C`: сколько хвостов уходит в промпт агрегации
    mope_c: usize,
    /// `--mope-t T`: раундов агрегации (0 = обычный Best-of-N)
    mope_t: usize,
    /// `--mope-tau τ`: длина хвоста кандидата
    mope_tau: usize,
    /// `--mope-topk k`: сколько экспертов активировать (1 = top-1, как в ZAYA1)
    mope_top_k: usize,
    /// `--mope-cache K`: сколько экспертов держать материализованными (LRU)
    mope_cache: usize,
    /// `--mope-temperature`: температура сэмплинга кандидатов
    mope_temperature: f32,
    /// `--mope-top-p`: ядро top-p при сэмплинге
    mope_top_p: f32,
    /// `--mope-limit N`: сколько строк обработать
    mope_limit: usize,
    /// Флаг задан пользователем явно (нужен, чтобы дефолт 4 не резал обучение)
    mope_limit_set: bool,
    /// `--mope-lr`: шаг AdamW роутера
    mope_lr: f64,
    /// `--mope-balance-lr`: шаг PID-балансировки (уравнение 5)
    mope_balance_lr: f64,
    /// `--mope-router PATH`: загрузить/сохранить роутер вместе с bias и PID
    mope_router: String,
    /// `--mope-save-router PATH`: куда сохранить обученный роутер
    mope_save_router: String,
    /// `--mope-agg PATH`: обученный агрегатор RSA (без него агрегация не обучена)
    mope_agg: String,
    /// `--mope-min-freq N`: порог частоты символа при слиянии словарей (3 или 7)
    mope_min_freq: u64,
    /// `--mope-charset-max N`: предел объединённого словаря MoPE (например 256)
    mope_charset_max: usize,
    /// `--mope-charset-out PATH`: куда записать объединённый charset.txt
    mope_charset_out: String,
    /// `--mope-char-counts A.csv,B.csv`: корпуса для подсчёта частот символов
    mope_char_counts: String,
    /// `--ssl-lexicon a.txt,b.txt`: печатный корпус того же прихода/периода.
    /// Пусто — весь SSL-тракт выключен, поведение прежнее.
    ssl_lexicon: String,
    /// `--ssl-ngram N`: порядок символьной n-граммной модели (меньше 2 — не строить)
    ssl_ngram: usize,
    /// `--ssl-rare P`: частота ниже P делает слово сомнительным, даже если оно в словаре
    ssl_rare: f64,
    /// `--ssl-gap G`: разрыв скоров ≤ G ⇒ печатаем два варианта в квадратных скобках
    ssl_gap: f64,
    /// `--ssl-out FILE`: псевдоразметка CSV (`путь,текст`) — файл сразу съедает --resume
    ssl_out: String,
    /// `--mope-export-bundle PATH`: выгрузить локальный чекпоинт в бандл MoPE
    mope_export_bundle: String,
    /// `--mope-int8`: писать бандл эксперта сразу в int8 (MOPEBI01)
    mope_int8: bool,
    /// `--mope-train` — дообучение Franken-MoPE (роутер + агрегатор + адаптеры)
    mope_train: bool,
    /// `--mope-target soft|hard` — цель роутера: softmax(-лоссы) или один победитель
    mope_target: String,
    /// `--mope-agg-lr X` — шаг обучения агрегатора/CCA/Res-scale/адаптеров
    mope_agg_lr: f64,
    /// `--mope-save-franken PATH` — сохранить всё обученное состояние
    mope_save_franken: String,
    /// `--mope-franken PATH` — загрузить обученное состояние (роутер+агрегатор+адаптеры)
    mope_franken: String,
    /// `--mope-adapt`: доучивать роутер и PID прямо на инференсе по скорам
    /// собственных кандидатов (прежнее поведение). По умолчанию выключено, если
    /// состояние загружено из файла: иначе выученная на разметке политика
    /// размывается сигналом без учителя.
    mope_adapt: bool,
    autotune_trials: usize,
    autotune_batches: usize,
    autotune_timeout: usize,
    autotune_vram: f64,
    autotune_objective: String,
    autotune_out: String,
    autotune_widths: String,
    autotune_batch_sizes: String,
}

fn parse_args() -> Result<Args> {
    let argv: Vec<String> = std::env::args().collect();
    let mut a = Args {
        train_csv: String::new(),
        val_csv: None,
        exp_dir: "exp".into(),
        charset: None,
        batch: 32,
        epochs: 100,
        lr: 5.107e-4,
        weight_decay: 1.9548e-5,
        img_h: 32,
        img_w: 1024,
        max_len: 64,
        hidden: 256,
        feat_dim: 512,
        rsa_user_set: false,
        build_charset: String::new(),
        rnn_layers: 2,
        surgery_eps: 0.01,
        grow_ladder: String::new(),
        inspect_ckpt: String::new(),
        resume: None,
        no_resume: false,
        ckpt_every: 0,
        ckpt_every_batch: 500,
        clip_warmup: 500,
        seed: 42,
        smoke: 0,
        eval_every: 1,
        autotune: false,
        infer: false,
        export_onnx: String::new(),
        onnx_layout: "nhwc".to_string(),
        onnx_int8: false,
        onnx_ref: String::new(),
        onnx_debug: false,
        onnx_calib: 4,
        onnx_no_decoder: false,
        mope: false,
        mope_experts: String::new(),
        // штатная конфигурация §VI отчёта (N, C, T) = (16, 4, 2)
        mope_n: 16,
        mope_c: 4,
        mope_t: 2,
        mope_tau: 4,
        mope_top_k: 1,
        mope_cache: 2,
        mope_temperature: 1.0,
        mope_top_p: 1.0,
        mope_limit: 4,
        mope_limit_set: false,
        mope_lr: 1e-2,
        mope_balance_lr: 1e-2,
        mope_router: String::new(),
        mope_save_router: String::new(),
        mope_agg: String::new(),
        mope_min_freq: 3,
        mope_charset_max: 256,
        mope_charset_out: String::new(),
        mope_char_counts: String::new(),
        ssl_lexicon: String::new(),
        ssl_ngram: 4,
        ssl_rare: 1e-4,
        ssl_gap: 0.5,
        ssl_out: String::new(),
        mope_export_bundle: String::new(),
        mope_int8: false,
        mope_train: false,
        mope_target: "soft".to_string(),
        mope_agg_lr: 3e-4,
        mope_save_franken: String::new(),
        mope_franken: String::new(),
        mope_adapt: false,
        autotune_trials: 0,
        autotune_batches: 4,
        autotune_timeout: 600,
        autotune_vram: 0.0,
        autotune_objective: "throughput".into(),
        autotune_out: String::new(),
        autotune_widths: String::new(),
        autotune_batch_sizes: String::new(),
    };
    let mut positional = Vec::new();
    let mut i = 1;
    while i < argv.len() {
        let arg = argv[i].clone();
        let take = |i: &mut usize, name: &str| -> Result<String> {
            if *i + 1 >= argv.len() {
                return Err(anyhow!("{name} требует значение"));
            }
            *i += 1;
            Ok(argv[*i].clone())
        };
        match arg.as_str() {
            "--help" | "-h" => {
                println!("trba-rust <train.csv> [val.csv] <exp_dir> [опции]");
                print!("{HELP_EXAMPLES}");
                println!("ОПЦИИ");
                println!("  --batch-size N   --epochs N     --lr X        --weight-decay X");
                println!("  --img-h N        --img-w N      --max-len N   --hidden N   --rnn-layers N");
                println!("  --feat-dim N     ширина признака энкодера, кратно 8. Проверена только");
                                     println!("                   512 (историческая SEResNetQ); 256 = 10.5M conv-весов и 4.4x");
                                     println!("                   SEResNetQ (42.15M conv-весов), 256 = 10.54M, 128 = 2.63M.");
                println!("  --build-charset  a.csv[,b.csv] — собрать словарь из текстов CSV в файл");
                println!("                   из --charset (<PAD>,<SOS>,<EOS> + символы по кодовым точкам)");
                println!("  --grow-ladder SPEC  постепенный рост: \"48x192:5,64x256h384:10\" (размер[hN][LN][mN]:эпохи)");
                println!("  --inspect-ckpt P    что в чекпоинте и как он перенесётся в текущую геометрию");
                println!("  --surgery-eps X     шум в новых столбцах при переносе весов (0 = побитово, 0.01 по умолчанию)");
                println!("  --charset PATH   --resume [PATH] --no-resume  --ckpt-every N");
                println!("  --infer            распознать картинки чекпоинтом: <вход> [результат.tsv] <exp_dir>");
                println!("  --export-onnx PATH выгрузить граф в ONNX (вход/выход: input -> logits, динамический batch)");
                println!("  --onnx-layout L    nhwc (по умолчанию, соответствует load_image_q) | nchw");
                println!("  --onnx-int8        QDQ-граф int8 по QAT-шкалам (нужны картинки для калибровки)");
                println!("  --onnx-ref DIR     записать тензоры для сверки с onnxruntime (tools/check_onnx_export.py)");
                println!("  --onnx-debug       дополнительные выходы conv0/stem/enc");
                println!("  --onnx-calib N     картинок на калибровку/сверку (по умолчанию 4)");
                println!("  --onnx-no-decoder  не разворачивать attention-декодер (энкодер + CTC-голова)");
                println!("  --mope             смесь предобученных экспертов (ZAYA1-8B MoE++ + Markovian RSA)");
                println!("  --mope-experts A,B чекпоинты экспертов: один файл = один писарь (2..256)");
                println!("  --mope-n/-c/-t/-tau N C T tau  параметры RSA (по умолчанию 16 4 2 4)");
                println!("  --mope-topk k      сколько экспертов активировать (по умолчанию 1)");
                println!("  --mope-cache K     сколько экспертов держать материализованными (LRU)");
                println!("  --mope-temperature T / --mope-top-p P  сэмплинг кандидатов");
                println!("  --mope-limit N     сколько строк обработать (по умолчанию 4; с --mope-train");
                println!("                     дефолт не применяется — учим на всём датасете, если флаг не задан)");
                println!("  --mope-lr / --mope-balance-lr  AdamW роутера / PID-балансировка загрузки");
                println!("  --mope-train       ДООБУЧЕНИЕ Franken-MoPE после конвертации экспертов:");
                println!("                     роутер + PID + агрегатор (CCA, Res-scale) + адаптеры размерностей;");
                println!("                     эксперты ЗАМОРОЖЕНЫ, учитель — настоящая разметка из train.csv");
                println!("  --mope-target soft|hard  цель роутера «от всех моделей беря лучшее»:");
                println!("                     soft = softmax(-лосс/T) по экспертам (по умолчанию), hard = один победитель");
                println!("  --mope-agg-lr LR   Adam агрегатора/CCA/Res-scale/адаптеров (по умолчанию 3e-4)");
                println!("  --mope-save-franken P  сохранить всё обученное состояние одним файлом (MOPEFR01)");
                println!("  --mope-franken P   подставить состояние из файла — и для инференса, и чтобы");
                println!("                     продолжить --mope-train (Adam-моменты и счётчик шагов тоже)");
                println!("  --mope-adapt       доучивать роутер и PID прямо на инференсе по скорам");
                println!("                     кандидатов (по умолчанию с загруженным состоянием они заморожены)");
                println!("  --mope-router P / --mope-save-router P / --mope-agg P  веса роутера и агрегатора");
                println!("  --mope-min-freq N  порог частоты символа при слиянии словарей (по умолчанию 3)");
                println!("  --mope-charset-max N  предел объединённого словаря (по умолчанию 256)");
                println!("  --mope-charset-out P  записать объединённый charset.txt");
                println!("  --mope-char-counts A.csv,B.csv  корпуса для частот символов");
                println!("  --mope-export-bundle P  выгрузить локальный чекпоинт в бандл MoPE");
                println!("  --mope-int8        тот же бандл, но сразу в int8 (MOPEBI01): файл в 4 раза");
                println!("                     меньше, загрузка без fp32-копии; распознавание то же");
                println!("  --seed N         --smoke N      --eval-every N");
                println!("  --ckpt-every N         номерной чекпоинт каждые N эпох");
                println!("  --ckpt-every-batch N   rolling checkpoint_last.bin каждые N батчей (0 = выкл, по умолчанию 500)");
                println!("  --clip-warmup N        глобальный clip по норме только на первых N шагах (по умолчанию 500, 0 = никогда)");
                println!("  --resume [PATH]        продолжить из самого свежего чекпоинта (или из PATH);");
                println!("                         если геометрия запуска больше — веса переносятся хирургией,");
                println!("                         а счётчики эпох/шагов сбрасываются (warmup отрабатывает заново)");
                println!("  --autotune       подбор (batch_size, img_w) по сетке стандартных размеров EAST");
                println!("    --autotune-trials N    бюджет проб (0 = вся сетка)");
                println!("    --autotune-batches N   батчей в одной пробе (по умолчанию 4)");
                println!("    --autotune-timeout N   секунд на пробу (по умолчанию 600)");
                println!("    --autotune-vram MIB    предел занятой памяти (0 = 90% свободного)");
                println!("    --autotune-objective X throughput | efficiency | latency");
                println!("    --autotune-out PATH    отчёт JSON (по умолчанию <exp_dir>/autotune.json)");
                println!("    --autotune-widths L    свой список ширин, напр. 128,256,512");
                println!("    --autotune-batch-sizes L  свой список батчей, напр. 2,8,32");
                std::process::exit(0);
            }
            "--batch-size" | "-b" => a.batch = take(&mut i, &arg)?.parse()?,
            "--epochs" => a.epochs = take(&mut i, &arg)?.parse()?,
            "--lr" => a.lr = take(&mut i, &arg)?.parse()?,
            "--weight-decay" => a.weight_decay = take(&mut i, &arg)?.parse()?,
            "--img-h" => a.img_h = take(&mut i, &arg)?.parse()?,
            "--img-w" => a.img_w = take(&mut i, &arg)?.parse()?,
            "--max-len" => a.max_len = take(&mut i, &arg)?.parse()?,
            "--hidden" => a.hidden = take(&mut i, &arg)?.parse()?,
            "--feat-dim" => {
                a.feat_dim = take(&mut i, &arg)?.parse()?;
                // Plumbing ширины разведён полностью (SEResNetQ::widths, геометрия
                // чекпоинта, ExpertSpec, адаптеры MoPE, экспорт ONNX), но CPU-бэкенд
                // на узком энкодере падает: fd=256 держит ровно один батч (SIGSEGV на
                // втором), fd=128 — ни одного.  Явный отказ лучше, чем segfault без
                // стека; разбор и команды воспроизведения — BUGFIX_REPORT §20.11.
                anyhow::ensure!(
                    a.feat_dim >= 8 && a.feat_dim % 8 == 0,
                    "--feat-dim {n} должен быть кратен 8 и не меньше 8 (512 = историческая \
                     SEResNetQ: 42.15M conv-весов; 256 = 10.54M; 128 = 2.63M). \
                     Каналы слоёв: [fd/8, fd/4, fd/2, fd/2, fd, fd].",
                    n = a.feat_dim
                );
            }
            "--build-charset" => a.build_charset = take(&mut i, &arg)?,
            "--rnn-layers" => a.rnn_layers = take(&mut i, &arg)?.parse()?,
            "--surgery-eps" => a.surgery_eps = take(&mut i, &arg)?.parse()?,
            "--grow-ladder" => a.grow_ladder = take(&mut i, &arg)?,
            "--inspect-ckpt" => a.inspect_ckpt = take(&mut i, &arg)?,
            "--charset" => a.charset = Some(take(&mut i, &arg)?),
            "--resume" | "-r" => match argv.get(i + 1) {
                Some(v) if !v.starts_with('-') => {
                    i += 1;
                    a.resume = Some(v.clone());
                }
                _ => a.resume = Some(String::new()),
            },
            "--no-resume" => a.no_resume = true,
            "--ckpt-every" => a.ckpt_every = take(&mut i, &arg)?.parse()?,
            "--ckpt-every-batch" => a.ckpt_every_batch = take(&mut i, &arg)?.parse()?,
            "--clip-warmup" => a.clip_warmup = take(&mut i, &arg)?.parse()?,
            "--seed" => a.seed = take(&mut i, &arg)?.parse()?,
            "--smoke" => a.smoke = take(&mut i, &arg)?.parse()?,
            "--eval-every" => a.eval_every = take(&mut i, &arg)?.parse()?,
            "--autotune" => a.autotune = true,
            "--infer" => a.infer = true,
            "--export-onnx" => a.export_onnx = take(&mut i, &arg)?,
            "--onnx-layout" => a.onnx_layout = take(&mut i, &arg)?,
            "--onnx-int8" => a.onnx_int8 = true,
            "--onnx-ref" => a.onnx_ref = take(&mut i, &arg)?,
            "--onnx-debug" => a.onnx_debug = true,
            "--onnx-calib" => a.onnx_calib = take(&mut i, &arg)?.parse()?,
            "--onnx-no-decoder" => a.onnx_no_decoder = true,
            "--mope" => a.mope = true,
            "--mope-experts" => a.mope_experts = take(&mut i, &arg)?,
            "--mope-n" => {
                a.mope_n = take(&mut i, &arg)?.parse()?;
                a.rsa_user_set = true;
            }
            "--mope-c" => {
                a.mope_c = take(&mut i, &arg)?.parse()?;
                a.rsa_user_set = true;
            }
            "--mope-t" => {
                a.mope_t = take(&mut i, &arg)?.parse()?;
                a.rsa_user_set = true;
            }
            "--mope-tau" => {
                a.mope_tau = take(&mut i, &arg)?.parse()?;
                a.rsa_user_set = true;
            }
            "--mope-topk" => a.mope_top_k = take(&mut i, &arg)?.parse()?,
            "--mope-cache" => a.mope_cache = take(&mut i, &arg)?.parse()?,
            "--mope-temperature" => {
                a.mope_temperature = take(&mut i, &arg)?.parse()?;
                a.rsa_user_set = true;
            }
            "--mope-top-p" => a.mope_top_p = take(&mut i, &arg)?.parse()?,
            "--mope-limit" => {
                a.mope_limit = take(&mut i, &arg)?.parse()?;
                a.mope_limit_set = true;
            }
            "--mope-lr" => a.mope_lr = take(&mut i, &arg)?.parse()?,
            "--mope-balance-lr" => a.mope_balance_lr = take(&mut i, &arg)?.parse()?,
            "--mope-router" => a.mope_router = take(&mut i, &arg)?,
            "--mope-save-router" => a.mope_save_router = take(&mut i, &arg)?,
            "--mope-agg" => a.mope_agg = take(&mut i, &arg)?,
            "--mope-min-freq" => a.mope_min_freq = take(&mut i, &arg)?.parse()?,
            "--mope-charset-max" => a.mope_charset_max = take(&mut i, &arg)?.parse()?,
            "--mope-charset-out" => a.mope_charset_out = take(&mut i, &arg)?,
            "--mope-char-counts" => a.mope_char_counts = take(&mut i, &arg)?,
            "--ssl-lexicon" => a.ssl_lexicon = take(&mut i, &arg)?,
            "--ssl-ngram" => a.ssl_ngram = take(&mut i, &arg)?.parse().unwrap_or(4),
            "--ssl-rare" => a.ssl_rare = take(&mut i, &arg)?.parse().unwrap_or(1e-4),
            "--ssl-gap" => a.ssl_gap = take(&mut i, &arg)?.parse().unwrap_or(0.5),
            "--ssl-out" => a.ssl_out = take(&mut i, &arg)?,
            "--mope-export-bundle" => a.mope_export_bundle = take(&mut i, &arg)?,
            "--mope-int8" => a.mope_int8 = true,
            "--mope-train" => a.mope_train = true,
            "--mope-target" => a.mope_target = take(&mut i, &arg)?.to_lowercase(),
            "--mope-agg-lr" => a.mope_agg_lr = take(&mut i, &arg)?.parse()?,
            "--mope-save-franken" => a.mope_save_franken = take(&mut i, &arg)?,
            "--mope-franken" => a.mope_franken = take(&mut i, &arg)?,
            "--mope-adapt" => a.mope_adapt = true,
            "--autotune-trials" => a.autotune_trials = take(&mut i, &arg)?.parse()?,
            "--autotune-batches" => a.autotune_batches = take(&mut i, &arg)?.parse()?,
            "--autotune-timeout" => a.autotune_timeout = take(&mut i, &arg)?.parse()?,
            "--autotune-vram" => a.autotune_vram = take(&mut i, &arg)?.parse()?,
            "--autotune-objective" => a.autotune_objective = take(&mut i, &arg)?,
            "--autotune-out" => a.autotune_out = take(&mut i, &arg)?,
            "--autotune-widths" => a.autotune_widths = take(&mut i, &arg)?,
            "--autotune-batch-sizes" => a.autotune_batch_sizes = take(&mut i, &arg)?,
            other => {
                if other.starts_with('-') {
                    // неизвестную опцию с префиксом --autotune называем явно:
                    // опечатка в подборе иначе выглядит как «не указан train.csv»
                    if other.starts_with("--autotune") {
                        return Err(anyhow!("неизвестная опция подбора: {other}"));
                    }
                    return Err(anyhow!("неизвестная опция: {other}"));
                }
                positional.push(other.to_string());
            }
        }
        i += 1;
    }
    // Позиционные аргументы запоминаем всегда, даже при --smoke: charset.txt
    // ищется рядом с train.csv, и без этого дочерние пробы --autotune (они идут
    // со --smoke) мгновенно умирают на «не найден charset.txt», хотя родитель
    // тот же путь видел. Требовательным к датасету остаётся только полный прогон.
    a.train_csv = positional.first().cloned().unwrap_or_default();
    a.val_csv = positional.get(1).cloned();
    if let Some(d) = positional.get(2) {
        a.exp_dir = d.clone();
    }
    if a.smoke == 0 && !a.autotune && a.train_csv.is_empty() && a.build_charset.is_empty() {
        return Err(anyhow!("не указан train.csv"));
    }
    if a.autotune && a.autotune_out.is_empty() {
        a.autotune_out = format!("{}/autotune.json", a.exp_dir);
    }
    Ok(a)
}

// ------------------------------------------------------------------ data --

struct Sample {
    path: String,
    tokens: Vec<usize>,
}

fn load_charset(path: &str) -> Result<Vec<String>> {
    let f = std::fs::File::open(path).map_err(|e| anyhow!("charset {path}: {e}"))?;
    let mut itos = Vec::new();
    for line in BufReader::new(f).lines() {
        let t = line?;
        if !t.is_empty() {
            itos.push(t);
        }
    }
    if itos.len() < 4 {
        return Err(anyhow!("charset слишком короткий"));
    }
    Ok(itos)
}

/// `path,text` with optional quoting ("" escape).
fn parse_csv_line(line: &str) -> Option<(String, String)> {
    let (p, rest) = if line.starts_with('"') {
        let end = line[1..].find('"').map(|i| i + 1)?;
        let mut p = line[1..end].replace("\"\"", "\"");
        let mut rest = &line[end + 1..];
        if rest.starts_with(',') {
            rest = &rest[1..];
        }
        p.shrink_to_fit();
        (p, rest)
    } else {
        let mut it = line.splitn(2, ',');
        (it.next()?.to_string(), it.next().unwrap_or(""))
    };
    let text = rest.trim().trim_matches('"').to_string();
    if p.is_empty() || text.is_empty() {
        return None;
    }
    Some((p, text))
}

fn load_csv(path: &str, stoi: &std::collections::HashMap<String, usize>, max_len: usize) -> (Vec<Sample>, usize) {
    let base = Path::new(path).parent().map(|p| p.to_path_buf()).unwrap_or_default();
    let f = match std::fs::File::open(path) {
        Ok(f) => f,
        Err(_) => return (Vec::new(), 0),
    };
    let mut out = Vec::new();
    let mut skipped = 0;
    for line in BufReader::new(f).lines().flatten() {
        let line = line.trim().to_string();
        if line.is_empty() {
            continue;
        }
        let (rel, text) = match parse_csv_line(&line) {
            Some(v) => v,
            None => {
                skipped += 1;
                continue;
            }
        };
        // like pack_attention_targets: unknown chars dropped, sequence
        // truncated to max_len (NOT skipped)
        let ids: Vec<usize> = text
            .chars()
            .filter_map(|c| stoi.get(&c.to_string()).copied())
            .take(max_len)
            .collect();
        if ids.is_empty() {
            skipped += 1;
            continue;
        }
        let p = Path::new(&rel);
        let full = if p.is_absolute() { rel.clone() } else { base.join(rel).to_string_lossy().into_owned() };
        out.push(Sample { path: full, tokens: ids });
    }
    (out, skipped)
}

/// Reference preprocessing: RGB -> aspect-preserving resize -> white canvas
/// (align left / centre vertically) -> (p/255*2-1) -> int8 with scale 1/127.
fn load_image_q(path: &str, img_h: usize, img_w: usize) -> Option<Vec<i8>> {
    let img = image::open(path).ok()?.to_rgb8();
    let (w0, h0) = img.dimensions();
    let scale = (img_h as f32 / h0.max(1) as f32).min(img_w as f32 / w0.max(1) as f32);
    let nw = (w0 as f32 * scale).round().max(1.0) as u32;
    let nh = (h0 as f32 * scale).round().max(1.0) as u32;
    let resized = image::imageops::resize(&img, nw, nh, image::imageops::FilterType::Triangle);
    let mut buf = vec![255u8; img_h * img_w * 3];
    let y0 = (img_h.saturating_sub(nh as usize)) / 2;
    for y in 0..nh as usize {
        for x in 0..nw as usize {
            let px = resized.get_pixel(x as u32, y as u32);
            let o = ((y + y0) * img_w + x) * 3;
            buf[o] = px[0];
            buf[o + 1] = px[1];
            buf[o + 2] = px[2];
        }
    }
    Some(buf.iter().map(|&p| (((p as f32 / 255.0) * 2.0 - 1.0) * 127.0).round().clamp(-127.0, 127.0) as i8).collect())
}

// ---------------------------------------------------------------- metrics --

fn edit_distance(a: &[char], b: &[char]) -> usize {
    let (n, m) = (a.len(), b.len());
    let mut d = vec![vec![0usize; m + 1]; n + 1];
    for i in 0..=n {
        d[i][0] = i;
    }
    for j in 0..=m {
        d[0][j] = j;
    }
    for i in 1..=n {
        for j in 1..=m {
            let c = if a[i - 1] == b[j - 1] { 0 } else { 1 };
            d[i][j] = (d[i - 1][j] + 1).min(d[i][j - 1] + 1).min(d[i - 1][j - 1] + c);
        }
    }
    d[n][m]
}

// ----------------------------------------------------------------- model --

struct Model {
    cnn: SEResNetQ,
    rnn: BiLstmStack,
    attn: AttentionDecoder,
    ctc: LinearF,
}

impl Model {
    fn new(in_dim: usize, hidden: usize, classes: usize, sos: usize, eos: usize, pad: usize) -> Self {
        Self::new_layers(in_dim, hidden, classes, sos, eos, pad, 2)
    }

    /// То же, но с явным числом слоёв BiLSTM. Нужно для MoPE: у предобученных
    /// пресетов Кожина `num_encoder_layers = 1` (trba_base_g1), а локальные
    /// чекпоинты trba-rust обучены с двумя. Манифест параметров строится по
    /// фактическому числу слоёв, поэтому чужой эксперт загружается целиком.
    fn new_layers(in_dim: usize, hidden: usize, classes: usize, sos: usize, eos: usize, pad: usize, rnn_layers: usize) -> Self {
        Self {
            cnn: SEResNetQ::new(in_dim),
            rnn: BiLstmStack::new(in_dim, hidden, rnn_layers.max(1)),
            attn: AttentionDecoder::new(hidden, hidden, classes, sos, eos, pad),
            ctc: LinearF::new(hidden, classes, true),
        }
    }

    fn zero_grad(&mut self) {
        self.cnn.zero_grad();
        self.rnn.zero_grad();
        self.attn.zero_grad();
        self.ctc.zero_grad();
    }

    /// Every trainable tensor, in a fixed order — this is the checkpoint
    /// manifest, so its length and order must not change casually.
    fn params(&mut self) -> Vec<ParamRef> {
        self.params_filtered(true)
    }

    /// What the *host* optimiser touches.  When the conv weights live on the
    /// device (`qnet::conv_weights_on_device()`), their gradients never reach
    /// the host, so they are excluded from the host clip and the host Adam step
    /// — the device does both through `SEResNetQ::device_adam_step`.  They stay
    /// in `params()` so the checkpoint format is unchanged (the host shadow is
    /// synced from the device before saving).
    fn host_params(&mut self) -> Vec<ParamRef> {
        self.params_filtered(!conv_weights_on_device())
    }

    fn params_filtered(&mut self, include_conv_w: bool) -> Vec<ParamRef> {
        let mut v: Vec<ParamRef> = Vec::new();
        macro_rules! push {
            ($name:expr, $p:expr, $g:expr) => {
                let (p, g) = ($p, $g);
                let len = p.len();
                v.push(ParamRef { name: $name, p: p.as_mut_ptr(), g: g.as_ptr() as *mut f32, len,
                                  shape: None });
            };
        }
        // То же, но с формой матрицы [rows, cols]: такой параметр уходит на Muon
        // (src/opt.rs). rows/cols вычисляются ДО взятия &mut, иначе неизменяемый
        // borrow (`c.col_cols()`, `a.w_ih.len()`) конфликтует с изменяемым.
        macro_rules! push2d {
            ($name:expr, $p:expr, $g:expr, $rows:expr, $cols:expr) => {
                let (rows, cols) = ($rows, $cols);
                let (p, g) = ($p, $g);
                let len = p.len();
                debug_assert_eq!(rows * cols, len, "форма матрицы не равна её длине");
                v.push(ParamRef { name: $name, p: p.as_mut_ptr(), g: g.as_ptr() as *mut f32, len,
                                  shape: if rows > 0 && cols > 0 { Some((rows, cols)) } else { None } });
            };
        }
        for c in self.cnn.convs_mut() {
            let n = c.name.clone();
            if include_conv_w {
                push2d!(format!("{n}.w"), &mut c.w, &mut c.g_w, c.out_c, c.col_cols());
            }
            push!(format!("{n}.gamma"), &mut c.bn.gamma, &mut c.bn.g_gamma);
            push!(format!("{n}.beta"), &mut c.bn.beta, &mut c.bn.g_beta);
        }
        for (li, layer) in [&mut self.cnn.layer1, &mut self.cnn.layer2, &mut self.cnn.layer3, &mut self.cnn.layer4]
            .iter_mut()
            .enumerate()
        {
            for (bi, b) in layer.iter_mut().enumerate() {
                push2d!(format!("l{li}b{bi}.se.fc1.w"), &mut b.se.fc1.w, &mut b.se.fc1.g_w,
                        b.se.fc1.out, b.se.fc1.inp);
                push2d!(format!("l{li}b{bi}.se.fc2.w"), &mut b.se.fc2.w, &mut b.se.fc2.g_w,
                        b.se.fc2.out, b.se.fc2.inp);
            }
        }
        for (li, l) in self.rnn.layers.iter_mut().enumerate() {
            push2d!(format!("rnn{li}.f.w_ih"), &mut l.fwd.w_ih, &mut l.fwd.g_w_ih,
                    4 * l.fwd.h, l.fwd.d);
            push!(format!("rnn{li}.f.b_ih"), &mut l.fwd.b_ih, &mut l.fwd.g_b_ih);
            push2d!(format!("rnn{li}.f.w_hh"), &mut l.fwd.w_hh, &mut l.fwd.g_w_hh,
                    4 * l.fwd.h, l.fwd.h);
            push!(format!("rnn{li}.f.b_hh"), &mut l.fwd.b_hh, &mut l.fwd.g_b_hh);
            push2d!(format!("rnn{li}.b.w_ih"), &mut l.bwd.w_ih, &mut l.bwd.g_w_ih,
                    4 * l.bwd.h, l.bwd.d);
            push!(format!("rnn{li}.b.b_ih"), &mut l.bwd.b_ih, &mut l.bwd.g_b_ih);
            push2d!(format!("rnn{li}.b.w_hh"), &mut l.bwd.w_hh, &mut l.bwd.g_w_hh,
                    4 * l.bwd.h, l.bwd.h);
            push!(format!("rnn{li}.b.b_hh"), &mut l.bwd.b_hh, &mut l.bwd.g_b_hh);
            push2d!(format!("rnn{li}.proj.w"), &mut l.proj_w, &mut l.g_proj_w, l.out, 2 * l.h);
            push!(format!("rnn{li}.proj.b"), &mut l.proj_b, &mut l.g_proj_b);
        }
        let a = &mut self.attn;
        push2d!("attn.i2h.w".into(), &mut a.i2h.w, &mut a.i2h.g_w, a.i2h.out, a.i2h.inp);
        push2d!("attn.h2h.w".into(), &mut a.h2h.w, &mut a.h2h.g_w, a.h2h.out, a.h2h.inp);
        push!("attn.h2h.b".into(), &mut a.h2h.b, &mut a.h2h.g_b);
        push2d!("attn.score.w".into(), &mut a.score.w, &mut a.score.g_w, a.score.out, a.score.inp);
        push2d!("attn.w_ih".into(), &mut a.w_ih, &mut a.g_w_ih,
                4 * a.hidden, a.w_ih.len() / (4 * a.hidden));
        push!("attn.b_ih".into(), &mut a.b_ih, &mut a.g_b_ih);
        push2d!("attn.w_hh".into(), &mut a.w_hh, &mut a.g_w_hh, 4 * a.hidden, a.hidden);
        push!("attn.b_hh".into(), &mut a.b_hh, &mut a.g_b_hh);
        push2d!("attn.gen.w".into(), &mut a.generator.w, &mut a.generator.g_w,
                a.generator.out, a.generator.inp);
        push!("attn.gen.b".into(), &mut a.generator.b, &mut a.generator.g_b);
        push2d!("ctc.w".into(), &mut self.ctc.w, &mut self.ctc.g_w, self.ctc.out, self.ctc.inp);
        push!("ctc.b".into(), &mut self.ctc.b, &mut self.ctc.g_b);
        v
    }
}

// ------------------------------------------------------------ checkpoint --

/// Имя лучшего чекпоинта хранит метрики, а `best.bin` — жёсткая ссылка на него:
/// оба имени указывают на один inode, поэтому место на диске не удваивается.
/// Предыдущий лучший файл удаляется, иначе каждое улучшение стоило бы 0.5 ГБ.
fn save_best_checkpoint(args: &Args, model: &mut Model, opt: &Adam, stream: &CudaStream,
                        epoch: usize, cer: f64, loss: f64) -> Result<()> {
    let name = format!("checkpoint_best_cer{cer:.3}_loss{loss:.4}_epoch{epoch:03}.bin");
    let path = format!("{}/{}", args.exp_dir, name);
    save_checkpoint(&path, model, CkptMeta { epoch_done: epoch, batch_in_epoch: 0 }, opt, stream, args)?;

    if let Ok(rd) = std::fs::read_dir(&args.exp_dir) {
        for e in rd.flatten() {
            let p = e.path();
            let n = p.file_name().and_then(|s| s.to_str()).unwrap_or("").to_string();
            if n.starts_with("checkpoint_best_") && p.to_string_lossy() != path {
                let _ = std::fs::remove_file(&p);
            }
        }
    }
    let link = format!("{}/best.bin", args.exp_dir);
    let _ = std::fs::remove_file(&link);
    match std::fs::hard_link(&path, &link) {
        Ok(()) => println!("   🏆 best.bin → {name} (CER {cer:.2}%)"),
        Err(e) => {
            // ФС без жёстких ссылок (FAT/exFAT/сетевые шары) — обычная копия
            std::fs::copy(&path, &link)
                .map_err(|e2| anyhow!("не удалось создать best.bin: {e2} (hard_link: {e})"))?;
            println!("   🏆 best.bin → копия {name} (CER {cer:.2}%, hard_link недоступен)");
        }
    }
    Ok(())
}

/// CER уже сохранённого лучшего чекпоинта — чтобы после возобновления best.bin
/// обновлялся только при реальном улучшении, а не на первой же валидации.
fn existing_best_cer(exp_dir: &str) -> Option<f64> {
    let rd = std::fs::read_dir(exp_dir).ok()?;
    let mut best: Option<f64> = None;
    for e in rd.flatten() {
        let n = e.file_name().to_string_lossy().to_string();
        if !n.starts_with("checkpoint_best_cer") {
            continue;
        }
        let tail = &n["checkpoint_best_cer".len()..];
        let num: String = tail.chars().take_while(|c| c.is_ascii_digit() || *c == '.').collect();
        if let Ok(v) = num.parse::<f64>() {
            best = Some(best.map_or(v, |b: f64| b.min(v)));
        }
    }
    best
}

/// Геометрия модели: `hidden`/`classes`/`rnn_layers`/`feat_dim` берутся из
/// фактических форм весов (а не из аргументов — так честнее), а разрешение и
/// `max_len` из весов не восстанавливаются, поэтому приходят из `args`.
fn model_geometry(model: &mut Model, args: &Args) -> Geometry {
    let lens: Vec<(String, usize)> = model.params().iter().map(|p| (p.name.clone(), p.len)).collect();
    let mut g = surgery::geometry_from_lens(&lens).unwrap_or_else(|| {
        Geometry::new(args.img_h, args.img_w, args.max_len, args.hidden, 0, args.rnn_layers)
            .with_feat_dim(args.feat_dim)
    });
    g.img_h = args.img_h;
    g.img_w = args.img_w;
    g.max_len = args.max_len;
    g
}

fn save_checkpoint(path: &str, model: &mut Model, meta: CkptMeta, opt: &Adam,
                   stream: &CudaStream, args: &Args) -> Result<()> {
    use std::io::{BufWriter, Write};

    // In device mode the host `w` vectors are only shadows: pull the master
    // weights back once (160.8 MB per save, instead of per batch).
    model.cnn.sync_conv_shadows(stream);

    if let Some(dir) = Path::new(path).parent() {
        if !dir.as_os_str().is_empty() {
            std::fs::create_dir_all(dir)?;
        }
    }
    let tmp = format!("{path}.tmp");
    let f = std::fs::File::create(&tmp)?;
    let mut w = BufWriter::with_capacity(1 << 20, f);

    // Пишем потоково, а не одним Vec: чекпоинт с Adam-моментами — это ~500 MB
    // (42M параметров свёрток по 12 байт + rnn/attn/ctc + BN), и держать их
    // целиком в памяти на каждом сохранении значит удваивать пик хоста.
    macro_rules! put_u64 {
        ($v:expr) => {
            w.write_all(&($v as u64).to_le_bytes())?
        };
    }
    macro_rules! put_f32s {
        ($s:expr) => {{
            let s: &[f32] = $s;
            put_u64!(s.len());
            // f32 -> little-endian байты: на x86/ARM порядок совпадает, поэтому
            // срез уходит одним write_all (42M поэлементных записей — лишняя
            // секунда на каждое сохранение)
            if cfg!(target_endian = "little") {
                let bytes = unsafe {
                    std::slice::from_raw_parts(s.as_ptr() as *const u8, s.len() * 4)
                };
                w.write_all(bytes)?;
            } else {
                for x in s {
                    w.write_all(&x.to_le_bytes())?;
                }
            }
        }};
    }

    let geom = model_geometry(model, args);
    w.write_all(CKPT_MAGIC_V6)?;
    put_u64!(meta.epoch_done);
    put_u64!(meta.batch_in_epoch);
    put_u64!(opt.t);
    // геометрия: из-за неё же resume умеет расти, а не только продолжать
    put_u64!(geom.img_h);
    put_u64!(geom.img_w);
    put_u64!(geom.max_len);
    put_u64!(geom.hidden);
    put_u64!(geom.classes);
    put_u64!(geom.rnn_layers);
    put_u64!(geom.feat_dim);

    let params = model.params();
    put_u64!(params.len());
    for pr in &params {
        // имя тензора: без него перенос в другую геометрию невозможен
        let nb = pr.name.as_bytes();
        put_u64!(nb.len());
        w.write_all(nb)?;
        let slice = unsafe { std::slice::from_raw_parts(pr.p as *const f32, pr.len) };
        put_f32s!(slice);
        // Adam-моменты параметра.  Пустой срез = шаг по параметру ещё не
        // выполнялся, при загрузке это не «нули», а «не трогать».
        let (m, v) = opt.moment(&pr.name);
        put_f32s!(m.map(|x| x.as_slice()).unwrap_or(&[]));
        put_f32s!(v.map(|x| x.as_slice()).unwrap_or(&[]));
    }

    // BN-статистика и Adam-моменты свёрток, по одному слою за раз в
    // переиспользуемый буфер: в device-режиме моменты живут только на GPU, а
    // все слои вместе — это 338 MB.
    let mut buf: Vec<f32> = Vec::new();
    for c in model.cnn.convs_mut() {
        put_f32s!(&c.bn.run_mean);
        put_f32s!(&c.bn.run_var);
        c.download_moment(stream, true, &mut buf);
        put_f32s!(&buf);
        c.download_moment(stream, false, &mut buf);
        put_f32s!(&buf);
    }

    w.flush()?;
    drop(w);
    // rename атомарен в пределах одной ФС: читатель видит либо старый файл
    // целиком, либо новый — никогда половину
    std::fs::rename(&tmp, path)?;
    Ok(())
}

/// Загрузка чекпоинта в модель текущей геометрии (V6/V5/V4).
///
/// Геометрия назначения выводится из форм весов самой модели, поэтому функция
/// не зависит от аргументов командной строки. Если формы всё же не сошлись
/// (запуск с другим `--hidden`, `--rnn-layers` или другим словарём), веса
/// переносятся хирургией из `src/surgery.rs`, и это печатается явно: молча
/// обучать половину модели заново — худшее, что может сделать resume.
fn load_checkpoint(path: &str, model: &mut Model, opt: &mut Adam,
                   stream: &CudaStream) -> Result<(CkptMeta, bool)> {
    let lens: Vec<(String, usize)> = model.params().iter().map(|p| (p.name.clone(), p.len)).collect();
    let dst = surgery::geometry_from_lens(&lens).unwrap_or_else(|| Geometry::new(0, 0, 0, 0, 0, 0));
    let (meta, src, rep) = load_checkpoint_surgery(path, model, &dst, opt, stream, &SurgeryCfg::default(), true)?;
    if !rep.is_empty() {
        println!("🧬 чекпоинт {path} перенесён в текущую геометрию:");
        for x in geometry_diff_lines(&src, &dst) {
            println!("   ⇄ {x}");
        }
        println!("   {}", rep.report());
    }
    Ok((meta, rep.moments > 0))
}

// ------------------------------------------- resume в другую геометрию ------

/// Сводка по чекпоинту без чтения весов: версия, мета, геометрия источника и
/// длины всех тензоров. Для V4/V5 геометрии в файле нет — она выводится из форм
/// (`surgery::geometry_from_lens`), для чего файл просматривается одним проходом
/// с пропуском данных через `seek`, поэтому просмотр 500-МБ чекпоинта мгновенный.
pub struct CkptInfo {
    pub version: &'static str,
    pub meta: CkptMeta,
    pub opt_t: usize,
    pub geom: Geometry,
    pub lens: Vec<(String, usize)>,
    pub has_moments: bool,
    pub named: bool,
    /// позиция сразу после заголовка — оттуда начинают чтение весов
    pub data_start: u64,
}

fn ck_get_u64<R: std::io::Read>(r: &mut R) -> Result<u64> {
    let mut b = [0u8; 8];
    r.read_exact(&mut b)?;
    Ok(u64::from_le_bytes(b))
}

fn ck_read_body<R: std::io::Read>(r: &mut R, d: &mut [f32]) -> Result<()> {
    if cfg!(target_endian = "little") {
        let bytes = unsafe { std::slice::from_raw_parts_mut(d.as_mut_ptr() as *mut u8, d.len() * 4) };
        r.read_exact(bytes)?;
    } else {
        let mut b = [0u8; 4];
        for x in d.iter_mut() {
            r.read_exact(&mut b)?;
            *x = f32::from_le_bytes(b);
        }
    }
    Ok(())
}

fn ck_skip<R: std::io::Seek>(r: &mut R, n: usize) -> Result<()> {
    r.seek(std::io::SeekFrom::Current((n * 4) as i64))?;
    Ok(())
}

fn ck_read_name<R: std::io::Read>(r: &mut R) -> Result<String> {
    let nl = ck_get_u64(r)? as usize;
    if nl > 1024 {
        return Err(anyhow!("имя тензора из {nl} байт — файл повреждён или это не V6"));
    }
    let mut b = vec![0u8; nl];
    r.read_exact(&mut b)?;
    Ok(String::from_utf8_lossy(&b).into_owned())
}

fn read_ckpt_header(path: &str, dst_names: &[String]) -> Result<CkptInfo> {
    use std::io::{BufReader, Read, Seek};
    let f = std::fs::File::open(path).map_err(|e| anyhow!("{path}: {e}"))?;
    let mut r = BufReader::with_capacity(1 << 20, f);
    let mut magic = [0u8; 8];
    r.read_exact(&mut magic)?;
    let (version, v6, v5) = if &magic == CKPT_MAGIC_V6 {
        ("V6", true, true)
    } else if &magic == CKPT_MAGIC {
        ("V5", false, true)
    } else if &magic == CKPT_MAGIC_V4 {
        ("V4", false, false)
    } else {
        return Err(anyhow!(
            "bad checkpoint magic {:?} (ожидался {:?}, {:?} или {:?})",
            String::from_utf8_lossy(&magic),
            String::from_utf8_lossy(CKPT_MAGIC_V6),
            String::from_utf8_lossy(CKPT_MAGIC),
            String::from_utf8_lossy(CKPT_MAGIC_V4)
        ));
    };

    let epoch_done = ck_get_u64(&mut r)? as usize;
    let batch_in_epoch = if v5 { ck_get_u64(&mut r)? as usize } else { 0 };
    let opt_t = ck_get_u64(&mut r)? as usize;
    let mut geom = Geometry::new(0, 0, 0, 0, 0, 0);
    if v6 {
        geom.img_h = ck_get_u64(&mut r)? as usize;
        geom.img_w = ck_get_u64(&mut r)? as usize;
        geom.max_len = ck_get_u64(&mut r)? as usize;
        geom.hidden = ck_get_u64(&mut r)? as usize;
        geom.classes = ck_get_u64(&mut r)? as usize;
        geom.rnn_layers = ck_get_u64(&mut r)? as usize;
        geom.feat_dim = ck_get_u64(&mut r)? as usize;
    }
    let n = ck_get_u64(&mut r)? as usize;
    let data_start = r.stream_position()?;

    let mut lens: Vec<(String, usize)> = Vec::with_capacity(n);
    for i in 0..n {
        let name = if v6 {
            ck_read_name(&mut r)?
        } else {
            // в V4/V5 имён нет: порядок тензоров от геометрии не зависит,
            // поэтому сопоставляем по индексу с манифестом текущей модели
            dst_names.get(i).cloned().unwrap_or_else(|| format!("#{i}"))
        };
        let len = ck_get_u64(&mut r)? as usize;
        lens.push((name, len));
        ck_skip(&mut r, len)?;
        if v5 {
            let lm = ck_get_u64(&mut r)? as usize;
            ck_skip(&mut r, lm)?;
            let lv = ck_get_u64(&mut r)? as usize;
            ck_skip(&mut r, lv)?;
        }
    }
    if !v6 {
        geom = surgery::geometry_from_lens(&lens).ok_or_else(|| {
            anyhow!(
                "в чекпоинте {version} геометрия не записана, а вывести её из форм не удалось \
                 (нужны ctc.b, attn.h2h.b, rnn0.f.w_ih, rnn*.proj.b; в файле {n} тензоров, \
                 у текущей модели {} — другое число слоёв BiLSTM?)",
                dst_names.len()
            )
        })?;
    }
    Ok(CkptInfo { version, meta: CkptMeta { epoch_done, batch_in_epoch }, opt_t, geom, lens, has_moments: v5, named: v6, data_start })
}

/// Загрузка чекпоинта в модель ДРУГОЙ геометрии: то, что совпало по форме,
/// копируется как есть (свёртки, BN, SE — они от размера картинки не зависят),
/// а `rnn*`/`attn*`/`ctc.w` растут или усекаются по правилам `surgery`.
///
/// Возвращает геометрию источника и отчёт (если хоть один тензор менял форму).
fn load_checkpoint_surgery(
    path: &str,
    model: &mut Model,
    dst: &Geometry,
    opt: &mut Adam,
    stream: &CudaStream,
    cfg: &SurgeryCfg,
    allow_surgery: bool,
) -> Result<(CkptMeta, Geometry, surgery::Report)> {
    use std::io::{BufReader, Seek};
    let params = model.params();
    let names: Vec<String> = params.iter().map(|p| p.name.clone()).collect();
    let info = read_ckpt_header(path, &names)?;
    let src = info.geom;
    // Adam-моменты переносим ТОЛЬКО в том же режиме. Если геометрия другая,
    // opt.t всё равно сбрасывается в 0, а поправка на смещение
    // m_hat = m/(1-b1^t) при t=1 даёт множитель ~10: оставленные моменты
    // превратили бы первый шаг на новой ступени в прыжок примерно в 9 раз
    // больше обычного и смазали бы весь перенос. Кроме того, при другом T
    // накопленная статистика вторых моментов просто чужая.
    let same_regime = src.same_training_regime(dst);

    let f = std::fs::File::open(path)?;
    let mut r = BufReader::with_capacity(1 << 20, f);
    r.seek(std::io::SeekFrom::Start(info.data_start))?;

    let by_name: std::collections::HashMap<&str, usize> =
        params.iter().enumerate().map(|(i, p)| (p.name.as_str(), i)).collect();
    let mut rep = surgery::Report::default();
    let mut used = vec![false; params.len()];
    let mut tmp: Vec<f32> = Vec::new();
    let mut rng = rand::rngs::StdRng::seed_from_u64(cfg.seed);
    let mut moments = 0usize;
    let n = info.lens.len();

    for i in 0..n {
        let name = if info.named { ck_read_name(&mut r)? } else { names.get(i).cloned().unwrap_or_default() };
        let len = ck_get_u64(&mut r)? as usize;
        let idx = if info.named { by_name.get(name.as_str()).copied() } else if i < params.len() { Some(i) } else { None };
        let Some(di) = idx else {
            ck_skip(&mut r, len)?;
            if info.has_moments {
                let lm = ck_get_u64(&mut r)? as usize;
                ck_skip(&mut r, lm)?;
                let lv = ck_get_u64(&mut r)? as usize;
                ck_skip(&mut r, lv)?;
            }
            rep.skipped.push((name, format!("в модели назначения нет такого тензора ({len} чисел)")));
            continue;
        };
        let pr = &params[di];
        used[di] = true;

        if len == pr.len {
            let d = unsafe { std::slice::from_raw_parts_mut(pr.p, pr.len) };
            ck_read_body(&mut r, d)?;
            rep.copied += 1;
            if info.has_moments {
                let mut m: Vec<f32> = Vec::new();
                let mut v: Vec<f32> = Vec::new();
                let lm = ck_get_u64(&mut r)? as usize;
                m.resize(lm, 0.0);
                if lm > 0 { ck_read_body(&mut r, &mut m)?; }
                let lv = ck_get_u64(&mut r)? as usize;
                v.resize(lv, 0.0);
                if lv > 0 { ck_read_body(&mut r, &mut v)?; }
                if lm == pr.len && lv == pr.len && lm > 0 && same_regime {
                    opt.set_moment(&pr.name, m, v);
                    moments += 1;
                }
            }
        } else if allow_surgery {
            tmp.clear();
            tmp.resize(len, 0.0);
            ck_read_body(&mut r, &mut tmp)?;
            let d = unsafe { std::slice::from_raw_parts_mut(pr.p, pr.len) };
            match surgery::transfer(&name, &tmp, d, &src, dst, cfg, &mut rng) {
                surgery::Act::Copy => rep.copied += 1,
                surgery::Act::Grow => {
                    rep.grown += 1;
                    rep.changed.push(format!("{name}: {} → {}", len, pr.len));
                }
                surgery::Act::Shrink => {
                    rep.shrunk += 1;
                    rep.changed.push(format!("{name}: {} → {}", len, pr.len));
                }
                surgery::Act::Skip(why) => rep.skipped.push((name.clone(), why)),
            }
            // Adam-моменты тензора другой формы не переносим: статистика старых
            // ячеек не имеет смысла для новых, а обнуление даёт им чистый старт
            if info.has_moments {
                let lm = ck_get_u64(&mut r)? as usize;
                ck_skip(&mut r, lm)?;
                let lv = ck_get_u64(&mut r)? as usize;
                ck_skip(&mut r, lv)?;
            }
        } else {
            return Err(anyhow!(
                "тензор {name}: в чекпоинте {len} чисел, в модели {} — формы разные, \
                 а перенос запрещён",
                pr.len
            ));
        }
    }
    for (i, pr) in params.iter().enumerate() {
        if !used[i] {
            rep.skipped.push((pr.name.clone(), "нет в чекпоинте — остаётся инициализация".to_string()));
        }
    }

    // BN и моменты свёрток — позиционно: CNN от геометрии не зависит
    let mut buf: Vec<f32> = Vec::new();
    for c in model.cnn.convs_mut() {
        let lm = ck_get_u64(&mut r)? as usize;
        if lm != c.bn.run_mean.len() {
            return Err(anyhow!(
                "BN run_mean: в чекпоинте {lm}, в модели {} — число каналов CNN изменилось, \
                 такой перенос невозможен",
                c.bn.run_mean.len()
            ));
        }
        ck_read_body(&mut r, &mut c.bn.run_mean)?;
        let lv = ck_get_u64(&mut r)? as usize;
        c.bn.run_var.resize(lv, 0.0);
        ck_read_body(&mut r, &mut c.bn.run_var)?;
        if info.has_moments {
            let a = ck_get_u64(&mut r)? as usize;
            buf.clear();
            buf.resize(a, 0.0);
            if a > 0 { ck_read_body(&mut r, &mut buf)?; }
            if a > 0 && same_regime { c.upload_moment(stream, true, &buf); moments += 1; }
            let b = ck_get_u64(&mut r)? as usize;
            buf.clear();
            buf.resize(b, 0.0);
            if b > 0 { ck_read_body(&mut r, &mut buf)?; }
            if b > 0 && same_regime { c.upload_moment(stream, false, &buf); }
        }
    }

    model.cnn.upload_conv_weights(stream);
    model.cnn.requantize_all(stream);
    opt.t = info.opt_t;
    rep.moments = moments;
    rep.notes.push(format!(
        "формат {} | эпох завершено {} | шаг оптимизатора {} | Adam-моментов восстановлено {}",
        info.version, info.meta.epoch_done, info.opt_t, moments
    ));
    if !same_regime && info.has_moments {
        rep.notes.push(
            "Adam-моменты НЕ перенесены: режим обучения изменился, а opt.t сбрасывается — \
             оставленные моменты дали бы первый шаг в ~9 раз больше обычного \
             (поправка на смещение m/(1-b1^t) при t=1)"
                .to_string(),
        );
    }
    Ok((info.meta, src, rep))
}

/// Строки отчёта о различиях геометрий. В V4/V5 разрешение и `max_len` не
/// записывались, поэтому выводить «вход 0×0» было бы враньём: такие строки
/// заменяются честной пометкой (формы весов от разрешения всё равно не зависят).
fn geometry_diff_lines(src: &Geometry, dst: &Geometry) -> Vec<String> {
    let mut d = src.diff(dst);
    if src.img_h == 0 || src.img_w == 0 {
        d.retain(|x| !x.starts_with("вход ") && !x.starts_with("max_len "));
        d.insert(
            0,
            "разрешение и max_len в V4/V5 не записываются — из форм весов выведены только hidden, словарь, число слоёв BiLSTM и выход CNN".to_string(),
        );
    }
    d
}

/// `--inspect-ckpt`: что в файле и как он ляжет в текущую геометрию.
fn run_inspect_ckpt(args: &Args, classes: usize, sos: usize, eos: usize, pad: usize) -> Result<()> {
    let dst = Geometry::new(args.img_h, args.img_w, args.max_len, args.hidden, classes, args.rnn_layers)
        .with_feat_dim(args.feat_dim);
    let mut m = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, args.rnn_layers);
    let ps = m.params();
    let names: Vec<String> = ps.iter().map(|p| p.name.clone()).collect();
    let want: std::collections::HashMap<&str, usize> = ps.iter().map(|p| (p.name.as_str(), p.len)).collect();
    let info = read_ckpt_header(&args.inspect_ckpt, &names)?;
    let bytes = std::fs::metadata(&args.inspect_ckpt).map(|x| x.len()).unwrap_or(0);
    println!("🔎 {} ({} формат, {:.1} МБ)", args.inspect_ckpt, info.version, bytes as f64 / 1048576.0);
    println!("   завершено эпох: {} | батч внутри эпохи: {} | шаг оптимизатора: {} | Adam-моменты: {}",
        info.meta.epoch_done, info.meta.batch_in_epoch, info.opt_t,
        if info.has_moments { "есть" } else { "нет (V4 — первые шаги после resume будут резче)" });
    println!("   геометрия чекпоинта: {}", info.geom);
    println!("   геометрия запуска  : {dst}");
    let d = geometry_diff_lines(&info.geom, &dst);
    if d.is_empty() {
        println!("   ⇄ совпадает: перенос весов не нужен, resume продолжит как есть");
    } else {
        for x in &d {
            println!("   ⇄ {x}");
        }
    }
    let mut grow = 0usize;
    let mut same = 0usize;
    for (name, len) in &info.lens {
        match want.get(name.as_str()) {
            Some(&w) if w == *len => same += 1,
            Some(&w) => {
                grow += 1;
                let how = surgery::blocks_for(name, &info.geom, &dst)
                    .map(|_| if w > *len { "рост" } else { "усечение" })
                    .unwrap_or("перенос невозможен — слой обучится заново");
                println!("   🔧 {name}: {len} → {w} ({how})");
            }
            None => println!("   ⚠️  {name}: в модели назначения нет такого тензора"),
        }
    }
    println!(
        "   итог: {} тензоров копируются как есть, {} меняют форму, всего в файле {}",
        same, grow, info.lens.len()
    );
    if grow == 0 && d.iter().all(|x| x.contains("весов не касается") || x.contains("параметров не добавляет")) {
        println!("   ✅ рост бесплатный: разрешение и max_len на формы весов не влияют");
    }
    Ok(())
}

/// Аргументы, которые ступень лестницы задаёт сама: их надо убрать из argv
/// родителя, иначе дочерний процесс увидит их дважды.
fn filter_args(raw: &[String], drop: &[&str]) -> Vec<String> {
    let mut out = Vec::new();
    let mut i = 0;
    while i < raw.len() {
        let a = raw[i].as_str();
        if drop.contains(&a) {
            i += 2;
            continue;
        }
        if a == "--no-resume" || a == "--grow-ladder" {
            i += if a == "--grow-ladder" { 2 } else { 1 };
            continue;
        }
        out.push(raw[i].clone());
        i += 1;
    }
    out
}

/// `--grow-ladder "48x192:3,64x256h384:5"` — постепенный рост: каждая ступень
/// запускается отдельным процессом, продолжает чекпоинт предыдущей и обучается
/// свои эпохи. Отдельный процесс — это не расточительство, а гарантия, что
/// память прошлой (меньшей) геометрии точно освобождена, и что падение одной
/// ступени не теряет уже сохранённые.
fn run_grow_ladder(args: &Args, classes: usize) -> Result<()> {
    let base = Geometry::new(args.img_h, args.img_w, args.max_len, args.hidden, classes, args.rnn_layers)
        .with_feat_dim(args.feat_dim);
    let plan = surgery::parse_ladder(&args.grow_ladder, &base).map_err(|e| anyhow!("{e}"))?;
    println!("🪜 лестница роста от {base}:");
    for (i, st) in plan.iter().enumerate() {
        let prev = if i == 0 { base } else { plan[i - 1].geom };
        let d = geometry_diff_lines(&prev, &st.geom);
        println!("   ступень {}: {} — {} эпох(и)", i + 1, st.geom, st.epochs);
        for x in &d {
            println!("        ⇄ {x}");
        }
    }
    let exe = std::env::current_exe()?;
    let raw: Vec<String> = std::env::args().skip(1).collect();
    let base_args = filter_args(
        &raw,
        &["--img-h", "--img-w", "--hidden", "--max-len", "--epochs", "--resume", "-r", "--rnn-layers", "--feat-dim", "--surgery-eps"],
    );
    let mut prev = args.resume.clone().unwrap_or_default();
    for (i, st) in plan.iter().enumerate() {
        let mut cmd = std::process::Command::new(&exe);
        cmd.args(&base_args).args([
            "--img-h", &st.geom.img_h.to_string(),
            "--img-w", &st.geom.img_w.to_string(),
            "--max-len", &st.geom.max_len.to_string(),
            "--hidden", &st.geom.hidden.to_string(),
            "--rnn-layers", &st.geom.rnn_layers.to_string(),
            "--feat-dim", &st.geom.feat_dim.to_string(),
            "--epochs", &st.epochs.to_string(),
            "--surgery-eps", &args.surgery_eps.to_string(),
        ]);
        if !prev.is_empty() {
            cmd.args(["--resume", &prev]);
        }
        println!(
            "\n▶ ступень {}/{}: {} | эпох {} | resume: {}",
            i + 1, plan.len(), st.geom, st.epochs,
            if prev.is_empty() { "— (обучение с нуля)".to_string() } else { prev.clone() }
        );
        let status = cmd.status().map_err(|e| anyhow!("не удалось запустить ступень роста: {e}"))?;
        if !status.success() {
            return Err(anyhow!(
                "ступень {} ({}) завершилась неудачно (код {:?}) — следующую запускать нельзя, \
                 иначе рост продолжится из неполных весов",
                i + 1, st.geom, status.code()
            ));
        }
        prev = format!("{}/{}", args.exp_dir, CKPT_LAST);
        let staged = format!(
            "{}/checkpoint_stage{:02}_{}x{}h{}.bin",
            args.exp_dir, i + 1, st.geom.img_h, st.geom.img_w, st.geom.hidden
        );
        if std::fs::copy(&prev, &staged).is_ok() {
            println!("   💾 слепок ступени: {staged}");
        }
    }
    println!("\n✅ лестница роста пройдена: {}", plan.last().map(|s| s.geom.to_string()).unwrap_or_default());
    Ok(())
}

/// Самый свежий чекпоинт в каталоге: rolling `checkpoint_last.bin` либо номерной,
/// если он новее.  Сравниваем по mtime, а не по имени: файл «эпоха 3» может быть
/// старше rolling-файла из середины эпохи 4.
fn newest_checkpoint(dir: &str) -> String {
    let rd = match std::fs::read_dir(dir) {
        Ok(r) => r,
        Err(_) => return String::new(),
    };
    let mut best: Option<(std::time::SystemTime, String)> = None;
    for e in rd.flatten() {
        let name = e.file_name().to_string_lossy().into_owned();
        let wanted = name == CKPT_LAST
            || (name.starts_with("checkpoint_epoch") && name.ends_with(".bin"));
        if !wanted {
            continue;
        }
        let mtime = e
            .metadata()
            .and_then(|m| m.modified())
            .unwrap_or(std::time::SystemTime::UNIX_EPOCH);
        let path = e.path().to_string_lossy().into_owned();
        if best.as_ref().map(|(t, _)| mtime > *t).unwrap_or(true) {
            best = Some((mtime, path));
        }
    }
    best.map(|(_, p)| p).unwrap_or_default()
}

// ------------------------------------------------------------------ main --

fn ctc_weight_for_epoch(epoch: usize) -> f32 {
    // reference: 0.3 -> 0.03 linearly over 15 epochs
    let (init, decay, minw) = (0.3f32, 15.0f32, 0.03f32);
    let p = ((epoch as f32 - 1.0) / decay).clamp(0.0, 1.0);
    init * (1.0 - p) + minw * p
}

/// Собрать словарь из текстов одного или нескольких CSV (`--build-charset`) и
/// записать его в файл из `--charset`.  Формат ровно тот, который читает
/// `load_charset`: `<PAD>`, `<SOS>`, `<EOS>` и далее по одному символу на строку
/// в порядке кодовых точек.  Разбор строк — тот же `parse_csv_line`, что и при
/// обучении, поэтому пустые тексты и битые строки отбрасываются одинаково.
fn build_charset_from_csvs(spec: &str, out: &str) -> Result<()> {
    use std::io::Write;
    let mut chars: std::collections::BTreeSet<char> = std::collections::BTreeSet::new();
    let (mut rows, mut bad, mut header) = (0usize, 0usize, 0usize);
    for p in spec.split(',') {
        let p = p.trim();
        if p.is_empty() {
            continue;
        }
        let f = std::fs::File::open(p).map_err(|e| anyhow!("--build-charset: {p}: {e}"))?;
        let mut first = true;
        for line in BufReader::new(f).lines().flatten() {
            let line = line.trim().to_string();
            if line.is_empty() {
                continue;
            }
            let (path_field, text) = match parse_csv_line(&line) {
                Some(v) => v,
                None => {
                    bad += 1;
                    continue;
                }
            };
            if first {
                first = false;
                if trba_rust::moe::is_csv_header(&path_field) {
                    header += 1;
                    continue;
                }
            }
            rows += 1;
            chars.extend(text.chars());
        }
    }
    if rows == 0 {
        return Err(anyhow!("--build-charset: в {spec} не нашлось ни одной строки `путь,текст`"));
    }
    let mut f = std::fs::File::create(out).map_err(|e| anyhow!("charset {out}: {e}"))?;
    writeln!(f, "<PAD>\n<SOS>\n<EOS>")?;
    for ch in &chars {
        writeln!(f, "{ch}")?;
    }
    println!(
        "🔤 словарь собран: {rows} строк из {spec}, {} символов + 3 служебных → {out} \
         (пропущено заголовков {header}, битых строк {bad})",
        chars.len()
    );
    Ok(())
}

fn main() -> Result<()> {
    let args = parse_args()?;
    if !args.build_charset.is_empty() {
        let out = args.charset.clone().unwrap_or_default();
        if out.is_empty() {
            return Err(anyhow!(
                "--build-charset требует --charset <файл-приёмник>: куда записать собранный словарь"
            ));
        }
        return build_charset_from_csvs(&args.build_charset, &out);
    }
    std::fs::create_dir_all(&args.exp_dir)?;
    // build.rs falls back to the CPU backend when nvcc is missing or the CUDA
    // compile fails, and a `cargo:warning=` line is trivially scrolled past —
    // that is how this project ended up "training on CUDA" on the CPU.  With
    // TRBA_REQUIRE_CUDA=1 in the environment the binary refuses to start on the
    // wrong backend, whatever build.rs decided at compile time.
    let backend = backend_name();
    let require_cuda = std::env::var("TRBA_REQUIRE_CUDA")
        .map(|v| matches!(v.to_ascii_lowercase().as_str(), "1" | "true" | "yes" | "on"))
        .unwrap_or(false);
    if require_cuda && backend != "cuda" {
        return Err(anyhow!(
            "TRBA_REQUIRE_CUDA=1, но бинарник слинкован с бэкендом '{backend}'. \
             Пересоберите: TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=<sm> cargo build --release"
        ));
    }
    println!("🚀 TRBA (Rust + INT8 QAT) | бэкенд: {backend} | {}", device_name());

    if args.autotune {
        // Подбор сам ничего не загружает: каждая проба — отдельный процесс со своим
        // --smoke, поэтому charset/train.csv ему передаются через argv как есть.
        let cfg = trba_rust::autotune::Cfg {
            trials: args.autotune_trials,
            probe_batches: args.autotune_batches.max(1),
            timeout: std::time::Duration::from_secs(args.autotune_timeout.max(1) as u64),
            vram_limit_mib: args.autotune_vram,
            objective: trba_rust::autotune::Objective::parse(&args.autotune_objective)?,
            out: args.autotune_out.clone(),
            widths: trba_rust::autotune::parse_list(&args.autotune_widths)?,
            batch_sizes: trba_rust::autotune::parse_list(&args.autotune_batch_sizes)?,
            seed: args.seed,
            max_len: args.max_len,
            img_h: args.img_h,
        };
        return trba_rust::autotune::run(&cfg);
    }

    let charset_path = args
        .charset
        .clone()
        .or_else(|| {
            let p = Path::new(&args.train_csv).parent()?.join("charset.txt");
            if p.exists() {
                Some(p.to_string_lossy().into_owned())
            } else {
                None
            }
        })
        .or_else(|| {
            let p = Path::new(&args.exp_dir).join("charset.txt");
            if p.exists() {
                Some(p.to_string_lossy().into_owned())
            } else {
                None
            }
        })
        .ok_or_else(|| anyhow!("не найден charset.txt (положите рядом с train.csv или укажите --charset)"))?;
    let itos = load_charset(&charset_path)?;
    let stoi: std::collections::HashMap<String, usize> = itos.iter().enumerate().map(|(i, s)| (s.clone(), i)).collect();
    let classes = itos.len();
    let (pad, sos, eos) = (stoi["<PAD>"], stoi["<SOS>"], stoi["<EOS>"]);
    println!("📖 charset: {classes} токенов | img {}x{} | max_len {} | hidden {} | слоёв BiLSTM {}",
        args.img_h, args.img_w, args.max_len, args.hidden, args.rnn_layers);

    // Что в чекпоинте и как он ляжет в текущую геометрию — до загрузки датасета.
    if !args.inspect_ckpt.is_empty() {
        return run_inspect_ckpt(&args, classes, sos, eos, pad);
    }
    // Постепенный рост: каждая ступень — отдельный процесс, продолжающий
    // чекпоинт предыдущей (см. run_grow_ladder).
    if !args.grow_ladder.is_empty() {
        return run_grow_ladder(&args, classes);
    }

    // Режим распознавания: те же веса, тот же препроцессинг и тот же greedy-декод,
    // что и при валидации, поэтому текст совпадает с тем, который печатал лог обучения.
    if args.infer {
        return run_inference(&args, &itos, &stoi);
    }

    // MoPE: смесь предобученных экспертов (отдельная реализация, src/moe.rs).
    // Каждый чекпоинт — свой писарь; роутер ZAYA1 выбирает активного, а
    // Markovian RSA дорабатывает ответ по хвостам кандидатов.
    if !args.mope_export_bundle.is_empty() {
        return run_export_bundle(&args, &itos, &stoi);
    }
    if args.mope {
        return run_mope(&args, &itos, &stoi);
    }

    // Экспорт в ONNX: те же веса и тот же препроцессинг, что и в --infer,
    // поэтому граф можно сверить с рантаймом по эталонным тензорам.
    if !args.export_onnx.is_empty() {
        return run_export(&args, &itos, &stoi);
    }

    let (train, skip_tr) = if args.smoke > 0 {
        (Vec::new(), 0)
    } else {
        load_csv(&args.train_csv, &stoi, args.max_len)
    };
    let (val, skip_va) = match &args.val_csv {
        Some(p) if args.smoke == 0 => load_csv(p, &stoi, args.max_len),
        _ => (Vec::new(), 0),
    };
    if args.smoke == 0 {
        println!("📄 train: {} (пропущено {skip_tr}) | val: {} (пропущено {skip_va})", train.len(), val.len());
        if train.is_empty() {
            return Err(anyhow!("пустой train.csv"));
        }
    }

    let mut model = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, args.rnn_layers);
    let mut opt = Adam::new();
    opt.clip_warmup = args.clip_warmup;
    println!(
        "⚙️  {} | глобальный clip: первые {} шаг(ов)",
        opt.muon.banner(),
        opt.clip_warmup
    );
    let stream = CudaStream::new();
    let mut sc = Scratch::new();

    // The conv weights are optimised on the device by default.  Say so, with the
    // VRAM price and the escape hatch, because on a 4 GB card both matter.
    if gpu_rnn_enabled() {
        println!(
            "🧠 TRBA_GPU_RNN=1: BiLSTM считается на GPU — feat не скачивается, d_feat не \
             загружается обратно; проекция cat->y остаётся на хосте (стадия 1, см. BUGFIX_REPORT §11.2)"
        );
    }
    if conv_weights_on_device() {
        let n: usize = model.cnn.convs_mut().iter().map(|c| c.out_c * c.col_cols()).sum();
        println!(
            "🧠 веса свёрток ({:.2}M) с градиентами и Adam-состоянием живут на GPU: \
             ~{:.0} MB VRAM, зато ~0.6 MB трафика через PCIe на батч вместо ~362 MB",
            n as f64 / 1e6,
            n as f64 * 16.0 / 1048576.0
        );
        println!(
            "   мало видеопамяти? TRBA_HOST_CONV_ADAM=1 вернёт оптимизатор на хост \
             (+362 MB/батч по PCIe); TRBA_PCIE_COUNTER=1 печатает фактический трафик"
        );
    }

    // Продолжение прогона: самый свежий чекпоинт (или явно указанный --resume
    // PATH).  Кроме весов восстанавливаются Adam-моменты и позиция внутри эпохи,
    // поэтому перезапуск после Ctrl-C, OOM-kill или падения драйвера продолжает
    // ровно прерванное место, а не начинает эпоху заново.
    let (start_epoch, skip_batches) = if args.no_resume {
        (1, 0)
    } else {
        let path = match &args.resume {
            Some(p) if !p.is_empty() => p.clone(),
            _ => newest_checkpoint(&args.exp_dir),
        };
        if path.is_empty() {
            (1, 0)
        } else {
            let dst_geom = Geometry::new(args.img_h, args.img_w, args.max_len, args.hidden, classes, args.rnn_layers)
                .with_feat_dim(args.feat_dim);
            let cfg = SurgeryCfg { eps: args.surgery_eps, seed: args.seed };
            match load_checkpoint_surgery(&path, &mut model, &dst_geom, &mut opt, &stream, &cfg, true) {
                Ok((meta, src_geom, rep)) => {
                    let grew = !rep.is_empty();
                    println!("📂 resume: {path}\n   чекпоинт: {src_geom}\n   запуск    : {dst_geom}");
                    // Разрешение в V4/V5 не записано (нули), поэтому сравниваем
                    // только то, что действительно определяет формы весов и бюджет
                    // ступени: разрешение и max_len влияют на счётчик эпох, но для
                    // старых форматов мы их просто не знаем — берём из запуска.
                    let geom_changed = !src_geom.same_training_regime(&dst_geom);
                    if geom_changed {
                        for x in geometry_diff_lines(&src_geom, &dst_geom) {
                            println!("   ⇄ {x}");
                        }
                        println!("🧬 перенос весов (хирургия, src/surgery.rs): {}", rep.report());
                        for ch in rep.changed.iter().take(10) {
                            println!("      🔧 {ch}");
                        }
                        if rep.changed.len() > 10 {
                            println!("      … и ещё {}", rep.changed.len() - 10);
                        }
                        if grew {
                            println!(
                                "   ℹ️  --surgery-eps {}: новые столбцы {} — новые ячейки {}",
                                args.surgery_eps,
                                if args.surgery_eps == 0.0 { "нули: выход сети сохранён побитово" } else { "малый шум: выход уезжает на ~eps" },
                                if args.surgery_eps == 0.0 { "мёртвы (нулевой градиент), зато ничего не сломано" } else { "сразу получают градиент и начинают специализироваться" }
                            );
                        } else {
                            println!("   ℹ️  формы весов не изменились: разрешение и max_len на них не влияют — перенос бесплатный");
                        }
                        // Новая геометрия — новая ступень: счётчики сбрасываются,
                        // поэтому --epochs N задаёт бюджет ЭТОЙ ступени, а warmup и
                        // bias-correction Adam отрабатывают заново (моменты
                        // изменённых тензоров и так обнулены). Без этого ступень
                        // роста «48x192:1» после чекпоинта с 20 эпохами не сделала
                        // бы ничего: start_epoch оказался бы больше --epochs.
                        opt.t = 0;
                        println!(
                            "   ♻️  счётчик эпох и шагов сброшен: --epochs {} относится к этой геометрии, warmup clip {} шагов",
                            args.epochs, args.clip_warmup
                        );
                        (1, 0)
                    } else {
                        println!(
                            "   завершено эпох: {} | продолжать с эпохи {}, батч {} | шаг оптимизатора {} | Adam-моменты: {}",
                            meta.epoch_done,
                            meta.epoch_done + 1,
                            meta.batch_in_epoch + 1,
                            opt.t,
                            if rep.moments > 0 { "восстановлены" } else { "нулевые (V4 или перенос) — первые шаги будут резче" }
                        );
                        (meta.epoch_done + 1, meta.batch_in_epoch)
                    }
                }
                Err(e) => {
                    eprintln!("⚠️  resume не удался ({e}) — обучение с нуля");
                    // Загрузка потоковая: к моменту ошибки часть весов, BN и opt.t
                    // уже перезаписаны из файла. Пересоздаём модель и оптимизатор
                    // целиком, иначе «с нуля» означает «из половины чекпоинта».
                    model = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, args.rnn_layers);
                    opt = Adam::new();
                    opt.clip_warmup = args.clip_warmup;
                    (1, 0)
                }
            }
        }
    };
    let probe_mode = std::env::var("TRBA_AUTOTUNE_PROBE").as_deref() == Ok("1");
    let last_path = format!("{}/{}", args.exp_dir, CKPT_LAST);
    if !probe_mode && args.ckpt_every_batch > 0 {
        println!(
            "💾 rolling-чекпоинт {last_path}: каждые {} батч(ей) и в конце каждой эпохи \
             (продолжить — тот же запуск без --no-resume)",
            args.ckpt_every_batch
        );
    }

    let img_len = 3 * args.img_h * args.img_w;
    let s_img = 1.0f32 / 127.0;
    // сколько памяти свободно до первого батча: проба подбора (--autotune)
    // печатает разницу как «занято этой конфигурацией»
    let (vram_free0, vram_total) = trba_rust::backend::memory_info();

    // Лучшая на данный момент CER: нужна, чтобы обновлять best.bin только при
    // реальном улучшении. При возобновлении восстанавливается из имени уже
    // лежащего в exp_dir файла checkpoint_best_cer*.bin.
    let mut best_cer = existing_best_cer(&args.exp_dir).unwrap_or(f64::MAX);
    if best_cer < f64::MAX {
        println!("♻️  лучший CER из уже сохранённых чекпоинтов: {best_cer:.2}%");
    }
    let mut prof = Profiler::new();
    if prof.on {
        eprintln!("[profile] TRBA_PROFILE=1: phases per batch will be reported to stderr");
    }

    if start_epoch > args.epochs {
        println!(
            "ℹ️  в чекпоинте завершено эпох: {}, а --epochs {} — обучать нечего. \
             Увеличьте --epochs либо растите геометрию (--img-h/--img-w/--hidden, \
             --grow-ladder): при изменении геометрии счётчик эпох сбрасывается, \
             и --epochs N задаёт бюджет новой ступени.",
            start_epoch - 1,
            args.epochs
        );
        return Ok(());
    }
    for epoch in start_epoch..=args.epochs {
        let cw = ctc_weight_for_epoch(epoch);
        let lr = args.lr * 0.5 * (1.0 + (std::f64::consts::PI * (epoch - 1) as f64 / args.epochs as f64).cos()) as f32;
        let mut order: Vec<usize> = if args.smoke > 0 {
            (0..args.smoke * args.batch).collect()
        } else {
            (0..train.len()).collect()
        };
        // Порядок батчей — функция от (seed, epoch), а не от всей истории
        // перемешиваний: только так продолжение с середины эпохи попадает в ту же
        // последовательность, и пропуск первых `skip` батчей возобновляет ровно
        // прерванное место, а не другую выборку.
        let mut rng = rand::rngs::StdRng::seed_from_u64(
            args.seed
                .wrapping_mul(0x9E37_79B9_7F4A_7C15)
                .wrapping_add((epoch as u64).wrapping_mul(0x632B_E59B_D51A_3E11)),
        );
        order.shuffle(&mut rng);
        // сколько батчей этой эпохи уже пройдено до прерывания
        let skip = if epoch == start_epoch { skip_batches } else { 0 };

        let mut loss_sum = 0.0f64;
        let mut attn_sum = 0.0f64;
        let mut ctc_sum = 0.0f64;
        let mut batches = 0usize;
        let mut done = 0usize;
        let t0 = std::time::Instant::now();

        for chunk in order.chunks(args.batch) {
            let b = chunk.len();
            if b == 0 {
                continue;
            }
            done += 1;
            if done <= skip {
                // эти батчи уже посчитаны до прерывания (см. --ckpt-every-batch)
                continue;
            }
            // ---- batch ----
            let mut imgs = vec![0i8; b * img_len];
            let steps = args.max_len + 1;
            let mut text_in = vec![vec![pad; steps]; b];
            let mut target_y = vec![vec![pad; steps]; b];
            let mut ctc_targets: Vec<Vec<usize>> = Vec::new();
            let mut ok: Vec<usize> = Vec::new();
            for (bi, &idx) in chunk.iter().enumerate() {
                let (path, tokens) = if args.smoke > 0 {
                    let mut r = rand::random::<u64>();
                    let mut t = Vec::new();
                    let l = 4 + (r % 8) as usize;
                    for _ in 0..l {
                        r = r.wrapping_mul(6364136223846793005).wrapping_add(1);
                        t.push(3 + (r as usize % (classes - 3)));
                    }
                    (String::new(), t)
                } else {
                    (train[idx].path.clone(), train[idx].tokens.clone())
                };
                let q = if args.smoke > 0 {
                    imgs[bi * img_len..(bi + 1) * img_len].iter_mut().for_each(|p| *p = rand::random::<i8>() % 64);
                    true
                } else {
                    match load_image_q(&path, args.img_h, args.img_w) {
                        Some(q) => {
                            imgs[bi * img_len..(bi + 1) * img_len].copy_from_slice(&q);
                            true
                        }
                        None => false,
                    }
                };
                if !q {
                    continue;
                }
                ok.push(bi);
                let l = tokens.len().min(args.max_len);
                text_in[bi][0] = sos;
                for i in 0..l {
                    text_in[bi][1 + i] = tokens[i];
                }
                for i in 0..l {
                    target_y[bi][i] = tokens[i];
                }
                target_y[bi][l] = eos;
                let mut ct = tokens[..l].to_vec();
                ct.push(eos);
                ctc_targets.push(ct);
            }
            // compact to successful samples
            if ok.len() != b {
                if ok.is_empty() {
                    continue;
                }
                let nb = ok.len();
                let mut imgs2 = vec![0i8; nb * img_len];
                for (ni, &bi) in ok.iter().enumerate() {
                    imgs2[ni * img_len..(ni + 1) * img_len].copy_from_slice(&imgs[bi * img_len..(bi + 1) * img_len]);
                }
                imgs = imgs2;
                text_in = ok.iter().map(|&bi| std::mem::take(&mut text_in[bi]).clone()).collect();
                let ty: Vec<Vec<usize>> = ok.iter().map(|&bi| std::mem::take(&mut target_y[bi]).clone()).collect();
                target_y = ty;
                // ctc_targets already only for ok (pushed in order)
                return_main_step(
                    &args, &mut model, &mut opt, &stream, &mut sc, &imgs, nb, &text_in, &target_y,
                    &ctc_targets, steps, cw, lr, s_img, pad, &mut loss_sum, &mut attn_sum,
                    &mut ctc_sum, &mut prof,
                )?;
            } else {
                return_main_step(
                    &args, &mut model, &mut opt, &stream, &mut sc, &imgs, b, &text_in, &target_y,
                    &ctc_targets, steps, cw, lr, s_img, pad, &mut loss_sum, &mut attn_sum,
                    &mut ctc_sum, &mut prof,
                )?;
            }
            batches += 1;

            // Частый rolling-чекпоинт: именно из него прогон продолжается после
            // Ctrl-C, OOM-kill или падения драйвера. Запись атомарна, поэтому
            // прерывание посреди сохранения не портит предыдущую версию.
            if !probe_mode && args.ckpt_every_batch > 0 && batches % args.ckpt_every_batch == 0 {
                let meta = CkptMeta { epoch_done: epoch - 1, batch_in_epoch: done };
                save_checkpoint(&last_path, &mut model, meta, &opt, &stream, &args)?;
                println!(
                    "💾 {last_path} | эпоха {epoch}, батч {done}/{}, шаг {}",
                    (order.len() + args.batch - 1) / args.batch.max(1),
                    opt.t
                );
            }
            if args.smoke > 0 && batches >= args.smoke {
                break;
            }
        }

        let nb_ = batches.max(1);
        let epoch_loss = loss_sum / nb_ as f64;
        let cnn_macs = model
            .cnn
            .convs_mut()
            .iter()
            .fold((0u64, 0u64), |(a, b), c| (a + c.macs_fwd, b + c.macs_bwd));
        for c in model.cnn.convs_mut() {
            c.macs_fwd = 0;
            c.macs_bwd = 0;
        }
        prof.report_and_reset(&format!("эпоха {epoch}"), cnn_macs);
        println!(
            "Эпоха {epoch}/{} | {:.0}s | loss {:.4} (attn {:.4} ctc {:.4}, w_ctc {cw:.3}) | lr {:.2e}",
            args.epochs,
            t0.elapsed().as_secs_f32(),
            epoch_loss,
            attn_sum / nb_ as f64,
            ctc_sum / nb_ as f64,
            lr
        );

        if epoch % args.eval_every == 0 && !val.is_empty() {
            let (val_cer, _val_acc, val_n) =
                validate(&args, &mut model, &stream, &mut sc, &val, &itos, &stoi, s_img, pad, eos, cw);
            if val_n > 0 && val_cer.is_finite() && val_cer < best_cer {
                best_cer = val_cer;
                save_best_checkpoint(&args, &mut model, &opt, &stream, epoch, val_cer, epoch_loss)?;
            }
        }

        // конец эпохи: номерной чекпоинт по расписанию + обязательный rolling,
        // из которого прогон продолжится после перезапуска
        let ckpt = if (args.ckpt_every > 0 && epoch % args.ckpt_every == 0) || epoch == args.epochs {
            Some(format!(
                "{}/checkpoint_epoch{:03}_loss{:.4}.bin",
                args.exp_dir, epoch, epoch_loss
            ))
        } else {
            None
        };
        if let Some(p) = ckpt.filter(|_| !probe_mode) {
            save_checkpoint(
                &p,
                &mut model,
                CkptMeta { epoch_done: epoch, batch_in_epoch: 0 },
                &opt,
                &stream,
                &args,
            )?;
            println!("💾 {p}");
        }
        if !probe_mode {
            save_checkpoint(
                &last_path,
                &mut model,
                CkptMeta { epoch_done: epoch, batch_in_epoch: 0 },
                &opt,
                &stream,
                &args,
            )?;
        }

        if args.smoke > 0 {
            if std::env::var("TRBA_AUTOTUNE_PROBE").as_deref() == Ok("1") {
                // машиночитаемая строка для родителя --autotune (src/autotune.rs).
                // Печатается до «smoke завершён», чтобы её не спутать с логом.
                let (free1, _) = trba_rust::backend::memory_info();
                let secs = t0.elapsed().as_secs_f64().max(1e-9);
                let nb = batches.max(1) as f64;
                let used_mib = if vram_total > 0 {
                    vram_free0.saturating_sub(free1) as f64 / 1048576.0
                } else {
                    0.0
                };
                println!(
                    "PROBE b={} w={} h={} ok=1 batches={} sec_per_batch={:.6} img_per_s={:.4} \
                     vram_mib={:.1} vram_total_mib={:.1}",
                    args.batch, args.img_w, args.img_h, batches, secs / nb,
                    nb * args.batch as f64 / secs, used_mib, vram_total as f64 / 1048576.0
                );
            }
            println!("✅ smoke завершён");
            break;
        }

    }
    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn return_main_step(
    args: &Args,
    model: &mut Model,
    opt: &mut Adam,
    stream: &CudaStream,
    sc: &mut Scratch,
    imgs: &[i8],
    b: usize,
    text_in: &[Vec<usize>],
    target_y: &[Vec<usize>],
    ctc_targets: &[Vec<usize>],
    steps: usize,
    cw: f32,
    lr: f32,
    s_img: f32,
    pad: usize,
    loss_sum: &mut f64,
    attn_sum: &mut f64,
    ctc_sum: &mut f64,
    prof: &mut Profiler,
) -> Result<()> {
    let classes = model.attn.classes;
    // ---------- forward ----------
    let img_buf = Arc::new(DevBuf::new(imgs.len()));
    img_buf.upload_i8(imgs, stream);
    prof.hit(0, stream);
    let (feat, trace) = model.cnn.forward(&img_buf, s_img, b, true, args.img_h, args.img_w, stream, sc);
    model.cnn.update_running_stats(&trace);
    prof.hit(1, stream);
    let t = trace.out.w_feat;
    // TRBA_GPU_RNN=1: feat не скачивается на хост — BiLSTM считается на
    // устройстве и получает [B, T, fd] прямо из cnn.forward.
    let (enc, rnn_tr) = if gpu_rnn_enabled() {
        prof.hit(2, stream); // выгрузки feat нет — фаза ~0
        let (enc, dtr) = model.rnn.forward_device(feat, b, t, stream);
        prof.hit(3, stream);
        (enc, RnnTrace::Dev(dtr))
    } else {
        let mut feat_h = vec![0.0f32; b * t * model.cnn.fd];
        feat.download_f32(&mut feat_h, stream);
        stream.sync();
        prof.hit(2, stream);
        let (enc, htr) = model.rnn.forward(&feat_h, b, t);
        prof.hit(3, stream);
        (enc, RnnTrace::Host(htr))
    };
    let (logits, attn_tr) = model.attn.forward_train(&enc, text_in, b, t);
    prof.hit(4, stream);
    let ctc_logits = model.ctc.forward(&enc, b * t);
    prof.hit(5, stream);

    // ---------- losses ----------
    // attention CE with ignore_index = PAD
    let mut count = 0usize;
    let mut attn_loss = 0.0f64;
    let mut d_logits = vec![0.0f32; b * steps * classes];
    for bi in 0..b {
        for st in 0..steps {
            let tgt = target_y[bi][st];
            if tgt == pad {
                continue;
            }
            count += 1;
            let row = &logits[(bi * steps + st) * classes..(bi * steps + st + 1) * classes];
            let mx = row.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
            let ex: Vec<f32> = row.iter().map(|&x| (x - mx).exp()).collect();
            let s: f32 = ex.iter().sum();
            attn_loss += (ex[tgt] / s).ln() as f64 * -1.0;
            for k in 0..classes {
                let p = ex[k] / s;
                d_logits[(bi * steps + st) * classes + k] = p - if k == tgt { 1.0 } else { 0.0 };
            }
        }
    }
    let count = count.max(1);
    let attn_loss = attn_loss / count as f64;
    let scale = (1.0 - cw) / count as f32;
    for x in d_logits.iter_mut() {
        *x *= scale;
    }
    let (ctc_loss, mut d_ctc) = ctc_loss_backward(&ctc_logits, b, t, classes, ctc_targets, 0);
    for x in d_ctc.iter_mut() {
        *x *= cw;
    }
    let total = (1.0 - cw) as f64 * attn_loss + cw as f64 * ctc_loss;
    *loss_sum += total;
    *attn_sum += attn_loss;
    *ctc_sum += ctc_loss;

    prof.hit(6, stream);

    // ---------- backward ----------
    model.zero_grad();
    let d_enc_attn = model.attn.backward(&d_logits, &attn_tr);
    prof.hit(7, stream);
    let d_ctc_enc = model.ctc.backward(&enc, &d_ctc, b * t);
    prof.hit(8, stream);
    let mut d_enc = vec![0.0f32; b * t * model.attn.hidden];
    for i in 0..d_enc.len() {
        d_enc[i] = d_enc_attn[i] + d_ctc_enc[i];
    }
    let d_feat_buf = match &rnn_tr {
        RnnTrace::Host(htr) => {
            let d_feat = model.rnn.backward(&d_enc, htr);
            prof.hit(9, stream);
            let buf = DevBuf::new(d_feat.len() * 4);
            buf.upload_f32(&d_feat, stream);
            prof.hit(10, stream);
            buf
        }
        // dx последнего слоя уже лежит на устройстве: d_feat уходит в
        // cnn.backward без выгрузки на хост и обратной загрузки
        RnnTrace::Dev(dtr) => {
            let buf = model.rnn.backward_device(&d_enc, dtr, stream);
            prof.hit(9, stream);
            prof.hit(10, stream);
            buf
        }
    };
    sc.reset_grad_sq(stream); // one f64 for the whole network, zeroed per batch
    model.cnn.backward(&d_feat_buf, &trace, stream, sc);
    stream.sync();
    prof.hit(11, stream);

    // ---------- clip + Adam ----------
    // The conv weights (42.15M parameters) are optimised on the device, so the
    // global grad norm is assembled from the host part plus one 8-byte device
    // scalar, and the clip factor is applied on both sides.
    let on_device = conv_weights_on_device();
    // Глобальный clip считаем только на warmup (по умолчанию 500 шагов,
    // `--clip-warmup`): дальше шаг ограничивает нормировка Muon с капом, а
    // чтение скаляра с устройства — это лишняя синхронизация на каждый батч.
    let need_clip = opt.clip_needed();
    let params = model.host_params();
    let f = if need_clip {
        let dev_sq = if on_device { sc.read_grad_sq(stream) } else { 0.0 };
        let norm = (Adam::sum_sq(&params) + dev_sq).sqrt();
        let clip = 5.0f64;
        if norm > clip { (clip / (norm + 1e-6)) as f32 } else { 1.0 }
    } else {
        1.0
    };
    Adam::scale_grads(&params, f);
    opt.step(&params, lr, args.weight_decay);
    prof.hit(12, stream);
    if on_device {
        if opt.muon.on {
            // Матрица свёртки = [out_c, in_c*kh*kw]. Норма считается на
            // устройстве в device-скаляр, масштаб — внутри самого ядра шага,
            // поэтому на хост не возвращается ни одного байта.
            model.cnn.device_muon_step(
                lr as f64, args.weight_decay as f64, f as f64, opt.muon.cap as f64,
                opt.muon.autoscale, stream);
        } else {
            let (bc1, bc2) = opt.bias_correction();
            model.cnn.device_adam_step(
                lr as f64, args.weight_decay as f64, f as f64,
                opt.beta1 as f64, opt.beta2 as f64, opt.eps as f64, bc1, bc2, stream);
        }
    }
    model.cnn.requantize_all(stream);
    prof.hit(13, stream);
    prof.batch_done();
    Ok(())
}

#[allow(clippy::too_many_arguments)]
// ---------------------------------------------------------------------------
// --infer: распознавание готовым чекпоинтом
//
// Вход — одна картинка, каталог картинок или CSV, у которого первая колонка
// содержит пути (то есть подходят train.csv/val.csv без изменений). Позиционный
// аргумент №2 в этом режиме — файл результатов (TSV `путь\tтекст`), а не
// val.csv; если его не указать, результат печатается в stdout. Чекпоинт
// берётся из --resume PATH, иначе <exp_dir>/best.bin, иначе самый свежий в
// exp_dir. Пакетная загрузка (args.batch) и препроцессинг ровно те же, что в
// обучении: aspect-preserving resize, белый холст, (p/255*2-1), int8 с шагом
// 1/127 — то есть на выходе тот же текст, который модель давала на валидации.
// ---------------------------------------------------------------------------

/// Одна картинка, каталог или CSV/TSV/TXT со списком путей в первой колонке.
fn collect_infer_inputs(spec: &str) -> Vec<String> {
    let p = Path::new(spec);
    if p.is_dir() {
        let mut v: Vec<String> = match std::fs::read_dir(p) {
            Ok(rd) => rd.flatten().map(|e| e.path().to_string_lossy().into_owned()).collect(),
            Err(_) => Vec::new(),
        };
        v.sort();
        v.retain(|s| {
            let e = s.to_lowercase();
            [".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"]
                .iter()
                .any(|x| e.ends_with(x))
        });
        return v;
    }
    let lower = spec.to_lowercase();
    if lower.ends_with(".csv") || lower.ends_with(".tsv") || lower.ends_with(".txt") {
        let base = p.parent().map(|b| b.to_path_buf()).unwrap_or_default();
        let mut v = Vec::new();
        if let Ok(f) = std::fs::File::open(spec) {
            for line in BufReader::new(f).lines().flatten() {
                let line = line.trim().to_string();
                if line.is_empty() || line.starts_with('#') {
                    continue;
                }
                let first = line
                    .split([',', '\t'])
                    .next()
                    .unwrap_or("")
                    .trim()
                    .trim_matches('"')
                    .to_string();
                if first.is_empty() {
                    continue;
                }
                let fp = Path::new(&first);
                v.push(if fp.is_absolute() {
                    first
                } else {
                    base.join(fp).to_string_lossy().into_owned()
                });
            }
        }
        return v;
    }
    vec![spec.to_string()]
}

fn write_raw_f32(path: &str, v: &[f32]) -> Result<()> {
    let mut bytes: Vec<u8> = Vec::with_capacity(v.len() * 4);
    for x in v {
        bytes.extend_from_slice(&x.to_le_bytes());
    }
    std::fs::write(path, bytes).map_err(|e| anyhow!("не удалось записать {path}: {e}"))
}

/// `--export-onnx`: собрать ONNX-граф из тех же весов, что использует
/// `--infer`, и (опционально) записать эталонные тензоры для сверки с
/// onnxruntime. Без чекпоинта граф экспортируется со случайными весами:
/// топология и арифметика узлов от значений весов не зависят.
fn run_export(
    args: &Args,
    itos: &[String],
    stoi: &std::collections::HashMap<String, usize>,
) -> Result<()> {
    use trba_rust::onnx::{self, ExportCfg, Layout};

    let classes = itos.len();
    let (pad, sos, eos) = (stoi["<PAD>"], stoi["<SOS>"], stoi["<EOS>"]);
    let mut model = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, args.rnn_layers);
    let mut opt = Adam::new();
    let stream = CudaStream::new();
    let mut sc = Scratch::new();

    let path = match &args.resume {
        Some(p) if !p.is_empty() => p.clone(),
        _ => {
            let best = format!("{}/best.bin", args.exp_dir);
            if Path::new(&best).exists() {
                best
            } else {
                newest_checkpoint(&args.exp_dir)
            }
        }
    };
    let ckpt_name = if path.is_empty() {
        println!("⚠️  чекпоинт не найден — экспортирую граф со случайными весами (проверка топологии)");
        "random".to_string()
    } else {
        let (meta, _moments) = load_checkpoint(&path, &mut model, &mut opt, &stream)
            .map_err(|e| anyhow!("--export-onnx: не удалось загрузить {path}: {e}"))?;
        println!("🧾 export: чекпоинт {path} | завершено эпох {}", meta.epoch_done);
        path.clone()
    };

    // --- картинки: калибровка шкал активаций (int8) и эталонные тензоры
    let files = if args.train_csv.is_empty() {
        Vec::new()
    } else {
        collect_infer_inputs(&args.train_csv)
    };
    let want = args.onnx_calib.max(1);
    let s_img = 1.0f32 / 127.0;
    let mut compact: Vec<i8> = Vec::new();
    let mut used: Vec<String> = Vec::new();
    for f in files.iter() {
        if used.len() >= want {
            break;
        }
        if let Some(q) = load_image_q(f, args.img_h, args.img_w) {
            compact.extend_from_slice(&q);
            used.push(f.clone());
        }
    }
    let nb = used.len();
    if nb == 0 && (args.onnx_int8 || !args.onnx_ref.is_empty()) {
        println!("⚠️  нет картинок (первый позиционный аргумент) — калибровки и эталонных тензоров не будет");
    }

    let layout = match args.onnx_layout.to_ascii_lowercase().as_str() {
        "nchw" => Layout::Nchw,
        _ => Layout::Nhwc,
    };

    let mut act_scales: std::collections::HashMap<String, f32> = std::collections::HashMap::new();
    let mut ref_feat: Vec<f32> = Vec::new();
    let mut ref_stem: Vec<f32> = Vec::new();
    let mut ref_enc: Vec<f32> = Vec::new();
    let mut ref_logits: Vec<f32> = Vec::new();
    let mut ref_dec_logits: Vec<f32> = Vec::new();
    let mut ref_text: Vec<String> = Vec::new();
    let mut dec_steps = 0usize;
    let mut t_runtime = args.img_w;

    if nb > 0 {
        let img_buf = Arc::new(DevBuf::new(compact.len()));
        img_buf.upload_i8(&compact, &stream);
        let (feat, tr) = model
            .cnn
            .forward(&img_buf, s_img, nb, false, args.img_h, args.img_w, &stream, &mut sc);
        t_runtime = tr.out.w_feat;
        if args.onnx_int8 {
            act_scales = onnx::collect_act_scales(&model.cnn, &tr);
            println!("🎚  int8: шкалы активаций сняты с {} слой(ов)", act_scales.len());
        }
        // Эталонный stem: q_chain[2] — это выход maxpool (int8 + шкала). Он
        // нужен, чтобы отделить расхождение «int8 QAT против fp32» от ошибки
        // экспорта: если stem совпадает на проценты, а feat на десятки —
        // шум накапливается с глубиной, а не появился из-за графа.
        if !args.onnx_ref.is_empty() && tr.q_chain.len() > 2 {
            let (qb, qs) = &tr.q_chain[2];
            let n_stem = nb * (model.cnn.fd / 4) * (args.img_h / 2) * (args.img_w / 2);
            let mut qi = vec![0i8; n_stem];
            qb.download_i8(&mut qi, &stream);
            stream.sync();
            ref_stem = qi.iter().map(|&v| v as f32 * qs).collect();
        }
        let mut feat_h = vec![0.0f32; nb * t_runtime * model.cnn.fd];
        feat.download_f32(&mut feat_h, &stream);
        stream.sync();
        let (enc, _rnn_tr) = model.rnn.forward(&feat_h, nb, t_runtime);
        ref_logits = model.ctc.forward(&enc, nb * t_runtime);
        ref_feat = feat_h;
        ref_enc = enc.clone();
        // Эталон декодера: те же шаги, что развёрнуты в графе (без раннего
        // стопа по EOS), поэтому сравнивать можно пошагово.
        if !args.onnx_no_decoder {
            let (preds, dec_logits) =
                model.attn.greedy_decode_full(&enc, nb, t_runtime, args.max_len, false);
            dec_steps = args.max_len + 1;
            ref_dec_logits = dec_logits;
            ref_text = preds
                .iter()
                .map(|p| p.iter().map(|&i| token_str(itos, i)).collect::<String>())
                .collect();
        }
    }

    let cfg = ExportCfg {
        img_h: args.img_h,
        img_w: args.img_w,
        hidden: args.hidden,
        classes,
        layout,
        debug_outputs: args.onnx_debug || !args.onnx_ref.is_empty(),
        with_decoder: !args.onnx_no_decoder,
        max_len: args.max_len,
    };
    let (bytes, st) =
        onnx::export_model(&model.cnn, &model.rnn, &model.ctc, &model.attn, &cfg, &act_scales, "trba-rust");
    onnx::write_file(&args.export_onnx, &bytes)
        .map_err(|e| anyhow!("не удалось записать {}: {e}", args.export_onnx))?;

    let in_dims = match layout {
        Layout::Nhwc => format!("[batch,{},{},3]", args.img_h, args.img_w),
        Layout::Nchw => format!("[batch,3,{},{}]", args.img_h, args.img_w),
    };
    println!(
        "📦 ONNX: {} | opset {} | узлов {} | инициализаторов {} | весов {:.1} МБ | файл {:.1} МБ",
        args.export_onnx,
        onnx::OPSET,
        st.nodes,
        st.initializers,
        st.weight_bytes as f64 / 1e6,
        st.file_bytes as f64 / 1e6
    );
    if cfg.with_decoder {
        println!(
            "   вход `input` {in_dims} ({:?}) → `logits` [batch,{},{}] + `pred` int64 [batch,{}] \
             (attention-декодер, {} шаг(ов) без раннего стопа) | `ctc_logits` [batch,{},{}] | `feat` [batch,{},512] | QDQ-пар: {}",
            layout, dec_steps, classes, dec_steps, dec_steps, st.t_feat, classes, st.t_feat, st.qdq_pairs
        );
    } else {
        println!(
            "   вход `input` {in_dims} ({:?}) → `logits` [batch,{},{}] (CTC-голова) | `feat` [batch,{},512] | QDQ-пар: {}",
            layout, st.t_feat, classes, st.t_feat, st.qdq_pairs
        );
    }
    if st.t_feat != t_runtime && nb > 0 {
        println!(
            "⚠️  длина признака в графе ({}) не совпала с прогонной ({}) — проверьте img_w",
            st.t_feat, t_runtime
        );
    }

    if !args.onnx_ref.is_empty() && nb > 0 {
        std::fs::create_dir_all(&args.onnx_ref)
            .map_err(|e| anyhow!("не удалось создать {}: {e}", args.onnx_ref))?;
        // вход в том же порядке байт, в котором его читает CNN (HWC)
        let input_f32: Vec<f32> = compact.iter().map(|&q| q as f32 * s_img).collect();
        write_raw_f32(&format!("{}/input.raw", args.onnx_ref), &input_f32)?;
        write_raw_f32(&format!("{}/ref_feat.raw", args.onnx_ref), &ref_feat)?;
        if !ref_stem.is_empty() {
            write_raw_f32(&format!("{}/ref_stem.raw", args.onnx_ref), &ref_stem)?;
        }
        write_raw_f32(&format!("{}/ref_enc.raw", args.onnx_ref), &ref_enc)?;
        write_raw_f32(&format!("{}/ref_logits.raw", args.onnx_ref), &ref_logits)?;
        if !ref_dec_logits.is_empty() {
            write_raw_f32(&format!("{}/ref_dec_logits.raw", args.onnx_ref), &ref_dec_logits)?;
            std::fs::write(format!("{}/ref_text.txt", args.onnx_ref), ref_text.join("\n") + "\n")
                .map_err(|e| anyhow!("не удалось записать ref_text.txt: {e}"))?;
        }
        let meta = format!(
            "n={nb}\nimg_h={}\nimg_w={}\nt={}\nhidden={}\nclasses={}\nlayout={}\ns_img={s_img}\nckpt={ckpt_name}\nstem={}\ndec_steps={}\nsos={}\neos={}\npad={}\nmax_len={}\n",
            args.img_h, args.img_w, st.t_feat, args.hidden, classes,
            if layout == Layout::Nhwc { "nhwc" } else { "nchw" },
            if ref_stem.is_empty() { "none".to_string() } else { format!("{}x{}x{}x{}", nb, 128, args.img_h / 2, args.img_w / 2) },
            dec_steps, sos, eos, pad, args.max_len
        );
        std::fs::write(format!("{}/meta.txt", args.onnx_ref), meta)
            .map_err(|e| anyhow!("не удалось записать meta.txt: {e}"))?;
        println!("🔬 эталонные тензоры: {} (input/feat/enc/logits + meta.txt)", args.onnx_ref);
        for (i, f) in used.iter().enumerate() {
            println!("   [{i}] {f}");
        }
    }
    Ok(())
}

fn run_inference(
    args: &Args,
    itos: &[String],
    stoi: &std::collections::HashMap<String, usize>,
) -> Result<()> {
    if args.train_csv.is_empty() {
        return Err(anyhow!(
            "--infer: укажите вход (картинка, каталог или CSV) первым позиционным аргументом"
        ));
    }
    let classes = itos.len();
    let (pad, sos, eos) = (stoi["<PAD>"], stoi["<SOS>"], stoi["<EOS>"]);

    let files = collect_infer_inputs(&args.train_csv);
    if files.is_empty() {
        return Err(anyhow!("--infer: в {:?} не нашлось ни одной картинки", args.train_csv));
    }
    // позиционный №2 в режиме --infer — файл результатов, а не val.csv
    let out_path = args.val_csv.clone().filter(|s| !s.is_empty());

    let mut model = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, args.rnn_layers);
    let mut opt = Adam::new();
    let stream = CudaStream::new();
    let mut sc = Scratch::new();

    let path = match &args.resume {
        Some(p) if !p.is_empty() => p.clone(),
        _ => {
            let best = format!("{}/best.bin", args.exp_dir);
            if Path::new(&best).exists() {
                best
            } else {
                newest_checkpoint(&args.exp_dir)
            }
        }
    };
    if path.is_empty() {
        return Err(anyhow!(
            "--infer: в {:?} нет чекпоинта (нужен best.bin / checkpoint_*.bin или --resume PATH)",
            args.exp_dir
        ));
    }
    // Ошибка загрузки здесь фатальна: распознавать «половиной чекпоинта» нельзя.
    let (meta, moments) = load_checkpoint(&path, &mut model, &mut opt, &stream)
        .map_err(|e| anyhow!("--infer: не удалось загрузить {path}: {e}"))?;
    println!(
        "🧾 infer: {path} | завершено эпох {} | Adam-моменты {} | вход {:?} ({} файл(ов)) | \
         результат: {}",
        meta.epoch_done,
        if moments {
            "восстановлены"
        } else {
            "нулевые (формат V4)"
        },
        args.train_csv,
        files.len(),
        match &out_path {
            Some(p) => p.as_str(),
            None => "stdout",
        }
    );

    let img_len = 3 * args.img_h * args.img_w;
    let s_img = 1.0f32 / 127.0;
    let b = args.batch.max(1);
    let mut out = String::new();
    let (mut n_ok, mut n_bad) = (0usize, 0usize);
    let t0 = std::time::Instant::now();

    for chunk in files.chunks(b) {
        let mut imgs = vec![0i8; chunk.len() * img_len];
        let mut keep: Vec<(usize, &String)> = Vec::new();
        for (bi, f) in chunk.iter().enumerate() {
            match load_image_q(f, args.img_h, args.img_w) {
                Some(q) => {
                    imgs[bi * img_len..(bi + 1) * img_len].copy_from_slice(&q);
                    keep.push((bi, f));
                }
                None => {
                    eprintln!("⚠️  не читается как картинка: {f}");
                    n_bad += 1;
                }
            }
        }
        if keep.is_empty() {
            continue;
        }
        // неудачные файлы выбрасываются из батча, иначе в тензоре будут дыры
        let nb = keep.len();
        let mut compact = vec![0i8; nb * img_len];
        for (ni, (bi, _)) in keep.iter().enumerate() {
            compact[ni * img_len..(ni + 1) * img_len]
                .copy_from_slice(&imgs[bi * img_len..(bi + 1) * img_len]);
        }
        let img_buf = Arc::new(DevBuf::new(compact.len()));
        img_buf.upload_i8(&compact, &stream);
        let (feat, tr) =
            model
                .cnn
                .forward(&img_buf, s_img, nb, false, args.img_h, args.img_w, &stream, &mut sc);
        let t = tr.out.w_feat;
        let mut feat_h = vec![0.0f32; nb * t * model.cnn.fd];
        feat.download_f32(&mut feat_h, &stream);
        stream.sync();
        let (enc, _rnn_tr) = model.rnn.forward(&feat_h, nb, t);
        let preds = model.attn.greedy_decode(&enc, nb, t, args.max_len);
        for ((_, f), pred) in keep.iter().zip(preds.iter()) {
            let text: String = pred.iter().map(|&i| token_str(itos, i)).collect();
            out.push_str(f);
            out.push('\t');
            out.push_str(&text);
            out.push('\n');
            n_ok += 1;
        }
    }

    match out_path {
        Some(p) => {
            if let Some(dir) = Path::new(&p).parent() {
                if !dir.as_os_str().is_empty() {
                    std::fs::create_dir_all(dir)?;
                }
            }
            std::fs::write(&p, &out).map_err(|e| anyhow!("не записать {p}: {e}"))?;
            println!("💾 {p}: {n_ok} строк (TSV: путь<TAB>текст)");
        }
        None => print!("{out}"),
    }
    let secs = t0.elapsed().as_secs_f64().max(1e-9);
    println!(
        "✅ infer: распознано {n_ok}, пропущено {n_bad} | {:.2} с | {:.2} картинок/с",
        secs,
        n_ok as f64 / secs
    );
    Ok(())
}

fn validate(
    args: &Args,
    model: &mut Model,
    stream: &CudaStream,
    sc: &mut Scratch,
    val: &[Sample],
    itos: &[String],
    _stoi: &std::collections::HashMap<String, usize>,
    s_img: f32,
    pad: usize,
    eos: usize,
    cw: f32,
) -> (f64, f64, usize) {
    let img_len = 3 * args.img_h * args.img_w;
    let b = args.batch.min(val.len()).min(8);
    let mut correct = 0usize;
    let mut n = 0usize;
    let mut cer_sum = 0.0f64;
    let (mut ref_len_sum, mut hyp_len_sum) = (0.0f64, 0.0f64);
    let mut loss = 0.0f64;
    for chunk in val.chunks(b) {
        let bb = chunk.len();
        let mut imgs = vec![0i8; bb * img_len];
        let mut refs = Vec::new();
        for (bi, s) in chunk.iter().enumerate() {
            match load_image_q(&s.path, args.img_h, args.img_w) {
                Some(q) => imgs[bi * img_len..(bi + 1) * img_len].copy_from_slice(&q),
                None => continue,
            };
            refs.push(s.tokens.clone());
        }
        if refs.len() != bb {
            continue;
        }
        let img_buf = Arc::new(DevBuf::new(imgs.len()));
        img_buf.upload_i8(&imgs, stream);
        let (feat, _tr) = model.cnn.forward(&img_buf, s_img, bb, false, args.img_h, args.img_w, stream, sc);
        let t = _tr.out.w_feat;
        let mut feat_h = vec![0.0f32; bb * t * model.cnn.fd];
        feat.download_f32(&mut feat_h, stream);
        stream.sync();
        let (enc, _rnn_tr) = model.rnn.forward(&feat_h, bb, t);
        let preds = model.attn.greedy_decode(&enc, bb, t, args.max_len);
        for (pred, ref_ids) in preds.iter().zip(refs.iter()) {
            let pred_s: String = pred.iter().map(|&i| token_str(itos, i)).collect();
            let ref_s: String = ref_ids.iter().map(|&i| token_str(itos, i)).collect();
            if pred_s == ref_s {
                correct += 1;
            }
            let a: Vec<char> = ref_s.chars().collect();
            let c: Vec<char> = pred_s.chars().collect();
            cer_sum += edit_distance(&a, &c) as f64 / a.len().max(1) as f64;
            ref_len_sum += a.len() as f64;
            hyp_len_sum += c.len() as f64;
            n += 1;
        }
        let _ = (pad, eos, cw, loss);
    }
    if n == 0 {
        return (f64::NAN, f64::NAN, 0);
    }
    let cer = cer_sum / n as f64 * 100.0;
    let acc = correct as f64 / n as f64 * 100.0;
    let (ref_len, hyp_len) = (ref_len_sum / n as f64, hyp_len_sum / n as f64);
    println!("   📊 val: acc {acc:.1}% | CER {cer:.1}% | n={n} | длина: эталон {ref_len:.1}, гипотеза {hyp_len:.1}");
    if cer > 100.0 {
        // CER = edit_distance / len(эталон) и НЕ ограничен сверху: если гипотеза
        // длиннее эталона, вставки дают больше 100%. Почти всегда это значит, что
        // --max-len сильно больше длины текста в датасете: декодер проходит все
        // шаги и не останавливается (ранний стоп не срабатывает, пока EOS не
        // выучен), а знаменатель при этом короткий.
        println!(
            "      ℹ️  CER выше 100% не ошибка метрики, а следствие того, что гипотеза в среднем длиннее эталона на {:.1} символов. Уменьшите --max-len до p99 длины текста + 2…4 (процентили печатает tools/yenisei_import.py) и перегенерируйте CSV тем же --max-len: строки длиннее него отбрасываются, а не обрезаются",
            hyp_len - ref_len
        );
    }
    // (CER %, точное совпадение %, число примеров) — по CER выбирается best.bin
    (cer, acc, n)
}

fn token_str(itos: &[String], i: usize) -> String {
    let s = &itos[i];
    if s.starts_with('<') {
        String::new()
    } else {
        s.clone()
    }
}

// ==========================================================================
//  MoPE — Mixture of Pretrained Experts (ZAYA1-8B, arXiv:2605.05365)
// ==========================================================================

use trba_rust::moe::{Candidate, ExpertBlob, ExpertSpec, quantize_expert};

/// Общий ГПСЧ для замыканий Markovian RSA: `markovian_rsa` и оба замыкания
/// (`generate`, `aggregate`) хотят менять один и тот же генератор, а Rust не
/// даёт два `&mut` сразу. Клонируемая обёртка над `Rc<RefCell<StdRng>>`
/// решает это без unsafe и без расхождения последовательностей.
#[derive(Clone)]
struct SharedRng(std::rc::Rc<std::cell::RefCell<rand::rngs::StdRng>>);

impl SharedRng {
    fn new(seed: u64) -> Self {
        use rand::SeedableRng;
        Self(std::rc::Rc::new(std::cell::RefCell::new(rand::rngs::StdRng::seed_from_u64(seed))))
    }
}

impl rand::RngCore for SharedRng {
    fn next_u32(&mut self) -> u32 {
        self.0.borrow_mut().next_u32()
    }
    fn next_u64(&mut self) -> u64 {
        self.0.borrow_mut().next_u64()
    }
    fn fill_bytes(&mut self, dest: &mut [u8]) {
        self.0.borrow_mut().fill_bytes(dest)
    }
    fn try_fill_bytes(&mut self, dest: &mut [u8]) -> Result<(), rand::Error> {
        self.0.borrow_mut().try_fill_bytes(dest)
    }
}

/// Кэш материализованных экспертов с вытеснением LRU. Эксперт — это ЦЕЛАЯ
/// модель, поэтому в VRAM/ОЗУ одновременно держим `cap` штук, а остальные
/// живут в int8-блобах (в 4 раза дешевле fp32).
struct ExpertCache {
    cap: usize,
    items: Vec<(usize, Model)>,
    swaps: usize,
}

impl ExpertCache {
    fn new(cap: usize) -> Self {
        Self { cap: cap.max(1), items: Vec::new(), swaps: 0 }
    }

    fn get(&mut self, i: usize, ctx: &ExpertCtx, stream: &CudaStream) -> &mut Model {
        if let Some(pos) = self.items.iter().position(|(k, _)| *k == i) {
            let it = self.items.remove(pos);
            self.items.insert(0, it);
            return &mut self.items[0].1;
        }
        self.swaps += 1;
        // Сначала освободить место, потом материализовать. Модель эксперта — это
        // fp32-веса + градиенты + Adam-моменты свёрток (~700 МБ на 43M параметров),
        // и при старом порядке «сначала новая, потом pop» пик памяти был cap+1
        // моделей вместо cap: при --mope-cache 1 в памяти жило два эксперта сразу.
        // На GPU это VRAM (10 ГБ у CMP 50HX), на CPU — ОЗУ, где запас меньше.
        let cap = self.cap.max(1);
        while self.items.len() >= cap {
            self.items.pop();
        }
        let m = materialize_expert(i, ctx, stream);
        self.items.insert(0, (i, m));
        &mut self.items[0].1
    }
}

/// Первые 8 байт файла — чтобы различать MOPEXP02 (fp32), MOPEBI01 (int8) и
    /// чекпоинты, не читая весь файл в память (бандл — десятки мегабайт).
fn file_magic(path: &str) -> Option<[u8; 8]> {
    use std::io::Read;
    let mut f = std::fs::File::open(path).ok()?;
    let mut m = [0u8; 8];
    f.read_exact(&mut m).ok()?;
    Some(m)
}

/// Чекпоинт → int8-блоб: симметричное квантование на тензор (та же
/// конвенция, что в `ConvQat`: шкала = max|w|/127, округление от нуля).
/// fp32-модель после этого освобождается — в памяти остаётся 1 байт на вес.
fn load_expert_blob(
    path: &str,
    args: &Args,
    classes: usize,
    sos: usize,
    eos: usize,
    pad: usize,
    stream: &CudaStream,
) -> Result<ExpertBlob> {
    let mut m = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, args.rnn_layers);
    let mut opt = Adam::new();
    let (meta, _) = load_checkpoint(path, &mut m, &mut opt, stream)?;
    let ps = m.params();
    let slices: Vec<&[f32]> = ps
        .iter()
        .map(|pr| unsafe { std::slice::from_raw_parts(pr.p as *const f32, pr.len) })
        .collect();
    // BN-статистика не входит в манифест обучаемых параметров, но без неё
    // инференс неверен, поэтому кладём её в блоб рядом (fp32, ~100 КБ).
    let mut bn = Vec::new();
    for c in m.cnn.convs_mut() {
        bn.extend_from_slice(&c.bn.run_mean);
        bn.extend_from_slice(&c.bn.run_var);
    }
    let name = format!("{path} (эпоха {})", meta.epoch_done);
    Ok(quantize_expert(&name, &slices).with_bn(bn))
}

/// Всё, что нужно, чтобы собрать рабочую модель эксперта: его собственная
/// геометрия, int8-веса, объединённый словарь MoPE и таблица перенумерации.
struct ExpertCtx {
    specs: Vec<ExpertSpec>,
    blobs: Vec<ExpertBlob>,
    /// общий словарь MoPE (0..2 = `<PAD> <SOS> <EOS>`)
    classes: usize,
    remap: Vec<Vec<i32>>,
}

/// int8-блоб → рабочая модель в геометрии И В СЛОВАРЕ ЭКСПЕРТА.
///
/// Все четыре vocab-тензора (`ctc.w`, `ctc.b`, `attn.gen.w`, `attn.gen.b`) и
/// teacher-forced нумерация `MopeFwd.ti/ty` живут в одной системе координат,
/// поэтому `teacher_ce` читает строки logits без смещения, а `attn.backward`
/// получает градиент ровно того размера, которого ждёт.
///
/// В общий словарь MoPE токены переносятся НА ГРАНИЦЕ: кандидаты после
/// `decode_full` проходят через `to_merged` (`ctx.remap[ei]`), а промпт
/// агрегатора, наоборот, собирается из нумерации эксперта (`merged.remap[cj]`).
///
/// Раньше модель собиралась сразу в общем словаре, и при РАЗНЫХ словарях
/// экспертов это ломалось трижды: (1) `teacher_ce` читала строки шириной
/// `spec.classes` из буфера шириной `ctx.classes` — молча, без паники, потому
/// что 41×68 < 40×70, и CE роутера становилась мусором; (2) `attn.backward`
/// падал с `range end index 2800 out of range for slice of length 2788`;
/// (3) строки, которых у эксперта нет, оставались после `remap_rows` нулевыми,
/// то есть эксперт мог «произнести» незнакомый ему символ с нулевым логитом.
fn materialize_expert(i: usize, ctx: &ExpertCtx, stream: &CudaStream) -> Model {
    let spec = &ctx.specs[i];
    let blob = &ctx.blobs[i];
    // спецтокены в словаре эксперта те же 0, 1, 2 (<PAD> <SOS> <EOS>)
    let mut m = Model::new_layers(spec.feat_dim, spec.hidden, spec.classes, 1, 2, 0, spec.rnn_layers);
    let ps = m.params();
    // По одному тензору: fp32-копия всех весов сразу не создаётся (экономия
    // ~180 МБ на пике). Длины обязаны совпадать — модель построена в словаре
    // эксперта, поэтому ни переноса строк, ни позиционного «наездова» нет.
    for (ti, pr) in ps.iter().enumerate() {
        let dst = unsafe { std::slice::from_raw_parts_mut(pr.p, pr.len) };
        let n = blob.dequantize_one(ti, dst);
        if n != pr.len {
            eprintln!(
                "   ⚠️  {} [{}]: в блобе {} чисел против {} в модели — тензор останется инициализированным",
                spec.name, pr.name, n, pr.len
            );
        }
    }
    let mut pos = 0usize;
    for c in m.cnn.convs_mut() {
        let n = c.bn.run_mean.len();
        if pos + 2 * n <= blob.bn.len() {
            c.bn.run_mean.copy_from_slice(&blob.bn[pos..pos + n]);
            c.bn.run_var.copy_from_slice(&blob.bn[pos + n..pos + 2 * n]);
        }
        pos += 2 * n;
    }
    m.cnn.requantize_all(stream);
    m
}

/// Токены эксперта → общий словарь MoPE. Граница, на которой кандидат
/// становится понятен RSA, агрегатору и печати через `merged.itos`: незнакомые
/// общему словарю индексы (их не бывает, но защита дешёвая) отбрасываются.
fn to_merged(tokens: &[usize], remap: &[i32]) -> Vec<usize> {
    tokens
        .iter()
        .filter_map(|&t| remap.get(t).copied())
        .filter(|&m| m >= 0)
        .map(|m| m as usize)
        .collect()
}

/// CNN + BiLSTM одного эксперта для одной строки: возвращает признаки
/// `feat [T, fd]` (fd — ширина энкодера ЭТОГО эксперта) и выход `enc [T, hidden]`. Картинка уже лежит на
/// устройстве (`img`), поэтому E экспертов не гоняют её по PCIe повторно.
fn expert_encode(
    m: &mut Model,
    img: &std::sync::Arc<DevBuf>,
    s_img: f32,
    img_h: usize,
    img_w: usize,
    sc: &mut Scratch,
    stream: &CudaStream,
) -> (Vec<f32>, Vec<f32>, usize) {
    let (fb, tr) = m.cnn.forward(img, s_img, 1, false, img_h, img_w, stream, sc);
    let t = tr.out.w_feat;
    let fd = m.cnn.fd; // ширина признака ЭТОГО эксперта, а не базовая 512
    let mut feat = vec![0.0f32; t * fd];
    fb.download_f32(&mut feat, stream);
    stream.sync();
    let (enc, _) = m.rnn.forward(&feat, 1, t);
    (feat, enc, t)
}

/// Признак для роутера: mean ⊕ max пул по времени → [2·c]. Это аналог
/// `x_l` из уравнения (1): одна точка residual-потока на строку. `c` — ширина
/// базового признака MoPE (`--feat-dim`), а не жёсткие 512.
fn pool_feat(feat: &[f32], t: usize, c: usize) -> Vec<f32> {
    let w = c.max(1);
    let mut x = vec![0.0f32; 2 * w];
    if t == 0 {
        return x;
    }
    for i in 0..t {
        for k in 0..w {
            let v = feat[i * w + k];
            x[k] += v / t as f32;
            if v > x[w + k] || i == 0 {
                x[w + k] = v;
            }
        }
    }
    x
}

fn cand_text(c: &Candidate, itos: &[String], pad: usize, eos: usize) -> String {
    let mut s = String::new();
    for &k in &c.tokens {
        if k == pad || k == eos {
            continue;
        }
        s.push_str(&token_str(itos, k));
    }
    s
}


/// Локальный чекпоинт trba-rust → переносимый бандл MoPE (тот же формат, что
/// пишет `tools/mope_import.py` из ONNX/PyTorch Кожина). После этого любой
/// эксперт собирается из одного файла, независимо от происхождения.
fn run_export_bundle(args: &Args, itos: &[String], stoi: &std::collections::HashMap<String, usize>) -> Result<()> {
    use trba_rust::moe::*;
    let classes = itos.len();
    let (pad, sos, eos) = (stoi["<PAD>"], stoi["<SOS>"], stoi["<EOS>"]);
    let stream = CudaStream::new();
    let path = match &args.resume {
        Some(p) if !p.is_empty() => p.clone(),
        _ => {
            let best = format!("{}/best.bin", args.exp_dir);
            if Path::new(&best).exists() {
                best
            } else {
                newest_checkpoint(&args.exp_dir)
            }
        }
    };
    let mut m = Model::new_layers(args.feat_dim, args.hidden, classes, sos, eos, pad, 2);
    let mut opt = Adam::new();
    if path.is_empty() || !Path::new(&path).exists() {
        println!("⚠️  чекпоинт не найден — бандл будет со случайными весами (проверка формата)");
    } else {
        let (meta, _) = load_checkpoint(&path, &mut m, &mut opt, &stream)?;
        println!("📖 {path}: эпоха {}", meta.epoch_done);
    }
    let mut tensors = Vec::new();
    let ps = m.params();
    for pr in ps.iter() {
        let v = unsafe { std::slice::from_raw_parts(pr.p as *const f32, pr.len) }.to_vec();
        tensors.push((pr.name.clone(), v));
    }
    for c in m.cnn.convs_mut() {
        let n = c.name.clone();
        tensors.push((format!("{n}.run_mean"), c.bn.run_mean.clone()));
        tensors.push((format!("{n}.run_var"), c.bn.run_var.clone()));
    }
    let spec = ExpertSpec {
        name: Path::new(&args.exp_dir)
            .file_name()
            .map(|x| x.to_string_lossy().into_owned())
            .unwrap_or_else(|| "trba-rust".to_string()),
        source: if path.is_empty() { "random".to_string() } else { path.clone() },
        kind: "trba-rust-bin".to_string(),
        img_h: args.img_h,
        img_w: args.img_w,
        max_len: args.max_len,
        hidden: args.hidden,
        feat_dim: args.feat_dim,
        classes,
        pad,
        sos,
        eos,
        rnn_layers: 2,
    };
    let bun = ExpertBundle { spec: spec.clone(), charset: itos.to_vec(), tensors };
    if args.mope_int8 {
        // Квантуем тем же путём, каким рантайм квантует fp32-бандл при загрузке
        // (bundle_to_blob, симметрично на тензор), поэтому распознавание с
        // int8-бандлом совпадает с fp32-бандлом, а файл вчетверо меньше.
        let blob = bundle_to_blob(&bun, &stream)?;
        let n = write_blob(&args.mope_export_bundle, &bun.spec, &bun.charset, &blob)?;
        println!(
            "💾 {} (int8 MOPEBI01): {:.2} МБ вместо {:.2} МБ fp32, {} параметров, {} тензоров",
            args.mope_export_bundle,
            n as f64 / 1e6,
            bun.bytes() as f64 / 1e6,
            bun.params(),
            bun.tensors.len()
        );
    } else {
        let n = write_bundle(&args.mope_export_bundle, &bun)?;
        println!("💾 {}: {:.2} МБ, {} параметров, {} тензоров", args.mope_export_bundle, n as f64 / 1e6, bun.params(), bun.tensors.len());
    }
    println!("   {}", spec.report());
    Ok(())
}

/// Бандл (ONNX/PyTorch Кожина) → int8-блоб в собственной геометрии эксперта.
fn bundle_to_blob(bun: &trba_rust::moe::ExpertBundle, stream: &CudaStream) -> Result<ExpertBlob> {
    use trba_rust::moe::*;
    let spec = &bun.spec;
    let mut m = Model::new_layers(spec.feat_dim, spec.hidden, spec.classes, spec.sos, spec.eos, spec.pad, spec.rnn_layers);
    let ps = m.params();
    let mut applied = 0usize;
    let mut skipped: Vec<String> = Vec::new();
    for pr in ps.iter() {
        match bun.get(&pr.name) {
            Some(v) if v.len() == pr.len => {
                unsafe { std::ptr::copy_nonoverlapping(v.as_ptr(), pr.p, pr.len) };
                applied += 1;
            }
            Some(v) => skipped.push(format!("{} (в бандле {} против {})", pr.name, v.len(), pr.len)),
            None => skipped.push(pr.name.clone()),
        }
    }
    // BN-статистика: в бандле она лежит отдельными тензорами по именам свёрток
    let mut bn = Vec::new();
    for c in m.cnn.convs_mut() {
        let n = c.name.clone();
        if let Some(v) = bun.get(&format!("{n}.run_mean")) {
            let k = v.len().min(c.bn.run_mean.len());
            c.bn.run_mean[..k].copy_from_slice(&v[..k]);
        }
        if let Some(v) = bun.get(&format!("{n}.run_var")) {
            let k = v.len().min(c.bn.run_var.len());
            c.bn.run_var[..k].copy_from_slice(&v[..k]);
        }
        bn.extend_from_slice(&c.bn.run_mean);
        bn.extend_from_slice(&c.bn.run_var);
    }
    m.cnn.requantize_all(stream);
    println!(
        "   {} → перенесено {} тензоров манифеста, пропущено {}",
        spec.name,
        applied,
        skipped.len()
    );
    if !skipped.is_empty() {
        let shown: Vec<&str> = skipped.iter().take(8).map(|s| s.as_str()).collect();
        println!("      ⚠️  без весов (останется инициализация): {shown:?}{}", if skipped.len() > 8 { " …" } else { "" });
    }
    let slices: Vec<&[f32]> = {
        let ps2 = m.params();
        ps2.iter().map(|pr| unsafe { std::slice::from_raw_parts(pr.p as *const f32, pr.len) }).collect()
    };
    Ok(quantize_expert(&spec.name, &slices).with_bn(bn))
}

/// Нативный чекпоинт trba-rust → int8-блоб.
fn native_to_blob(path: &str, spec: &trba_rust::moe::ExpertSpec, stream: &CudaStream) -> Result<ExpertBlob> {
    use trba_rust::moe::*;
    let mut m = Model::new_layers(spec.feat_dim, spec.hidden, spec.classes, spec.sos, spec.eos, spec.pad, spec.rnn_layers);
    let mut opt = Adam::new();
    let (meta, _) = load_checkpoint(path, &mut m, &mut opt, stream)?;
    println!("   {} → чекпоинт, эпоха {}", spec.name, meta.epoch_done);
    let mut bn = Vec::new();
    for c in m.cnn.convs_mut() {
        bn.extend_from_slice(&c.bn.run_mean);
        bn.extend_from_slice(&c.bn.run_var);
    }
    let slices: Vec<&[f32]> = {
        let ps = m.params();
        ps.iter().map(|pr| unsafe { std::slice::from_raw_parts(pr.p as *const f32, pr.len) }).collect()
    };
    Ok(quantize_expert(path, &slices).with_bn(bn))
}

/// `--mope`: распознавание смесью предобученных экспертов РАЗНОГО происхождения.
///
/// Источники экспертов (можно вперемешку, в одном запуске):
///   * `base.mope`  — бандл из `trba_base_g1.onnx`/`.pth` Кожина
///     (64×256, 1 слой BiLSTM, 194 токена дореформенной орфографии);
///   * `exp/checkpoint_last.bin` — чекпоинт trba-rust (32×128, 2 слоя, свой
///     charset.txt, например куррентшрифт с умляутами).
///
/// Разные размерности дружатся так: каждый эксперт считает в СВОЕЙ геометрии,
/// а в общее пространство MoPE его переводят обучаемые адаптеры (тождественные
/// при совпадении размеров). Словари мёржатся в один с отсечкой редких
/// символов, строки выходных проекций переносятся через remap.
fn run_mope(args: &Args, itos: &[String], _stoi: &std::collections::HashMap<String, usize>) -> Result<()> {
    use trba_rust::moe::*;
    let stream = CudaStream::new();
    let paths: Vec<String> = args
        .mope_experts
        .split(',')
        .map(|s| s.trim().to_string())
        .filter(|s| !s.is_empty())
        .collect();
    if paths.is_empty() {
        return Err(anyhow!(
            "--mope требует --mope-experts: например base.mope,exp/checkpoint_last.bin (один файл = один писарь)"
        ));
    }

    // ---------- 1. геометрия и словари каждого эксперта ----------
    let mut specs: Vec<ExpertSpec> = Vec::new();
    let mut charsets: Vec<Vec<String>> = Vec::new();
    let mut bundles: Vec<Option<ExpertBundle>> = Vec::new();
    // int8-бандл (MOPEBI01) нечего квантовать: блоб достаётся как есть, без
    // fp32-копии и без прохода квантования (−172 МБ пика и −2 с на эксперта).
    let mut direct: Vec<Option<ExpertBlob>> = Vec::new();
    for p in &paths {
        if p.ends_with(".mope") {
            match file_magic(p) {
                Some(m) if &m == BLOB_MAGIC => {
                    let (spec, cs, blob) =
                        read_blob(p).map_err(|e| anyhow!("не читается int8-бандл {p}: {e}"))?;
                    println!("📦 {}", blob_report(&spec, &blob));
                    charsets.push(cs);
                    specs.push(spec);
                    bundles.push(None);
                    direct.push(Some(blob));
                }
                _ => {
                    let b = read_bundle(p).map_err(|e| anyhow!("не читается бандл {p}: {e}"))?;
                    println!("📦 {}", b.spec.report());
                    charsets.push(b.charset.clone());
                    specs.push(b.spec.clone());
                    bundles.push(Some(b));
                    direct.push(None);
                }
            }
        } else {
            let cs = itos.to_vec();
            let name = Path::new(p).file_stem().map(|x| x.to_string_lossy().into_owned()).unwrap_or_else(|| p.clone());
            println!(
                "📦 {name} [trba-rust-bin] img {}×{} max_len {} hidden {} feat {} классов {} rnn 2",
                args.img_h, args.img_w, args.max_len, args.hidden, args.feat_dim, cs.len()
            );
            specs.push(ExpertSpec {
                name,
                source: p.clone(),
                kind: "trba-rust-bin".to_string(),
                img_h: args.img_h,
                img_w: args.img_w,
                max_len: args.max_len,
                hidden: args.hidden,
                feat_dim: args.feat_dim,
                classes: cs.len(),
                pad: 0,
                sos: 1,
                eos: 2,
                rnn_layers: 2,
            });
            charsets.push(cs);
            bundles.push(None);
            direct.push(None);
        }
    }
    let e = specs.len();
    for i in 1..e {
        for d in specs[i].diff(&specs[0]) {
            println!("   ⇄ эксперт {} отличается от 0: {d}", i);
        }
    }

    // ---------- 2. слияние словарей с отсечкой редких символов ----------
    ssl_init(&args);
    let corpus: Vec<String> = args.mope_char_counts.split(',').map(|s| s.trim().to_string()).filter(|s| !s.is_empty()).collect();
    let counts: Vec<Vec<u64>> = charsets
        .iter()
        .map(|cs| {
            if corpus.is_empty() {
                Vec::new()
            } else {
                let mut acc = vec![0u64; cs.len()];
                for p in &corpus {
                    match count_charset_in_file(p, cs) {
                        Ok(c) => {
                            for i in 0..acc.len() {
                                acc[i] += c[i];
                            }
                        }
                        Err(err) => println!("   ⚠️  корпус {p} не читается: {err}"),
                    }
                }
                // Нулевая частота почти всегда означает, что --mope-char-counts
                // указывает не на тот корпус, на котором обучался эксперт (например,
                // на его первые 20 000 строк из 109 570), а не что символ редкий.
                // Отсеять такой токен — значит навсегда запретить эксперту его
                // выдавать: CE платит ln(classes), а в расшифровке символа не будет.
                // Именно так терялись дореформенные «Ѣ», «І», «і» и «Ц», «Ы», «+».
                // Помечаем нули как «непроверенные» (u64::MAX / 2) — merge_charsets
                // такие сохраняет, а порог частоты применяется только к реальным
                // наблюдениям. Специальные токены (0..3) в тексте не встречаются
                // никогда, поэтому в отчёт не попадают.
                let zeros: Vec<usize> =
                    (3..acc.len()).filter(|&i| acc[i] == 0).collect();
                if !zeros.is_empty() {
                    let shown: Vec<String> = zeros
                        .iter()
                        .take(12)
                        .map(|&i| cs.get(i).cloned().unwrap_or_default())
                        .collect();
                    println!(
                        "   ℹ️  {} токен(ов) эксперта не встретились в --mope-char-counts: оставлены как непроверенные → {:?} (порог частоты к ним не применяется). Если это не ожидаемо — корпус не соответствует обучению эксперта",
                        zeros.len(),
                        shown
                    );
                }
                for v in acc.iter_mut() {
                    if *v == 0 {
                        *v = u64::MAX / 2;
                    }
                }
                acc
            }
        })
        .collect();
    let merged = merge_charsets(&charsets, &counts, args.mope_min_freq, args.mope_charset_max);
    println!("🔤 {}", merged.report());
    if !args.mope_charset_out.is_empty() {
        std::fs::write(&args.mope_charset_out, merged.itos.join("\n") + "\n")?;
        println!("   💾 объединённый charset: {} ({} токенов)", args.mope_charset_out, merged.len());
    }
    let classes = merged.len();

    // ---------- 3. веса → int8-хранилище ----------
    let t0 = std::time::Instant::now();
    let mut blobs = Vec::new();
    for i in 0..e {
        blobs.push(match direct[i].take() {
            Some(b) => b,
            None => match bundles[i].take() {
                Some(b) => bundle_to_blob(&b, &stream)?,
                None => native_to_blob(&paths[i], &specs[i], &stream)?,
            },
        });
    }
    let n_direct = direct.iter().filter(|d| d.is_some()).count();
    println!(
        "🧠 MoPE: {e} экспертов → int8 за {:.1} с ({} МБ/шт, {} параметров{})",
        t0.elapsed().as_secs_f64(),
        blobs[0].q.len() / 1_000_000,
        blobs[0].params(),
        if n_direct > 0 {
            format!(", из них {n_direct} уже были в int8")
        } else {
            String::new()
        }
    );
    println!("   {}", memory_report_for(args, e, blobs[0].params()));
    if args.mope_c > args.mope_n.max(1) {
        println!("   ⚠️  C не может превышать N (C ≤ N в §VI) — взял C = {}", args.mope_n.max(1));
    }

    // ---------- 4. конфигурация RSA ----------
    let mut cfg = MopeCfg {
        experts: paths.clone(),
        top_k: args.mope_top_k.clamp(1, e),
        router_latent: ROUTER_LATENT,
        rsa: RsaCfg {
            n: args.mope_n.max(1),
            c: args.mope_c.max(1).min(args.mope_n.max(1)),
            t_rounds: args.mope_t,
            beta: specs.iter().map(|s| s.max_len).max().unwrap_or(args.max_len).max(1),
            tau: args.mope_tau.clamp(1, args.max_len.max(1)),
            temperature: args.mope_temperature,
            top_p: args.mope_top_p,
        },
        vram_cache: args.mope_cache.max(1),
        balance_lr: args.mope_balance_lr,
        balance_wd: 0.0,
        target_temperature: 0.5,
    };
    cfg.validate().map_err(|x| anyhow!(x))?;
    if let Some(w) = cfg.rsa.warn_long_tail() {
        println!("⚠️  {w}");
    }
    println!(
        "🔀 RSA: N={} C={} T={} τ={} β={} top-k={} temperature={} top-p={}",
        cfg.rsa.n, cfg.rsa.c, cfg.rsa.t_rounds, cfg.rsa.tau, cfg.rsa.beta, cfg.top_k, cfg.rsa.temperature, cfg.rsa.top_p
    );

    let files: Vec<String> = collect_infer_inputs(&args.train_csv).into_iter().take(args.mope_limit.max(1)).collect();
    if files.is_empty() {
        return Err(anyhow!("нет картинок по пути {}", args.train_csv));
    }

    // ---------- 5. роутер, агрегатор, адаптеры ----------
    let hidden_common = specs[0].hidden;
    let d_pool = 2 * args.feat_dim;
    let mut router = RouterMlp::new(d_pool, cfg.router_latent, e);
    let mut pid = PidBias::new(e);
    let mut agg = Aggregator::new(classes, hidden_common, hidden_common, args.feat_dim, cfg.rsa.c, cfg.rsa.tau);
    // адаптеры: признаки эксперта → общее пространство роутера и контекст
    // агрегации → память конкретного эксперта. При совпадении размеров они
    // тождественны и не тратят ни времени, ни точности.
    let mut feat_ad: Vec<Adapter> = specs.iter().map(|sp| Adapter::new(sp.feat_dim, args.feat_dim)).collect();
    let mut ctx_ad: Vec<Adapter> = specs.iter().map(|sp| Adapter::new(hidden_common, sp.hidden)).collect();
    let n_adapt: usize = feat_ad.iter().chain(ctx_ad.iter()).filter(|a| !a.is_identity()).count();
    if n_adapt > 0 {
        println!("🔗 адаптеров размерностей: {n_adapt} (обучаемые, инициализированы тождественно/достройкой)");
    }
    let mut agg_trained = if !args.mope_agg.is_empty() {
        match load_aggregator(&args.mope_agg, &mut agg) {
            Ok(true) => {
                println!("📦 агрегатор загружен из {}", args.mope_agg);
                true
            }
            Ok(false) => {
                println!("⚠️  {} не подходит по размерам — агрегатор со случайными весами", args.mope_agg);
                false
            }
            Err(err) => {
                println!("⚠️  агрегатор не загружен ({err})");
                false
            }
        }
    } else {
        false
    };
    // Загружено ли обученное состояние (роутер и/или весь Franken-контейнер).
    // От этого зависит, доучивается ли роутер на инференсе.
    let mut state_loaded = false;
    if !args.mope_router.is_empty() {
        match load_router(&args.mope_router, &mut router) {
            Ok(Some(p)) => {
                pid = p;
                state_loaded = true;
                println!("📦 роутер загружен из {} (шагов PID: {})", args.mope_router, pid.t);
            }
            Ok(None) => println!("⚠️  {} не подходит по размерам — роутер инициализирован заново", args.mope_router),
            Err(err) => println!("⚠️  роутер не загружен ({err})"),
        }
    }
    let mut router_opt = RouterAdam::new(&router);

    let ctx = std::rc::Rc::new(ExpertCtx {
        specs: specs.clone(),
        blobs,
        classes,
        remap: merged.remap.clone(),
    });
    let cache = std::rc::Rc::new(std::cell::RefCell::new(ExpertCache::new(cfg.vram_cache)));
    let agg = std::rc::Rc::new(std::cell::RefCell::new(agg));
    let rng = SharedRng::new(args.seed as u64);
    // ОДИН Scratch на весь прогон: пул воркспейсов CPU-бэкенда не возвращает
    // память ОС, поэтому новый Scratch на каждого кандидата только раздувал пик.
    let scratch = std::rc::Rc::new(std::cell::RefCell::new(Scratch::new()));

    // ---------- 5b. обученное состояние Franken-MoPE и его оптимизаторы ----------
    let mut franken_steps = 0u64;
    let mut agg_opt = FlatAdam::new(&agg.borrow().adam_shapes());
    let mut ad_opt = FlatAdam::new(&adapter_shapes(&feat_ad, &ctx_ad));
    if !args.mope_franken.is_empty() {
        match load_franken(&args.mope_franken) {
            Ok(f) => {
                println!("📦 {}", franken_report(&f, e));
                // MOPEFR02 несёт геометрию раундов RSA: подставляем её, если своих
                // флагов пользователь не задавал. Именно это снимает предупреждение
                // «агрегатор обучен на промпте C=2·τ=8, а запрошено C=4·τ=4» как класс.
                if let Some(rs) = &f.rsa {
                    if args.rsa_user_set {
                        if (rs.n, rs.c, rs.t_rounds, rs.beta, rs.tau)
                            != (cfg.rsa.n, cfg.rsa.c, cfg.rsa.t_rounds, cfg.rsa.beta, cfg.rsa.tau)
                        {
                            println!(
                                "   ⚠️  в файле геометрия раундов N={} C={} T={} β={} τ={}, но заданы свои RSA-флаги — работаем с вашими N={} C={} T={} β={} τ={}",
                                rs.n, rs.c, rs.t_rounds, rs.beta, rs.tau,
                                cfg.rsa.n, cfg.rsa.c, cfg.rsa.t_rounds, cfg.rsa.beta, cfg.rsa.tau
                            );
                        }
                    } else {
                        cfg.rsa.n = rs.n;
                        cfg.rsa.c = rs.c;
                        cfg.rsa.t_rounds = rs.t_rounds;
                        cfg.rsa.beta = rs.beta;
                        cfg.rsa.tau = rs.tau;
                        cfg.rsa.temperature = rs.temperature;
                        cfg.rsa.top_p = rs.top_p;
                        println!(
                            "   🔀 геометрия раундов из файла: N={} C={} T={} β={} τ={} temperature={} (свои RSA-флаги не заданы)",
                            rs.n, rs.c, rs.t_rounds, rs.beta, rs.tau, rs.temperature
                        );
                    }
                } else {
                    println!("   ℹ️  файл MOPEFR01 без геометрии раундов: остаются значения из флагов/по умолчанию (N={} C={} T={} τ={})", cfg.rsa.n, cfg.rsa.c, cfg.rsa.t_rounds, cfg.rsa.tau);
                }
                if f.itos.len() != classes {
                    println!(
                        "   ⚠️  словарь в файле ({} токенов) отличается от пересчитанного ({classes}): проверьте --mope-min-freq, --mope-charset-max и --mope-char-counts — они должны совпадать с обучением",
                        f.itos.len()
                    );
                }
                if f.router.e == e && f.router.d_in == d_pool && f.agg.classes == classes {
                    let shapes = f.agg.adam_shapes();
                    // Ёмкость промпта закладывается при обучении (C·τ). embed()
                    // на более длинном промпте не падает, а тихо прижимает
                    // сегмент и позицию к последним — лучше сказать об этом
                    // сразу, иначе раунды агрегации молча деградируют.
                    if f.agg.max_c < cfg.rsa.c || f.agg.max_tau < cfg.rsa.tau {
                        println!(
                            "   ⚠️  агрегатор обучен на промпте C={}·τ={}, а запрошено C={}·τ={}: лишние сегменты/позиции будут прижаты к последним. Либо уменьшите --mope-c/--mope-tau, либо дообучите с ними же",
                            f.agg.max_c, f.agg.max_tau, cfg.rsa.c, cfg.rsa.tau
                        );
                    }
                    router = f.router;
                    pid = f.pid;
                    *agg.borrow_mut() = f.agg;
                    if f.feat_ad.len() == e {
                        feat_ad = f.feat_ad;
                    }
                    if f.ctx_ad.len() == e {
                        ctx_ad = f.ctx_ad;
                    }
                    franken_steps = f.steps;
                    agg_opt = f.opt.unwrap_or_else(|| FlatAdam::new(&shapes));
                    ad_opt = FlatAdam::new(&adapter_shapes(&feat_ad, &ctx_ad));
                    router_opt = RouterAdam::new(&router);
                    // Состояние из franken.bin получено --mope-train, то есть
                    // агрегатор уже обучен: предупреждение про случайные раунды
                    // здесь было бы ложным.
                    agg_trained = true;
                    state_loaded = true;
                    println!(
                        "   ✅ роутер, PID-балансировка, агрегатор (CCA + Res-scale) и адаптеры подставлены из файла ({} шагов обучения позади)",
                        franken_steps
                    );
                } else {
                    println!(
                        "   ⚠️  размеры не совпали (роутер {}→{} на {} экспертов, агрегатор на {} классов, нужно {} / {} / {e} / {classes}) — работаем с тем, что было",
                        f.router.d_in, f.router.r, f.router.e, f.agg.classes, d_pool, ROUTER_LATENT
                    );
                }
            }
            Err(err) => println!("⚠️  Franken-файл {} не загружен: {err}", args.mope_franken),
        }
    }

    // ---------- 6. ДООБУЧЕНИЕ: роутер + агрегатор + CCA + Res-scale + адаптеры ----------
    if args.mope_train {
        use rand::seq::SliceRandom;
        use rand::SeedableRng;
        if args.mope_target != "soft" && args.mope_target != "hard" {
            println!("⚠️  --mope-target {} не бывает: soft (цель = softmax(-лосс/T)) или hard (один победитель) — беру soft", args.mope_target);
        }
        let hard_target = args.mope_target == "hard";
        let max_len = args.max_len.max(1);
        let steps = max_len + 1;
        {
            let own: Vec<usize> = specs
                .iter()
                .map(|s| trba_rust::moe::expert_steps(s.max_len, steps) - 1)
                .collect();
            if own.windows(2).any(|w| w[0] != w[1]) || own.first().map(|&v| v != max_len).unwrap_or(false) {
                println!(
                    "   📏 длина прогона по экспертам: {:?} шагов (потолок --max-len {max_len}); корзины разной длины смешиваются, каждый декодирует свою длину",
                    own
                );
            }
        }
        let (train_set, skipped) = load_csv(&args.train_csv, &merged.stoi, max_len);
        if train_set.is_empty() {
            return Err(anyhow!(
                "--mope-train: в {} нет ни одной размеченной строки. Нужен CSV «путь,текст», а словарь должен покрывать текст (--mope-char-counts, --mope-min-freq)",
                args.train_csv
            ));
        }
        let val_set: Vec<Sample> = match &args.val_csv {
            Some(p) if !p.is_empty() => load_csv(p, &merged.stoi, max_len).0,
            _ => Vec::new(),
        };
        // общий токен -> токен эксперта (-1 = символа у эксперта нет)
        let mut inv: Vec<Vec<i32>> = vec![vec![-1i32; classes]; e];
        for i in 0..e {
            for (old, &new) in merged.remap[i].iter().enumerate() {
                if new >= 0 && (new as usize) < classes {
                    inv[i][new as usize] = old as i32;
                }
            }
        }
        let (beta, tau) = (cfg.rsa.beta, cfg.rsa.tau);
        let cc = cfg.rsa.c.clamp(1, e);
        let epochs = args.epochs.max(1);
        println!(
            "🎓 дообучение Franken-MoPE: {} обучающих строк (пропущено {skipped}), {} контрольных, {} шагов декодера, {} эпох",
            train_set.len(),
            val_set.len(),
            steps,
            epochs
        );
        println!(
            "   учатся: роутер (lr {}, цель {}) · PID-балансировка (lr {}) · агрегатор+CCA+Res-scale (lr {}) · адаптеры размерностей ({})",
            args.mope_lr,
            if hard_target { "hard" } else { "soft" },
            cfg.balance_lr,
            args.mope_agg_lr,
            if n_adapt == 0 { "все тождественны — не тратят время".to_string() } else { format!("{n_adapt} шт. обучаемых") }
        );
        println!(
            "   эксперты ЗАМОРОЖЕНЫ: {} параметров в int8, их веса оптимизатором не трогаются (учитель — настоящая разметка)",
            ctx.blobs.iter().map(|b| b.params()).sum::<usize>()
        );
        // `--mope-limit` по умолчанию 4 — это «быстрый просмотр» для инференса.
        // В обучении такой дефолт молча резал бы датасет до четырёх строк, поэтому
        // здесь лимит действует ТОЛЬКО если пользователь задал его явно.
        let train_cap = if args.mope_limit_set { args.mope_limit } else { 0 };
        if train_cap > 0 && train_cap < train_set.len() {
            println!(
                "   ⚠️ --mope-limit {}: дообучение пойдёт по {} строкам из {} (снимите флаг или задайте 0, чтобы учить на всём датасете)",
                train_cap, train_cap.min(train_set.len()), train_set.len()
            );
        }
        let mut cum_loads = vec![0.0f64; e];
        let t_train = std::time::Instant::now();
        for epoch in 1..=epochs {
            let mut order: Vec<usize> = (0..train_set.len()).collect();
            {
                let mut r = rand::rngs::StdRng::seed_from_u64(
                    (args.seed as u64).wrapping_mul(0x9E37_79B9_7F4A_7C15).wrapping_add(epoch as u64),
                );
                order.shuffle(&mut r);
            }
            if train_cap > 0 {
                order.truncate(train_cap.min(order.len()));
            }
            let t_ep = std::time::Instant::now();
            let (mut rl_s, mut al_s, mut pick_s, mut oracle_s) = (0.0f64, 0.0f64, 0.0f64, 0.0f64);
            let (mut n_ep, mut n_agg, mut hit) = (0usize, 0usize, 0usize);
            let mut ep_loads = vec![0.0f64; e];
            for &idx in &order {
                let smp = &train_set[idx];
                let fw = mope_forward_all(&smp.path, &smp.tokens, steps, e, &inv, &specs, &ctx, &cache, &scratch, &stream);
                let oracle = match mope_oracle(&fw.losses) {
                    Some(o) => o,
                    None => {
                        println!("   ⚠️  {} — ни один эксперт не смог прочитать строку, пропуск", smp.path);
                        continue;
                    }
                };
                let fin: Vec<f32> = fw.losses.iter().map(|l| if l.is_finite() { *l as f32 } else { 1e3 }).collect();

                // --- (1) роутер: цель «от всех моделей беря лучшее», но по настоящему учителю
                let feat512 = if feat_ad[0].is_identity() { fw.feat0.clone() } else { feat_ad[0].forward(&fw.feat0, fw.t_feat0) };
                let x = pool_feat(&feat512, fw.t_feat0, args.feat_dim);
                let target = if hard_target { targets_from_best(&fin) } else { targets_from_losses(&fin, cfg.target_temperature) };
                router.zero_grad();
                let tr = router.forward(&x, 1, None);
                let picked = router.select(&tr.s, cfg.top_k);
                let rl = router.backward(&tr, &x, None, &target);
                router_opt.step(&mut router, args.mope_lr, 1e-4);
                cum_loads[picked[0]] += 1.0;
                ep_loads[picked[0]] += 1.0;
                pid.step(&mut router.bias, &cum_loads, cfg.balance_lr, cfg.balance_wd);
                if picked[0] == oracle {
                    hit += 1;
                }
                pick_s += if fw.losses[picked[0]].is_finite() { fw.losses[picked[0]] } else { 0.0 };
                oracle_s += fw.losses[oracle];
                rl_s += rl as f64;
                n_ep += 1;

                // --- (2) агрегатор: промпт из хвостов кандидатов (как в инференсе),
                //     учитель — настоящая разметка через teacher-forced декод с
                //     подмешанным контекстом агрегации.
                let ei = picked[0];
                if fw.ts[ei] == 0 {
                    continue;
                }
                let mut prompt: Vec<usize> = Vec::new();
                {
                    let mut rng_t = rng.clone();
                    for j in 0..cc {
                        let cj = *picked.get(j).unwrap_or(&picked[0]);
                        if fw.ts[cj] == 0 {
                            continue;
                        }
                        let toks = {
                            let mut c = cache.borrow_mut();
                            let m = c.get(cj, &ctx, &stream);
                            m.attn
                                .decode_full(&fw.encs[cj], 1, fw.ts[cj], beta.min(specs[cj].max_len.max(1)), true, cfg.rsa.temperature, cfg.rsa.top_p, Some(&mut rng_t))
                                .0
                                .into_iter()
                                .next()
                                .unwrap_or_default()
                        };
                        // нумерация эксперта -> общий словарь (выброшенные символы не попадают в промпт)
                        let mapped: Vec<usize> = toks
                            .into_iter()
                            .filter_map(|t| {
                                let n = merged.remap[cj].get(t).copied().unwrap_or(-1);
                                if n >= 0 {
                                    Some(n as usize)
                                } else {
                                    None
                                }
                            })
                            .collect();
                        let n = mapped.len();
                        prompt.extend_from_slice(if n > tau { &mapped[n - tau..] } else { &mapped });
                    }
                }
                if prompt.is_empty() {
                    continue;
                }
                let atr = {
                    let mut a = agg.borrow_mut();
                    a.zero_grad();
                    a.forward(&prompt, tau, &feat512, fw.t_feat0)
                };
                let ctx_e = if ctx_ad[ei].is_identity() { atr.ctx.clone() } else { ctx_ad[ei].forward(&atr.ctx, 1) };
                let mut enc_aug = Vec::with_capacity(ctx_e.len() + fw.encs[ei].len());
                enc_aug.extend_from_slice(&ctx_e);
                enc_aug.extend_from_slice(&fw.encs[ei]);
                let d_ctx_e = {
                    let mut c = cache.borrow_mut();
                    let m = c.get(ei, &ctx, &stream);
                    m.attn.zero_grad();
                    let (logits, dtr) = m.attn.forward_train(&enc_aug, std::slice::from_ref(&fw.ti[ei]), 1, fw.ts[ei] + 1);
                    // строк в logits ровно столько, сколько вернул декодер:
                    // attn.backward индексирует d_logits как [b*rows, classes],
                    // поэтому размер градиента обязан быть logits.len()
                    let rows = logits.len() / specs[ei].classes.max(1);
                    let (l, mut d_logits, npos) = teacher_ce(&logits, &fw.ty[ei], rows, specs[ei].classes, 0);
                    let sc = 1.0 / npos.max(1) as f32;
                    for z in d_logits.iter_mut() {
                        *z *= sc;
                    }
                    // d(batch_h) [1, T+1, C]: нулевой шаг памяти — это контекст агрегации
                    let d_bh = m.attn.backward(&d_logits, &dtr);
                    al_s += trba_rust::moe::penalized_ce(l, npos, fw.dropped[ei], specs[ei].classes);
                    n_agg += 1;
                    let n = ctx_e.len().min(d_bh.len());
                    d_bh[..n].to_vec()
                };
                let mut d_ctx = d_ctx_e;
                if d_ctx.len() < ctx_e.len() {
                    d_ctx.resize(ctx_e.len(), 0.0);
                }
                let d_ctx = if ctx_ad[ei].is_identity() { d_ctx } else { ctx_ad[ei].backward(&d_ctx, &atr.ctx, 1) };
                let d_feat = {
                    let mut a = agg.borrow_mut();
                    a.backward(&d_ctx, &atr, tau, &prompt, &feat512, fw.t_feat0)
                };
                let mut touched_ad = false;
                if !feat_ad[0].is_identity() {
                    feat_ad[0].backward(&d_feat, &fw.feat0, fw.t_feat0);
                    touched_ad = true;
                }
                if !ctx_ad[ei].is_identity() {
                    touched_ad = true;
                }
                {
                    let mut a = agg.borrow_mut();
                    a.adam_step(&mut agg_opt, args.mope_agg_lr, 0.0);
                }
                if touched_ad {
                    adapters_adam_step(&mut feat_ad, &mut ctx_ad, &mut ad_opt, args.mope_agg_lr);
                }
            }
            franken_steps += n_ep as u64;
            let n = n_ep.max(1) as f64;
            println!(
                "Эпоха {epoch}/{epochs} | {:.0} с | роутер {:.4} | агрегатор {:.4} ({} шагов) | выбор роутера {:.4} | оракул {:.4} | попадание в оракула {:.1}% | H(p)/ln E {:.3}",
                t_ep.elapsed().as_secs_f64(),
                rl_s / n,
                if n_agg > 0 { al_s / n_agg as f64 } else { f64::NAN },
                n_agg,
                pick_s / n,
                oracle_s / n,
                100.0 * hit as f64 / n,
                load_entropy_norm(&ep_loads)
            );
            if !val_set.is_empty() && (epoch % args.eval_every.max(1) == 0 || epoch == epochs) {
                let take_n = if train_cap > 0 { train_cap.min(val_set.len()) } else { val_set.len() };
                let (mut vo, mut vp, mut vn, mut vh) = (0.0f64, 0.0f64, 0usize, 0usize);
                for smp in val_set.iter().take(take_n) {
                    let fw = mope_forward_all(&smp.path, &smp.tokens, steps, e, &inv, &specs, &ctx, &cache, &scratch, &stream);
                    let oracle = match mope_oracle(&fw.losses) {
                        Some(o) => o,
                        None => continue,
                    };
                    let feat512 = if feat_ad[0].is_identity() { fw.feat0.clone() } else { feat_ad[0].forward(&fw.feat0, fw.t_feat0) };
                    let x = pool_feat(&feat512, fw.t_feat0, args.feat_dim);
                    let tr = router.forward(&x, 1, None);
                    let picked = router.select(&tr.s, cfg.top_k);
                    vo += fw.losses[oracle];
                    vp += if fw.losses[picked[0]].is_finite() { fw.losses[picked[0]] } else { fw.losses[oracle] };
                    if picked[0] == oracle {
                        vh += 1;
                    }
                    vn += 1;
                }
                if vn > 0 {
                    println!(
                        "   📏 контроль ({vn} строк): оракул {:.4} | выбор роутера {:.4} | разрыв {:+.4} | совпадение с оракулом {:.1}%",
                        vo / vn as f64,
                        vp / vn as f64,
                        (vp - vo) / vn as f64,
                        100.0 * vh as f64 / vn as f64
                    );
                }
            }
        }
        println!(
            "──────────── Franken-MoPE: дообучение завершено за {:.1} с, {} шагов ────────────",
            t_train.elapsed().as_secs_f64(),
            franken_steps
        );
        println!("  загрузка экспертов (накопительно): {cum_loads:?}");
        println!("  H(p)/ln E = {:.4} (1.0 = равномерно, Fig. 4 отчёта)", load_entropy_norm(&cum_loads));
        println!("  bias роутера (уравнение 5): {:?}", router.bias);
        println!("  обучено параметров: роутер {} · агрегатор {} · адаптеры {}", router.params(), agg.borrow().params(), feat_ad.iter().chain(ctx_ad.iter()).map(|a| a.params()).sum::<usize>());
        if !args.mope_save_franken.is_empty() {
            let n = save_franken(
                &args.mope_save_franken,
                &merged.itos,
                &router,
                &pid,
                &agg.borrow(),
                &feat_ad,
                &ctx_ad,
                franken_steps,
                Some(&agg_opt),
                &cfg.rsa,
            )?;
            println!(
                "💾 Franken-MoPE: {} ({:.2} МБ) — словарь, роутер, PID, агрегатор (CCA + Res-scale), {} адаптеров, состояние Adam",
                args.mope_save_franken,
                n as f64 / 1e6,
                feat_ad.len() + ctx_ad.len()
            );
            println!(
                "   инференс с ним: --mope --mope-experts {} --mope-franken {} --mope-n {} --mope-c {} \
                     --mope-t {} --mope-tau {} --mope-temperature 0",
                paths.join(","),
                args.mope_save_franken,
                cfg.rsa.n,
                cfg.rsa.c,
                cfg.rsa.t_rounds,
                cfg.rsa.tau
            );
        } else {
            println!("   ⚠️  не указан --mope-save-franken PATH — обученное состояние никуда не сохранено");
        }
        if !args.mope_save_router.is_empty() {
            let n = save_router(&args.mope_save_router, &router, &pid)?;
            println!("💾 отдельно роутер + PID: {} ({} байт)", args.mope_save_router, n);
        }
        return Ok(());
    }

    let mut loads = vec![0.0f64; e];
    let mut wins = vec![0usize; e];
    let mut bon_wins = vec![0usize; e];
    let mut router_loss = 0.0f64;
    // Инференс исторически доучивал роутер на лету: цель строилась по скорам
    // собственных кандидатов, потому что другой просто не было. Теперь состояние
    // можно обучить на настоящей разметке (--mope-train), и такая подстройка без
    // учителя уводит выученную политику в сторону, да ещё и делает прогон
    // невоспроизводимым. Поэтому при загруженном файле роутер и PID заморожены;
    // --mope-adapt возвращает прежнее поведение.
    let router_online = args.mope_adapt || !state_loaded;
    if state_loaded {
        println!(
            "   {} роутер на инференсе: {}",
            if router_online { "🔁" } else { "🧊" },
            if router_online {
                "доучивается на лету по скорам кандидатов (--mope-adapt)"
            } else {
                "ЗАМОРОЖЕН — выученное состояние не меняется (для доучивания на лету добавьте --mope-adapt)"
            }
        );
    }
    let mut agg_warned = false;
    let mut n_done = 0usize;
    let mut agree = 0usize;
    let mut improved = 0usize;
    let t_all = std::time::Instant::now();

    for f in &files {
        // картинка в геометрии каждого эксперта — по мере необходимости
        let imgs: std::rc::Rc<std::cell::RefCell<Vec<Option<std::sync::Arc<DevBuf>>>>> =
            std::rc::Rc::new(std::cell::RefCell::new(vec![None; e]));
        let img_of = |ei: usize, ctx: &ExpertCtx, imgs: &std::rc::Rc<std::cell::RefCell<Vec<Option<std::sync::Arc<DevBuf>>>>>, stream: &CudaStream| -> Option<(std::sync::Arc<DevBuf>, usize, usize)> {
            {
                let c = imgs.borrow();
                if let Some(Some(buf)) = c.get(ei) {
                    let sp = &ctx.specs[ei];
                    return Some((buf.clone(), sp.img_h, sp.img_w));
                }
            }
            let sp = &ctx.specs[ei];
            let q = load_image_q(&f0(f), sp.img_h, sp.img_w)?;
            let buf = std::sync::Arc::new(DevBuf::new(q.len()));
            buf.upload_i8(&q, stream);
            imgs.borrow_mut()[ei] = Some(buf.clone());
            Some((buf, sp.img_h, sp.img_w))
        };

        // 1) признаки опорного эксперта — один проход CNN на роутинг
        let (feat, t_feat) = {
            let (buf, h, w) = match img_of(0, &ctx, &imgs, &stream) {
                Some(v) => v,
                None => {
                    println!("⚠️  не читается как картинка: {f} — пропуск");
                    continue;
                }
            };
            let sc = scratch.clone();
            let mut c = cache.borrow_mut();
            let m = c.get(0, &ctx, &stream);
            let (ft, _enc, t) = expert_encode(m, &buf, 1.0 / 127.0, h, w, &mut sc.borrow_mut(), &stream);
            (ft, t)
        };
        let feat512 = if feat_ad[0].is_identity() { feat.clone() } else { feat_ad[0].forward(&feat, t_feat) };
        let x = pool_feat(&feat512, t_feat, args.feat_dim);
        let tr = router.forward(&x, 1, None);
        let picked = router.select(&tr.s, cfg.top_k);
        loads[picked[0]] += 1.0;

        // 2) Markovian RSA
        let beta = cfg.rsa.beta;
        let (temp, top_p, tau) = (cfg.rsa.temperature, cfg.rsa.top_p, cfg.rsa.tau);
        let trace = {
            let cache_g = cache.clone();
            let cache_a = cache.clone();
            let ctx_g = ctx.clone();
            let ctx_a = ctx.clone();
            let agg_a = agg.clone();
            let imgs_g = imgs.clone();
            let imgs_a = imgs.clone();
            let mut rng_g = rng.clone();
            let mut rng_a = rng.clone();
            let mut rng_m = rng.clone();
            let sc_g = scratch.clone();
            let sc_a = scratch.clone();
            let stream_g: &CudaStream = &stream;
            let stream_a: &CudaStream = &stream;
            let picked_g = picked.clone();
            let picked_a = picked.clone();
            let feat_a: &[f32] = &feat512;
            let file = f.clone();
            // своя длина декодирования у каждого эксперта (корзины по длине)
            let beta_e: Vec<usize> = specs.iter().map(|s| beta.min(s.max_len.max(1))).collect();
            // второе замыкание (aggregate) не может забрать тот же Vec — move
            let beta_e_a = beta_e.clone();
            let generate = move |i: usize| -> Candidate {
                let ei = picked_g[i % picked_g.len()];
                let (buf, h, w) = match img_of(ei, &ctx_g, &imgs_g, stream_g) {
                    Some(v) => v,
                    None => return Candidate { tokens: Vec::new(), expert: ei, score: -1e4 },
                };
                let mut c = cache_g.borrow_mut();
                let m = c.get(ei, &ctx_g, stream_g);
                let (_, enc, t) = {
                    let mut sc = sc_g.borrow_mut();
                    expert_encode(m, &buf, 1.0 / 127.0, h, w, &mut sc, stream_g)
                };
                let (toks, _, lp) = m.attn.decode_full(&enc, 1, t, beta_e[ei], true, temp, top_p, Some(&mut rng_g));
                // декод выдаёт нумерацию ЭКСПЕРТА — переносим в общий словарь
                let remap_ei: &[i32] = &ctx_g.remap[ei];
                let own = toks.into_iter().next().unwrap_or_default();
                Candidate { tokens: to_merged(&own, remap_ei), expert: ei, score: lp[0] }
            };
            let ctx_ad_pick = ctx_ad[picked_a[0]].clone();
            let mut aggregate = move |prompt: &[usize], _round: usize| -> Candidate {
                let ei = picked_a[0];
                let atr = {
                    let mut a = agg_a.borrow_mut();
                    a.forward(prompt, tau, feat_a, t_feat)
                };
                let (buf, h, w) = match img_of(ei, &ctx_a, &imgs_a, stream_a) {
                    Some(v) => v,
                    None => return Candidate { tokens: Vec::new(), expert: usize::MAX, score: -1e4 },
                };
                let mut c = cache_a.borrow_mut();
                let m = c.get(ei, &ctx_a, stream_a);
                let (_, enc, t) = {
                    let mut sc = sc_a.borrow_mut();
                    expert_encode(m, &buf, 1.0 / 127.0, h, w, &mut sc, stream_a)
                };
                // Контекст агрегации — дополнительный шаг памяти декодера,
                // переведённый адаптером в размерность ЭТОГО эксперта (при
                // совпадении hidden адаптер тождественен и не тратит времени).
                // Без адаптера здесь раньше подставлялся чужой ctx напрямую.
                let ctx_e = if ctx_ad_pick.is_identity() { atr.ctx.clone() } else { ctx_ad_pick.forward(&atr.ctx, 1) };
                let mut enc_aug = Vec::with_capacity(ctx_e.len() + enc.len());
                enc_aug.extend_from_slice(&ctx_e);
                enc_aug.extend_from_slice(&enc);
                let (toks, _, lp) = m.attn.decode_full(&enc_aug, 1, t + 1, beta_e_a[ei], true, 1.0, 1.0, Some(&mut rng_a));
                let _ = file;
                // агрегирующий раунд decode_full идёт моделью эксперта picked_a[0]
                let remap_ei: &[i32] = &ctx_a.remap[ei];
                let own = toks.into_iter().next().unwrap_or_default();
                Candidate { tokens: to_merged(&own, remap_ei), expert: usize::MAX, score: lp[0] }
            };
            markovian_rsa(&cfg.rsa, generate, &mut aggregate, &mut rng_m)
        };

        let bon = best_by_score(&trace.round0);
        let best = trace.best.clone();
        // 3) сигнал роутеру: «от всех моделей беря лучшее»
        let mut losses = vec![1e3f32; e];
        for cand in trace.round0.iter() {
            if cand.expert < e {
                losses[cand.expert] = losses[cand.expert].min(-cand.score);
            }
        }
        for r in trace.rounds.iter() {
            if r.out.expert < e {
                losses[r.out.expert] = losses[r.out.expert].min(-r.out.score);
            }
        }
        let target = targets_from_losses(&losses, cfg.target_temperature);
        router.zero_grad();
        let rl = router.backward(&tr, &x, None, &target);
        if router_online {
            router_opt.step(&mut router, args.mope_lr, 1e-4);
            pid.step(&mut router.bias, &loads, cfg.balance_lr, cfg.balance_wd);
        }
        router_loss += rl as f64;
        if bon.expert < e {
            bon_wins[bon.expert] += 1;
        }
        if best.expert < e {
            wins[best.expert] += 1;
        }
        if best.score > bon.score {
            improved += 1;
        }
        let tb = merged_text(&merged, &bon);
        let tf = merged_text(&merged, &best);
        if tb == tf {
            agree += 1;
        }
        n_done += 1;
        println!("▸ {f}");
        println!(
            "   маршрутизация: {:?} из {e}, s(top-1) = {:.4}, {:.1} с/строка",
            picked,
            tr.s[picked[0]],
            t_all.elapsed().as_secs_f64() / n_done as f64
        );
        // Два близких кандидата — в квадратных скобках через слэш (ложные
        // срабатывания допустимы, пропуск редкой фамилии — нет), плюс
        // альтернативы из печатного словаря того же прихода.
        if let Some(s) = ssl_ctx() {
            let pair: [(String, f64); 2] = [
                (tb.to_string(), bon.score as f64),
                (tf.to_string(), best.score as f64),
            ];
            let two = trba_rust::ssl::format_alternatives(&pair, s.gap, 2);
            let ann = trba_rust::ssl::annotate_words(&tf, &s.lex, &s.idx, 2, 2, s.rare);
            if two != tb || ann != tf {
                println!("   🔎 SSL: {two} | по словарю прихода: {ann}");
            }
            if !s.out.is_empty() {
                if let Ok(mut fh) = std::fs::OpenOptions::new()
                    .create(true)
                    .append(true)
                    .open(&s.out)
                {
                    use std::io::Write;
                    let _ = writeln!(fh, "{}", trba_rust::ssl::csv_line(&f, &ann));
                }
            }
        }
        println!(
            "   Best-of-{}: {} «{}» score {:.4}",
            cfg.rsa.n,
            if bon.expert < e { specs[bon.expert].name.clone() } else { "агрегатор".to_string() },
            tb,
            bon.score
        );
        println!(
            "   RSA T={}: {} «{}» score {:.4}, промпт ≤ {} (граница C·τ = {})",
            cfg.rsa.t_rounds,
            if best.expert < e { specs[best.expert].name.clone() } else { "агрегатор".to_string() },
            tf,
            best.score,
            trace.max_prompt,
            cfg.rsa.context_bound()
        );
        if !agg_trained && cfg.rsa.t_rounds > 0 && !agg_warned {
            agg_warned = true;
            println!(
                "   ⚠️  агрегатор не обучен: его раунды случайны, смотрите на Best-of-N. \
Обучите его (--mope-train … --mope-save-franken exp/franken.bin) и запустите снова с --mope-franken exp/franken.bin"
            );
        }
    }

    let h = load_entropy_norm(&loads);
    println!("──────────── MoPE: итог по {n_done} строкам ────────────");
    println!("  общий словарь: {classes} токенов (из {} у эксперта 0)", specs[0].classes);
    for i in 0..e {
        // сколько токенов общего словаря эксперт в принципе способен выдать
        let covers = (0..classes)
            .filter(|&m| ctx.remap[i].iter().any(|&r| r == m as i32))
            .count();
        println!(
            "  [{}] свой словарь {} токенов, модель живёт в нём же; общий словарь покрыт на {}/{} \
             (за непокрытые символы CE платит ln({}) — см. moe::penalized_ce)",
            specs[i].name,
            specs[i].classes,
            covers,
            classes,
            classes
        );
    }
    println!("  загрузка экспертов: {loads:?}");
    println!("  балансировка H(p)/ln E = {h:.4} (1.0 = равномерно, Fig. 4 отчёта)");
    println!("  побед Best-of-N: {bon_wins:?} | финальных ответов RSA: {wins:?}");
    println!("  агрегация улучшила скор в {improved}/{n_done}, текст совпал с Best-of-N в {agree}/{n_done}");
    println!(
        "  лосс роутера {router_loss:.4} (цель — скоры кандидатов; при --mope-train цель другая: CE учителя) | подмен экспертов {} | {:.1} с",
        cache.borrow().swaps,
        t_all.elapsed().as_secs_f64()
    );
    println!("  bias (уравнение 5): {:?}", router.bias);
    let save_to = if !args.mope_save_router.is_empty() {
        args.mope_save_router.clone()
    } else if !args.mope_router.is_empty() {
        args.mope_router.clone()
    } else {
        String::new()
    };
    if !save_to.is_empty() {
        let n = save_router(&save_to, &router, &pid)?;
        println!("💾 роутер + PID сохранены в {save_to} ({n} байт)");
    }
    Ok(())
}

/// Текст кандидата через ОБЩИЙ словарь MoPE (токены уже в общей нумерации).
fn merged_text(mc: &trba_rust::moe::MergedCharset, c: &trba_rust::moe::Candidate) -> String {
    let mut s = String::new();
    for &t in &c.tokens {
        if t >= mc.itos.len() || t < 3 {
            continue;
        }
        s.push_str(&mc.itos[t]);
    }
    s
}

/// CE учителя для одного прогона декодера: `logits [1, steps, V]`, цели
/// `[steps]` (позиции с `pad` игнорируются). Формула та же, что в основном
/// обучающем цикле: вычитание максимума, `-ln p[tgt]`, нормировка на число
/// учтённых позиций. Возвращает (лосс, d_logits, число позиций).
fn teacher_ce(logits: &[f32], target: &[usize], steps: usize, classes: usize, pad: usize) -> (f64, Vec<f32>, usize) {
    let mut count = 0usize;
    let mut loss = 0.0f64;
    let mut d = vec![0.0f32; steps * classes];
    for st in 0..steps {
        let tgt = *target.get(st).unwrap_or(&pad);
        if tgt == pad || tgt >= classes {
            continue;
        }
        count += 1;
        let row = &logits[st * classes..(st + 1) * classes];
        let mx = row.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
        let ex: Vec<f32> = row.iter().map(|&x| (x - mx).exp()).collect();
        let s: f32 = ex.iter().sum();
        loss += -(ex[tgt] / s).ln() as f64;
        for k in 0..classes {
            d[st * classes + k] = ex[k] / s - if k == tgt { 1.0 } else { 0.0 };
        }
    }
    (loss / count.max(1) as f64, d, count)
}

/// Результат одного учительского прогона строки по всем экспертам.
struct MopeFwd {
    /// CE каждого эксперта; NaN — эксперт не смог (картинка не читается или в
    /// его словаре нет ни одного символа разметки)
    losses: Vec<f64>,
    /// teacher-forced вход и цели в нумерации каждого эксперта
    ti: Vec<Vec<usize>>,
    ty: Vec<Vec<usize>>,
    /// память декодера (выход BiLSTM) и число шагов T каждого эксперта
    encs: Vec<Vec<f32>>,
    ts: Vec<usize>,
    /// Сколько символов разметки выпало из цели эксперта (их нет в его словаре).
    /// Нужно для честного сравнения экспертов — см. `moe::penalized_ce`.
    dropped: Vec<usize>,
    /// признаки CNN опорного эксперта — вход роутера и агрегатора
    feat0: Vec<f32>,
    t_feat0: usize,
}

/// Прогон всех экспертов по одной размеченной строке: картинка в геометрии
/// каждого эксперта, teacher-forced декод и CE в ЕГО нумерации. Эксперты
/// заморожены: градиенты их весов здесь не накапливаются осмысленно и нигде не
/// применяются (оптимизатор шагает только по роутеру, агрегатору и адаптерам).
#[allow(clippy::too_many_arguments)]
// ------------- SSL: словарь вариантов, скобки альтернатив, псевдоразметка -----

/// Контекст самообучения: строится ОДИН раз на всю программу, поэтому горячий
/// цикл инференса не платит ни за чтение корпуса, ни за n-граммы.
pub struct SslCtx {
    pub lex: trba_rust::ssl::Lexicon,
    pub idx: trba_rust::ssl::LexIndex,
    pub lm: trba_rust::ssl::CharNgram,
    pub rare: f64,
    pub gap: f64,
    pub out: String,
}

static SSL: std::sync::OnceLock<Option<SslCtx>> = std::sync::OnceLock::new();

fn ssl_init(args: &Args) {
    let _ = SSL.get_or_init(|| {
        if args.ssl_lexicon.trim().is_empty() {
            return None;
        }
        let mut text = String::new();
        for p in args.ssl_lexicon.split(',') {
            let p = p.trim();
            if p.is_empty() {
                continue;
            }
            match std::fs::read_to_string(p) {
                Ok(s) => {
                    text.push_str(&s);
                    text.push('\n');
                }
                Err(err) => println!("   ⚠️  --ssl-lexicon {p} не читается: {err}"),
            }
        }
        if text.trim().is_empty() {
            return None;
        }
        let lex = trba_rust::ssl::Lexicon::from_text(&text);
        let idx = trba_rust::ssl::LexIndex::from_lexicon(&lex);
        let lm = if args.ssl_ngram >= 2 {
            trba_rust::ssl::CharNgram::train(&text, args.ssl_ngram)
        } else {
            trba_rust::ssl::CharNgram::default()
        };
        println!(
            "   📖 SSL-словарь: {} словоформ, {} классов вариантов написания, n-граммы n={}, корпус {} байт",
            lex.forms,
            lex.variants.len(),
            args.ssl_ngram,
            text.len()
        );
        Some(SslCtx {
            lex,
            idx,
            lm,
            rare: args.ssl_rare,
            gap: args.ssl_gap,
            out: args.ssl_out.clone(),
        })
    });
}

/// `None`, если `--ssl-lexicon` не задан или не прочитался.
fn ssl_ctx() -> &'static Option<SslCtx> {
    SSL.get_or_init(|| None)
}

fn mope_forward_all(
    path: &str,
    tokens: &[usize],
    steps: usize,
    e: usize,
    inv: &[Vec<i32>],
    specs: &[trba_rust::moe::ExpertSpec],
    ctx: &std::rc::Rc<ExpertCtx>,
    cache: &std::rc::Rc<std::cell::RefCell<ExpertCache>>,
    scratch: &std::rc::Rc<std::cell::RefCell<Scratch>>,
    stream: &CudaStream,
) -> MopeFwd {
    let mut out = MopeFwd {
        losses: vec![f64::NAN; e],
        ti: vec![vec![0usize; steps]; e],
        ty: vec![vec![0usize; steps]; e],
        encs: vec![Vec::new(); e],
        ts: vec![0usize; e],
        dropped: vec![0usize; e],
        feat0: Vec::new(),
        t_feat0: 0,
    };
    // Длины прогонов задаются сразу — даже пропущенный эксперт (нет картинки)
    // должен иметь векторы своего размера, иначе потребитель прочитает чужую длину.
    for ei in 0..e {
        let st = trba_rust::moe::expert_steps(specs[ei].max_len, steps);
        out.ti[ei] = vec![0usize; st];
        out.ty[ei] = vec![0usize; st];
    }
    for ei in 0..e {
        let sp = &specs[ei];
        // Своя длина прогона: позиционные эмбеддинги декодера эксперта рассчитаны
        // на его max_len, глобальный --max-len — только потолок.
        let steps = trba_rust::moe::expert_steps(sp.max_len, steps);
        let q = match load_image_q(path, sp.img_h, sp.img_w) {
            Some(q) => q,
            None => continue,
        };
        // символы, которых у этого эксперта нет в словаре, из разметки выпадают
        let y: Vec<usize> = tokens
            .iter()
            .filter_map(|&t| {
                let o = inv[ei].get(t).copied().unwrap_or(-1);
                if o >= 0 {
                    Some(o as usize)
                } else {
                    None
                }
            })
            .collect();
        if y.is_empty() {
            continue;
        }
        let (mut ti, mut ty) = (vec![0usize; steps], vec![0usize; steps]);
        ti[0] = 1; // SOS
        for (i, &tk) in y.iter().enumerate() {
            if i + 1 < steps {
                ti[i + 1] = tk;
            }
            if i < steps {
                ty[i] = tk;
            }
        }
        if y.len() < steps {
            ty[y.len()] = 2; // EOS
        }
        let buf = std::sync::Arc::new(DevBuf::new(q.len()));
        buf.upload_i8(&q, stream);
        let (feat, enc, t, l0, npos) = {
            let mut c = cache.borrow_mut();
            let m = c.get(ei, ctx, stream);
            let (feat, enc, t) = {
                let mut sc = scratch.borrow_mut();
                expert_encode(m, &buf, 1.0 / 127.0, sp.img_h, sp.img_w, &mut sc, stream)
            };
            let (logits, _tr) = m.attn.forward_train(&enc, std::slice::from_ref(&ti), 1, t);
            // Число строк берём из самого буфера: декодер возвращает не t и не
            // steps (max_len+1), а столько строк, сколько реально прошло через
            // teacher-forced прогон. Любое другое число рассогласует размер
            // градиента с тем, что ожидает attn.backward.
            let rows = logits.len() / sp.classes.max(1);
            let (l0, _d, npos) = teacher_ce(&logits, &ty, rows, sp.classes, 0);
            (feat, enc, t, l0, npos)
        };
        if ei == 0 {
            out.feat0 = feat;
            out.t_feat0 = t;
        }
        // Символы, которых у эксперта нет в словаре, из teacher-forced цели
        // выпадают выше; без поправки такой эксперт выглядел бы лучше просто
        // потому, что его цель короче и легче. Штраф ln(classes) за каждый
        // потерянный символ делает CE экспертов сравнимыми (см. penalized_ce).
        let dropped = tokens.len().saturating_sub(y.len());
        out.losses[ei] = trba_rust::moe::penalized_ce(l0, npos, dropped, sp.classes);
        out.dropped[ei] = dropped;
        out.ti[ei] = ti;
        out.ty[ei] = ty;
        out.encs[ei] = enc;
        out.ts[ei] = t;
    }
    out
}

/// Индекс эксперта с наименьшим конечным лоссом («оракул» — то, чему учится
/// роутер). Если конечных нет, возвращается `None`.
fn mope_oracle(losses: &[f64]) -> Option<usize> {
    let mut best: Option<(usize, f64)> = None;
    for (i, &l) in losses.iter().enumerate() {
        if !l.is_finite() {
            continue;
        }
        if best.map(|(_, b)| l < b).unwrap_or(true) {
            best = Some((i, l));
        }
    }
    best.map(|(i, _)| i)
}

/// Длины тензоров адаптеров в том порядке, в котором их обходит
/// `adapters_adam_step`: сначала все `feat_ad`, затем все `ctx_ad`, по два
/// тензора (w, b) на адаптер.
fn adapter_shapes(feat_ad: &[trba_rust::moe::Adapter], ctx_ad: &[trba_rust::moe::Adapter]) -> Vec<usize> {
    let mut sh = Vec::new();
    for a in feat_ad.iter().chain(ctx_ad.iter()) {
        sh.push(a.w.len());
        sh.push(a.b.len());
    }
    sh
}

/// Один шаг Adam по адаптерам размерностей. Порядок тензоров фиксирован:
/// `feat_ad` затем `ctx_ad`, по два тензора (w, b) на адаптер — тот же порядок
/// задаётся при создании `FlatAdam`.
fn adapters_adam_step(
    feat_ad: &mut [trba_rust::moe::Adapter],
    ctx_ad: &mut [trba_rust::moe::Adapter],
    opt: &mut trba_rust::moe::FlatAdam,
    lr: f64,
) {
    let (bc1, bc2) = opt.begin_step();
    let mut k = 0usize;
    for a in feat_ad.iter_mut().chain(ctx_ad.iter_mut()) {
        opt.apply(k, &mut a.w, &a.g_w, lr, 0.0, bc1, bc2);
        opt.apply(k + 1, &mut a.b, &a.g_b, lr, 0.0, bc1, bc2);
        k += 2;
        a.zero_grad();
    }
}

/// Отчёт о памяти: PCIe 2.0 x4 ≈ 1.6 ГБ/с — реальный канал машины пользователя.
fn memory_report_for(args: &Args, experts: usize, params: usize) -> String {
    use trba_rust::moe::*;
    let cfg = MopeCfg {
        experts: (0..experts).map(|i| format!("e{i}")).collect(),
        top_k: 1,
        router_latent: ROUTER_LATENT,
        rsa: RsaCfg::default(),
        vram_cache: args.mope_cache.max(1),
        balance_lr: 1e-3,
        balance_wd: 0.0,
        target_temperature: 0.5,
    };
    // 10240 МиБ = CMP 50HX пользователя; PCIe 2.0 x4 ≈ 1600 МБ/с
    let vram = if args.autotune_vram > 0.0 { args.autotune_vram } else { 10240.0 };
    cfg.memory_report(params, vram, 1600.0)
}

fn f0(f: &str) -> String {
    f.to_string()
}
