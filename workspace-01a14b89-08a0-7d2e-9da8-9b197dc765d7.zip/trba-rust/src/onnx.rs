//! # Экспорт TRBA в ONNX
//!
//! Файл `.onnx` — это protobuf-сообщение `onnx.ModelProto`. Тянуть в проект
//! crate `protobuf` или `onnx` нельзя (offline-сборка на машине пользователя,
//! где нет ни crates.io, ни Python), поэтому сериализация написана вручную:
//! ~150 строк примитивов (varint, tag, length-delimited) и конструкторы
//! `TensorProto` / `NodeProto` / `AttributeProto` / `ValueInfoProto`. Номера
//! полей взяты из `onnx.proto3` (onnx 1.23):
//!
//! ```text
//! ModelProto   : ir_version=1  producer_name=2  producer_version=3  domain=4
//!                model_version=5  doc_string=6  graph=7  opset_import=8
//!                metadata_props=14
//! OperatorSetId: domain=1  version=2
//! GraphProto   : node=1  name=2  initializer=5  doc_string=10  input=11
//!                output=12  value_info=13
//! NodeProto    : input=1  output=2  name=3  op_type=4  attribute=5  domain=7
//! TensorProto  : dims=1  data_type=2  float_data=4  int32_data=5  int64_data=7
//!                name=8  raw_data=9  external_data=13  data_location=14
//! AttributeProto: name=1 f=2 i=3 s=4 t=5 g=6 floats=7 ints=8 strings=9
//!                tensors=10 graphs=11 doc_string=13 type=20
//! ValueInfoProto: name=1 type=2 ; TypeProto.tensor_type=1 ;
//!                TensorType{elem_type=1, shape=2} ;
//!                TensorShapeProto.dim=1 ; Dimension{dim_value=1, dim_param=2}
//! ```
//!
//! Числовые repeated-поля пишутся packed (`raw_data` для тензоров, varint-поток
//! для `dims`) — парсеры protobuf обязаны принимать и packed, и unpacked, а
//! `raw_data` по спецификации ONNX имеет приоритет над `float_data`.
//!
//! ## Что экспортируется
//!
//! `input` → CNN SEResNet31-QAT → `feat` [N, T, fd] → BiLSTM(2 слоя) →
//! `enc` [N, T, H] → CTC-голова → `logits` [N, T, classes].
//!
//! * BatchNorm свёрнут в Conv (`W' = W·γ/σ`, `b' = β − μ·γ/σ`, σ² = run_var,
//!   ε = 1e-5) — на инференсе BN всегда считается по running-статистике, так
//!   что свёртка точна и убирает из графа ~60 узлов.
//! * BiLSTM — один узел `LSTM` с `direction="bidirectional"` на слой. Порядок
//!   гейтов в ONNX — **i, o, f, c**, в trba-rust — **i, f, g, o**, поэтому
//!   строки `W`/`R`/`B` переставляются (`perm_gates`). Реверсный выход ONNX
//!   `Y[tt, 1]` уже выровнен по позиции (hidden, увидевший x[T-1..tt]) — это
//!   ровно то, что `cat_from_h` берёт из слота `T-1-tt`, поэтому никакого
//!   разворота времени в графе нет. Проверено экспериментом: LSTM с `R=0` и
//!   всплеском на последнем входе откликается в `Y[T-1, 1]`, а не в `Y[0, 1]`.
//! * Граф статический по `T` (ширина картинки) и динамический по batch:
//!   `dim_param = "batch"`. Это соответствует `onnx_mode` референсного
//!   Python-экспортёра: без раннего стопа по EOS, все `max_len` шагов.
//!
//! ## Раскладка входа — ВАЖНО
//!
//! `load_image_q()` в `main.rs` пишет байты **HWC-interleaved**
//! (`buf[(y·W + x)·3 + c]`), а `launch_im2col_pad` читает буфер как **NCHW**
//! (`input[(b·C + ci)·H·W + y·W + x]`). Обучение, валидация и `--infer`
//! используют один и тот же загрузчик, поэтому конвейер самосогласован, но
//! «каналы» модели — это не R/G/B плоскости, а переупакованные пиксели.
//! Экспорт по умолчанию объявляет вход как `NHWC` и ставит в начало
//! `Transpose(perm=[0,3,1,2])`: так ONNX получает ровно те байты, которые
//! модель видела на обучении, и любой потребитель (Python, C++, Rust) может
//! кормить её естественным HWC-массивом. Флаг `--onnx-layout nchw` отключает
//! транспозицию, если вход уже приходит «плоскостями», как это делает
//! референсный Python-экспортёр.

use std::collections::HashMap;

use crate::qnet::{BasicBlock, ConvQat, LinearF, SELayer, BN_EPS};
use crate::rnn::BiLstmLayer;

// ----------------------------------------------------------------- protobuf --

const WIRE_VARINT: u32 = 0;
const WIRE_LEN: u32 = 2;
const WIRE_I32: u32 = 5;

/// `onnx.TensorProto.DataType`
pub const DT_FLOAT: i32 = 1;
pub const DT_UINT8: i32 = 2;
pub const DT_INT8: i32 = 3;
pub const DT_INT32: i32 = 6;
pub const DT_INT64: i32 = 7;

/// `onnx.AttributeProto.AttributeType`
const AT_FLOAT: i32 = 1;
const AT_INT: i32 = 2;
const AT_STRING: i32 = 3;
const AT_TENSOR: i32 = 4;
const AT_INTS: i32 = 7;

/// opset, под который строится граф: 17 — последний, где `ReduceMean` ещё
/// принимает `axes` атрибутом (в 18+ это вход-тензор), и он поддерживается
/// onnxruntime 1.16+ включительно.
pub const OPSET: i64 = 17;
pub const IR_VERSION: i64 = 8;

fn varint(out: &mut Vec<u8>, mut v: u64) {
    loop {
        let b = (v & 0x7f) as u8;
        v >>= 7;
        if v == 0 {
            out.push(b);
            return;
        }
        out.push(b | 0x80);
    }
}

fn tag(out: &mut Vec<u8>, field: u32, wire: u32) {
    varint(out, ((field as u64) << 3) | wire as u64);
}

fn f_varint(out: &mut Vec<u8>, field: u32, v: i64) {
    tag(out, field, WIRE_VARINT);
    varint(out, v as u64);
}

fn f_i32(out: &mut Vec<u8>, field: u32, v: i32) {
    f_varint(out, field, v as i64);
}

fn f_bytes(out: &mut Vec<u8>, field: u32, data: &[u8]) {
    tag(out, field, WIRE_LEN);
    varint(out, data.len() as u64);
    out.extend_from_slice(data);
}

fn f_str(out: &mut Vec<u8>, field: u32, s: &str) {
    f_bytes(out, field, s.as_bytes());
}

fn f_f32(out: &mut Vec<u8>, field: u32, v: f32) {
    tag(out, field, WIRE_I32);
    out.extend_from_slice(&v.to_le_bytes());
}

fn f_msg(out: &mut Vec<u8>, field: u32, msg: &[u8]) {
    f_bytes(out, field, msg);
}

fn f_packed_f32(out: &mut Vec<u8>, field: u32, vals: &[f32]) {
    if vals.is_empty() {
        return;
    }
    let mut p = Vec::with_capacity(vals.len() * 4);
    for v in vals {
        p.extend_from_slice(&v.to_le_bytes());
    }
    f_bytes(out, field, &p);
}

fn f_packed_i64(out: &mut Vec<u8>, field: u32, vals: &[i64]) {
    if vals.is_empty() {
        return;
    }
    let mut p = Vec::with_capacity(vals.len() * 2);
    for v in vals {
        varint(&mut p, *v as u64);
    }
    f_bytes(out, field, &p);
}

// ------------------------------------------------------------- TensorProto --

pub struct Tensor {
    pub name: String,
    pub dims: Vec<i64>,
    pub dt: i32,
    pub raw: Vec<u8>,
}

impl Tensor {
    pub fn encode(&self) -> Vec<u8> {
        let mut m = Vec::with_capacity(64 + self.raw.len());
        f_packed_i64(&mut m, 1, &self.dims);
        f_i32(&mut m, 2, self.dt);
        f_str(&mut m, 8, &self.name);
        f_bytes(&mut m, 9, &self.raw);
        m
    }
    pub fn len(&self) -> usize {
        self.dims.iter().fold(1usize, |a, &d| a * d.max(0) as usize)
    }
}

pub fn tensor_f32(name: &str, dims: &[i64], data: &[f32]) -> Tensor {
    let mut raw = Vec::with_capacity(data.len() * 4);
    for v in data {
        raw.extend_from_slice(&v.to_le_bytes());
    }
    Tensor { name: name.to_string(), dims: dims.to_vec(), dt: DT_FLOAT, raw }
}

pub fn tensor_i64(name: &str, dims: &[i64], data: &[i64]) -> Tensor {
    let mut raw = Vec::with_capacity(data.len() * 8);
    for v in data {
        raw.extend_from_slice(&v.to_le_bytes());
    }
    Tensor { name: name.to_string(), dims: dims.to_vec(), dt: DT_INT64, raw }
}

pub fn tensor_i8(name: &str, dims: &[i64], data: &[i8]) -> Tensor {
    Tensor {
        name: name.to_string(),
        dims: dims.to_vec(),
        dt: DT_INT8,
        raw: data.iter().map(|&v| v as u8).collect(),
    }
}

// ---------------------------------------------------------- AttributeProto --

pub fn attr_i(name: &str, v: i64) -> Vec<u8> {
    let mut a = Vec::new();
    f_str(&mut a, 1, name);
    f_varint(&mut a, 3, v);
    f_i32(&mut a, 20, AT_INT);
    a
}

pub fn attr_f(name: &str, v: f32) -> Vec<u8> {
    let mut a = Vec::new();
    f_str(&mut a, 1, name);
    f_f32(&mut a, 2, v);
    f_i32(&mut a, 20, AT_FLOAT);
    a
}

pub fn attr_s(name: &str, v: &str) -> Vec<u8> {
    let mut a = Vec::new();
    f_str(&mut a, 1, name);
    f_bytes(&mut a, 4, v.as_bytes());
    f_i32(&mut a, 20, AT_STRING);
    a
}

pub fn attr_ints(name: &str, v: &[i64]) -> Vec<u8> {
    let mut a = Vec::new();
    f_str(&mut a, 1, name);
    {
        let mut p = Vec::with_capacity(v.len() * 2);
        for x in v {
            varint(&mut p, *x as u64);
        }
        f_bytes(&mut a, 8, &p);
    }
    f_i32(&mut a, 20, AT_INTS);
    a
}

pub fn attr_tensor(name: &str, t: &Tensor) -> Vec<u8> {
    let mut a = Vec::new();
    f_str(&mut a, 1, name);
    f_msg(&mut a, 5, &t.encode());
    f_i32(&mut a, 20, AT_TENSOR);
    a
}

// ------------------------------------------------------------- NodeProto ---

pub fn node(op: &str, inputs: &[&str], outputs: &[&str], attrs: &[Vec<u8>], name: &str) -> Vec<u8> {
    let mut n = Vec::new();
    for i in inputs {
        f_str(&mut n, 1, i);
    }
    for o in outputs {
        f_str(&mut n, 2, o);
    }
    if !name.is_empty() {
        f_str(&mut n, 3, name);
    }
    f_str(&mut n, 4, op);
    for a in attrs {
        f_msg(&mut n, 5, a);
    }
    n
}

// -------------------------------------------------------- ValueInfoProto ---

/// Размерность входа/выхода: либо число, либо символическое имя
/// (`dim_param`) для динамической оси.
pub enum Dim {
    Fixed(i64),
    Param(String),
}

pub fn dim_fixed(v: i64) -> Dim {
    Dim::Fixed(v)
}

pub fn dim_param(s: &str) -> Dim {
    Dim::Param(s.to_string())
}

pub fn value_info(name: &str, dt: i32, dims: &[Dim]) -> Vec<u8> {
    let mut shape = Vec::new();
    for d in dims {
        let mut dm = Vec::new();
        match d {
            Dim::Fixed(v) => f_varint(&mut dm, 1, *v),
            Dim::Param(p) => f_str(&mut dm, 2, p),
        }
        f_msg(&mut shape, 1, &dm);
    }
    let mut tt = Vec::new();
    f_i32(&mut tt, 1, dt);
    f_msg(&mut tt, 2, &shape);
    let mut tp = Vec::new();
    f_msg(&mut tp, 1, &tt);
    let mut v = Vec::new();
    f_str(&mut v, 1, name);
    f_msg(&mut v, 2, &tp);
    v
}

// ----------------------------------------------------------- Graph/Model ---

pub struct Graph {
    pub nodes: Vec<Vec<u8>>,
    pub inits: Vec<Tensor>,
    pub inputs: Vec<Vec<u8>>,
    pub outputs: Vec<Vec<u8>>,
    counter: usize,
    seen: HashMap<String, usize>,
}

impl Graph {
    pub fn new() -> Self {
        Self { nodes: Vec::new(), inits: Vec::new(), inputs: Vec::new(), outputs: Vec::new(), counter: 0, seen: HashMap::new() }
    }

    /// Уникальное имя: ONNX требует, чтобы имена узлов, тензоров и
    /// инициализаторов не пересекались.
    fn uid(&mut self, hint: &str) -> String {
        self.counter += 1;
        let clean: String = hint.chars().map(|c| if c.is_ascii_alphanumeric() || c == '_' { c } else { '_' }).collect();
        let k = self.seen.entry(clean.clone()).or_insert(0);
        *k += 1;
        if *k == 1 {
            format!("/{clean}")
        } else {
            format!("/{clean}_{k}")
        }
    }

    pub fn init_f32(&mut self, hint: &str, dims: &[i64], data: &[f32]) -> String {
        let name = self.uid(hint);
        self.inits.push(tensor_f32(&name, dims, data));
        name
    }

    pub fn init_i64(&mut self, hint: &str, dims: &[i64], data: &[i64]) -> String {
        let name = self.uid(hint);
        self.inits.push(tensor_i64(&name, dims, data));
        name
    }

    pub fn init_i8(&mut self, hint: &str, dims: &[i64], data: &[i8]) -> String {
        let name = self.uid(hint);
        self.inits.push(tensor_i8(&name, dims, data));
        name
    }

    /// Узел с одним выходом; возвращает имя выхода.
    pub fn op1(&mut self, op: &str, ins: &[&str], attrs: Vec<Vec<u8>>, hint: &str) -> String {
        let out = self.uid(hint);
        let name = self.uid(&format!("{op}_node"));
        self.nodes.push(node(op, ins, &[&out], &attrs, &name));
        out
    }

    /// Узел с произвольным списком выходов (пустая строка = «выход не нужен»,
    /// так ONNX пропускает необязательные `Y_h`/`Y_c` у `LSTM`).
    pub fn opn(&mut self, op: &str, ins: &[&str], outs: &[&str], attrs: Vec<Vec<u8>>, hint: &str) {
        let name = self.uid(&format!("{op}_node"));
        let _ = hint;
        self.nodes.push(node(op, ins, outs, &attrs, &name));
    }

    pub fn add_input(&mut self, name: &str, dt: i32, dims: &[Dim]) {
        self.inputs.push(value_info(name, dt, dims));
    }

    pub fn add_output(&mut self, name: &str, dt: i32, dims: &[Dim]) {
        self.outputs.push(value_info(name, dt, dims));
    }

    pub fn n_nodes(&self) -> usize {
        self.nodes.len()
    }

    pub fn init_bytes(&self) -> usize {
        self.inits.iter().map(|t| t.raw.len()).sum()
    }

    /// `ModelProto` целиком.
    pub fn encode(&self, graph_name: &str, producer: &str, doc: &str) -> Vec<u8> {
        let mut g = Vec::new();
        for n in &self.nodes {
            f_msg(&mut g, 1, n);
        }
        f_str(&mut g, 2, graph_name);
        for t in &self.inits {
            f_msg(&mut g, 5, &t.encode());
        }
        f_str(&mut g, 10, doc);
        for v in &self.inputs {
            f_msg(&mut g, 11, v);
        }
        for v in &self.outputs {
            f_msg(&mut g, 12, v);
        }

        let mut os = Vec::new();
        f_str(&mut os, 1, "");
        f_varint(&mut os, 2, OPSET);

        let mut m = Vec::new();
        f_varint(&mut m, 1, IR_VERSION);
        f_str(&mut m, 2, producer);
        f_str(&mut m, 3, "1");
        f_str(&mut m, 4, "ai.trba");
        f_varint(&mut m, 5, 1);
        f_str(&mut m, 6, doc);
        f_msg(&mut m, 7, &g);
        f_msg(&mut m, 8, &os);
        m
    }
}

// ------------------------------------------------------------ конфигурация --

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Layout {
    /// вход `[N, H, W, 3]`, в начале графа `Transpose → [N, 3, H, W]`
    Nhwc,
    /// вход `[N, 3, H, W]` — байты уже «плоскостями»
    Nchw,
}

pub struct ExportCfg {
    pub img_h: usize,
    pub img_w: usize,
    pub hidden: usize,
    pub classes: usize,
    pub layout: Layout,
    /// дополнительно отдать `conv0`/`stem`/`enc` выходами — для послойной сверки
    pub debug_outputs: bool,
    /// разворачивать ли attention-декодер (иначе граф = энкодер + CTC-голова)
    pub with_decoder: bool,
    /// сколько токенов просит заказчик: декодер делает `max_len + 1` шагов
    pub max_len: usize,
}

pub struct ExportStats {
    pub nodes: usize,
    pub initializers: usize,
    pub weight_bytes: usize,
    pub file_bytes: usize,
    pub t_feat: usize,
    pub h_feat: usize,
    pub qdq_pairs: usize,
}

// --------------------------------------------------------- свёртка BN в Conv --

/// `y = (conv(x) − μ)·γ/√(σ²+ε) + β`  ⇔  `y = conv'(x) + b'`, где
/// `W'[o] = W[o]·γ[o]/σ[o]`, `b'[o] = β[o] − μ[o]·γ[o]/σ[o]`.
pub fn fold_conv_bn(c: &ConvQat) -> (Vec<f32>, Vec<f32>) {
    let mut w = c.w.clone();
    let cols = c.col_cols();
    let mut b = vec![0.0f32; c.out_c];
    for o in 0..c.out_c {
        let sigma = (c.bn.run_var[o] + BN_EPS).sqrt();
        let k = c.bn.gamma[o] / sigma;
        for j in 0..cols {
            w[o * cols + j] *= k;
        }
        b[o] = c.bn.beta[o] - c.bn.run_mean[o] * k;
    }
    (w, b)
}

// ------------------------------------------------------ перестановка гейтов --

/// `[4H, cols]`, порядок trba-rust **i, f, g, o** → порядок ONNX **i, o, f, c**.
pub fn perm_gates(src: &[f32], h: usize, cols: usize) -> Vec<f32> {
    const ORDER: [usize; 4] = [0, 3, 1, 2]; // куда кладём наши i,f,g,o
    let mut out = vec![0.0f32; src.len()];
    for (dst, &sr) in ORDER.iter().enumerate() {
        for r in 0..h {
            let from = (sr * h + r) * cols;
            let to = (dst * h + r) * cols;
            out[to..to + cols].copy_from_slice(&src[from..from + cols]);
        }
    }
    out
}

/// Вектор смещений `[4H]` — та же перестановка блоков.
pub fn perm_gate_vec(src: &[f32], h: usize) -> Vec<f32> {
    const ORDER: [usize; 4] = [0, 3, 1, 2];
    let mut out = vec![0.0f32; src.len()];
    for (dst, &sr) in ORDER.iter().enumerate() {
        out[dst * h..(dst + 1) * h].copy_from_slice(&src[sr * h..(sr + 1) * h]);
    }
    out
}

/// Шкалы активаций для QDQ-графа: `s_in` каждого Conv из трейса одного
/// калибровочного прохода. Это ровно те шкалы, по которым активации
/// квантовались на обучении, поэтому int8-граф onnxruntime повторяет
/// обученную модель, а не «какую-то» квантованную.
pub fn collect_act_scales(cnn: &crate::qnet::SEResNetQ, tr: &crate::qnet::NetTrace) -> HashMap<String, f32> {
    let mut m = HashMap::new();
    m.insert(cnn.c0.name.clone(), tr.stem.c0.s_in);
    m.insert(cnn.c1.name.clone(), tr.stem.c1.s_in);
    let mut bi = 0usize;
    for layer in [&cnn.layer1, &cnn.layer2, &cnn.layer3, &cnn.layer4] {
        for blk in layer.iter() {
            if bi >= tr.blocks.len() {
                break;
            }
            let t = &tr.blocks[bi];
            bi += 1;
            m.insert(blk.conv1.name.clone(), t.c1.s_in);
            m.insert(blk.conv2.name.clone(), t.c2.s_in);
            if let (Some(d), Some(dt)) = (&blk.ds, &t.ds) {
                m.insert(d.name.clone(), dt.s_in);
            }
        }
    }
    m.insert(cnn.o0.name.clone(), tr.out.c0.s_in);
    m.insert(cnn.o1.name.clone(), tr.out.c1.s_in);
    m
}

// ------------------------------------------------------------------- CNN ----

fn conv_node(
    g: &mut Graph,
    c: &ConvQat,
    x: &str,
    relu: bool,
    act_scales: &HashMap<String, f32>,
    qdqs: &mut usize,
) -> String {
    let (w, b) = fold_conv_bn(c);
    let dims = [c.out_c as i64, c.in_c as i64, c.kh as i64, c.kw as i64];
    let mut xin = x.to_string();
    // QDQ-пара ставится только если для слоя известна калибровочная шкала
    // активации (её отдаёт прямой проход по калибровочному батчу: `s_in` из
    // QAT-цепочки). Без неё квантовать нельзя — иначе граф перестанет
    // соответствовать обученной модели.
    let s_act = act_scales.get(&c.name).copied();
    let wq_init;
    let wname = if let Some(sa) = s_act {
        let sa = if sa.is_finite() && sa > 0.0 { sa } else { 1e-8 };
        // Вес квантуется уже после свёртки BN: шкала = max|W'|/127.
        let amax = w.iter().fold(0.0f32, |a, &v| a.max(v.abs()));
        let ws = if amax > 0.0 { amax / 127.0 } else { 1e-8 };
        let q: Vec<i8> = w
            .iter()
            .map(|&v| {
                let r = (v / ws).round();
                (r.clamp(-127.0, 127.0)) as i8
            })
            .collect();
        wq_init = g.init_i8(&format!("{}.Wq", c.name), &dims, &q);
        let wsn = g.init_f32(&format!("{}.Ws", c.name), &[], &[ws]);
        let wzp = g.init_i8(&format!("{}.Wzp", c.name), &[], &[0i8]);
        let zp = g.init_i8(&format!("{}.x_zp", c.name), &[], &[0i8]);
        let san = g.init_f32(&format!("{}.x_s", c.name), &[], &[sa]);
        let qn = g.op1("QuantizeLinear", &[&xin, &san, &zp], vec![], &format!("{}_xq", c.name));
        let dq = g.op1("DequantizeLinear", &[&qn, &san, &zp], vec![], &format!("{}_xdq", c.name));
        let wdq = g.op1("DequantizeLinear", &[&wq_init, &wsn, &wzp], vec![], &format!("{}_wdq", c.name));
        xin = dq;
        *qdqs += 1;
        wdq
    } else {
        g.init_f32(&format!("{}.W", c.name), &dims, &w)
    };
    let bn = g.init_f32(&format!("{}.B", c.name), &[c.out_c as i64], &b);
    let y = g.op1(
        "Conv",
        &[&xin, &wname, &bn],
        vec![
            attr_ints("kernel_shape", &[c.kh as i64, c.kw as i64]),
            attr_ints("strides", &[c.sh as i64, c.sw as i64]),
            attr_ints("pads", &[c.ph as i64, c.pw as i64, c.ph as i64, c.pw as i64]),
        ],
        &format!("{}_conv", c.name),
    );
    if relu {
        g.op1("Relu", &[&y], vec![], &format!("{}_relu", c.name))
    } else {
        y
    }
}

fn linear_node(g: &mut Graph, l: &LinearF, x: &str, hint: &str) -> String {
    let wn = g.init_f32(&format!("{hint}.W"), &[l.out as i64, l.inp as i64], &l.w);
    let mut attrs = vec![attr_i("transB", 1)];
    let ins: Vec<String> = if l.use_bias && !l.b.is_empty() {
        let bn = g.init_f32(&format!("{hint}.B"), &[l.out as i64], &l.b);
        vec![x.to_string(), wn, bn]
    } else {
        attrs.push(attr_f("alpha", 1.0));
        attrs.push(attr_f("beta", 0.0));
        vec![x.to_string(), wn]
    };
    let refs: Vec<&str> = ins.iter().map(|s| s.as_str()).collect();
    g.op1("Gemm", &refs, attrs, hint)
}

fn se_block(g: &mut Graph, se: &SELayer, y2: &str) -> String {
    let p = g.op1("GlobalAveragePool", &[y2], vec![], "se_gap");
    let p = g.op1("Flatten", &[&p], vec![attr_i("axis", 1)], "se_flat");
    let p = linear_node(g, &se.fc1, &p, "se_fc1");
    let p = g.op1("Relu", &[&p], vec![], "se_relu");
    let p = linear_node(g, &se.fc2, &p, "se_fc2");
    let p = g.op1("Sigmoid", &[&p], vec![], "se_sig");
    let axes = g.init_i64("se_axes", &[2], &[2, 3]);
    let p = g.op1("Unsqueeze", &[&p, &axes], vec![], "se_gate4d");
    g.op1("Mul", &[y2, &p], vec![], "se_mul")
}

fn basic_block(
    g: &mut Graph,
    blk: &BasicBlock,
    x: &str,
    h: usize,
    w: usize,
    act_scales: &HashMap<String, f32>,
    qdqs: &mut usize,
) -> (String, usize, usize) {
    // downsample (если есть) считается до conv1 и складывается с выходом SE —
    // как в `BasicBlock::forward`, residual добавляется к pre-ReLU BN-выходу.
    let ds = blk.ds.as_ref().map(|d| conv_node(g, d, x, false, act_scales, qdqs));
    let (h1, w1) = blk.conv1.out_hw(h, w);
    let y1 = conv_node(g, &blk.conv1, x, true, act_scales, qdqs);
    let (h2, w2) = blk.conv2.out_hw(h1, w1);
    let y2 = conv_node(g, &blk.conv2, &y1, false, act_scales, qdqs);
    let yse = se_block(g, &blk.se, &y2);
    let id = ds.unwrap_or_else(|| x.to_string());
    let z = g.op1("Add", &[&yse, &id], vec![], "res_add");
    let z = g.op1("Relu", &[&z], vec![], "res_relu");
    (z, h2, w2)
}

// ------------------------------------------------------------------ BiLSTM --

fn bilstm_layer(g: &mut Graph, l: &BiLstmLayer, x: &str, n_t: usize, li: usize) -> String {
    let h = l.h;
    let d = l.fwd.d;
    let xt = g.op1("Transpose", &[x], vec![attr_ints("perm", &[1, 0, 2])], &format!("lstm{li}_xt"));

    let mut w = perm_gates(&l.fwd.w_ih, h, d);
    w.extend_from_slice(&perm_gates(&l.bwd.w_ih, h, d));
    let wn = g.init_f32(&format!("lstm{li}.W"), &[2, 4 * h as i64, d as i64], &w);

    let mut r = perm_gates(&l.fwd.w_hh, h, h);
    r.extend_from_slice(&perm_gates(&l.bwd.w_hh, h, h));
    let rn = g.init_f32(&format!("lstm{li}.R"), &[2, 4 * h as i64, h as i64], &r);

    let mut b = perm_gate_vec(&l.fwd.b_ih, h);
    b.extend_from_slice(&perm_gate_vec(&l.fwd.b_hh, h));
    b.extend_from_slice(&perm_gate_vec(&l.bwd.b_ih, h));
    b.extend_from_slice(&perm_gate_vec(&l.bwd.b_hh, h));
    let bnn = g.init_f32(&format!("lstm{li}.B"), &[2, 8 * h as i64], &b);

    // Y_h/Y_c не нужны — пустые имена выходов.
    let y = g.uid(&format!("lstm{li}_Y"));
    let nm = g.uid("LSTM_node");
    g.nodes.push(node(
        "LSTM",
        &[&xt, &wn, &rn, &bnn],
        &[&y, "", ""],
        &[attr_s("direction", "bidirectional"), attr_i("hidden_size", h as i64), attr_i("layout", 0)],
        &nm,
    ));

    // Y = [T, 2, N, H]: dir 0 — прямое направление, dir 1 — реверсное.
    // Реверс в ONNX уже выровнен по позиции: Y[tt, 1] — это hidden, который
    // просуммировал x[T-1..tt], то есть ровно то, что cat_from_h кладёт в
    // позицию tt (она берёт реверсный слот T-1-tt). Разворачивать время НЕ
    // нужно — проверка `tools/check_onnx_export.py` (пункт D) сверяет это с
    // независимым numpy-пересчётом, а решающий эксперимент с R=0 и всплеском
    // на последнем входе показывает отклик реверса именно на t=T-1.
    let i0 = g.init_i64("dir0", &[1], &[0]);
    let i1 = g.init_i64("dir1", &[1], &[1]);
    let yf = g.op1("Gather", &[&y, &i0], vec![attr_i("axis", 1)], &format!("lstm{li}_f"));
    let yb = g.op1("Gather", &[&y, &i1], vec![attr_i("axis", 1)], &format!("lstm{li}_b"));

    let _ = n_t;
    let sq = g.init_i64("squeeze_axes", &[1], &[1]);
    let yf = g.op1("Squeeze", &[&yf, &sq], vec![], &format!("lstm{li}_fsq"));
    let yb = g.op1("Squeeze", &[&yb, &sq], vec![], &format!("lstm{li}_bsq"));
    let yf = g.op1("Transpose", &[&yf], vec![attr_ints("perm", &[1, 0, 2])], &format!("lstm{li}_ft"));
    let yb = g.op1("Transpose", &[&yb], vec![attr_ints("perm", &[1, 0, 2])], &format!("lstm{li}_bt"));
    let cat = g.op1("Concat", &[&yf, &yb], vec![attr_i("axis", 2)], &format!("lstm{li}_cat"));

    let shp = g.init_i64("proj_flat", &[2], &[-1, 2 * h as i64]);
    let cat2 = g.op1("Reshape", &[&cat, &shp], vec![], &format!("lstm{li}_flat"));
    let pw = g.init_f32(&format!("lstm{li}.proj_W"), &[l.out as i64, 2 * h as i64], &l.proj_w);
    let pb = g.init_f32(&format!("lstm{li}.proj_B"), &[l.out as i64], &l.proj_b);
    let pr = {
        let ins = vec![cat2.clone(), pw, pb];
        let refs: Vec<&str> = ins.iter().map(|s| s.as_str()).collect();
        g.op1("Gemm", &refs, vec![attr_i("transB", 1)], &format!("lstm{li}_proj"))
    };
    let shp2 = g.init_i64("proj_unflat", &[3], &[-1, n_t as i64, l.out as i64]);
    g.op1("Reshape", &[&pr, &shp2], vec![], &format!("lstm{li}_out"))
}

// ------------------------------------------------------------------ сборка --

/// Полный граф: `input → CNN → feat → BiLSTM → enc → CTC → logits`.
pub fn build_graph(
    cnn: &crate::qnet::SEResNetQ,
    rnn: &crate::rnn::BiLstmStack,
    ctc: &LinearF,
    attn: &crate::attn::AttentionDecoder,
    cfg: &ExportCfg,
    act_scales: &HashMap<String, f32>,
) -> (Graph, ExportStats) {
    let mut g = Graph::new();
    let mut qdqs = 0usize;

    // ---- вход
    let mut x: String = match cfg.layout {
        Layout::Nhwc => {
            g.add_input("input", DT_FLOAT, &[dim_param("batch"), dim_fixed(cfg.img_h as i64), dim_fixed(cfg.img_w as i64), dim_fixed(3)]);
            g.op1("Transpose", &["input"], vec![attr_ints("perm", &[0, 3, 1, 2])], "in_nchw")
        }
        Layout::Nchw => {
            g.add_input("input", DT_FLOAT, &[dim_param("batch"), dim_fixed(3), dim_fixed(cfg.img_h as i64), dim_fixed(cfg.img_w as i64)]);
            "input".to_string()
        }
    };

    // ---- stem
    let (mut h, mut w) = (cfg.img_h, cfg.img_w);
    x = conv_node(&mut g, &cnn.c0, &x, true, act_scales, &mut qdqs);
    if cfg.debug_outputs {
        g.add_output("conv0", DT_FLOAT, &[dim_param("batch"), dim_fixed(64), dim_fixed(h as i64), dim_fixed(w as i64)]);
        g.nodes.push(node("Identity", &[&x], &["conv0"], &[], "conv0_dbg"));
    }
    x = conv_node(&mut g, &cnn.c1, &x, true, act_scales, &mut qdqs);
    h /= 2;
    w /= 2;
    x = g.op1("MaxPool", &[&x], vec![attr_ints("kernel_shape", &[2, 2]), attr_ints("strides", &[2, 2])], "stem_pool");
    if cfg.debug_outputs {
        g.add_output("stem", DT_FLOAT, &[dim_param("batch"), dim_fixed(128), dim_fixed(h as i64), dim_fixed(w as i64)]);
        g.nodes.push(node("Identity", &[&x], &["stem"], &[], "stem_dbg"));
    }

    // ---- residual-блоки
    for (li, layer) in [&cnn.layer1, &cnn.layer2, &cnn.layer3, &cnn.layer4].iter().enumerate() {
        for blk in layer.iter() {
            let (y, hh, ww) = basic_block(&mut g, blk, &x, h, w, act_scales, &mut qdqs);
            x = y;
            h = hh;
            w = ww;
            let _ = li;
        }
    }

    // ---- conv_out: 2x2/(2,1) уменьшает H до 1, затем 2x2/1 убирает остатки
    x = conv_node(&mut g, &cnn.o0, &x, true, act_scales, &mut qdqs);
    let (h0, w0) = cnn.o0.out_hw(h, w);
    h = h0;
    w = w0;
    x = conv_node(&mut g, &cnn.o1, &x, true, act_scales, &mut qdqs);
    let (h1, w1) = cnn.o1.out_hw(h, w);
    h = h1;
    w = w1;

    // ---- features: mean по H → [N, fd, W] → [N, W, fd]
    let fm = g.op1("ReduceMean", &[&x], vec![attr_ints("axes", &[2]), attr_i("keepdims", 0)], "feat_mean");
    let feat = g.op1("Transpose", &[&fm], vec![attr_ints("perm", &[0, 2, 1])], "feat_nchw_to_ntc");
    g.nodes.push(node("Identity", &[&feat], &["feat"], &[], "feat_out"));
    g.add_output("feat", DT_FLOAT, &[dim_param("batch"), dim_fixed(w as i64), dim_fixed(cnn.fd as i64)]);

    // ---- BiLSTM
    let mut enc = feat.clone();
    for (li, l) in rnn.layers.iter().enumerate() {
        enc = bilstm_layer(&mut g, l, &enc, w, li);
    }
    if cfg.debug_outputs {
        g.nodes.push(node("Identity", &[&enc], &["enc"], &[], "enc_dbg"));
        g.add_output("enc", DT_FLOAT, &[dim_param("batch"), dim_fixed(w as i64), dim_fixed(cfg.hidden as i64)]);
    }

    // ---- CTC-голова
    let shp = g.init_i64("ctc_flat", &[2], &[-1, cfg.hidden as i64]);
    let flat = g.op1("Reshape", &[&enc, &shp], vec![], "ctc_flat_in");
    let lg = linear_node(&mut g, ctc, &flat, "ctc");
    let shp3 = g.init_i64("ctc_shape", &[3], &[-1, w as i64, cfg.classes as i64]);
    // Имя `logits` зарезервировано за основным выходом: если декодер
    // развёрнут, это его логиты [N, max_len+1, V] (как в референсном
    // Python-экспортёре), а CTC-голова отдаётся как `ctc_logits`.
    let ctc_name = if cfg.with_decoder { "ctc_logits" } else { "logits" };
    g.opn("Reshape", &[&lg, &shp3], &[ctc_name], vec![], "ctc_logits_reshape");
    g.add_output(ctc_name, DT_FLOAT, &[dim_param("batch"), dim_fixed(w as i64), dim_fixed(cfg.classes as i64)]);

    if cfg.with_decoder {
        build_decoder(&mut g, attn, &enc, w, cfg.max_len + 1);
    }

    let stats = ExportStats {
        nodes: g.n_nodes(),
        initializers: g.inits.len(),
        weight_bytes: g.init_bytes(),
        file_bytes: 0,
        t_feat: w,
        h_feat: h,
        qdq_pairs: qdqs,
    };
    (g, stats)
}

pub fn export_model(
    cnn: &crate::qnet::SEResNetQ,
    rnn: &crate::rnn::BiLstmStack,
    ctc: &LinearF,
    attn: &crate::attn::AttentionDecoder,
    cfg: &ExportCfg,
    act_scales: &HashMap<String, f32>,
    producer: &str,
) -> (Vec<u8>, ExportStats) {
    let (g, mut stats) = build_graph(cnn, rnn, ctc, attn, cfg, act_scales);
    let doc = format!(
        "TRBA (SEResNet31-QAT + 2x BiLSTM + CTC head), img {}x{}, hidden {}, classes {}, layout {:?}",
        cfg.img_h, cfg.img_w, cfg.hidden, cfg.classes, cfg.layout
    );
    let bytes = g.encode("trba_encoder_ctc", producer, &doc);
    stats.file_bytes = bytes.len();
    (bytes, stats)
}

pub fn write_file(path: &str, bytes: &[u8]) -> std::io::Result<()> {
    if let Some(dir) = std::path::Path::new(path).parent() {
        if !dir.as_os_str().is_empty() {
            std::fs::create_dir_all(dir)?;
        }
    }
    std::fs::write(path, bytes)
}

// ------------------------------------------------------- attention-декодер --

/// Развёртка attention-декодера (`attn.rs::greedy_decode_full`) в статический
/// граф: `n_steps = max_len + 1` итераций без раннего стопа — так же устроен
/// `onnx_mode` референсного Python-экспортёра и так же считается эталон.
///
/// Один шаг в терминах ONNX:
///
/// ```text
/// hh   = h2h(h)                                 Gemm(transB=1)
/// e    = tanh(proj_h + hh[:,None,:]) · score_w  Unsqueeze, Add, Tanh, MatMul
/// a    = softmax(e, axis=T) → [N,1,T]           Softmax, Transpose
/// ctx  = a · enc → [N,C]                        MatMul, Reshape
/// ci   = concat(ctx, onehot(prev))              OneHot, Concat
/// pre  = ci·w_ihᵀ + (b_ih+b_hh) + h·w_hhᵀ       Gemm, Gemm(beta=1)
/// i,f,g,o = split(pre, axis=1)                  Split
/// c    = σ(f)·c_prev + σ(i)·tanh(g)             Sigmoid, Tanh, Mul, Add
/// h    = σ(o)·tanh(c)                           Tanh, Mul
/// lg   = generator(h)                           Gemm
/// prev = argmax(lg, axis=-1)                    ArgMax
/// ```
///
/// Порядок гейтов здесь **наш** (i, f, g, o) — `Split` режет `pre` на четыре
/// равные части именно в этом порядке, поэтому перестановка, нужная для узла
/// `LSTM`, декодеру не требуется.
fn build_decoder(g: &mut Graph, attn: &crate::attn::AttentionDecoder, enc: &str, n_t: usize, n_steps: usize) {
    let hs = attn.hidden;
    let ctx = attn.ctx;
    let v = attn.classes;

    // ---- константы декодера
    let i2h_w = g.init_f32("dec.i2h_W", &[hs as i64, ctx as i64], &attn.i2h.w);
    let h2h_w = g.init_f32("dec.h2h_W", &[hs as i64, hs as i64], &attn.h2h.w);
    let h2h_b = g.init_f32("dec.h2h_B", &[hs as i64], &attn.h2h.b);
    // score.w лежит как [1, Hs]; MatMul хочет [Hs, 1] — те же числа, другая форма
    let score_w = g.init_f32("dec.score_W", &[hs as i64, 1], &attn.score.w);
    let w_ih = g.init_f32("dec.w_ih", &[4 * hs as i64, (ctx + v) as i64], &attn.w_ih);
    let b_sum: Vec<f32> = attn.b_ih.iter().zip(attn.b_hh.iter()).map(|(a, b)| a + b).collect();
    let b_sum = g.init_f32("dec.b_ih_plus_b_hh", &[4 * hs as i64], &b_sum);
    let w_hh = g.init_f32("dec.w_hh", &[4 * hs as i64, hs as i64], &attn.w_hh);
    let gen_w = g.init_f32("dec.gen_W", &[v as i64, hs as i64], &attn.generator.w);
    let gen_b = g.init_f32("dec.gen_B", &[v as i64], &attn.generator.b);
    let depth = g.init_i64("dec.depth", &[], &[v as i64]);
    let oh_vals = g.init_f32("dec.onehot_values", &[2], &[0.0, 1.0]);
    let axes1 = g.init_i64("dec.axes1", &[1], &[1]);
    let hs_dim = g.init_i64("dec.hs_dim", &[1], &[hs as i64]);
    let shp_flat = g.init_i64("dec.enc_flat", &[2], &[-1, ctx as i64]);
    let shp_proj = g.init_i64("dec.proj_shape", &[3], &[-1, n_t as i64, hs as i64]);
    let shp_ctx = g.init_i64("dec.ctx_shape", &[2], &[-1, ctx as i64]);

    // ---- proj_h = i2h(enc): считается один раз на все шаги
    let enc2 = g.op1("Reshape", &[enc, &shp_flat], vec![], "dec_enc_flat");
    let ph = {
        let ins = [enc2.as_str(), i2h_w.as_str()];
        g.op1("Gemm", &ins, vec![attr_i("transB", 1), attr_f("alpha", 1.0), attr_f("beta", 0.0)], "dec_i2h")
    };
    let proj_h = g.op1("Reshape", &[&ph, &shp_proj], vec![], "dec_proj_h");

    // ---- нулевые h/c и стартовый токен: batch динамический, поэтому размеры
    //      берутся из Shape(enc) и материализуются ConstantOfShape.
    let shp = g.op1("Shape", &[enc], vec![], "dec_shape_of_enc");
    let i0 = g.init_i64("dec.i0", &[1], &[0]);
    let ndim = g.op1("Gather", &[&shp, &i0], vec![attr_i("axis", 0)], "dec_batch_dim");
    let shape2 = g.op1("Concat", &[&ndim, &hs_dim], vec![attr_i("axis", 0)], "dec_shape_nh");
    let zero_f = tensor_f32("zero_f32", &[1], &[0.0]);
    let sos_t = tensor_i64("sos_i64", &[1], &[attn.sos as i64]);
    let mut h = g.op1("ConstantOfShape", &[&shape2], vec![attr_tensor("value", &zero_f)], "dec_h_init");
    let mut cc = g.op1("ConstantOfShape", &[&shape2], vec![attr_tensor("value", &zero_f)], "dec_c_init");
    let mut prev = g.op1("ConstantOfShape", &[&ndim], vec![attr_tensor("value", &sos_t)], "dec_prev_init");

    let mut steps: Vec<String> = Vec::with_capacity(n_steps);
    for _st in 0..n_steps {
        let hh = {
            let ins = [h.as_str(), h2h_w.as_str(), h2h_b.as_str()];
            g.op1("Gemm", &ins, vec![attr_i("transB", 1)], "dec_h2h")
        };
        let hh3 = g.op1("Unsqueeze", &[&hh, &axes1], vec![], "dec_hh3");
        let e = g.op1("Add", &[&proj_h, &hh3], vec![], "dec_score_sum");
        let e = g.op1("Tanh", &[&e], vec![], "dec_score_tanh");
        let e = g.op1("MatMul", &[&e, &score_w], vec![], "dec_score");
        let a = g.op1("Softmax", &[&e], vec![attr_i("axis", 1)], "dec_softmax");
        let a = g.op1("Transpose", &[&a], vec![attr_ints("perm", &[0, 2, 1])], "dec_alpha");
        let cv = g.op1("MatMul", &[&a, enc], vec![], "dec_context3");
        let cv = g.op1("Reshape", &[&cv, &shp_ctx], vec![], "dec_context");
        let oh = g.op1("OneHot", &[&prev, &depth, &oh_vals], vec![attr_i("axis", -1)], "dec_onehot");
        let ci = g.op1("Concat", &[&cv, &oh], vec![attr_i("axis", 1)], "dec_cell_in");
        let t1 = {
            let ins = [ci.as_str(), w_ih.as_str(), b_sum.as_str()];
            g.op1("Gemm", &ins, vec![attr_i("transB", 1)], "dec_gates_ih")
        };
        let pre = {
            let ins = [h.as_str(), w_hh.as_str(), t1.as_str()];
            g.op1("Gemm", &ins, vec![attr_i("transB", 1), attr_f("beta", 1.0)], "dec_gates_hh")
        };
        let o0 = g.uid("dec_gi");
        let o1 = g.uid("dec_gf");
        let o2 = g.uid("dec_gg");
        let o3 = g.uid("dec_go");
        let nm = g.uid("Split_node");
        g.nodes.push(node("Split", &[&pre], &[&o0, &o1, &o2, &o3], &[attr_i("axis", 1)], &nm));
        let ig = g.op1("Sigmoid", &[&o0], vec![], "dec_ig");
        let fg = g.op1("Sigmoid", &[&o1], vec![], "dec_fg");
        let cg = g.op1("Tanh", &[&o2], vec![], "dec_cg");
        let og = g.op1("Sigmoid", &[&o3], vec![], "dec_og");
        let keep = g.op1("Mul", &[&fg, &cc], vec![], "dec_c_keep");
        let add = g.op1("Mul", &[&ig, &cg], vec![], "dec_c_add");
        cc = g.op1("Add", &[&keep, &add], vec![], "dec_c_new");
        let ct = g.op1("Tanh", &[&cc], vec![], "dec_tanh_c");
        h = g.op1("Mul", &[&og, &ct], vec![], "dec_h_new");
        let lg = {
            let ins = [h.as_str(), gen_w.as_str(), gen_b.as_str()];
            g.op1("Gemm", &ins, vec![attr_i("transB", 1)], "dec_generator")
        };
        prev = g.op1("ArgMax", &[&lg], vec![attr_i("axis", -1), attr_i("keepdims", 0)], "dec_argmax");
        let lg3 = g.op1("Unsqueeze", &[&lg, &axes1], vec![], "dec_step_logits");
        steps.push(lg3);
    }

    let refs: Vec<&str> = steps.iter().map(|s| s.as_str()).collect();
    g.opn("Concat", &refs, &["logits"], vec![attr_i("axis", 1)], "dec_logits_concat");
    g.add_output("logits", DT_FLOAT, &[dim_param("batch"), dim_fixed(n_steps as i64), dim_fixed(v as i64)]);
    g.opn("ArgMax", &["logits"], &["pred"], vec![attr_i("axis", 2), attr_i("keepdims", 0)], "dec_pred");
    g.add_output("pred", DT_INT64, &[dim_param("batch"), dim_fixed(n_steps as i64)]);
}

// ------------------------------------------------------- минимальный парсер --
// Нужен только для unit-тестов: проверить, что написанный байтами граф
// действительно разбирается обратно в узлы/тензоры (round-trip без Python).

pub struct ParsedModel {
    pub ir_version: i64,
    pub producer: String,
    pub opset: i64,
    pub graph_name: String,
    pub nodes: Vec<ParsedNode>,
    pub initializers: Vec<(String, Vec<i64>, i32, usize)>,
    pub inputs: Vec<String>,
    pub outputs: Vec<String>,
}

pub struct ParsedNode {
    pub op: String,
    pub inputs: Vec<String>,
    pub outputs: Vec<String>,
    pub name: String,
    pub attrs_i: HashMap<String, i64>,
    pub attrs_ints: HashMap<String, Vec<i64>>,
    pub attrs_s: HashMap<String, String>,
}

struct Rd<'a> {
    b: &'a [u8],
    i: usize,
}

impl<'a> Rd<'a> {
    fn new(b: &'a [u8]) -> Self {
        Self { b, i: 0 }
    }
    fn eof(&self) -> bool {
        self.i >= self.b.len()
    }
    fn varint(&mut self) -> u64 {
        let mut v = 0u64;
        let mut sh = 0;
        loop {
            let byte = self.b[self.i];
            self.i += 1;
            v |= ((byte & 0x7f) as u64) << sh;
            if byte & 0x80 == 0 {
                return v;
            }
            sh += 7;
        }
    }
    fn bytes(&mut self) -> Vec<u8> {
        let n = self.varint() as usize;
        let out = self.b[self.i..self.i + n].to_vec();
        self.i += n;
        out
    }
    fn str(&mut self) -> String {
        String::from_utf8_lossy(&self.bytes()).to_string()
    }
    fn packed_i64(&mut self) -> Vec<i64> {
        let raw = self.bytes();
        let mut r = Rd::new(&raw);
        let mut v = Vec::new();
        while !r.eof() {
            v.push(r.varint() as i64);
        }
        v
    }
    /// Возвращает (field, wire) и продвигается только за тег.
    fn tag(&mut self) -> (u32, u32) {
        let t = self.varint();
        ((t >> 3) as u32, (t & 7) as u32)
    }
    fn skip(&mut self, wire: u32) {
        match wire {
            0 => {
                let _ = self.varint();
            }
            1 => self.i += 8,
            2 => {
                let _ = self.bytes();
            }
            5 => self.i += 4,
            _ => panic!("unexpected wire {wire}"),
        }
    }
}

fn parse_tensor(b: &[u8]) -> (String, Vec<i64>, i32, usize) {
    let mut r = Rd::new(b);
    let (mut name, mut dims, mut dt, mut raw_len, mut count) = (String::new(), Vec::new(), 0i32, 0usize, 0usize);
    while !r.eof() {
        let (f, w) = r.tag();
        match f {
            1 => dims = r.packed_i64(),
            2 => dt = r.varint() as i32,
            8 => name = r.str(),
            9 => raw_len = r.bytes().len(),
            4 => count = r.bytes().len() / 4,
            _ => r.skip(w),
        }
    }
    (name, dims, dt, raw_len.max(count))
}

fn parse_node(b: &[u8]) -> ParsedNode {
    let mut r = Rd::new(b);
    let mut n = ParsedNode {
        op: String::new(),
        inputs: Vec::new(),
        outputs: Vec::new(),
        name: String::new(),
        attrs_i: HashMap::new(),
        attrs_ints: HashMap::new(),
        attrs_s: HashMap::new(),
    };
    while !r.eof() {
        let (f, w) = r.tag();
        match f {
            1 => n.inputs.push(r.str()),
            2 => n.outputs.push(r.str()),
            3 => n.name = r.str(),
            4 => n.op = r.str(),
            5 => {
                let ab = r.bytes();
                let mut ar = Rd::new(&ab);
                let mut aname = String::new();
                let mut ai = 0i64;
                let mut aints: Vec<i64> = Vec::new();
                let mut as_ = String::new();
                while !ar.eof() {
                    let (af, aw) = ar.tag();
                    match af {
                        1 => aname = ar.str(),
                        3 => ai = ar.varint() as i64,
                        4 => as_ = ar.str(),
                        8 => aints = ar.packed_i64(),
                        _ => ar.skip(aw),
                    }
                }
                if !aints.is_empty() {
                    n.attrs_ints.insert(aname.clone(), aints);
                } else if !as_.is_empty() {
                    n.attrs_s.insert(aname.clone(), as_);
                } else {
                    n.attrs_i.insert(aname, ai);
                }
            }
            _ => r.skip(w),
        }
    }
    n
}

fn parse_value_info(b: &[u8]) -> String {
    let mut r = Rd::new(b);
    let mut name = String::new();
    while !r.eof() {
        let (f, w) = r.tag();
        if f == 1 {
            name = r.str();
        } else {
            r.skip(w);
        }
    }
    name
}

pub fn parse_model(b: &[u8]) -> ParsedModel {
    let mut r = Rd::new(b);
    let mut m = ParsedModel {
        ir_version: 0,
        producer: String::new(),
        opset: 0,
        graph_name: String::new(),
        nodes: Vec::new(),
        initializers: Vec::new(),
        inputs: Vec::new(),
        outputs: Vec::new(),
    };
    while !r.eof() {
        let (f, w) = r.tag();
        match f {
            1 => m.ir_version = r.varint() as i64,
            2 => m.producer = r.str(),
            7 => {
                let gb = r.bytes();
                let mut gr = Rd::new(&gb);
                while !gr.eof() {
                    let (gf, gw) = gr.tag();
                    match gf {
                        1 => m.nodes.push(parse_node(&gr.bytes())),
                        2 => m.graph_name = gr.str(),
                        5 => m.initializers.push(parse_tensor(&gr.bytes())),
                        11 => m.inputs.push(parse_value_info(&gr.bytes())),
                        12 => m.outputs.push(parse_value_info(&gr.bytes())),
                        _ => gr.skip(gw),
                    }
                }
            }
            8 => {
                let ob = r.bytes();
                let mut or_ = Rd::new(&ob);
                while !or_.eof() {
                    let (of, ow) = or_.tag();
                    if of == 2 {
                        m.opset = or_.varint() as i64;
                    } else {
                        or_.skip(ow);
                    }
                }
            }
            _ => r.skip(w),
        }
    }
    m
}
