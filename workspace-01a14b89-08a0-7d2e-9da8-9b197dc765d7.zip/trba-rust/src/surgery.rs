//! # Хирургия весов: наращивание геометрии через `--resume`
//!
//! Задача: модель, обученную на `32×128`, продолжить на `64×256` (и заодно
//! сделать выразительнее — `hidden 256 → 384`), **переиспользуя веса**, а не
//! начиная с нуля. Размер растёт постепенно: `32×128 → 48×192 → 64×256`.
//!
//! ## Что вообще зависит от геометрии
//!
//! | изменение | что происходит с весами |
//! |---|---|
//! | `img_h`/`img_w` (разрешение входа) | **ничего**: свёртки, BN, SE, BiLSTM и attention-декодер от размера картинки не зависят. Меняется только число шагов `T = img_w/8` — позиционных эмбеддингов в архитектуре нет, поэтому перенос бесплатный. Следить надо за шкалами int8-активаций (пересчитываются на новых батчах) и за временем: больше пикселей = больше вычислений. |
//! | `max_len` | ничего: это число шагов развёртки декодера, параметров не добавляет |
//! | `hidden` | меняются формы `rnn*`, `attn*`, `ctc.w` — нужна хирургия |
//! | `classes` (словарь) | меняются строки `ctc.*`, `attn.gen.*` и столбцы `attn.w_ih` — нужна хирургия |
//! | `rnn_layers` | новые слои не из чего строить — инициализируются заново, старые переносятся |
//!
//! ## Правило переноса (Net2Net / Net2WiderNet)
//!
//! Новые **строки** (новые ячейки LSTM, новые выходы) заполняются дубликатами
//! существующих — `r % src_rows` внутри своего блока, поэтому новая ячейка с
//! первого шага вычисляет осмысленное, а не случайное. Новые **столбцы** (вклад
//! новых ячеек в старые) заполняются нулями при `eps = 0`: старые ячейки и все
//! выходы сети сохраняются **побитово**, то есть наращивание ничего не ломает.
//!
//! Нулевые столбцы означают и нулевой градиент в новые ячейки — мёртвый вес.
//! Поэтому при `eps > 0` в новые столбцы добавляется шум `±eps·std(весов)`:
//! выход сети уезжает на ~eps (при `eps = 0.01` — на процент), зато новые
//! ячейки сразу получают градиент и начинают специализироваться. Дублированные
//! строки при этом тоже чуть разводятся шумом, иначе копии остаются
//! идентичными навсегда и симметрия не ломается.
//!
//! ## Блочность — главное, из-за чего нельзя просто дописать хвост
//!
//! Вентили LSTM лежат не «сначала все i, потом все f», а блоками по `h`:
//! строка `r` матрицы `[4h, ·]` — это вентиль `r / h`, ячейка `r % h`. Поэтому
//! при `h → h'` новые строки обязаны вставляться **в конец каждого из четырёх
//! блоков**, а не в конец вектора. То же для `proj.w [h, 2h]`: столбцы — это
//! два блока (прямое и обратное направления), и новые столбцы идут в конец
//! каждого. `attn.w_ih [4h, ctx+classes]` разбит и по строкам (4 вентиля), и по
//! столбцам (контекст и эмбеддинг токена). Всё это описывается одной
//! структурой [`Block`] — списком пар `(src_size, dst_size)` для осей.

use rand::rngs::StdRng;
use rand::Rng;

/// Геометрия модели: всё, что определяет формы весов, включая ширину энкодера
/// `feat_dim` (`--feat-dim`, по умолчанию 512 — историческая архитектура).
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Geometry {
    pub img_h: usize,
    pub img_w: usize,
    pub max_len: usize,
    pub hidden: usize,
    pub classes: usize,
    pub rnn_layers: usize,
    pub feat_dim: usize,
}

impl Geometry {
    pub fn new(img_h: usize, img_w: usize, max_len: usize, hidden: usize, classes: usize, rnn_layers: usize) -> Self {
        Self { img_h, img_w, max_len, hidden, classes, rnn_layers, feat_dim: 512 }
    }

    /// Ширина энкодера отличается от 512 (`--feat-dim`): формы весов CNN и вход
    /// BiLSTM зависят от неё, поэтому геометрия обязана её помнить.
    pub fn with_feat_dim(mut self, feat_dim: usize) -> Self {
        self.feat_dim = feat_dim;
        self
    }

    /// Совпадают ли формы весов: то, что реально требует хирургии. Разрешение и
    /// `max_len` сюда не входят — на формы они не влияют, но на статистику
    /// градиентов влияют (число шагов T меняется), поэтому для решения «переносить
    /// ли Adam-моменты» нужен более широкий предикат [`Geometry::same_training_regime`].
    pub fn same_weight_shapes(&self, other: &Geometry) -> bool {
        self.hidden == other.hidden
            && self.classes == other.classes
            && self.rnn_layers == other.rnn_layers
            && self.feat_dim == other.feat_dim
    }

    /// Тот же режим обучения: ни формы, ни число шагов не изменились. Только в
    /// этом случае Adam-моменты имеет смысл переносить.
    pub fn same_training_regime(&self, other: &Geometry) -> bool {
        self.same_weight_shapes(other)
            && (self.img_h == 0 || other.img_h == 0
                || (self.img_h == other.img_h
                    && self.img_w == other.img_w
                    && self.max_len == other.max_len))
    }

    /// Что изменилось при переходе **от `self` (старая геометрия) к `other`
    /// (новая)** и чем это грозит весам. Порядок аргументов важен: от него
    /// зависит слово «рост»/«усечение», поэтому вызывается как `old.diff(&new)`.
    /// Пустой список = перенос бесплатный.
    pub fn diff(&self, other: &Geometry) -> Vec<String> {
        let mut d = Vec::new();
        if self.img_h != other.img_h || self.img_w != other.img_w {
            d.push(format!(
                "вход {}×{} вместо {}×{} (весов не касается: свёртки и BiLSTM от размера картинки не зависят, меняется только число шагов T)",
                other.img_h, other.img_w, self.img_h, self.img_w
            ));
        }
        if self.max_len != other.max_len {
            d.push(format!(
                "max_len {} вместо {} (шаги развёртки декодера, параметров не добавляет)",
                other.max_len, self.max_len
            ));
        }
        if self.hidden != other.hidden {
            d.push(format!(
                "hidden {} вместо {} — хирургия rnn/attn/ctc: {}",
                other.hidden,
                self.hidden,
                if other.hidden > self.hidden { "рост" } else { "усечение" }
            ));
        }
        if self.classes != other.classes {
            d.push(format!(
                "словарь {} вместо {} токенов — хирургия строк ctc/attn.gen",
                other.classes, self.classes
            ));
        }
        if self.rnn_layers != other.rnn_layers {
            d.push(format!(
                "слоёв BiLSTM {} вместо {} — {}",
                other.rnn_layers,
                self.rnn_layers,
                if other.rnn_layers > self.rnn_layers {
                    "новым слоям не из чего расти, они инициализируются заново"
                } else {
                    "лишние слои отбрасываются"
                }
            ));
        }
        if self.feat_dim != other.feat_dim {
            d.push(format!(
                "выход CNN {} вместо {} — первый слой BiLSTM и внимание по контексту меняют формы",
                other.feat_dim, self.feat_dim
            ));
        }
        d
    }

    /// `64x256`, `48x192h320`, `64x256h384L2m32` — спецификация ступени роста.
    pub fn parse_spec(spec: &str, base: &Geometry) -> Result<Geometry, String> {
        let mut g = *base;
        let mut saw_size = false;
        let mut pending_w = false;
        let mut num = String::new();
        let mut mode = ' ';
        for c in spec.chars() {
            match c {
                '0'..='9' => num.push(c),
                'x' | 'X' if !num.is_empty() && !saw_size => {
                    g.img_h = num.parse().map_err(|_| format!("{spec}: img_h"))?;
                    num.clear();
                    saw_size = true;
                    pending_w = true;
                    mode = 'w';
                }
                'h' | 'H' | 'L' | 'm' | 'M' | 'c' | 'C' => {
                    if mode == 'w' && !num.is_empty() {
                        g.img_w = num.parse().map_err(|_| format!("{spec}: img_w"))?;
                        num.clear();
                        pending_w = false;
                        mode = ' ';
                    } else if !num.is_empty() {
                        apply(&mut g, mode, &num, spec)?;
                        num.clear();
                    }
                    mode = c;
                }
                other => return Err(format!("{spec}: неожиданный символ {other:?} (формат: 64x256h384L2m32)")),
            }
        }
        if !num.is_empty() {
            if mode == 'w' {
                g.img_w = num.parse().map_err(|_| format!("{spec}: img_w"))?;
                pending_w = false;
            } else {
                apply(&mut g, mode, &num, spec)?;
            }
        }
        if !saw_size {
            return Err(format!("{spec}: нет размера HxW (например 64x256 или 48x192h320)"));
        }
        if pending_w {
            return Err(format!("{spec}: после «x» нет ширины (ожидалось например 64x256)"));
        }
        if g.img_h == 0 || g.img_w == 0 || g.hidden == 0 || g.classes == 0 || g.rnn_layers == 0 {
            return Err(format!("{spec}: какое-то из измерений оказалось нулевым"));
        }
        Ok(g)
    }
}

fn apply(g: &mut Geometry, mode: char, num: &str, spec: &str) -> Result<(), String> {
    let v: usize = num.parse().map_err(|_| format!("{spec}: {mode}{num} — не число"))?;
    match mode {
        'h' | 'H' => g.hidden = v,
        'L' => g.rnn_layers = v,
        'm' | 'M' => g.max_len = v,
        'c' | 'C' => g.classes = v,
        'w' => g.img_w = v,
        _ => return Err(format!("{spec}: неизвестный модификатор {mode:?}")),
    }
    Ok(())
}

impl std::fmt::Display for Geometry {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(
            f,
            "{}×{} max_len {} hidden {} классов {} rnn {} feat {}",
            self.img_h, self.img_w, self.max_len, self.hidden, self.classes, self.rnn_layers, self.feat_dim
        )
    }
}

/// Разбиение осей матрицы на блоки: для каждой оси список пар
/// `(размер_в_источнике, размер_в_назначении)`. Одномерный тензор — это
/// `rows = [(n_src, n_dst)]`, `cols = [(1, 1)]`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Block {
    pub rows: Vec<(usize, usize)>,
    pub cols: Vec<(usize, usize)>,
}

impl Block {
    pub fn plain(rows: (usize, usize), cols: (usize, usize)) -> Self {
        Self { rows: vec![rows], cols: vec![cols] }
    }
    /// Четыре вентильных блока LSTM по строкам.
    pub fn gated(h: (usize, usize), cols: Vec<(usize, usize)>) -> Self {
        Self { rows: vec![h, h, h, h], cols }
    }
    pub fn src_rows(&self) -> usize { self.rows.iter().map(|p| p.0).sum() }
    pub fn dst_rows(&self) -> usize { self.rows.iter().map(|p| p.1).sum() }
    pub fn src_cols(&self) -> usize { self.cols.iter().map(|p| p.0).sum() }
    pub fn dst_cols(&self) -> usize { self.cols.iter().map(|p| p.1).sum() }
}

/// Как переносить.
#[derive(Clone, Copy, Debug)]
pub struct SurgeryCfg {
    /// Шум в новых столбцах, в долях `std` исходных весов. `0.0` = побитовое
    /// сохранение выхода сети (новые ячейки при этом мёртвы), `0.01` = выход
    /// уезжает примерно на процент, зато новые ячейки сразу учатся.
    pub eps: f32,
    pub seed: u64,
}

impl Default for SurgeryCfg {
    fn default() -> Self { Self { eps: 0.01, seed: 42 } }
}

/// Что сделали с тензором.
#[derive(Clone, Debug, PartialEq)]
pub enum Act {
    /// формы совпали — скопирован как есть
    Copy,
    /// назначение больше источника — строки дублированы, столбцы дополнены
    Grow,
    /// назначение меньше — усечено по блокам
    Shrink,
    /// перенести не удалось (причина)
    Skip(String),
}

/// Итог переноса: сколько тензоров скопировано/выращено/усечено/пропущено.
#[derive(Clone, Debug, Default)]
pub struct Report {
    pub copied: usize,
    pub grown: usize,
    pub shrunk: usize,
    pub skipped: Vec<(String, String)>,
    pub notes: Vec<String>,
    /// тензоры, где появились новые строки/столбцы (им обнуляют Adam-моменты)
    pub changed: Vec<String>,
    /// сколько Adam-моментов восстановлено (0 = старый формат V4 или рост)
    pub moments: usize,
}

impl Report {
    pub fn is_empty(&self) -> bool {
        self.grown == 0 && self.shrunk == 0 && self.skipped.is_empty()
    }
    pub fn report(&self) -> String {
        let mut s = format!(
            "скопировано {} тензоров, выращено {}, усечено {}, пропущено {}",
            self.copied, self.grown, self.shrunk, self.skipped.len()
        );
        for n in &self.notes {
            s.push_str(&format!("\n   ℹ️  {n}"));
        }
        for (name, why) in self.skipped.iter().take(12) {
            s.push_str(&format!("\n   ⚠️  {name}: {why}"));
        }
        if self.skipped.len() > 12 {
            s.push_str(&format!("\n   … и ещё {}", self.skipped.len() - 12));
        }
        s
    }
}

/// Разбор имени тензора из манифеста модели в блочную структуру.
///
/// `None` = форма от `hidden`/`classes` не зависит (свёртки, BN, SE): такие
/// тензоры копируются как есть, а если формы всё же не сошлись — это смена
/// числа каналов CNN, и перенос невозможен без переобучения слоя.
pub fn blocks_for(name: &str, s: &Geometry, d: &Geometry) -> Option<Block> {
    let (sh, dh) = (s.hidden, d.hidden);
    let h = (sh, dh);
    let c = (s.classes, d.classes);
    let one = (1, 1);

    if let Some(rest) = name.strip_prefix("rnn") {
        // rnn{li}.{f|b}.{w_ih|b_ih|w_hh|b_hh} | rnn{li}.proj.{w|b}
        let mut parts = rest.split('.');
        let li: usize = parts.next()?.parse().ok()?;
        let dir = parts.next().unwrap_or("");
        let tensor = parts.next().unwrap_or(dir);
        let in_dim = |g: &Geometry| if li == 0 { g.feat_dim } else { g.hidden };
        return match (dir, tensor) {
            ("f", "w_ih") | ("b", "w_ih") => Some(Block::gated(h, vec![(in_dim(s), in_dim(d))])),
            ("f", "w_hh") | ("b", "w_hh") => Some(Block::gated(h, vec![h])),
            ("f", "b_ih") | ("b", "b_ih") | ("f", "b_hh") | ("b", "b_hh") => {
                Some(Block::gated(h, vec![one]))
            }
            ("proj", "w") => Some(Block { rows: vec![h], cols: vec![h, h] }),
            ("proj", "b") => Some(Block { rows: vec![h], cols: vec![one] }),
            _ => None,
        };
    }

    match name {
        "attn.i2h.w" => Some(Block::plain(h, h)),
        "attn.h2h.w" => Some(Block::plain(h, h)),
        "attn.h2h.b" => Some(Block { rows: vec![h], cols: vec![one] }),
        "attn.score.w" => Some(Block::plain(one, h)),
        // ячейка декодера видит [контекст | эмбеддинг токена]
        "attn.w_ih" => Some(Block::gated(h, vec![h, c])),
        "attn.b_ih" => Some(Block::gated(h, vec![one])),
        "attn.w_hh" => Some(Block::gated(h, vec![h])),
        "attn.b_hh" => Some(Block::gated(h, vec![one])),
        "attn.gen.w" => Some(Block::plain(c, h)),
        "attn.gen.b" => Some(Block { rows: vec![c], cols: vec![one] }),
        "ctc.w" => Some(Block::plain(c, h)),
        "ctc.b" => Some(Block { rows: vec![c], cols: vec![one] }),
        _ => None,
    }
}

/// Перенос одного тензора. Возвращает, что именно сделано.
///
/// `src`/`dst` — плоские срезы в раскладке «строки × столбцы» (row-major).
pub fn transfer(
    name: &str,
    src: &[f32],
    dst: &mut [f32],
    s: &Geometry,
    d: &Geometry,
    cfg: &SurgeryCfg,
    rng: &mut StdRng,
) -> Act {
    if src.len() == dst.len() {
        dst.copy_from_slice(src);
        return Act::Copy;
    }
    let Some(b) = blocks_for(name, s, d) else {
        return Act::Skip(format!(
            "форма {} ≠ {} и от hidden/classes не зависит — слой придётся обучить заново",
            src.len(),
            dst.len()
        ));
    };
    if b.src_rows() * b.src_cols() != src.len() || b.dst_rows() * b.dst_cols() != dst.len() {
        return Act::Skip(format!(
            "разбиение осей {:?} не сходится с длинами {} и {}",
            b,
            src.len(),
            dst.len()
        ));
    }
    transfer_blocks(src, dst, &b, cfg.eps, rng);
    if dst.len() > src.len() { Act::Grow } else { Act::Shrink }
}

/// Ядро переноса: для каждого элемента назначения ищем соответствующий элемент
/// источника внутри своих блоков строк и столбцов.
pub fn transfer_blocks(src: &[f32], dst: &mut [f32], b: &Block, eps: f32, rng: &mut StdRng) {
    let (sr, dr) = (b.src_rows(), b.dst_rows());
    let (sc, dc) = (b.src_cols(), b.dst_cols());
    debug_assert_eq!(src.len(), sr * sc);
    debug_assert_eq!(dst.len(), dr * dc);

    // std исходных весов — масштаб шума для новых столбцов
    let mean = src.iter().map(|&x| x as f64).sum::<f64>() / src.len().max(1) as f64;
    let var = src.iter().map(|&x| (x as f64 - mean).powi(2)).sum::<f64>() / src.len().max(1) as f64;
    let std = var.sqrt() as f32;
    let noise = eps * std;

    let rowmap = prefix(&b.rows);
    let colmap = prefix(&b.cols);

    for r in 0..dr {
        let (rb, ro) = locate(&rowmap, r);
        let new_row = ro >= rb.2;
        let sr_row = rb.0 + if new_row { ro % rb.2.max(1) } else { ro };
        for c in 0..dc {
            let (cb, co) = locate(&colmap, c);
            let new_col = co >= cb.2;
            let sc_col = cb.0 + if new_col { co % cb.2.max(1) } else { co };
            let v = src[sr_row * sc + sc_col];
            dst[r * dc + c] = if new_col {
                // вклад новой ячейки в старые выходы: ноль (побитовое
                // сохранение) либо малый шум (чтобы новые ячейки учились)
                if noise > 0.0 { rng.gen_range(-1.0..1.0) * noise } else { 0.0 }
            } else if new_row && noise > 0.0 {
                v + rng.gen_range(-1.0..1.0) * noise
            } else {
                v
            };
        }
    }
}

fn prefix(v: &[(usize, usize)]) -> Vec<(usize, usize, usize, usize)> {
    let mut out = Vec::with_capacity(v.len());
    let (mut so, mut dof) = (0usize, 0usize);
    for &(s, d) in v {
        out.push((so, dof, s, d));
        so += s;
        dof += d;
    }
    out
}

/// Какой блок покрывает индекс `i` и какое у него смещение внутри блока.
fn locate(map: &[(usize, usize, usize, usize)], i: usize) -> (&(usize, usize, usize, usize), usize) {
    for m in map {
        if i < m.1 + m.3 {
            return (m, i - m.1);
        }
    }
    let last = &map[0];
    (last, i.saturating_sub(last.1))
}

/// Восстановление геометрии по формам тензоров — нужно для чекпоинтов V4/V5,
/// где ни геометрии, ни имён нет. `hidden`/`classes`/`rnn_layers`/`feat_dim`
/// извлекаются однозначно; `img_h`/`img_w`/`max_len` из весов не
/// восстанавливаются (на формы они не влияют) и возвращаются нулями — вызывающий
/// подставляет их из своих аргументов.
pub fn geometry_from_lens(lens: &[(String, usize)]) -> Option<Geometry> {
    let get = |n: &str| lens.iter().find(|(k, _)| k == n).map(|p| p.1);
    let classes = get("ctc.b")?; // [classes]
    let hidden = get("attn.h2h.b")?; // [hidden]
    if hidden == 0 || classes == 0 {
        return None;
    }
    let mut rnn_layers = 0usize;
    while get(&format!("rnn{rnn_layers}.proj.b")).is_some() {
        rnn_layers += 1;
    }
    if rnn_layers == 0 {
        return None;
    }
    let w0 = get("rnn0.f.w_ih")?; // [4h, feat_dim]
    let feat_dim = w0 / (4 * hidden);
    if feat_dim == 0 {
        return None;
    }
    Some(Geometry { img_h: 0, img_w: 0, max_len: 0, hidden, classes, rnn_layers, feat_dim })
}

/// Ступень постепенного роста: геометрия + сколько эпох на ней обучаться.
#[derive(Clone, Debug)]
pub struct Stage {
    pub geom: Geometry,
    pub epochs: usize,
}

/// `"48x192:3,64x256h384:5"` → две ступени, каждая наследует предыдущую.
pub fn parse_ladder(spec: &str, base: &Geometry) -> Result<Vec<Stage>, String> {
    if spec.trim().is_empty() {
        return Err("пустая лестница роста".to_string());
    }
    let mut out = Vec::new();
    let mut cur = *base;
    for part in spec.split(',') {
        let part = part.trim();
        if part.is_empty() {
            continue;
        }
        let (gs, es) = part
            .rsplit_once(':')
            .ok_or_else(|| format!("{part}: нет «:эпохи» (например 64x256:5)"))?;
        let epochs: usize = es.parse().map_err(|_| format!("{part}: {es:?} — не число эпох"))?;
        if epochs == 0 {
            return Err(format!("{part}: ноль эпох — ступень ничего не делает"));
        }
        cur = Geometry::parse_spec(gs, &cur)?;
        out.push(Stage { geom: cur, epochs });
    }
    if out.is_empty() {
        return Err("в лестнице роста нет ни одной ступени".to_string());
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;
    use rand::SeedableRng;

    fn geom(hidden: usize, classes: usize) -> Geometry {
        Geometry::new(32, 128, 16, hidden, classes, 2)
    }

    #[test]
    fn grow_hidden_preserves_outputs_bitwise_at_zero_eps() {
        let s = geom(4, 3);
        let d = geom(6, 3);
        let mut rng = StdRng::seed_from_u64(7);
        let src: Vec<f32> = (0..3 * 4).map(|i| (i as f32) * 0.1 - 0.5).collect();
        let mut dst = vec![0.0f32; 3 * 6];
        let act = transfer("ctc.w", &src, &mut dst, &s, &d, &SurgeryCfg { eps: 0.0, seed: 7 }, &mut rng);
        assert_eq!(act, Act::Grow);
        // логиты на том же hidden-векторе, дополненном нулями в новых ячейках
        let h_src = [0.3f32, -0.2, 0.7, 0.1];
        let mut h_dst = [0.0f32; 6];
        h_dst[..4].copy_from_slice(&h_src);
        for c in 0..3 {
            let before: f32 = (0..4).map(|k| src[c * 4 + k] * h_src[k]).sum();
            let after: f32 = (0..6).map(|k| dst[c * 6 + k] * h_dst[k]).sum();
            assert_eq!(before, after, "логит класса {c} обязан сохраниться побитово");
        }
    }

    #[test]
    fn gated_rows_grow_inside_each_gate_block_not_at_the_tail() {
        // w_hh [4h, h]: при h 2→3 новые строки обязаны попасть в конец КАЖДОГО
        // из четырёх вентильных блоков, иначе вентили перепутаются местами.
        let s = geom(2, 5);
        let d = geom(3, 5);
        let mut rng = StdRng::seed_from_u64(1);
        // помечаем строку номером: r-я строка блока g = g*2 + r, столбцы +0/+0.5
        let rows: Vec<f32> = (0..4 * 2).map(|r| r as f32).collect();
        let src: Vec<f32> = rows.iter().flat_map(|&v| [v, v + 0.5]).collect();
        let mut dst = vec![0.0f32; 4 * 3 * 3];
        let act = transfer("rnn0.f.w_hh", &src, &mut dst, &s, &d, &SurgeryCfg { eps: 0.0, seed: 1 }, &mut rng);
        assert_eq!(act, Act::Grow);
        for g in 0..4 {
            for r in 0..2 {
                for c in 0..2 {
                    let want = (g * 2 + r) as f32 + if c == 1 { 0.5 } else { 0.0 };
                    assert_eq!(dst[(g * 3 + r) * 3 + c], want, "старая строка g={g} r={r} c={c}");
                }
            }
            let v = dst[(g * 3 + 2) * 3];
            assert!(
                (v - (g * 2) as f32).abs() < 1e-6,
                "новая строка вентиля {g} — дубликат своего блока, получено {v}"
            );
            for r in 0..3 {
                assert_eq!(dst[(g * 3 + r) * 3 + 2], 0.0, "новый столбец обязан быть нулевым при eps=0");
            }
        }
    }

    #[test]
    fn proj_columns_are_two_direction_blocks() {
        let s = geom(2, 5);
        let d = geom(3, 5);
        let mut rng = StdRng::seed_from_u64(3);
        let src: Vec<f32> = (0..2 * 4).map(|i| i as f32).collect();
        let mut dst = vec![-1.0f32; 3 * 6];
        transfer("rnn0.proj.w", &src, &mut dst, &s, &d, &SurgeryCfg { eps: 0.0, seed: 3 }, &mut rng);
        // блок 0 (прямое направление): столбцы 0..2, блок 1 (обратное): 3..5
        assert_eq!(&dst[0..3], &[0.0, 1.0, 0.0]);
        assert_eq!(&dst[3..6], &[2.0, 3.0, 0.0]);
        assert_eq!(&dst[6..9], &[4.0, 5.0, 0.0]);
        assert_eq!(&dst[9..12], &[6.0, 7.0, 0.0]);
        // новая строка выхода — дубликат
        assert_eq!(&dst[12..15], &[0.0, 1.0, 0.0]);
    }

    #[test]
    fn attn_w_ih_has_gate_rows_and_two_column_groups() {
        let s = geom(2, 3);
        let d = geom(3, 4);
        let b = blocks_for("attn.w_ih", &s, &d).unwrap();
        assert_eq!(b.rows, vec![(2, 3), (2, 3), (2, 3), (2, 3)]);
        assert_eq!(b.cols, vec![(2, 3), (3, 4)], "контекст = hidden, затем словарь");
        assert_eq!(b.src_rows() * b.src_cols(), 8 * 5);
        assert_eq!(b.dst_rows() * b.dst_cols(), 12 * 7);
        let mut rng = StdRng::seed_from_u64(9);
        let src: Vec<f32> = (0..40).map(|i| i as f32 * 0.01).collect();
        let mut dst = vec![0.0f32; 84];
        assert_eq!(
            transfer("attn.w_ih", &src, &mut dst, &s, &d, &SurgeryCfg { eps: 0.0, seed: 9 }, &mut rng),
            Act::Grow
        );
        // строка 0: [ctx0 ctx1 0 | cls0 cls1 cls2 0]
        assert_eq!(&dst[0..3], &[0.0, 0.01, 0.0]);
        assert_eq!(&dst[3..7], &[0.02, 0.03, 0.04, 0.0]);
    }

    #[test]
    fn shrink_truncates_inside_blocks() {
        let s = geom(6, 5);
        let d = geom(4, 5);
        let mut rng = StdRng::seed_from_u64(4);
        let src: Vec<f32> = (0..4 * 6 * 6).map(|i| i as f32).collect();
        let mut dst = vec![0.0f32; 4 * 4 * 4];
        assert_eq!(
            transfer("rnn1.b.w_hh", &src, &mut dst, &s, &d, &SurgeryCfg { eps: 0.0, seed: 4 }, &mut rng),
            Act::Shrink
        );
        for g in 0..4 {
            for r in 0..4 {
                for c in 0..4 {
                    assert_eq!(dst[(g * 4 + r) * 4 + c], src[(g * 6 + r) * 6 + c], "g={g} r={r} c={c}");
                }
            }
        }
    }

    #[test]
    fn eps_noise_keeps_drift_small_and_breaks_symmetry() {
        let s = geom(4, 3);
        let d = geom(8, 3);
        let cfg = SurgeryCfg { eps: 0.01, seed: 11 };
        let src: Vec<f32> = (0..3 * 4).map(|i| ((i * 37) % 11) as f32 * 0.05 - 0.25).collect();
        let mut a = vec![0.0f32; 3 * 8];
        let mut b = vec![0.0f32; 3 * 8];
        transfer("ctc.w", &src, &mut a, &s, &d, &cfg, &mut StdRng::seed_from_u64(cfg.seed));
        transfer("ctc.w", &src, &mut b, &s, &d, &cfg, &mut StdRng::seed_from_u64(cfg.seed));
        assert_eq!(a, b, "перенос детерминирован при одном seed");
        let std = {
            let m = src.iter().sum::<f32>() / src.len() as f32;
            (src.iter().map(|x| (x - m).powi(2)).sum::<f32>() / src.len() as f32).sqrt()
        };
        for c in 0..3 {
            for k in 0..4 {
                assert!(
                    (a[c * 8 + k] - src[c * 4 + k]).abs() < 0.011 * std,
                    "старый вес уехал сильнее eps·std"
                );
            }
        }
        let newcols: Vec<f32> = (0..3).flat_map(|c| a[c * 8 + 4..c * 8 + 8].to_vec()).collect();
        assert!(newcols.iter().any(|v| v.abs() > 1e-9), "при eps>0 новые ячейки обязаны получать градиент");
        assert!(newcols.iter().all(|v| v.abs() < 0.05 * std), "шум обязан оставаться малым");
    }

    #[test]
    fn resolution_and_max_len_need_no_surgery_at_all() {
        // главное свойство роста разрешения: формы весов не меняются
        let a = Geometry::new(32, 128, 16, 256, 140, 2);
        let b = Geometry::new(64, 256, 32, 256, 140, 2);
        for name in [
            "rnn0.f.w_ih", "rnn0.f.w_hh", "rnn0.proj.w", "rnn1.b.w_hh",
            "attn.i2h.w", "attn.w_ih", "attn.gen.w", "ctc.w", "ctc.b",
        ] {
            let bl = blocks_for(name, &a, &b).expect(name);
            assert_eq!(bl.src_rows(), bl.dst_rows(), "{name}: строки");
            assert_eq!(bl.src_cols(), bl.dst_cols(), "{name}: столбцы");
        }
        let d = b.diff(&a);
        assert_eq!(d.len(), 2, "только вход и max_len: {d:?}");
        assert!(d[0].contains("весов не касается"), "{d:?}");
    }

    #[test]
    fn moments_are_only_worth_carrying_in_the_same_regime() {
        let a = Geometry::new(32, 128, 16, 64, 140, 2);
        assert!(a.same_training_regime(&a));
        // рост разрешения: формы те же, но шагов вдвое больше => статистика градиентов чужая
        let bigger = Geometry::new(64, 256, 16, 64, 140, 2);
        assert!(a.same_weight_shapes(&bigger), "формы весов от разрешения не зависят");
        assert!(!a.same_training_regime(&bigger), "а моменты переносить нельзя: T удвоилось");
        // рост hidden: формы меняются
        let wider = Geometry::new(32, 128, 16, 96, 140, 2);
        assert!(!a.same_weight_shapes(&wider) && !a.same_training_regime(&wider));
        // V4/V5: разрешение неизвестно (нули) => судим только по формам
        let legacy = Geometry { img_h: 0, img_w: 0, max_len: 0, ..a };
        assert!(legacy.same_training_regime(&bigger), "без данных о разрешении режим считается тем же");
        assert!(!legacy.same_training_regime(&wider));
    }

    #[test]
    fn diff_reads_as_a_transition_from_self_to_other() {
        let old = Geometry::new(32, 128, 16, 64, 140, 2);
        let new = Geometry::new(64, 256, 32, 96, 140, 3);
        let d = old.diff(&new);
        assert!(d.iter().any(|x| x.contains("вход 64×256 вместо 32×128")), "{d:?}");
        assert!(
            d.iter().any(|x| x.contains("hidden 96 вместо 64") && x.contains("рост")),
            "направление роста перепутано: {d:?}"
        );
        assert!(d.iter().any(|x| x.contains("слоёв BiLSTM 3 вместо 2") && x.contains("заново")), "{d:?}");
        // обратный порядок вызова — обратное направление, а не та же строка
        let r = new.diff(&old);
        assert!(
            r.iter().any(|x| x.contains("hidden 64 вместо 96") && x.contains("усечение")),
            "{r:?}"
        );
        assert!(r.iter().any(|x| x.contains("слоёв BiLSTM 2 вместо 3") && x.contains("отбрасываются")), "{r:?}");
        assert!(old.diff(&old).is_empty(), "та же геометрия — пустой diff");
    }

    #[test]
    fn classes_growth_moves_output_rows() {
        let s = geom(4, 3);
        let d = geom(4, 5);
        let mut rng = StdRng::seed_from_u64(5);
        let src: Vec<f32> = (0..3 * 4).map(|i| i as f32).collect();
        let mut dst = vec![-1.0f32; 5 * 4];
        assert_eq!(
            transfer("ctc.w", &src, &mut dst, &s, &d, &SurgeryCfg { eps: 0.0, seed: 5 }, &mut rng),
            Act::Grow
        );
        assert_eq!(&dst[0..12], &[0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0]);
        // новые классы — дубликаты существующих, а не нули: нулевой логит
        // означал бы «класс невозможен», и градиент в него не шёл бы
        assert_eq!(&dst[12..16], &[0.0, 1.0, 2.0, 3.0]);
        assert_eq!(&dst[16..20], &[4.0, 5.0, 6.0, 7.0]);
    }

    #[test]
    fn unknown_family_is_skipped_with_a_reason_not_garbage() {
        let s = geom(4, 3);
        let d = geom(8, 3);
        let mut rng = StdRng::seed_from_u64(6);
        let src = vec![1.0f32; 16];
        let mut dst = vec![0.0f32; 32];
        match transfer("c1.w", &src, &mut dst, &s, &d, &SurgeryCfg::default(), &mut rng) {
            Act::Skip(why) => assert!(why.contains("придётся обучить заново"), "{why}"),
            other => panic!("ожидался Skip, получено {other:?}"),
        }
        let mut dst2 = vec![0.0f32; 33];
        assert!(matches!(
            transfer("ctc.w", &src, &mut dst2, &s, &d, &SurgeryCfg::default(), &mut rng),
            Act::Skip(_)
        ));
    }

    #[test]
    fn geometry_spec_parsing() {
        let base = Geometry::new(32, 128, 16, 256, 140, 2);
        let g = Geometry::parse_spec("64x256", &base).unwrap();
        assert_eq!((g.img_h, g.img_w, g.hidden, g.max_len), (64, 256, 256, 16));
        let g = Geometry::parse_spec("48x192h320", &base).unwrap();
        assert_eq!((g.img_h, g.img_w, g.hidden), (48, 192, 320));
        let g = Geometry::parse_spec("64x256h384L3m32", &base).unwrap();
        assert_eq!((g.img_h, g.img_w, g.hidden, g.rnn_layers, g.max_len), (64, 256, 384, 3, 32));
        assert_eq!(g.classes, 140, "не указанное в спецификации наследуется");
        assert!(Geometry::parse_spec("h384", &base).is_err(), "без HxW спецификация неполна");
        assert!(Geometry::parse_spec("64x", &base).is_err());
        assert!(Geometry::parse_spec("64x256z9", &base).is_err(), "неизвестный модификатор");
        assert!(Geometry::parse_spec("64x256h0", &base).is_err(), "нулевой hidden");
    }

    #[test]
    fn geometry_inference_from_tensor_lens() {
        let g = Geometry::new(32, 128, 16, 256, 140, 2);
        let lens = vec![
            ("ctc.b".to_string(), g.classes),
            ("ctc.w".to_string(), g.classes * g.hidden),
            ("attn.h2h.b".to_string(), g.hidden),
            ("rnn0.f.w_ih".to_string(), 4 * g.hidden * g.feat_dim),
            ("rnn0.proj.b".to_string(), g.hidden),
            ("rnn1.f.w_ih".to_string(), 4 * g.hidden * g.hidden),
            ("rnn1.proj.b".to_string(), g.hidden),
        ];
        let got = geometry_from_lens(&lens).unwrap();
        assert_eq!(got.hidden, 256);
        assert_eq!(got.classes, 140);
        assert_eq!(got.rnn_layers, 2);
        assert_eq!(got.feat_dim, 512);
        assert_eq!(got.img_h, 0, "разрешение из весов не восстанавливается — это нормально");
        assert!(geometry_from_lens(&[("ctc.b".to_string(), 140)]).is_none());
    }

    #[test]
    fn ladder_specs_chain_into_a_plan() {
        let base = Geometry::new(32, 128, 16, 256, 140, 2);
        let plan = parse_ladder("48x192:3,64x256h384:5", &base).unwrap();
        assert_eq!(plan.len(), 2);
        assert_eq!(plan[0].geom.img_w, 192);
        assert_eq!(plan[0].epochs, 3);
        assert_eq!(plan[1].geom.hidden, 384);
        assert_eq!(plan[1].epochs, 5);
        assert_eq!((plan[1].geom.img_h, plan[1].geom.img_w), (64, 256));
        assert!(parse_ladder("48x192", &base).is_err(), "без числа эпох ступень неполна");
        assert!(parse_ladder("", &base).is_err());
        assert!(parse_ladder("48x192:0", &base).is_err(), "ноль эпох бессмысленен");
    }
}
