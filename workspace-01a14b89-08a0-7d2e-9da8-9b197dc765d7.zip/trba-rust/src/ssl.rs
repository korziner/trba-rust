//! Самообучение (SSL) без новой разметки: источники сигнала для исторического
//! HTR (Kurrentschrift, метрические книги, алфавитные списки, описи) и способ
//! превратить их в скор или ограничение декодера.
//!
//! Общий принцип: у исторического документа почти всегда есть ВТОРОЙ дешёвый
//! источник истины — печатный текст того же прихода и периода, повторяющиеся
//! канцелярские формулировки, упорядоченность списков, повтор одного слова в
//! разных графах, согласие двух голов одной модели. Всё это даёт сигнал без
//! ручной разметки; сводится он в `pseudo_conf`/`rescore`.
//!
//! Производительность: словари и n-граммы — `HashMap`, подсчёт пар в кластере —
//! O(k) через счётчики, а не O(k²); никаких аллокаций в горячем цикле скоринга
//! кроме самого ключа.

use std::collections::HashMap;

/// Консервативная нормализация словоформы: регистр, долгое ſ, ß, умлауты,
/// дефисы и пробелы внутри слова. НЕ смешивает c/k, i/j, u/v — они различают
/// слова, поэтому живут в `variant_key`.
pub fn normalize(w: &str) -> String {
    let mut out = String::with_capacity(w.len() + 4);
    for ch in w.chars() {
        match ch {
            'ſ' => out.push('s'),
            'ß' => out.push_str("ss"),
            'ä' | 'Ä' => out.push_str("ae"),
            'ö' | 'Ö' => out.push_str("oe"),
            'ü' | 'Ü' => out.push_str("ue"),
            '-' | ' ' | '\u{ad}' => {}
            _ => out.push(ch.to_lowercase().next().unwrap_or(ch)),
        }
    }
    out
}

/// Агрессивный ключ варианта написания: две словоформы считаются одним словом,
/// если их ключи равны. Покрывает разнобой рукописной орфографии XVII–XIX вв.:
/// i/j, u/v, c/k, tz/z, th/t, ck/k, ff/f, dt/t и удвоения букв. Именно это и
/// есть «частотный словарь проверенных вариантов написания»: частота варианта
/// суммируется по всем написаниям одного слова.
pub fn variant_key(w: &str) -> String {
    let mut s = normalize(w).replace('j', "i").replace('v', "u").replace('c', "k");
    for (a, b) in [("tz", "z"), ("th", "t"), ("ck", "k"), ("ff", "f"), ("dt", "t")] {
        s = s.replace(a, b);
    }
    let mut out = String::with_capacity(s.len());
    let mut prev = '\0';
    for ch in s.chars() {
        if ch != prev {
            out.push(ch);
        }
        prev = ch;
    }
    out
}

/// Частотный словарь печатного корпуса с классами вариантов.
#[derive(Default, Clone)]
pub struct Lexicon {
    /// нормализованная словоформа → число вхождений
    pub freq: HashMap<String, u64>,
    /// ключ варианта → суммарное число вхождений всех написаний
    pub variants: HashMap<String, u64>,
    /// знаменатель (все словоупотребления)
    pub total: u64,
    /// число различных словоформ
    pub forms: usize,
}

impl Lexicon {
    /// Словарь из печатного текста того же прихода/периода. Разбиение по
    /// не-буквенным символам сохраняет кириллицу, включая дореформенные
    /// «Ѣ», «І», «і» (`is_alphabetic`), и отбрасывает цифры с пунктуацией.
    pub fn from_text(corpus: &str) -> Lexicon {
        let mut out = Lexicon::default();
        for w in corpus.split(|c: char| !c.is_alphabetic()) {
            if w.is_empty() {
                continue;
            }
            let n = normalize(w);
            if n.is_empty() {
                continue;
            }
            *out.freq.entry(n).or_insert(0) += 1;
            *out.variants.entry(variant_key(w)).or_insert(0) += 1;
            out.total += 1;
        }
        out.forms = out.freq.len();
        out
    }

    /// Взвешенное слияние нескольких источников: приходский печатный корпус,
    /// губернский справочник, список населённых мест, алфавитный указатель.
    /// Вес > 1 повышает доверие к более авторитетному источнику.
    pub fn merge_weighted(parts: &[(&Lexicon, f64)]) -> Lexicon {
        let mut out = Lexicon::default();
        for (l, w) in parts {
            for (k, &c) in &l.freq {
                let add = (c as f64 * w).round() as u64;
                if add > 0 {
                    *out.freq.entry(k.clone()).or_insert(0) += add;
                    out.total += add;
                }
            }
            for (k, &c) in &l.variants {
                let add = (c as f64 * w).round() as u64;
                if add > 0 {
                    *out.variants.entry(k.clone()).or_insert(0) += add;
                }
            }
        }
        out.forms = out.freq.len();
        out
    }

    pub fn known(&self, w: &str) -> bool {
        self.freq.contains_key(&normalize(w))
    }
    /// Слово известно хотя бы в одном варианте написания.
    pub fn known_variant(&self, w: &str) -> bool {
        self.variants.contains_key(&variant_key(w))
    }
    /// P(словоформа) со сглаживанием add-1.
    pub fn prob(&self, w: &str) -> f64 {
        let c = self.freq.get(&normalize(w)).copied().unwrap_or(0) as f64;
        (c + 1.0) / (self.total as f64 + self.forms as f64 + 1.0)
    }
    /// P(класс варианта) — частота, суммарная по всем написаниям слова.
    pub fn variant_prob(&self, w: &str) -> f64 {
        let c = self.variants.get(&variant_key(w)).copied().unwrap_or(0) as f64;
        (c + 1.0) / (self.total as f64 + self.variants.len() as f64 + 1.0)
    }
}

/// Символьная n-граммная модель того же периода со stupid backoff (×0.4).
/// Дешевле и устойчивее нейросетевой LM на малых корпусах, считается за один
/// проход; граница слова кодируется маркерами \u{2} и \u{3}.
#[derive(Default, Clone)]
pub struct CharNgram {
    pub n: usize,
    /// все порядки сразу: ключ — сама k-грамма
    pub counts: HashMap<String, u64>,
    pub total: u64,
}

impl CharNgram {
    pub fn train(corpus: &str, n: usize) -> CharNgram {
        let n = n.max(2);
        let mut out = CharNgram { n, counts: HashMap::new(), total: 0 };
        for w in corpus.split(|c: char| !c.is_alphabetic()) {
            if w.is_empty() {
                continue;
            }
            let s = format!("\u{2}{}\u{3}", normalize(w));
            let ch: Vec<char> = s.chars().collect();
            for i in 0..ch.len() {
                for k in 1..=n {
                    if i + 1 >= k {
                        let key: String = ch[i + 1 - k..=i].iter().collect();
                        *out.counts.entry(key).or_insert(0) += 1;
                    }
                }
                out.total += 1;
            }
        }
        out
    }

    fn p(&self, ctx: &str, c: char) -> f64 {
        let key = format!("{ctx}{c}");
        let num = self.counts.get(&key).copied().unwrap_or(0) as f64;
        if ctx.is_empty() {
            return (num + 1.0) / (self.total as f64 + 96.0);
        }
        let den = self.counts.get(ctx).copied().unwrap_or(0) as f64;
        if den > 0.0 && num > 0.0 {
            num / den
        } else {
            0.4 * self.p(&ctx.chars().skip(1).collect::<String>(), c)
        }
    }

    pub fn logp(&self, w: &str) -> f64 {
        let s = format!("\u{2}{}\u{3}", normalize(w));
        let ch: Vec<char> = s.chars().collect();
        let mut sum = 0.0f64;
        for i in 1..ch.len() {
            let st = (i + 1).saturating_sub(self.n.max(1)); // n=0 не обрушает срез
            let ctx: String = ch[st..i].iter().collect();
            let p = self.p(&ctx, ch[i]);
            sum += if p > 0.0 { p.ln() } else { -20.0 };
        }
        sum
    }

    /// На символ — чтобы сравнивать слова разной длины (иначе короткое слово
    /// всегда «правдоподобнее» длинного, и rescoring ломает длинные слова).
    pub fn logp_per_char(&self, w: &str) -> f64 {
        self.logp(w) / (normalize(w).chars().count() as f64 + 2.0)
    }
}

/// Словарь, обусловленный графой. В метрической книге набор слов определяется
/// колонкой (дата, имя, приход, сословие, должность восприемника), а колонка
/// известна БЕЗ разметки — по линовке печатной формы. Это резко сужает
/// множество допустимых гипотез и делает псевдоразметку чище.
#[derive(Default, Clone)]
pub struct FieldLexicon {
    pub by_field: HashMap<String, Lexicon>,
    pub global: Lexicon,
}

impl FieldLexicon {
    pub fn add_text(&mut self, field: &str, corpus: &str) {
        let l = Lexicon::from_text(corpus);
        self.global = Lexicon::merge_weighted(&[(&self.global, 1.0), (&l, 1.0)]);
        self.by_field.insert(field.to_string(), l);
    }
    /// Для неизвестной графы — глобальный словарь, а не ноль: лучше слабый
    /// сигнал, чем штраф, отправляющий правильную гипотезу в конец N-best.
    pub fn prob(&self, field: &str, w: &str) -> f64 {
        match self.by_field.get(field) {
            Some(l) => l.prob(w),
            None => self.global.prob(w),
        }
    }
}

/// Тип упорядоченности списка: алфавитный (указатели, азбучные списки, описи)
/// или номерной (фолио, номера домов, страницы).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum OrderKind {
    Alphabet,
    Numeric,
}

fn lead_num(s: &str) -> Option<i64> {
    let d: String = s.chars().take_while(|c| c.is_ascii_digit()).collect();
    if d.is_empty() {
        None
    } else {
        d.parse().ok()
    }
}

/// Число нарушений порядка в соседних парах. Для алфавитного списка сравниваются
/// КОНСЕРВАТИВНО нормализованные формы (variant_key здесь неприменим: он
/// смешивает c/k и ломает порядок «Citrone» → «Dattel»).
pub fn order_violations(words: &[&str], kind: OrderKind) -> usize {
    let mut v = 0usize;
    for w in words.windows(2) {
        let bad = match kind {
            OrderKind::Alphabet => normalize(w[0]) > normalize(w[1]),
            OrderKind::Numeric => match (lead_num(w[0]), lead_num(w[1])) {
                (Some(a), Some(b)) => a > b,
                _ => false, // нечисловые вставки нарушением не считаются
            },
        };
        if bad {
            v += 1;
        }
    }
    v
}

/// Доля пар, стоящих в правильном порядке, в [0, 1]. Это label-free сигнал:
/// если расшифровка нарушает порядок списка, она почти наверняка ошибочна —
/// порядок в рукописи виден и без знания букв.
pub fn order_score(words: &[&str], kind: OrderKind) -> f64 {
    if words.len() < 2 {
        return 1.0;
    }
    1.0 - order_violations(words, kind) as f64 / (words.len() - 1) as f64
}

/// Согласованность одинаково выглядящих слов: кропы из одного визуального
/// кластера (кластер даёт уже посчитанный признак энкодера) обязаны иметь
/// одинаковую расшифровку. Доля согласованных пар, считаемая за O(k).
pub fn cluster_agreement(clusters: &[usize], hyps: &[&str]) -> f64 {
    let mut groups: HashMap<usize, Vec<usize>> = HashMap::new();
    for (i, &c) in clusters.iter().enumerate() {
        groups.entry(c).or_default().push(i);
    }
    let (mut same, mut pairs) = (0u64, 0u64);
    for idx in groups.values() {
        if idx.len() < 2 {
            continue;
        }
        let mut cnt: HashMap<&str, u64> = HashMap::new();
        for &i in idx {
            *cnt.entry(hyps.get(i).copied().unwrap_or("")).or_insert(0) += 1;
        }
        let k = idx.len() as u64;
        pairs += k * (k - 1) / 2;
        for &c in cnt.values() {
            same += c * (c - 1) / 2;
        }
    }
    if pairs == 0 {
        1.0
    } else {
        same as f64 / pairs as f64
    }
}

/// Симметричная KL двух распределений одной длины — CTC-голова против
/// attention-декодера на одной картинке. Ноль при совпадении: это цель
/// самодистилляции (слабую голову тянем к сильной на неразмеченных данных).
pub fn sym_kl(p: &[f32], q: &[f32], eps: f32) -> f64 {
    if p.len() != q.len() || p.is_empty() {
        return f64::NAN;
    }
    let mut s = 0.0f64;
    for i in 0..p.len() {
        let a = p[i].max(eps) as f64;
        let b = q[i].max(eps) as f64;
        s += a * (a / b).ln() + b * (b / a).ln();
    }
    s * 0.5
}

/// Согласие двух распределений в [0, 1] (1 = полное): удобная форма sym_kl для
/// взвешивания псевдоразметки.
pub fn head_agreement(p: &[f32], q: &[f32]) -> f64 {
    let d = sym_kl(p, q, 1e-6);
    if !d.is_finite() {
        return 0.0;
    }
    1.0 / (1.0 + d)
}

/// Веса слагаемых SSL при пересчёте N-best. Подбираются на небольшом
/// размеченном контроле (десятки строк), а не на глаз.
#[derive(Clone, Copy, Debug)]
pub struct SslWeights {
    /// символьная n-граммная модель
    pub lm: f64,
    /// частотный словарь вариантов
    pub lex: f64,
}

impl Default for SslWeights {
    fn default() -> Self {
        SslWeights { lm: 1.0, lex: 2.0 }
    }
}

/// Пересчёт акустического скора гипотезы языковыми слагаемыми (shallow fusion).
/// Скоринг усредняется по словам строки, чтобы длина строки не перевешивала.
pub fn rescore(acoustic: f64, text: &str, lex: &Lexicon, lm: &CharNgram, w: &SslWeights) -> f64 {
    let words: Vec<&str> = text.split_whitespace().collect();
    if words.is_empty() {
        return acoustic;
    }
    let (mut lx, mut lg) = (0.0f64, 0.0f64);
    for wd in &words {
        lx += lex.variant_prob(wd).ln();
        lg += lm.logp_per_char(wd);
    }
    let n = words.len() as f64;
    acoustic + w.lex * lx / n + w.lm * lg / n
}

/// Доверие к псевдоразметке строки в [0, 1]: доля слов, известных хотя бы в
/// одном варианте написания (0.4), правдоподобие по n-граммам (0.3), согласие
/// визуальных кластеров (0.2), согласие двух голов модели (0.1). Состав
/// слагаемых важнее самих коэффициентов: каждый из них — независимый источник
/// сигнала, и строку в самообучение берут только когда сошлись несколько.
pub fn pseudo_conf(text: &str, lex: &Lexicon, lm: &CharNgram, agree: f64, heads: f64) -> f64 {
    let words: Vec<&str> = text.split_whitespace().collect();
    if words.is_empty() {
        return 0.0;
    }
    let hit = words.iter().filter(|w| lex.known_variant(w)).count() as f64 / words.len() as f64;
    let mut s = 0.0f64;
    for w in &words {
        s += lm.logp_per_char(w);
    }
    let lm_mean = s / words.len() as f64; // отрицательное
    let lm_norm = 1.0 - (-lm_mean).clamp(0.0, 6.0) / 6.0;
    (0.4 * hit + 0.3 * lm_norm + 0.2 * agree.clamp(0.0, 1.0) + 0.1 * heads.clamp(0.0, 1.0)).clamp(0.0, 1.0)
}

/// Отбор псевдоразметки для самообучения: индекс строки, текст, доверие;
/// упорядочено по убыванию доверия, чтобы брать «самые уверенные N%» — тот же
/// приём, что в self-training по curriculum (сначала 60%, потом 80%, потом все).
pub fn pick_pseudo_labels(
    hyps: &[&str],
    lex: &Lexicon,
    lm: &CharNgram,
    agree: &[f64],
    heads: &[f64],
    min_conf: f64,
) -> Vec<(usize, String, f64)> {
    let mut out: Vec<(usize, String, f64)> = Vec::new();
    for (i, h) in hyps.iter().enumerate() {
        let c = pseudo_conf(
            h,
            lex,
            lm,
            agree.get(i).copied().unwrap_or(0.0),
            heads.get(i).copied().unwrap_or(0.0),
        );
        if c >= min_conf {
            out.push((i, (*h).to_string(), c));
        }
    }
    out.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap_or(std::cmp::Ordering::Equal));
    out
}

#[cfg(test)]
mod ssl_tests {
    use super::*;

    #[test]
    fn normalize_and_variant_key_unify_historical_spellings() {
        assert_eq!(normalize("Kirche"), "kirche");
        assert_eq!(normalize("Straße"), "strasse");
        assert_eq!(normalize("ſchön"), "schoen");
        assert_eq!(normalize("Müller"), "mueller");
        // варианты написания одного слова дают один ключ
        assert_eq!(variant_key("Cinder"), variant_key("Kinder"));
        assert_eq!(variant_key("Mueller"), variant_key("Müller"));
        assert_eq!(variant_key("Straße"), variant_key("Strasse"));
        assert_eq!(variant_key("Thurm"), variant_key("Turm"));
        // разные слова ключ не смешивает
        assert_ne!(variant_key("Kirche"), variant_key("Kirsche"));
    }

    #[test]
    fn lexicon_counts_variants_together() {
        let l = Lexicon::from_text("Kirche kirche Kirsche Dorf dorf dorf");
        assert!(l.known("Kirche") && l.known_variant("kirche"));
        assert!(!l.known("xyzqq"));
        assert!(l.variant_prob("dorf") > l.variant_prob("Kirche"));
        assert!(l.variant_prob("Kirche") > l.variant_prob("xyzqq"));
        // дореформенная кириллица не теряется при разбиении
        let c = Lexicon::from_text("Церквей церквей Ѣнисей іюля");
        assert!(c.known("Церквей") && c.known("Ѣнисей") && c.known("іюля"));
        // взвешенное слияние источников
        let m = Lexicon::merge_weighted(&[(&l, 1.0), (&c, 2.0)]);
        assert!(m.known("dorf") && m.known("Церквей"));
    }

    #[test]
    fn char_ngram_prefers_corpus_plausible_words() {
        let corpus = "kirche kirche kirche dorf dorf taufe geburt";
        let lm = CharNgram::train(corpus, 4);
        assert!(lm.logp_per_char("kirche") > lm.logp_per_char("qzxwv"));
        assert!(lm.logp("kirche").is_finite() && lm.logp("qzxwv").is_finite());
        assert!(lm.logp_per_char("kirche") < 0.0);
    }

    #[test]
    fn order_signal_reads_alphabet_and_numbers() {
        let ok = ["Apfel", "Birne", "Citrone", "Dattel"];
        assert!((order_score(&ok, OrderKind::Alphabet) - 1.0).abs() < 1e-9);
        let bad = ["Birne", "Apfel", "Citrone", "Dattel"];
        assert_eq!(order_violations(&bad, OrderKind::Alphabet), 1);
        assert!(order_score(&bad, OrderKind::Alphabet) < 1.0);
        assert_eq!(order_violations(&["12", "13", "47"], OrderKind::Numeric), 0);
        assert_eq!(order_violations(&["47", "13"], OrderKind::Numeric), 1);
        // нечисловая вставка нарушением не считается
        assert_eq!(order_violations(&["12", "—", "47"], OrderKind::Numeric), 0);
        assert!((order_score(&[], OrderKind::Alphabet) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn cluster_agreement_rewards_identical_transcriptions() {
        assert!((cluster_agreement(&[0, 0, 1], &["kirche", "kirche", "dorf"]) - 1.0).abs() < 1e-9);
        assert!(cluster_agreement(&[0, 0], &["kirche", "dorf"]).abs() < 1e-9);
        // одиночные кропы пар не дают
        assert!((cluster_agreement(&[0, 1, 2], &["a", "b", "c"]) - 1.0).abs() < 1e-9);
        assert!((cluster_agreement(&[7, 7, 7], &["x", "x", "x"]) - 1.0).abs() < 1e-9);
        assert!((cluster_agreement(&[7, 7, 7], &["x", "y", "x"]) - 1.0 / 3.0).abs() < 1e-9);
    }

    #[test]
    fn head_agreement_is_one_on_identical_posteriors() {
        let p = vec![0.5f32, 0.25, 0.25];
        assert!(sym_kl(&p, &p, 1e-6).abs() < 1e-9);
        assert!((head_agreement(&p, &p) - 1.0).abs() < 1e-9);
        assert!(sym_kl(&p, &[0.34, 0.33, 0.33], 1e-6) > 0.0);
        assert!(head_agreement(&p, &[0.34, 0.33, 0.33], ) < 1.0);
        // разные длины — не сигнал, а ошибка вызывающего кода
        assert!(sym_kl(&p, &[0.5, 0.5], 1e-6).is_nan());
        assert!(head_agreement(&p, &[0.5, 0.5]).abs() < 1e-9);
    }

    #[test]
    fn field_lexicon_conditions_on_column() {
        let mut fl = FieldLexicon::default();
        fl.add_text("date", "januar februar januar");
        fl.add_text("name", "ivan petr ivan");
        assert!(fl.prob("date", "januar") > fl.prob("date", "ivan"));
        assert!(fl.prob("name", "ivan") > fl.prob("name", "februar"));
        assert!(fl.prob("unknown", "ivan") > 0.0);
        assert!(fl.global.known("januar") && fl.global.known("ivan"));
    }

    #[test]
    fn pseudo_labels_keep_only_confident_rows() {
        let corpus = "kirche kirche dorf dorf taufe";
        let lex = Lexicon::from_text(corpus);
        let lm = CharNgram::train(corpus, 4);
        let hi = pseudo_conf("kirche dorf", &lex, &lm, 1.0, 1.0);
        let lo = pseudo_conf("qzxwv jkw", &lex, &lm, 0.0, 0.0);
        assert!(hi > lo && hi <= 1.0 && lo >= 0.0);
        let picked = pick_pseudo_labels(
            &["kirche dorf", "qzxwv jkw"],
            &lex,
            &lm,
            &[1.0, 0.0],
            &[1.0, 0.0],
            0.5,
        );
        assert_eq!(picked.len(), 1);
        assert_eq!(picked[0].0, 0);
        assert_eq!(picked[0].1, "kirche dorf");
        // пустая строка доверия не имеет
        assert!(pseudo_conf("", &lex, &lm, 1.0, 1.0).abs() < 1e-9);
    }

    #[test]
    fn rescore_prefers_lexical_hypothesis() {
        let lex = Lexicon::from_text("kirche kirche dorf");
        let lm = CharNgram::train("kirche kirche dorf", 4);
        let w = SslWeights::default();
        let a = rescore(-10.0, "kirche", &lex, &lm, &w);
        let b = rescore(-10.0, "qzxwv", &lex, &lm, &w);
        assert!(a > b);
        // при нулевых весах остаётся чистая акустика
        let z = SslWeights { lm: 0.0, lex: 0.0 };
        assert!((rescore(-10.0, "qzxwv", &lex, &lm, &z) + 10.0).abs() < 1e-9);
    }
}

// ============ достройка: проекция на словарь, скобки, ансамбль, pseudo-CSV ====

/// Расстояние Левенштейна в символах (две строки DP, без рекурсии).
pub fn levenshtein(a: &str, b: &str) -> usize {
    let x: Vec<char> = a.chars().collect();
    let y: Vec<char> = b.chars().collect();
    if x.is_empty() { return y.len(); }
    if y.is_empty() { return x.len(); }
    let mut prev: Vec<usize> = (0..=y.len()).collect();
    let mut cur = vec![0usize; y.len() + 1];
    for i in 1..=x.len() {
        cur[0] = i;
        for j in 1..=y.len() {
            let d = if x[i - 1] == y[j - 1] { 0 } else { 1 };
            cur[j] = (prev[j] + 1).min(cur[j - 1] + 1).min(prev[j - 1] + d);
        }
        std::mem::swap(&mut prev, &mut cur);
    }
    prev[y.len()]
}

/// Индекс словаря для быстрого поиска ближайших словоформ: два ведра, по первой
/// и по последней букве. Кандидаты — объединение вёдер, поэтому опечатка в первой
/// букве не уводит слово из поиска (оно остаётся в ведре последней буквы).
/// Просмотр ограничен `max_scan` на ведро — стоимость предсказуема.
#[derive(Default, Clone)]
pub struct LexIndex {
    pub by_first: HashMap<char, Vec<String>>,
    pub by_last: HashMap<char, Vec<String>>,
    pub words: usize,
}

impl LexIndex {
    pub fn from_lexicon(lex: &Lexicon) -> LexIndex {
        let mut out = LexIndex::default();
        for w in lex.freq.keys() {
            if let Some(f) = w.chars().next() { out.by_first.entry(f).or_default().push(w.clone()); }
            if let Some(l) = w.chars().last() { out.by_last.entry(l).or_default().push(w.clone()); }
        }
        out.words = lex.freq.len();
        out
    }

    /// Ближайшие словоформы: сначала по расстоянию, затем по частоте.
    pub fn nearest(&self, lex: &Lexicon, word: &str, k: usize, max_edit: usize, max_scan: usize) -> Vec<(String, u64)> {
        let n = normalize(word);
        let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
        let mut out: Vec<(String, u64, usize)> = Vec::new();
        for bucket in [n.chars().next().and_then(|c| self.by_first.get(&c)),
                       n.chars().last().and_then(|c| self.by_last.get(&c))] {
            let list = match bucket { Some(l) => l, None => continue };
            for (i, cand) in list.iter().enumerate() {
                if i >= max_scan { break; }
                if cand == &n || !seen.insert(cand.clone()) { continue; }
                let d = levenshtein(&n, cand);
                if d <= max_edit {
                    out.push((cand.clone(), lex.freq.get(cand).copied().unwrap_or(0), d));
                }
            }
        }
        out.sort_by(|a, b| a.2.cmp(&b.2).then(b.1.cmp(&a.1)).then(a.0.cmp(&b.0)));
        out.truncate(k.max(1));
        out.into_iter().map(|(s, f, _)| (s, f)).collect()
    }
}

/// Сомнительна ли гипотеза: разрыв между лучшим и вторым скором не больше gap.
/// Скоры в одной шкале, больше = лучше (логарифмическое правдоподобие).
pub fn doubtful(top: f64, second: f64, gap: f64) -> bool { top - second <= gap }

/// До `max_alt` вариантов в квадратных скобках через слэш, когда разрыв мал:
/// `[Ивановъ/Иванов]`. Когда лучший уверенно впереди — просто текст без скобок.
/// Политика намеренно допускает ложные срабатывания: пропуск редкой фамилии
/// дороже, а убрать скобки потом легко регуляркой `\[([^\]]*)\]`.
pub fn format_alternatives(cands: &[(String, f64)], gap: f64, max_alt: usize) -> String {
    let mut v: Vec<&(String, f64)> = cands.iter().collect();
    v.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
    let mut seen: std::collections::HashSet<String> = std::collections::HashSet::new();
    let mut kept: Vec<&(String, f64)> = Vec::new();
    for c in v.iter() {
        if c.0.trim().is_empty() { continue; }
        if seen.insert(c.0.clone()) { kept.push(c); }
    }
    if kept.is_empty() { return String::new(); }
    let max_alt = max_alt.max(1);
    if kept.len() == 1 || !doubtful(kept[0].1, kept[1].1, gap) { return kept[0].0.clone(); }
    let n = kept.len().min(max_alt);
    let parts: Vec<&str> = kept[..n].iter().map(|c| c.0.as_str()).collect();
    format!("[{}]", parts.join("/"))
}

/// Пометка сомнительных слов альтернативами из словаря. Слово сомнительно, если
/// оно неизвестно словарю ни в одном варианте написания ИЛИ его частота ниже
/// `rare` — редкие фамилии метрических книг попадают сюда, даже когда справочник
/// прихода их знает. Пунктуация вокруг слова сохраняется.
pub fn annotate_words(text: &str, lex: &Lexicon, idx: &LexIndex, k: usize, max_edit: usize, rare: f64) -> String {
    let mut out = String::with_capacity(text.len() + 16);
    for (wi, tok) in text.split_whitespace().enumerate() {
        if wi > 0 { out.push(' '); }
        let core: String = tok.chars().filter(|c| c.is_alphabetic()).collect();
        let pre: String = tok.chars().take_while(|c| !c.is_alphabetic()).collect();
        let suf: String = tok.chars().rev().take_while(|c| !c.is_alphabetic()).collect::<Vec<char>>().into_iter().rev().collect();
        out.push_str(&pre);
        if core.is_empty() { out.push_str(&suf); continue; }
        let suspicious = !lex.known_variant(&core) || lex.variant_prob(&core) < rare;
        if !suspicious {
            out.push_str(&core);
            out.push_str(&suf);
            continue;
        }
        out.push('[');
        out.push_str(&core);
        for (a, _) in idx.nearest(lex, &core, k, max_edit, 4000).iter() {
            if a != &core { out.push('/'); out.push_str(a); }
        }
        out.push(']');
        out.push_str(&suf);
    }
    out
}

/// Согласие ансамбля экспертов (или корзин разной длины) на одной строке: доля
/// совпавших пар. Это `agree` в `pseudo_conf`; у MoPE ансамбль уже есть, поэтому
/// оценка неопределённости достаётся бесплатно.
pub fn ensemble_agreement(hyps: &[&str]) -> f64 {
    let n = hyps.len();
    if n < 2 { return 1.0; }
    let mut cnt: HashMap<&str, u64> = HashMap::new();
    for h in hyps { *cnt.entry(*h).or_insert(0) += 1; }
    let mut same = 0u64;
    for &c in cnt.values() { same += c * (c - 1) / 2; }
    same as f64 / (n * (n - 1) / 2) as f64
}

fn csv_field(s: &str) -> String {
    if s.contains(',') || s.contains('"') || s.contains('\n') {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else { s.to_string() }
}

/// Псевдоразметка в CSV формата trba-rust (`путь,текст`) — такой файл сразу
/// съедает `--resume`, то есть цикл самообучения замыкается без нового кода
/// обучения. Экранирование по RFC 4180.
pub fn write_pseudo_csv(path: &str, rows: &[(&str, &str)]) -> std::io::Result<usize> {
    use std::io::Write;
    let mut f = std::fs::File::create(path)?;
    for (img, text) in rows { writeln!(f, "{},{}", csv_field(img), csv_field(text))?; }
    Ok(rows.len())
}

#[cfg(test)]
mod ssl_tests2 {
    use super::*;

    #[test]
    fn levenshtein_basic() {
        assert_eq!(levenshtein("", ""), 0);
        assert_eq!(levenshtein("abc", ""), 3);
        assert_eq!(levenshtein("Ивановъ", "Иванов"), 1);
        assert_eq!(levenshtein("Kirche", "Kirsche"), 1);
    }

    #[test]
    fn lex_index_finds_nearest_forms() {
        let lex = Lexicon::from_text("Ивановъ Ивановъ Петровъ Петровъ Сидоровъ Kirche Kirche Dorf");
        let idx = LexIndex::from_lexicon(&lex);
        assert!(idx.words >= 4);
        let n = idx.nearest(&lex, "Иванов", 3, 2, 1000);
        assert!(!n.is_empty() && n[0].0 == "ивановъ");
        let n2 = idx.nearest(&lex, "Kirch", 2, 1, 1000);
        assert!(!n2.is_empty() && n2[0].0 == "kirche");
        assert!(idx.nearest(&lex, "qqqqqqqqqq", 2, 1, 1000).is_empty());
    }

    #[test]
    fn format_alternatives_brackets_only_when_doubtful() {
        let confident = vec![("Ивановъ".to_string(), -1.0), ("Иванов".to_string(), -3.0)];
        assert_eq!(format_alternatives(&confident, 0.5, 2), "Ивановъ");
        let doubt = vec![("Ивановъ".to_string(), -1.0), ("Иванов".to_string(), -1.2)];
        assert_eq!(format_alternatives(&doubt, 0.5, 2), "[Ивановъ/Иванов]");
        let three = vec![("a".to_string(), -1.0), ("b".to_string(), -1.1), ("c".to_string(), -1.2)];
        assert_eq!(format_alternatives(&three, 0.5, 2), "[a/b]");
        let dup = vec![("a".to_string(), -1.0), ("a".to_string(), -1.05), ("".to_string(), -1.1)];
        assert_eq!(format_alternatives(&dup, 0.5, 2), "a");
        assert_eq!(format_alternatives(&[], 0.5, 2), "");
    }

    #[test]
    fn annotate_words_flags_rare_and_unknown() {
        let lex = Lexicon::from_text("крестился крестился крестился сына сына Ивановъ Петровъ Петровъ");
        let idx = LexIndex::from_lexicon(&lex);
        let a = annotate_words("крестился сына", &lex, &idx, 2, 2, 1e-9);
        assert!(!a.contains('['), "{a}");
        let b = annotate_words("Иванов", &lex, &idx, 2, 2, 1e-9);
        assert!(b.starts_with("[Иванов/"), "{b}");
        let c = annotate_words("Петровъ", &lex, &idx, 2, 2, 0.5);
        assert!(c.starts_with('['), "{c}");
        let d = annotate_words("Ивановъ,", &lex, &idx, 2, 2, 0.5);
        assert!(d.ends_with(','), "{d}");
    }

    #[test]
    fn ensemble_agreement_counts_pairs() {
        assert!((ensemble_agreement(&["a", "a", "a", "a"]) - 1.0).abs() < 1e-9);
        assert!(ensemble_agreement(&["a", "b", "c", "d"]).abs() < 1e-9);
        assert!((ensemble_agreement(&["a", "a", "a", "b"]) - 0.5).abs() < 1e-9);
        assert!((ensemble_agreement(&["a"]) - 1.0).abs() < 1e-9);
    }

    #[test]
    fn pseudo_csv_roundtrips_quoting() {
        let p = std::env::temp_dir().join("ssl_pseudo_test.csv");
        let ps = p.to_string_lossy().to_string();
        let n = write_pseudo_csv(&ps, &[("img/a.png", "Ивановъ крестился"), ("img/b.png", "текст, с запятой")]).unwrap();
        assert_eq!(n, 2);
        let s = std::fs::read_to_string(&ps).unwrap();
        let lines: Vec<&str> = s.trim().split('\n').collect();
        assert_eq!(lines.len(), 2);
        assert_eq!(lines[0], "img/a.png,Ивановъ крестился");
        assert!(lines[1].contains("\"текст, с запятой\""), "{}", lines[1]);
        let _ = std::fs::remove_file(&ps);
    }
}

/// Одна строка псевдоразметки в CSV формата trba-rust (`путь,текст`).
pub fn csv_line(img: &str, text: &str) -> String {
    format!("{},{}", csv_field(img), csv_field(text))
}
