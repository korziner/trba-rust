//! INT8-QAT port of the reference `SEResNet31`
//! (`manuscript-ocr/recognizers/_trba/model/seresnet31.py`).
//!
//! Graph (identical topology to the PyTorch original):
//!
//! ```text
//! stem    : conv3x3(3,64)+BN+ReLU, conv3x3(64,128)+BN+ReLU, maxpool2x2
//! layer1  : SEBasicBlock(128,256, stride 2, 1x1 downsample)
//! layer2  : SEBasicBlock(256,256) x2
//! layer3  : SEBasicBlock(256,512, stride 2, 1x1 downsample) + SEBasicBlock(512,512) x4
//! layer4  : SEBasicBlock(512,512) x3
//! conv_out: conv2x2 s(2,1) p(0,1)(512,512)+BN+ReLU, conv2x2(512,512)+BN+ReLU
//! ```
//!
//! Quantisation discipline (fake-QAT, "Towards Unified INT8 Training" style):
//! * conv GEMMs run on int8 operands with int32 accumulation; the accumulator
//!   is dequantised by `s_act * s_w` and BatchNorm runs in fp32 on top of it;
//! * activations are re-quantised per tensor with a dynamic max-abs scale at
//!   every ReLU output / residual sum (straight-through on the way back);
//! * conv weight gradients use an int8 GEMM (quantised `dX` x int8 `col`),
//!   i.e. gradients travel in int8 too, exactly as in the paper;
//! * `grad_input` uses the fused fp32 gather kernel (no col materialisation).
//!
//! Convention: every int8 tensor `q` represents the value `v = q * s` with a
//! per-tensor scale `s`.  A backward edge therefore hands over `dL/dv`
//! (fp32, device); the consumer multiplies by its own `s` and re-quantises.

use rayon::prelude::*;
use std::sync::Arc;

use crate::backend::*;

type CV = core::ffi::c_void;

pub const BN_EPS: f32 = 1e-5;
pub const BN_MOMENTUM: f32 = 0.1;

// ------------------------------------------------------------ small layers --

#[derive(Clone)]
pub struct BatchNorm {
    pub gamma: Vec<f32>,
    pub beta: Vec<f32>,
    pub run_mean: Vec<f32>,
    pub run_var: Vec<f32>,
    pub g_gamma: Vec<f32>,
    pub g_beta: Vec<f32>,
    pub c: usize,
}

impl BatchNorm {
    pub fn new(c: usize) -> Self {
        Self {
            gamma: vec![1.0; c],
            beta: vec![0.0; c],
            run_mean: vec![0.0; c],
            run_var: vec![1.0; c],
            g_gamma: vec![0.0; c],
            g_beta: vec![0.0; c],
            c,
        }
    }
    pub fn update_running(&mut self, mean: &[f32], var: &[f32]) {
        for i in 0..self.c {
            self.run_mean[i] = (1.0 - BN_MOMENTUM) * self.run_mean[i] + BN_MOMENTUM * mean[i];
            self.run_var[i] = (1.0 - BN_MOMENTUM) * self.run_var[i] + BN_MOMENTUM * var[i];
        }
    }
    pub fn zero_grad(&mut self) {
        self.g_gamma.iter_mut().for_each(|x| *x = 0.0);
        self.g_beta.iter_mut().for_each(|x| *x = 0.0);
    }
}

/// Plain fp32 fully-connected layer (SE bottlenecks).  Host side: tiny.
#[derive(Clone)]
pub struct LinearF {
    pub w: Vec<f32>, // [out, in] row-major
    pub b: Vec<f32>,
    pub g_w: Vec<f32>,
    pub g_b: Vec<f32>,
    pub inp: usize,
    pub out: usize,
    pub use_bias: bool,
}

/// Минимальный объём работы, при котором rayon окупается.
///
/// Возвращает значение для `IndexedParallelIterator::with_min_len`: `1` —
/// делить работу между потоками свободно, `usize::MAX` — выполнить регион
/// последовательно в вызывающем потоке (без split/join). Порог выбран замером:
/// на батче b=3, hidden=128 шесть мелких параллельных регионов на шаг декодера
/// давали +30% к `attn_fwd` при `RAYON_NUM_THREADS=1`, тогда как на рабочих
/// размерах (b=32, hidden=256) каждый регион в сотни раз больше порога и
/// распараллеливается всегда.
#[inline]
pub fn par_min(ops: usize) -> usize {
    if ops >= (1 << 16) {
        1
    } else {
        usize::MAX
    }
}

impl LinearF {
    pub fn new(inp: usize, out: usize, use_bias: bool) -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let limit = (6.0 / (inp + out) as f32).sqrt();
        Self {
            w: (0..inp * out).map(|_| rng.gen_range(-limit..limit)).collect(),
            b: vec![0.0; out],
            g_w: vec![0.0; inp * out],
            g_b: vec![0.0; out],
            inp,
            out,
            use_bias,
        }
    }
    pub fn forward(&self, x: &[f32], rows: usize) -> Vec<f32> {
        let mut y = vec![0.0f32; rows * self.out];
        let (inp, out) = (self.inp, self.out);
        // Строки независимы: параллельно по r, порядок суммирования по i внутри
        // каждого выхода прежний — результат побитово тот же.
        let (w, bb, ub) = (&self.w, &self.b, self.use_bias);
        y.par_chunks_mut(out).enumerate().for_each(|(r, yr)| {
            let xr = &x[r * inp..(r + 1) * inp];
            for o in 0..out {
                let mut s = if ub { bb[o] } else { 0.0 };
                let wr = &w[o * inp..(o + 1) * inp];
                for i in 0..inp {
                    s += xr[i] * wr[i];
                }
                yr[o] = s;
            }
        });
        y
    }

    /// Батч-версия `backward_row`: ровно то же, что `rows` последовательных
    /// вызовов подряд, но в два параллельных прохода.
    ///
    /// Проход 1 считает градиенты весов параллельно по строкам `o` матрицы
    /// (строке `o` принадлежат `g_w[o*inp..]` и `g_b[o]`), суммируя по строкам
    /// `r` в прежнем порядке `0..rows`. Проход 2 считает `dx` параллельно по
    /// `r`, суммируя по `o` в прежнем порядке. Ни один аккумулятор не меняется
    /// в другой последовательности, поэтому числа совпадают побитово, а объём
    /// арифметики тот же: в проход уходит по одному умножению на элемент.
    pub fn backward_rows_par(&mut self, x: &[f32], dy: &[f32], rows: usize) -> Vec<f32> {
        let (inp, out) = (self.inp, self.out);
        if self.use_bias {
            self.g_w
                .par_chunks_mut(inp)
                .zip(self.g_b.par_iter_mut())
                .enumerate()
                .for_each(|(o, (gw, gb))| {
                    for r in 0..rows {
                        let d = dy[r * out + o];
                        if d == 0.0 {
                            continue;
                        }
                        *gb += d;
                        let xr = &x[r * inp..(r + 1) * inp];
                        for i in 0..inp {
                            gw[i] += d * xr[i];
                        }
                    }
                });
        } else {
            self.g_w.par_chunks_mut(inp).enumerate().for_each(|(o, gw)| {
                for r in 0..rows {
                    let d = dy[r * out + o];
                    if d == 0.0 {
                        continue;
                    }
                    let xr = &x[r * inp..(r + 1) * inp];
                    for i in 0..inp {
                        gw[i] += d * xr[i];
                    }
                }
            });
        }
        let mut dx = vec![0.0f32; rows * inp];
        let w = &self.w;
        dx.par_chunks_mut(inp).enumerate().for_each(|(r, dxr)| {
            let dyr = &dy[r * out..(r + 1) * out];
            for o in 0..out {
                let d = dyr[o];
                if d == 0.0 {
                    continue;
                }
                let wr = &w[o * inp..(o + 1) * inp];
                for i in 0..inp {
                    dxr[i] += d * wr[i];
                }
            }
        });
        dx
    }
    pub fn backward(&mut self, x: &[f32], dy: &[f32], rows: usize) -> Vec<f32> {
        let mut dx = vec![0.0f32; rows * self.inp];
        for r in 0..rows {
            for o in 0..self.out {
                let d = dy[r * self.out + o];
                if d == 0.0 {
                    continue;
                }
                if self.use_bias {
                    self.g_b[o] += d;
                }
                for i in 0..self.inp {
                    self.g_w[o * self.inp + i] += d * x[r * self.inp + i];
                    dx[r * self.inp + i] += d * self.w[o * self.inp + i];
                }
            }
        }
        dx
    }
    /// single-row backward: accumulates grads, returns dx
    pub fn backward_row(&mut self, x: &[f32], dy: &[f32]) -> Vec<f32> {
        let mut dx = vec![0.0f32; self.inp];
        for o in 0..self.out {
            let d = dy[o];
            if d == 0.0 {
                continue;
            }
            if self.use_bias {
                self.g_b[o] += d;
            }
            for i in 0..self.inp {
                self.g_w[o * self.inp + i] += d * x[i];
                dx[i] += d * self.w[o * self.inp + i];
            }
        }
        dx
    }
    pub fn zero_grad(&mut self) {
        self.g_w.iter_mut().for_each(|x| *x = 0.0);
        self.g_b.iter_mut().for_each(|x| *x = 0.0);
    }
}

// ---------------------------------------------------------------- scratch --

/// Growable pool of device buffers reused across batches/layers.
pub struct Scratch {
    f32s: Vec<DevBuf>,
    i8s: Vec<DevBuf>,
    i32s: Vec<DevBuf>,
}

impl Scratch {
    pub fn new() -> Self {
        Self { f32s: Vec::new(), i8s: Vec::new(), i32s: Vec::new() }
    }
    /// NOTE: the returned pointer stays valid until the same slot is
    /// requested again with a *larger* size.
    pub fn f32(&mut self, slot: usize, elems: usize) -> *mut f32 {
        while self.f32s.len() <= slot {
            self.f32s.push(DevBuf::new(0));
        }
        let need = elems * 4;
        if self.f32s[slot].len < need {
            self.f32s[slot] = DevBuf::new(need);
        }
        self.f32s[slot].ptr as *mut f32
    }
    pub fn i8(&mut self, slot: usize, elems: usize) -> *mut i8 {
        while self.i8s.len() <= slot {
            self.i8s.push(DevBuf::new(0));
        }
        if self.i8s[slot].len < elems {
            self.i8s[slot] = DevBuf::new(elems);
        }
        self.i8s[slot].ptr as *mut i8
    }
    pub fn i32(&mut self, slot: usize, elems: usize) -> *mut i32 {
        while self.i32s.len() <= slot {
            self.i32s.push(DevBuf::new(0));
        }
        let need = elems * 4;
        if self.i32s[slot].len < need {
            self.i32s[slot] = DevBuf::new(need);
        }
        self.i32s[slot].ptr as *mut i32
    }

    /// Copy a host vector into a scratch slot and return the *device* pointer.
    ///
    /// Every kernel argument has to be a device pointer.  Handing a
    /// `Vec::as_ptr()` straight to a `launch_*` function works on the CPU
    /// backend (there "device" pointers are host pointers) and is an instant
    /// "illegal memory access" on CUDA — that is what kept the GPU path from
    /// ever running while the CPU path looked fine.
    pub fn upload_f32(&mut self, slot: usize, host: &[f32], stream: &CudaStream) -> *mut f32 {
        let p = self.f32(slot, host.len());
        unsafe {
            cuda_memcpy_h2d(p as *mut CV, host.as_ptr() as *const CV, host.len() * 4, stream.0);
        }
        p
    }

    /// Zero the per-batch f64 accumulator that collects `sum(g^2)` of the
    /// device-resident conv gradients.  One scalar for the whole network, so the
    /// global grad-norm clip costs 8 bytes of D2H instead of 160.8 MB.
    pub fn reset_grad_sq(&mut self, stream: &CudaStream) {
        let p = self.f32(S_GSQ, 2);
        let zero = [0.0f64];
        unsafe { cuda_memcpy_h2d(p as *mut CV, zero.as_ptr() as *const CV, 8, stream.0) };
    }

    /// Device pointer to that accumulator (an `*mut f64` into a 2-element slot).
    pub fn grad_sq(&mut self) -> *mut f64 {
        self.f32(S_GSQ, 2) as *mut f64
    }

    /// Read the accumulator back to the host (8 bytes) and leave it zeroed for
    /// the next batch.
    pub fn read_grad_sq(&mut self, stream: &CudaStream) -> f64 {
        let p = self.f32(S_GSQ, 2);
        let mut out = [0.0f64];
        unsafe { cuda_memcpy_d2h(out.as_mut_ptr() as *mut CV, p as *const CV, 8, stream.0) };
        stream.sync();
        out[0]
    }

    pub fn upload_i8(&mut self, slot: usize, host: &[i8], stream: &CudaStream) -> *mut i8 {
        let p = self.i8(slot, host.len());
        unsafe {
            cuda_memcpy_h2d(p as *mut CV, host.as_ptr() as *const CV, host.len(), stream.0);
        }
        p
    }
}

// scratch slots
const S_COL: usize = 0;
const S_ACC: usize = 0;
const S_X: usize = 1;
const S_Y: usize = 2;
const S_T1: usize = 3;
const S_T2: usize = 4;
const S_T3: usize = 5;
const S_T4: usize = 6;
const S_T5: usize = 7;
const S_MEAN: usize = 8;
const S_VAR: usize = 9;
const S_SDY: usize = 10;
const S_SDXH: usize = 11;
const S_MAX: usize = 12;
const S_SMALL: usize = 13; // [B, C] pools / gates
// Device mirrors of host-resident parameters (see Scratch::upload_*):
const S_WF32: usize = 14; // f32 conv weights, used by grad_input
const S_BNG: usize = 15; //  BatchNorm gamma
const S_BNB: usize = 16; //  BatchNorm beta
const S_GSQ: usize = 17; //  8-byte f64: sum of g^2 over every conv layer
const S_QT: usize = 0;
const S_QTT: usize = 1;
// slot 2 is free: the GEMM's int8 weight operand now lives in a persistent
// per-layer device buffer (ConvQat::w_q_dev) that the backward pass reuses.

/// Set `TRBA_GRAD_INPUT_FP32=1` to compute dX from the fp32 master weights
/// (uploaded per layer per batch) instead of the int8 fake-quant weights that
/// are already resident on the device.  Useful as a numerical reference; on a
/// PCIe 2.0 x4 link it costs ~161 MB of extra H2D traffic per batch.
/// Set `TRBA_HOST_CONV_ADAM=1` to keep the conv weights' gradient accumulation,
/// Adam step and QAT re-quantisation on the host (the original design).  By
/// default `w`, `g`, `m` and `v` of all 28 conv layers stay resident on the
/// device: 42.15M parameters x 16 B = ~674 MB of VRAM, in exchange for deleting
/// 362 MB of PCIe traffic per batch (160.8 MB of int32 grad_W downstream,
/// 160.8 MB of fp32 weights upstream for grad_input, 40.2 MB of re-quantised
/// int8 weights upstream).  On PCIe 2.0 x4 that is ~270 ms per batch.
pub fn conv_weights_on_device() -> bool {
    static FLAG: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *FLAG.get_or_init(|| {
        !std::env::var("TRBA_HOST_CONV_ADAM").map(|v| v == "1").unwrap_or(false)
    })
}

/// Muon для резидентных весов свёрток: тот же флаг `TRBA_OPT`, что и на хосте
/// (`MuonSpec::from_env`). Закешировано, потому что от него зависит размер
/// device-буферов m/v — менять его посреди запуска нельзя.
pub fn muon_conv_on_device() -> bool {
    static FLAG: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *FLAG.get_or_init(|| crate::opt::MuonSpec::from_env().on)
}

fn grad_input_fp32_weights() -> bool {
    static FLAG: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *FLAG.get_or_init(|| std::env::var("TRBA_GRAD_INPUT_FP32").map(|v| v == "1").unwrap_or(false))
}

// ------------------------------------------------------------------- conv --

/// Device-resident optimiser state for one conv layer: the fp32 master weights,
/// the current gradient, the two Adam moments and the two 4-byte scalars the QAT
/// re-quantise needs.  16 bytes of VRAM per parameter.
struct DevOpt {
    w: DevBuf,       // fp32 master weights, compact [out_c, col_cols]
    g: DevBuf,       // fp32 gradient of the current batch
    m: DevBuf,       // Adam first moment (4-байтная заглушка в режиме Muon)
    v: DevBuf,       // Adam second moment (4-байтная заглушка в режиме Muon)
    gsq: DevBuf,     // 8 B f64: сумма g^2 по слою — норма для Muon
    max_abs: DevBuf, // 4 B: max|w|, produced by launch_max_abs_f32
    w_s: DevBuf,     // 4 B: max|w|/127, mirrored back to the host
}

pub struct ConvQat {
    pub name: String,
    pub in_c: usize,
    pub out_c: usize,
    pub kh: usize,
    pub kw: usize,
    pub sh: usize,
    pub sw: usize,
    pub ph: usize,
    pub pw: usize,
    pub w: Vec<f32>, // [out_c, col_cols]
    pub w_q: Vec<i8>,
    pub w_q_pad: Vec<i8>,
    pub w_s: f32,
    pub bn: BatchNorm,
    pub g_w: Vec<f32>,
    /// Счётчики MAC для отчёта о достигнутой производительности (TRBA_PROFILE=1).
    /// Forward: один GEMM `rows x out_c x col_cols`. Backward: два GEMM того же
    /// размера (grad_input и grad_weight), поэтому 2x. По ним main.rs печатает
    /// достигнутые GMAC/s int8-GEMM — прямое свидетельство того, что тензорные
    /// ядра действительно нагружены (сравнение с пиком IMMA см. в README).
    pub macs_fwd: u64,
    pub macs_bwd: u64,
    /// Resident device copy of `w_q_pad` (the padded int8 fake-quant weights).
    /// Uploaded at most once per `requantize()` and shared by the forward GEMM
    /// and the int8 `grad_input` kernel, so the weights cross PCIe once per
    /// layer per batch instead of three times — and never as fp32.  On a PCIe
    /// 2.0 x4 link that is the difference between ~797 MB and ~475 MB per step.
    w_q_dev: Option<DevBuf>,
    w_q_dirty: bool,
    /// Optimiser state that never leaves the device (see `conv_weights_on_device`).
    dev_opt: Option<DevOpt>,
}

pub struct ConvFwd {
    pub x: DevBuf, // pre-BN, f32 NCHW
    pub y: DevBuf, // post-BN pre-ReLU, f32 NCHW
    pub mean: DevBuf,
    pub var: DevBuf,
    pub mean_h: Vec<f32>,
    pub var_h: Vec<f32>,
    pub h_out: usize,
    pub w_out: usize,
}

pub struct ConvTrace {
    pub b: usize,
    pub h_in: usize,
    pub w_in: usize,
    pub h_out: usize,
    pub w_out: usize,
    pub s_in: f32,
    pub x: DevBuf,
    pub mean: DevBuf,
    pub var: DevBuf,
    pub mean_h: Vec<f32>,
    pub var_h: Vec<f32>,
    pub q_in: Arc<DevBuf>,
}

impl ConvQat {
    pub fn new(
        name: &str,
        in_c: usize,
        out_c: usize,
        kh: usize,
        kw: usize,
        sh: usize,
        sw: usize,
        ph: usize,
        pw: usize,
    ) -> Self {
        use rand::Rng;
        let mut rng = rand::thread_rng();
        let col = in_c * kh * kw;
        let limit = (6.0 / (col + out_c * kh * kw) as f32).sqrt();
        let w: Vec<f32> = (0..out_c * col).map(|_| rng.gen_range(-limit..limit)).collect();
        let mut c = Self {
            name: name.into(),
            in_c,
            out_c,
            kh,
            kw,
            sh,
            sw,
            ph,
            pw,
            w,
            w_q: Vec::new(),
            w_q_pad: Vec::new(),
            w_s: 1.0,
            bn: BatchNorm::new(out_c),
            g_w: vec![0.0; out_c * col],
            w_q_dev: None,
            w_q_dirty: true,
            macs_fwd: 0,
            macs_bwd: 0,
            dev_opt: None,
        };
        c.requantize();
        c
    }

    /// The layer's device optimiser state, allocated on first use and seeded
    /// from the host master weights (the only time they ever travel).
    fn dev_opt_mut(&mut self, stream: &CudaStream) -> &mut DevOpt {
        if self.dev_opt.is_none() {
            let n = self.out_c * self.col_cols();
            // Muon не хранит моментов: вместо 2 * n * 4 байт (на всю сеть это
            // 338 MB VRAM) выделяется заглушка, и из чекпоинта моменты свёрток
            // исчезают вместе с ней.
            let muon = muon_conv_on_device();
            let mom = if muon { 1 } else { n };
            let d = DevOpt {
                w: DevBuf::new(n * 4),
                g: DevBuf::new(n * 4),
                m: DevBuf::new(mom * 4),
                v: DevBuf::new(mom * 4),
                gsq: DevBuf::new(8),
                max_abs: DevBuf::new(4),
                w_s: DevBuf::new(4),
            };
            d.w.upload_f32(&self.w, stream);
            unsafe {
                launch_zero_f32(d.g.as_f32_mut(), n as i64, stream.0);
                launch_zero_f32(d.m.as_f32_mut(), mom as i64, stream.0);
                launch_zero_f32(d.v.as_f32_mut(), mom as i64, stream.0);
                launch_zero_f32(d.gsq.as_f32_mut(), 2, stream.0);
            }
            self.dev_opt = Some(d);
        }
        self.dev_opt.as_mut().unwrap()
    }

    /// Accumulate the int32 grad_W GEMM output into the resident fp32 gradient
    /// and add this layer's sum of squares to the network-wide scalar that the
    /// global grad-norm clip is built from.  Replaces a 160.8 MB download.
    pub fn device_grad_accum(&mut self, gw_i32: *const i32, deq: f32, gsq: *mut f64,
                             stream: &CudaStream) {
        let n = (self.out_c * self.col_cols()) as i64;
        let d = self.dev_opt_mut(stream);
        unsafe {
            launch_grad_accum_i32(gw_i32, d.g.as_f32_mut(), deq, n, stream.0);
            launch_sum_sq_add_f32(d.g.as_f32(), gsq, n, stream.0);
        }
    }

    /// One Adam step on the resident weights, with src/opt.rs arithmetic, then
    /// zero the gradient for the next batch.
    /// Muon-шаг по резидентным весам: норма -> масштаб -> axpy, всё на
    /// устройстве. Матрица слоя = [out_c, in_c*kh*kw].
    pub fn device_muon(&mut self, lr: f64, wd: f64, clip: f64, cap: f64, autoscale: bool,
                       stream: &CudaStream) {
        let (rows, cols) = (self.out_c, self.col_cols());
        let n = (rows * cols) as i64;
        let d = self.dev_opt_mut(stream);
        let gsq = d.gsq.ptr as *mut f64;
        unsafe {
            launch_zero_f32(d.gsq.as_f32_mut(), 2, stream.0);
            launch_sum_sq_add_f32(d.g.as_f32(), gsq, n, stream.0);
            launch_muon_step_f32(d.w.as_f32_mut(), d.g.as_f32(), gsq as *const f64, n, lr, wd,
                                 clip, rows.min(cols) as f64, rows.max(cols) as f64, cap,
                                 autoscale as i64, stream.0);
            launch_zero_f32(d.g.as_f32_mut(), n, stream.0);
        }
    }

    pub fn device_adam(&mut self, lr: f64, wd: f64, clip: f64, b1: f64, b2: f64, eps: f64,
                       bc1: f64, bc2: f64, stream: &CudaStream) {
        let n = (self.out_c * self.col_cols()) as i64;
        // Если Adam включили после создания device-состояния (TRBA_OPT=adam),
        // моменты могут быть заглушками по 4 байта — доращиваем, иначе ядро
        // писало бы за их границей.
        if self.dev_opt.as_ref().map_or(false, |d| d.m.len < n as usize * 4) {
            let d = self.dev_opt.as_mut().unwrap();
            d.m = DevBuf::new(n as usize * 4);
            d.v = DevBuf::new(n as usize * 4);
            unsafe {
                launch_zero_f32(d.m.as_f32_mut(), n, stream.0);
                launch_zero_f32(d.v.as_f32_mut(), n, stream.0);
            }
        }
        let d = self.dev_opt_mut(stream);
        unsafe {
            launch_adam_f32(d.w.as_f32_mut(), d.g.as_f32(), d.m.as_f32_mut(), d.v.as_f32_mut(),
                            n, lr, wd, clip, b1, b2, eps, bc1, bc2, stream.0);
            launch_zero_f32(d.g.as_f32_mut(), n, stream.0);
        }
    }

    /// Re-quantise the resident fp32 weights into the resident padded int8 GEMM
    /// operand.  Only the 4-byte scale comes back (the conv epilogue needs it as
    /// a host scalar); the 40.2 MB of int8 weights never travel.
    pub fn device_requantize(&mut self, stream: &CudaStream) {
        let (rows, col) = (self.out_c, self.col_cols());
        let kp = align16(col);
        let need = align16(rows) * kp;
        if self.w_q_dev.as_ref().map_or(true, |b| b.len < need) {
            self.w_q_dev = Some(DevBuf::new(need));
        }
        let wq = self.w_q_dev.as_ref().unwrap().as_i8_mut();
        let d = self.dev_opt_mut(stream);
        let (w, mx, ws) = (d.w.as_f32(), d.max_abs.as_f32_mut(), d.w_s.as_f32_mut());
        let ws_ptr = d.w_s.ptr;
        unsafe {
            launch_max_abs_f32(w, mx, (rows * col) as i64, stream.0);
            launch_quantize_pad_i8(w, mx as *const f32, ws, wq, rows as i64, col as i64,
                                   kp as i64, stream.0);
        }
        // The only thing the host needs back: the scale, as a scalar for the
        // conv epilogue's dequant divisor (4 bytes, not 160.8 MB).
        let mut s = [0.0f32];
        unsafe { cuda_memcpy_d2h(s.as_mut_ptr() as *mut CV, ws_ptr as *const CV, 4, stream.0) };
        stream.sync();
        self.w_s = s[0];
        self.w_q_dirty = false; // the kernel just wrote the device operand
    }

    /// Host shadow <- device master weights.  Checkpoints only: 160.8 MB once
    /// per save instead of once per batch.
    /// Скопировать резидентные fp32-веса в `dst` **независимо от режима**:
    /// `sync_shadow_from_device` в host-режиме (TRBA_HOST_CONV_ADAM=1) — no-op,
    /// а тестам и диагностике нужно прочитать то, что посчитало ядро. Если
    /// device-состояния ещё нет, `dst` не трогается.
    pub fn peek_device_weights(&self, dst: &mut [f32], stream: &CudaStream) {
        let d = match self.dev_opt.as_ref() {
            Some(d) => d,
            None => return,
        };
        let n = dst.len().min(d.w.len / 4);
        if n == 0 {
            return;
        }
        stream.sync();
        unsafe {
            cuda_memcpy_d2h(dst.as_mut_ptr() as *mut CV, d.w.ptr as *const CV, n * 4, stream.0)
        };
        stream.sync();
    }

    pub fn sync_shadow_from_device(&mut self, stream: &CudaStream) {
        if !conv_weights_on_device() {
            return;
        }
        let src = self.dev_opt_mut(stream).w.ptr;
        let bytes = self.w.len() * 4;
        stream.sync();
        unsafe { cuda_memcpy_d2h(self.w.as_mut_ptr() as *mut CV, src as *const CV, bytes, stream.0) };
        stream.sync();
    }

    /// Copy one Adam moment of this layer out of the device optimiser state into
    /// `dst` (resized to the parameter count).  `first` selects m, otherwise v.
    ///
    /// In host mode the moments live in the host `Adam` and are saved with the
    /// parameter itself, so this returns zeros of the right length; that keeps the
    /// checkpoint layout identical in both modes.  Downloading one layer at a time
    /// into a reused buffer matters: all conv moments together are 338 MB, and a
    /// checkpoint every few hundred batches should not double the host footprint.
    pub fn download_moment(&mut self, stream: &CudaStream, first: bool, dst: &mut Vec<f32>) {
        let n = self.out_c * self.col_cols();
        dst.clear();
        // В режиме Muon моментов у свёрток нет вовсе: пустой срез = «не
        // дублировать», минус 338 MB на каждый чекпоинт.
        if muon_conv_on_device() {
            return;
        }
        if !conv_weights_on_device() {
            // В host-режиме моменты свёрток уже сохранены вместе с параметром в
            // host-Adam: пустой срез здесь значит «не дублировать», а не «нули».
            // Иначе каждый чекпоинт носил бы ещё 338 MB нулей.
            return;
        }
        dst.resize(n, 0.0f32);
        let src = if first {
            self.dev_opt_mut(stream).m.ptr
        } else {
            self.dev_opt_mut(stream).v.ptr
        };
        stream.sync();
        unsafe {
            cuda_memcpy_d2h(dst.as_mut_ptr() as *mut CV, src as *const CV, n * 4, stream.0);
        }
        stream.sync();
    }

    /// Host moments -> device optimiser state, after loading a checkpoint.
    pub fn upload_moment(&mut self, stream: &CudaStream, first: bool, src: &[f32]) {
        if !conv_weights_on_device() {
            return;
        }
        // В режиме Muon моментов у свёрток нет: m/v — заглушки по 4 байта, и
        // запись n элементов из старого (adam'овского) чекпоинта ушла бы за их
        // границей. Молча пропускаем: Muon состояние не нужно.
        if muon_conv_on_device() {
            return;
        }
        let n = self.out_c * self.col_cols();
        if src.len() != n {
            // чекпоинт от другой конфигурации: лучше нули, чем чтение за границей
            return;
        }
        let dst = if first {
            self.dev_opt_mut(stream).m.ptr
        } else {
            self.dev_opt_mut(stream).v.ptr
        };
        unsafe {
            cuda_memcpy_h2d(dst, src.as_ptr() as *const CV, n * 4, stream.0);
        }
        stream.sync();
    }

    /// Device master weights <- host shadow, after loading a checkpoint.
    pub fn upload_weights_to_device(&mut self, stream: &CudaStream) {
        if !conv_weights_on_device() {
            return;
        }
        let dst = self.dev_opt_mut(stream).w.ptr;
        let bytes = self.w.len() * 4;
        unsafe { cuda_memcpy_h2d(dst, self.w.as_ptr() as *const CV, bytes, stream.0) };
        self.w_q_dirty = true; // the int8 operand no longer matches the weights
    }

    /// Device pointer to the padded int8 weights, uploading them only if this
    /// layer has been requantised since the last upload.
    fn w_q_on_device(&mut self, stream: &CudaStream) -> *const i8 {
        let n = self.w_q_pad.len();
        if conv_weights_on_device() {
            // In device mode `device_requantize` writes this buffer directly.
            if self.w_q_dev.as_ref().map_or(true, |b| b.len < n) || self.w_q_dirty {
                self.device_requantize(stream);
            }
            return self.w_q_dev.as_ref().unwrap().as_i8();
        }
        if self.w_q_dev.as_ref().map_or(true, |b| b.len < n) {
            self.w_q_dev = Some(DevBuf::new(n));
            self.w_q_dirty = true;
        }
        if self.w_q_dirty {
            self.w_q_dev.as_ref().unwrap().upload_i8(&self.w_q_pad, stream);
            self.w_q_dirty = false;
        }
        self.w_q_dev.as_ref().unwrap().as_i8()
    }

    pub fn col_cols(&self) -> usize {
        self.in_c * self.kh * self.kw
    }
    pub fn out_hw(&self, h: usize, w: usize) -> (usize, usize) {
        (
            (h + 2 * self.ph - self.kh) / self.sh + 1,
            (w + 2 * self.pw - self.kw) / self.sw + 1,
        )
    }

    pub fn requantize(&mut self) {
        let mx = self.w.iter().map(|x| x.abs()).fold(0.0f32, f32::max);
        self.w_s = if mx > 0.0 { mx / 127.0 } else { 1.0 };
        self.w_q = self
            .w
            .iter()
            .map(|&v| (v / self.w_s).clamp(-127.0, 127.0).round() as i8)
            .collect();
        let k = self.col_cols();
        let rp = align16(self.out_c);
        let cp = align16(k);
        self.w_q_pad = vec![0i8; rp * cp];
        for r in 0..self.out_c {
            self.w_q_pad[r * cp..r * cp + k].copy_from_slice(&self.w_q[r * k..(r + 1) * k]);
        }
        // The resident device copy now describes weights that no longer exist.
        self.w_q_dirty = true;
    }

    pub fn zero_grad(&mut self) {
        self.g_w.iter_mut().for_each(|x| *x = 0.0);
        self.bn.zero_grad();
    }

    pub fn forward(
        &mut self,
        q_in: &DevBuf,
        s_in: f32,
        b: usize,
        h: usize,
        w: usize,
        train: bool,
        stream: &CudaStream,
        sc: &mut Scratch,
    ) -> ConvFwd {
        let (ho, wo) = self.out_hw(h, w);
        let rows = b * ho * wo;
        let k = self.col_cols();
        let kp = align16(k);
        let rp = align16(rows);
        self.macs_fwd += (rows * self.out_c * k) as u64;

        let col = sc.i8(S_COL, rp * kp);
        unsafe {
            launch_im2col_pad(
                q_in.as_i8(),
                col,
                b as i32,
                self.in_c as i32,
                h as i32,
                w as i32,
                self.kh as i32,
                self.kw as i32,
                self.sh as i32,
                self.sw as i32,
                self.ph as i32,
                self.pw as i32,
                ho as i32,
                wo as i32,
                kp as i32,
                stream.0,
            );
        }
        let acc = sc.i32(S_ACC, rows * self.out_c);
        // The padded int8 weights live in ONE resident device buffer that the
        // backward pass reuses; re-uploaded only when requantize() changed them.
        let wq = self.w_q_on_device(stream);
        unsafe {
            launch_gemm_int8(
                col as *const i8,
                wq as *const i8,
                acc,
                rows as i32,
                self.out_c as i32,
                k as i32,
                stream.0,
            );
        }
        let n = b * self.out_c * ho * wo;
        let x = sc.f32(S_X, n);
        unsafe {
            launch_epilogue_f32(
                acc as *const i32,
                self.out_c as i32,
                s_in * self.w_s,
                x,
                self.out_c as i32,
                ho as i32,
                wo as i32,
                n as i64,
                stream.0,
            );
        }
        let mean = sc.f32(S_MEAN, self.out_c);
        let var = sc.f32(S_VAR, self.out_c);
        if train {
            unsafe {
                launch_bn_stats(
                    x as *const f32,
                    b as i32,
                    self.out_c as i32,
                    (ho * wo) as i32,
                    mean,
                    var,
                    stream.0,
                );
            }
        } else {
            unsafe {
                cuda_memcpy_h2d(mean as *mut CV, self.bn.run_mean.as_ptr() as *const CV, self.out_c * 4, stream.0);
                cuda_memcpy_h2d(var as *mut CV, self.bn.run_var.as_ptr() as *const CV, self.out_c * 4, stream.0);
            }
        }
        let y = sc.f32(S_Y, n);
        // gamma/beta are host Vecs; upload them before the kernel reads them.
        let gamma_d = sc.upload_f32(S_BNG, &self.bn.gamma, stream);
        let beta_d = sc.upload_f32(S_BNB, &self.bn.beta, stream);
        unsafe {
            launch_bn_apply(
                x as *const f32,
                mean as *const f32,
                var as *const f32,
                gamma_d as *const f32,
                beta_d as *const f32,
                BN_EPS,
                y,
                self.out_c as i32,
                (ho * wo) as i32,
                n as i64,
                stream.0,
            );
        }
        let mut mean_h = vec![0.0f32; self.out_c];
        let mut var_h = vec![0.0f32; self.out_c];
        unsafe {
            cuda_memcpy_d2h(mean_h.as_mut_ptr() as *mut CV, mean as *mut CV, self.out_c * 4, stream.0);
            cuda_memcpy_d2h(var_h.as_mut_ptr() as *mut CV, var as *mut CV, self.out_c * 4, stream.0);
        }
        stream.sync();

        let ox = DevBuf::new(n * 4);
        let oy = DevBuf::new(n * 4);
        let om = DevBuf::new(self.out_c * 4);
        let ov = DevBuf::new(self.out_c * 4);
        unsafe {
            cuda_memcpy_dtod(ox.ptr, x as *mut CV, n * 4, stream.0);
            cuda_memcpy_dtod(oy.ptr, y as *mut CV, n * 4, stream.0);
            cuda_memcpy_dtod(om.ptr, mean as *mut CV, self.out_c * 4, stream.0);
            cuda_memcpy_dtod(ov.ptr, var as *mut CV, self.out_c * 4, stream.0);
        }
        ConvFwd { x: ox, y: oy, mean: om, var: ov, mean_h, var_h, h_out: ho, w_out: wo }
    }

    /// `dy` = dL/d(BN output value), device f32.  Returns dL/d(input value).
    pub fn backward(
        &mut self,
        dy: *const f32,
        tr: &ConvTrace,
        stream: &CudaStream,
        sc: &mut Scratch,
    ) -> DevBuf {
        let b = tr.b;
        let (hi, wi) = (tr.h_in, tr.w_in);
        let (ho, wo) = (tr.h_out, tr.w_out);
        let rows = b * ho * wo;
        let n_in = b * self.in_c * hi * wi;
        let n_out = b * self.out_c * ho * wo;
        let hw = ho * wo;
        let k = self.col_cols();
        let kp = align16(k);
        let rp = align16(rows);
        self.macs_bwd += 2 * (rows * self.out_c * k) as u64;

        let sdy = sc.f32(S_SDY, self.out_c);
        let sdxh = sc.f32(S_SDXH, self.out_c);
        unsafe {
            launch_bn_bwd_sums(
                dy,
                tr.x.as_f32(),
                tr.mean.as_f32(),
                tr.var.as_f32(),
                BN_EPS,
                self.out_c as i32,
                hw as i32,
                n_out as i64,
                sdy,
                sdxh,
                stream.0,
            );
        }
        let dx = sc.f32(S_T1, n_out);
        let gamma_d = sc.upload_f32(S_BNG, &self.bn.gamma, stream);
        unsafe {
            launch_bn_bwd_dx(
                dy,
                tr.x.as_f32(),
                tr.mean.as_f32(),
                tr.var.as_f32(),
                gamma_d as *const f32,
                sdy as *const f32,
                sdxh as *const f32,
                BN_EPS,
                self.out_c as i32,
                hw as i32,
                n_out as i64,
                (b * hw) as i64,
                dx,
                stream.0,
            );
        }
        let mut g = vec![0.0f32; self.out_c];
        unsafe { cuda_memcpy_d2h(g.as_mut_ptr() as *mut CV, sdy as *mut CV, self.out_c * 4, stream.0) };
        for i in 0..self.out_c {
            self.bn.g_beta[i] += g[i];
        }
        unsafe { cuda_memcpy_d2h(g.as_mut_ptr() as *mut CV, sdxh as *mut CV, self.out_c * 4, stream.0) };
        for i in 0..self.out_c {
            self.bn.g_gamma[i] += g[i];
        }

        // grad_W: int8 GEMM (quantised dX)^T x col(input)
        let maxb = sc.f32(S_MAX, 1);
        unsafe { launch_reduce_max_abs(dx as *const f32, n_out as i64, maxb, stream.0) };
        let mut mx = [0.0f32];
        unsafe { cuda_memcpy_d2h(mx.as_mut_ptr() as *mut CV, maxb as *mut CV, 4, stream.0) };
        stream.sync();
        let s_dx = (mx[0] / 127.0).max(1e-12);
        let qdx = sc.i8(S_QT, n_out);
        unsafe { launch_quant_f32_i8(dx as *const f32, n_out as i64, s_dx, qdx, stream.0) };
        let op = align16(self.out_c);
        let qdx_t = sc.i8(S_QTT, op * rp);
        unsafe {
            launch_transpose_i8(qdx as *const i8, rows as i32, self.out_c as i32, qdx_t, stream.0);
        }
        let col = sc.i8(S_COL, rp * kp);
        unsafe {
            launch_im2col_pad(
                tr.q_in.as_i8(),
                col,
                b as i32,
                self.in_c as i32,
                hi as i32,
                wi as i32,
                self.kh as i32,
                self.kw as i32,
                self.sh as i32,
                self.sw as i32,
                self.ph as i32,
                self.pw as i32,
                ho as i32,
                wo as i32,
                kp as i32,
                stream.0,
            );
        }
        let gw = sc.i32(S_ACC, self.out_c * k);
        unsafe {
            launch_gemm_int8(
                qdx_t as *const i8,
                col as *const i8,
                gw,
                self.out_c as i32,
                k as i32,
                rows as i32,
                stream.0,
            );
        }
        let deq = s_dx * tr.s_in;
        if conv_weights_on_device() {
            // The int32 GEMM output stays on the device: it is folded into the
            // resident fp32 gradient, and this layer's contribution to the
            // global grad-norm goes into one 8-byte scalar.  This is the single
            // biggest traffic item in the whole step (160.8 MB per batch).
            let gsq = sc.grad_sq();
            self.device_grad_accum(gw as *const i32, deq, gsq, stream);
        } else {
            let mut gw_raw = vec![0i32; self.out_c * k];
            unsafe {
                cuda_memcpy_d2h(gw_raw.as_mut_ptr() as *mut CV, gw as *mut CV, self.out_c * k * 4, stream.0);
            }
            stream.sync();
            for i in 0..self.out_c * k {
                self.g_w[i] += gw_raw[i] as f32 * deq;
            }
        }

        let gi = DevBuf::new(n_in * 4);
        let dims = (
            b as i32, self.in_c as i32, hi as i32, wi as i32, self.out_c as i32,
            self.kh as i32, self.kw as i32, self.sh as i32, self.sw as i32,
            self.ph as i32, self.pw as i32, ho as i32, wo as i32,
        );
        if grad_input_fp32_weights() {
            // Reference path: fp32 master weights, uploaded per layer per batch
            // (they are updated in place by the optimizer through raw pointers,
            // so no generation cache is possible here).
            let w_d = sc.upload_f32(S_WF32, &self.w, stream);
            unsafe {
                launch_conv_backward_grad_input(dy, w_d as *const f32, gi.as_f32_mut(),
                                                dims.0, dims.1, dims.2, dims.3, dims.4, dims.5,
                                                dims.6, dims.7, dims.8, dims.9, dims.10, dims.11,
                                                dims.12, stream.0);
            }
        } else {
            // Default: the int8 fake-quant weights that this layer's forward
            // GEMM already put on the device.  Zero extra PCIe traffic, and it
            // is the QAT-consistent choice — dX is derived from the weights the
            // forward pass actually applied.  The kernel folds the per-tensor
            // scale in once, after the fp32 accumulation.
            let wq = self.w_q_on_device(stream);
            unsafe {
                launch_conv_backward_grad_input_i8(dy, wq, kp as i32, self.w_s,
                                                   gi.as_f32_mut(), dims.0, dims.1, dims.2,
                                                   dims.3, dims.4, dims.5, dims.6, dims.7,
                                                   dims.8, dims.9, dims.10, dims.11, dims.12,
                                                   stream.0);
            }
        }
        gi
    }
}

// ------------------------------------------------------------- quant utils --

/// dynamic max-abs quantisation of a device f32 tensor into an owned buffer
pub fn quantize_owned(v: *const f32, n: usize, stream: &CudaStream, sc: &mut Scratch) -> (Arc<DevBuf>, f32) {
    let maxb = sc.f32(S_MAX, 1);
    unsafe { launch_reduce_max_abs(v, n as i64, maxb, stream.0) };
    let mut mx = [0.0f32];
    unsafe { cuda_memcpy_d2h(mx.as_mut_ptr() as *mut CV, maxb as *mut CV, 4, stream.0) };
    stream.sync();
    let s = (mx[0] / 127.0).max(1e-12);
    let q = Arc::new(DevBuf::new(n));
    unsafe { launch_quant_f32_i8(v, n as i64, s, q.as_i8_mut(), stream.0) };
    (q, s)
}

/// ReLU + dynamic quantisation (the standard activation boundary)
pub fn relu_quant_owned(y: *const f32, n: usize, stream: &CudaStream, sc: &mut Scratch) -> (Arc<DevBuf>, f32) {
    let maxb = sc.f32(S_MAX, 1);
    unsafe { launch_reduce_max_abs(y, n as i64, maxb, stream.0) };
    let mut mx = [0.0f32];
    unsafe { cuda_memcpy_d2h(mx.as_mut_ptr() as *mut CV, maxb as *mut CV, 4, stream.0) };
    stream.sync();
    let s = (mx[0] / 127.0).max(1e-12);
    let q = Arc::new(DevBuf::new(n));
    unsafe { launch_relu_quant(y, n as i64, s, q.as_i8_mut(), stream.0) };
    (q, s)
}

// ------------------------------------------------------------------ blocks --

pub struct SELayer {
    pub fc1: LinearF,
    pub fc2: LinearF,
}

impl SELayer {
    pub fn new(c: usize, reduction: usize) -> Self {
        Self { fc1: LinearF::new(c, c / reduction, false), fc2: LinearF::new(c / reduction, c, false) }
    }
    pub fn zero_grad(&mut self) {
        self.fc1.zero_grad();
        self.fc2.zero_grad();
    }
}

pub struct BasicBlock {
    pub conv1: ConvQat,
    pub conv2: ConvQat,
    pub se: SELayer,
    pub ds: Option<ConvQat>,
}

pub struct BlockTrace {
    pub c1: ConvTrace,
    pub c2: ConvTrace,
    pub ds: Option<ConvTrace>,
    pub q1: Arc<DevBuf>,
    pub s1: f32,
    pub y2: DevBuf,
    pub gate: Vec<f32>,
    pub pooled: Vec<f32>,
    pub h1: Vec<f32>,
    pub b: usize,
    pub h_out: usize,
    pub w_out: usize,
    pub c: usize,
    pub h_in: usize,
    pub w_in: usize,
    pub s_in: f32,
    pub q_in: Arc<DevBuf>,
}

impl BasicBlock {
    pub fn new(in_c: usize, out_c: usize, stride: usize, name: &str) -> Self {
        let ds = if stride != 1 || in_c != out_c {
            Some(ConvQat::new(&format!("{name}.downsample.0"), in_c, out_c, 1, 1, stride, stride, 0, 0))
        } else {
            None
        };
        Self {
            conv1: ConvQat::new(&format!("{name}.conv1"), in_c, out_c, 3, 3, stride, stride, 1, 1),
            conv2: ConvQat::new(&format!("{name}.conv2"), out_c, out_c, 3, 3, 1, 1, 1, 1),
            se: SELayer::new(out_c, 16),
            ds,
        }
    }

    pub fn zero_grad(&mut self) {
        self.conv1.zero_grad();
        self.conv2.zero_grad();
        self.se.zero_grad();
        if let Some(d) = &mut self.ds {
            d.zero_grad();
        }
    }

    pub fn forward(
        &mut self,
        q_in: &Arc<DevBuf>,
        s_in: f32,
        b: usize,
        h: usize,
        w: usize,
        train: bool,
        stream: &CudaStream,
        sc: &mut Scratch,
    ) -> (Arc<DevBuf>, f32, BlockTrace) {
        let (ho1, wo1) = self.conv1.out_hw(h, w);
        let c = self.conv2.out_c;
        let n_out = b * c * ho1 * wo1;

        let ds_fwd: Option<ConvFwd> = if let Some(ds) = &mut self.ds {
            Some(ds.forward(q_in, s_in, b, h, w, train, stream, sc))
        } else {
            None
        };

        let f1 = self.conv1.forward(q_in, s_in, b, h, w, train, stream, sc);
        let (h1o, w1o) = (f1.h_out, f1.w_out);
        let n1 = b * self.conv1.out_c * h1o * w1o;
        let (q1, s1) = relu_quant_owned(f1.y.as_f32(), n1, stream, sc);

        let f2 = self.conv2.forward(&q1, s1, b, h1o, w1o, train, stream, sc);
        let (h2, w2) = (f2.h_out, f2.w_out);

        // SE on the pre-ReLU BN output of conv2 (as in the reference)
        let pooled_buf = sc.f32(S_SMALL, b * c);
        unsafe {
            launch_avgpool_hw(f2.y.as_f32(), c as i32, (h2 * w2) as i32, b as i64, pooled_buf, stream.0);
        }
        let mut pooled = vec![0.0f32; b * c];
        unsafe { cuda_memcpy_d2h(pooled.as_mut_ptr() as *mut CV, pooled_buf as *mut CV, b * c * 4, stream.0) };
        stream.sync();
        let pre1 = self.se.fc1.forward(&pooled, b);
        let h1v: Vec<f32> = pre1.iter().map(|&v| v.max(0.0)).collect();
        let pre2 = self.se.fc2.forward(&h1v, b);
        let gate: Vec<f32> = pre2.iter().map(|&v| 1.0 / (1.0 + (-v).exp())).collect();

        let gate_buf = sc.f32(S_SMALL, b * c);
        unsafe { cuda_memcpy_h2d(gate_buf as *mut CV, gate.as_ptr() as *const CV, b * c * 4, stream.0) };
        let yse = sc.f32(S_T3, n_out);
        unsafe {
            launch_mul_gate(f2.y.as_f32(), gate_buf as *const f32, c as i32, (h2 * w2) as i32, n_out as i64, yse, stream.0);
        }
        let z = sc.f32(S_T4, n_out);
        match &ds_fwd {
            Some(f) => unsafe { launch_add_f32(yse as *const f32, f.y.as_f32(), n_out as i64, z, stream.0) },
            None => {
                let id = sc.f32(S_T5, n_out);
                unsafe { launch_dequant_i8_f32(q_in.as_i8(), n_out as i64, s_in, id, stream.0) };
                unsafe { launch_add_f32(yse as *const f32, id as *const f32, n_out as i64, z, stream.0) };
            }
        }
        let (q_out, s_z) = relu_quant_owned(z as *const f32, n_out, stream, sc);

        let ds_trace = ds_fwd.map(|f| trace_of(f, b, h, w, s_in, q_in.clone()));

        let tr = BlockTrace {
            c1: {
                let x = f1.x; let mean = f1.mean; let var = f1.var;
                let mh = f1.mean_h.clone(); let vh = f1.var_h.clone();
                ConvTrace { b, h_in: h, w_in: w, h_out: h1o, w_out: w1o, s_in, x, mean, var, mean_h: mh, var_h: vh, q_in: q_in.clone() }
            },
            c2: {
                let x = f2.x; let mean = f2.mean; let var = f2.var;
                let mh = f2.mean_h.clone(); let vh = f2.var_h.clone();
                ConvTrace { b, h_in: h1o, w_in: w1o, h_out: h2, w_out: w2, s_in: s1, x, mean, var, mean_h: mh, var_h: vh, q_in: q1.clone() }
            },
            ds: ds_trace,
            q1,
            s1,
            y2: f2.y,
            gate,
            pooled,
            h1: h1v,
            b,
            h_out: h2,
            w_out: w2,
            c,
            h_in: h,
            w_in: w,
            s_in,
            q_in: q_in.clone(),
        };
        (q_out, s_z, tr)
    }

    /// `dq_out`/`s_dq`: dL/dq_int of the block output.  `q_out` needed for the
    /// ReLU mask.  Returns dL/d(input value) as device f32.
    pub fn backward(
        &mut self,
        dq_out: &DevBuf,
        s_dq: f32,
        q_out: &DevBuf,
        tr: &BlockTrace,
        stream: &CudaStream,
        sc: &mut Scratch,
    ) -> DevBuf {
        let b = tr.b;
        let (ho, wo) = (tr.h_out, tr.w_out);
        let n_out = b * tr.c * ho * wo;
        let hw = ho * wo;
        let n_in = b * self.conv1.in_c * tr.h_in * tr.w_in;

        // dz = dL/dq * s_dq, masked by the ReLU sign of the block output
        let gvz = sc.f32(S_T1, n_out);
        unsafe { launch_dequant_i8_f32(dq_out.as_i8(), n_out as i64, s_dq, gvz, stream.0) };
        let qzv = sc.f32(S_T5, n_out);
        unsafe { launch_dequant_i8_f32(q_out.as_i8(), n_out as i64, 1.0, qzv, stream.0) };
        let dz = DevBuf::new(n_out * 4);
        unsafe { launch_mask_relu_bwd(qzv as *const f32, gvz as *const f32, n_out as i64, dz.as_f32_mut(), stream.0) };

        // ---- SE backward ----
        let gate_buf = sc.f32(S_SMALL, b * tr.c);
        unsafe { cuda_memcpy_h2d(gate_buf as *mut CV, tr.gate.as_ptr() as *const CV, b * tr.c * 4, stream.0) };
        let dy2 = sc.f32(S_T2, n_out);
        unsafe {
            launch_mul_gate(dz.as_f32(), gate_buf as *const f32, tr.c as i32, hw as i32, n_out as i64, dy2, stream.0);
        }
        let prod = sc.f32(S_T3, n_out);
        unsafe { launch_mul_f32(dz.as_f32(), tr.y2.as_f32(), n_out as i64, prod, stream.0) };
        let poolmean = sc.f32(S_SMALL, b * tr.c);
        unsafe { launch_avgpool_hw(prod as *const f32, tr.c as i32, hw as i32, b as i64, poolmean, stream.0) };
        let mut dgate = vec![0.0f32; b * tr.c];
        unsafe { cuda_memcpy_d2h(dgate.as_mut_ptr() as *mut CV, poolmean as *mut CV, b * tr.c * 4, stream.0) };
        stream.sync();
        for g in dgate.iter_mut() {
            *g *= hw as f32; // mean -> sum
        }
        // sigmoid + fc2 + relu + fc1 on the host
        let mut dpre2 = vec![0.0f32; b * tr.c];
        for i in 0..b * tr.c {
            dpre2[i] = dgate[i] * tr.gate[i] * (1.0 - tr.gate[i]);
        }
        let dh1 = self.se.fc2.backward(&tr.h1, &dpre2, b);
        let dpre1: Vec<f32> = dh1.iter().zip(tr.h1.iter()).map(|(&d, &h)| d * if h > 0.0 { 1.0 } else { 0.0 }).collect();
        let dpooled = self.se.fc1.backward(&tr.pooled, &dpre1, b);
        let apb = sc.f32(S_T3, n_out);
        let dp_buf = sc.f32(S_SMALL, b * tr.c);
        unsafe { cuda_memcpy_h2d(dp_buf as *mut CV, dpooled.as_ptr() as *const CV, b * tr.c * 4, stream.0) };
        unsafe {
            launch_avgpool_hw_backward(dp_buf as *const f32, tr.c as i32, hw as i32, b as i64, apb, stream.0);
        }
        let dy2_full = sc.f32(S_T4, n_out);
        unsafe { launch_add_f32(dy2 as *const f32, apb as *const f32, n_out as i64, dy2_full, stream.0) };

        // ---- conv2 backward (no ReLU after its BN) ----
        let gv1 = self.conv2.backward(dy2_full as *const f32, &tr.c2, stream, sc); // dL/d v1 (value of q1)
        // mask ReLU of conv1: dy1 = gv1 * (q1 > 0)
        let q1v = sc.f32(S_T5, n1_len(tr));
        unsafe { launch_dequant_i8_f32(tr.q1.as_i8(), n1_len(tr) as i64, 1.0, q1v, stream.0) };
        let dy1 = DevBuf::new(n1_len(tr) * 4);
        unsafe { launch_mask_relu_bwd(q1v as *const f32, gv1.as_f32(), n1_len(tr) as i64, dy1.as_f32_mut(), stream.0) };

        // ---- conv1 backward ----
        let gi_in = self.conv1.backward(dy1.as_f32(), &tr.c1, stream, sc); // dL/d v_in

        // ---- skip branch ----
        let total = DevBuf::new(n_in * 4);
        match (&mut self.ds, &tr.ds) {
            (Some(ds), Some(dtr)) => {
                let dx_ds = ds.backward(dz.as_f32(), dtr, stream, sc); // dL/d v_in via skip
                unsafe { launch_add_f32(gi_in.as_f32(), dx_ds.as_f32(), n_in as i64, total.as_f32_mut(), stream.0) };
            }
            _ => {
                unsafe { launch_add_f32(gi_in.as_f32(), dz.as_f32(), n_in as i64, total.as_f32_mut(), stream.0) };
            }
        }
        total
    }
}

fn n1_len(tr: &BlockTrace) -> usize {
    tr.b * tr.c * tr.c1.h_out * tr.c1.w_out
}

fn trace_of(f: ConvFwd, b: usize, h_in: usize, w_in: usize, s_in: f32, q_in: Arc<DevBuf>) -> ConvTrace {
    ConvTrace {
        b,
        h_in,
        w_in,
        h_out: f.h_out,
        w_out: f.w_out,
        s_in,
        x: f.x,
        mean: f.mean,
        var: f.var,
        mean_h: f.mean_h,
        var_h: f.var_h,
        q_in,
    }
}

// ------------------------------------------------------------------- net --

pub struct StemTrace {
    pub c0: ConvTrace,
    pub c1: ConvTrace,
    pub q0: Arc<DevBuf>,
    pub s0: f32,
    pub q1: Arc<DevBuf>,
    pub s1: f32,
    pub b: usize,
    pub h_pool_in: usize,
    pub w_pool_in: usize,
}

pub struct OutTrace {
    pub c0: ConvTrace,
    pub c1: ConvTrace,
    pub q0: Arc<DevBuf>,
    pub s0: f32,
    pub b: usize,
    pub h_feat: usize, // H before meanpool (1 or 2)
    pub w_feat: usize,
}

pub struct NetTrace {
    pub stem: StemTrace,
    pub blocks: Vec<BlockTrace>,
    pub out: OutTrace,
    pub q_chain: Vec<(Arc<DevBuf>, f32)>, // quantised output + scale of every stage
    pub s_img: f32,
}

pub struct SEResNetQ {
    pub c0: ConvQat,
    pub c1: ConvQat,
    pub layer1: Vec<BasicBlock>,
    pub layer2: Vec<BasicBlock>,
    pub layer3: Vec<BasicBlock>,
    pub layer4: Vec<BasicBlock>,
    pub o0: ConvQat,
    pub o1: ConvQat,
    /// Ширина признака на выходе энкодера (`--feat-dim`): число каналов
    /// последней стадии и, значит, размерность `[B, T, fd]`, которую ест BiLSTM.
    pub fd: usize,
}

impl SEResNetQ {
    /// Таблица каналов по стадиям: `[stem0, stem1, layer1, layer2, layer3, out]`.
    /// При `fd = 512` это в точности историческая архитектура (64, 128, 256, 256,
    /// 512, 512), поэтому дефолт остаётся бит-в-бит прежним. Число параметров
    /// растёт как fd²: fd=128 даёт в 16 раз меньше весов (2.7M против 42.9M).
    pub fn widths(fd: usize) -> [usize; 6] {
        [fd / 8, fd / 4, fd / 2, fd / 2, fd, fd]
    }

    /// `fd` — ширина признака на выходе (кратно 8; для int8-GEMM выгодно кратно 16).
    pub fn new(fd: usize) -> Self {
        assert!(fd >= 8 && fd % 8 == 0, "--feat-dim должен быть кратен 8 (получено {fd})");
        let w = Self::widths(fd);
        Self {
            c0: ConvQat::new("stem.0", 3, w[0], 3, 3, 1, 1, 1, 1),
            c1: ConvQat::new("stem.3", w[0], w[1], 3, 3, 1, 1, 1, 1),
            layer1: vec![BasicBlock::new(w[1], w[2], 2, "layer1.0")],
            layer2: vec![BasicBlock::new(w[2], w[3], 1, "layer2.0"), BasicBlock::new(w[3], w[3], 1, "layer2.1")],
            layer3: {
                let mut v = vec![BasicBlock::new(w[3], w[4], 2, "layer3.0")];
                for i in 1..5 {
                    v.push(BasicBlock::new(w[4], w[4], 1, &format!("layer3.{i}")));
                }
                v
            },
            layer4: (0..3).map(|i| BasicBlock::new(w[5], w[5], 1, &format!("layer4.{i}"))).collect(),
            o0: ConvQat::new("conv_out.0", w[5], w[5], 2, 2, 2, 1, 0, 1),
            o1: ConvQat::new("conv_out.3", w[5], w[5], 2, 2, 1, 1, 0, 0),
            fd,
        }
    }

    pub fn convs_mut(&mut self) -> Vec<&mut ConvQat> {
        let mut v = vec![&mut self.c0, &mut self.c1];
        for l in [&mut self.layer1, &mut self.layer2, &mut self.layer3, &mut self.layer4] {
            for b in l.iter_mut() {
                if let Some(d) = &mut b.ds {
                    v.push(d);
                }
                v.push(&mut b.conv1);
                v.push(&mut b.conv2);
            }
        }
        v.push(&mut self.o0);
        v.push(&mut self.o1);
        v
    }

    pub fn zero_grad(&mut self) {
        for c in self.convs_mut() {
            c.zero_grad();
        }
        for l in [&mut self.layer1, &mut self.layer2, &mut self.layer3, &mut self.layer4] {
            for b in l.iter_mut() {
                b.se.zero_grad();
            }
        }
    }

    /// Re-quantise every conv layer.  In device mode this runs on the GPU from
    /// the resident master weights (only a 4-byte scale comes back per layer);
    /// otherwise it is the original host-side `requantize`.
    pub fn requantize_all(&mut self, stream: &CudaStream) {
        let on_device = conv_weights_on_device();
        for c in self.convs_mut() {
            if on_device {
                c.device_requantize(stream);
            } else {
                c.requantize();
            }
        }
    }

    /// Adam step for every conv layer's weights, on the device.  `bc1`/`bc2`
    /// must be the same bias corrections the host step used (`Adam::bias_correction`).
    pub fn device_adam_step(&mut self, lr: f64, wd: f64, clip: f64, b1: f64, b2: f64,
                            eps: f64, bc1: f64, bc2: f64, stream: &CudaStream) {
        for c in self.convs_mut() {
            c.device_adam(lr, wd, clip, b1, b2, eps, bc1, bc2, stream);
        }
    }

    /// Muon-шаг для весов всех свёрток, на устройстве. Заменяет
    /// `device_adam_step`, когда `opt.muon.on` (см. src/opt.rs).
    pub fn device_muon_step(&mut self, lr: f64, wd: f64, clip: f64, cap: f64, autoscale: bool,
                            stream: &CudaStream) {
        for c in self.convs_mut() {
            c.device_muon(lr, wd, clip, cap, autoscale, stream);
        }
    }

    /// Pull the device master weights into the host shadows before writing a
    /// checkpoint.  A no-op in host mode.
    pub fn sync_conv_shadows(&mut self, stream: &CudaStream) {
        for c in self.convs_mut() {
            c.sync_shadow_from_device(stream);
        }
    }

    /// Push freshly loaded host weights to the device.  A no-op in host mode.
    pub fn upload_conv_weights(&mut self, stream: &CudaStream) {
        for c in self.convs_mut() {
            c.upload_weights_to_device(stream);
        }
    }

    /// `img` = int8 image activations with scale `s_img` (values in [-1, 1]).
    /// Returns encoder input features `[B, T, fd]` (device f32) + trace.
    pub fn forward(
        &mut self,
        img: &Arc<DevBuf>,
        s_img: f32,
        b: usize,
        train: bool,
        img_h: usize,
        img_w: usize,
        stream: &CudaStream,
        sc: &mut Scratch,
    ) -> (DevBuf, NetTrace) {
        let mut h = img_h;
        let mut w = img_w;
        let mut chain: Vec<(Arc<DevBuf>, f32)> = Vec::new();

        // stem.  Размеры активаций берём из out_c соответствующего слоя: зашитые
        // 64/128 (исторические ширины при fd=512) при fd<512 завышали длину вдвое-
        // вчетверо, и relu_quant_owned читал за концом буфера — SIGSEGV (§20.11).
        let f0 = self.c0.forward(img, s_img, b, h, w, train, stream, sc);
        let n0 = b * self.c0.out_c * h * w;
        let (q0, s0) = relu_quant_owned(f0.y.as_f32(), n0, stream, sc);
        chain.push((q0.clone(), s0));
        let f1 = self.c1.forward(&q0, s0, b, h, w, train, stream, sc);
        let n1 = b * self.c1.out_c * h * w;
        let (q1, s1) = relu_quant_owned(f1.y.as_f32(), n1, stream, sc);
        chain.push((q1.clone(), s1));
        // maxpool2x2 stays ON THE DEVICE over int8.  The old host path cost
        // 416 MB of PCIe traffic per batch — 128 MB to download q1, 32 MB to
        // upload the pooled tensor and 256 MB to upload the u64 argmax indices
        // again during the backward pass — plus 256 MB of host RAM for those
        // indices.  The backward now recomputes the argmax from q1, which the
        // trace keeps anyway (the ReLU mask needs it), so the indices never
        // exist.  On PCIe 2.0 x4 that single change is ~310 ms per batch.
        let (h_in, w_in) = (h, w);
        h /= 2;
        w /= 2;
        let q_pool = Arc::new(DevBuf::new(b * self.c1.out_c * h * w));
        unsafe {
            launch_maxpool2x2_forward_i8(q1.as_i8(), q_pool.as_i8_mut(), b as i32,
                                         self.c1.out_c as i32, h_in as i32, w_in as i32, stream.0);
        }
        let s_pool = s1; // pure selection: same scale
        chain.push((q_pool.clone(), s_pool));

        let stem_tr = StemTrace {
            c0: trace_of(f0, b, img_h, img_w, s_img, img.clone()),
            c1: trace_of(f1, b, h * 2, w * 2, s0, q0.clone()),
            q0: q0.clone(),
            s0,
            q1: q1.clone(),
            s1,
            b,
            h_pool_in: h_in,
            w_pool_in: w_in,
        };
        // NOTE: stem c0 trace q_in unused (image gradient is discarded);
        // replace with the real image buffer below via NetTrace.s_img.

        let mut q_cur = q_pool;
        let mut s_cur = s_pool;
        let mut blocks = Vec::new();
        for layer in [&mut self.layer1, &mut self.layer2, &mut self.layer3, &mut self.layer4] {
            for blk in layer.iter_mut() {
                let (q, s, tr) = blk.forward(&q_cur, s_cur, b, h, w, train, stream, sc);
                h = tr.h_out;
                w = tr.w_out;
                chain.push((q.clone(), s));
                q_cur = q;
                s_cur = s;
                blocks.push(tr);
            }
        }

        // conv_out
        let fo0 = self.o0.forward(&q_cur, s_cur, b, h, w, train, stream, sc);
        let no0 = b * self.fd * fo0.h_out * fo0.w_out;
        let (qo0, so0) = relu_quant_owned(fo0.y.as_f32(), no0, stream, sc);
        chain.push((qo0.clone(), so0));
        let (ho0, wo0) = (fo0.h_out, fo0.w_out);
        let fo1 = self.o1.forward(&qo0, so0, b, ho0, wo0, train, stream, sc);
        let no1 = b * self.fd * fo1.h_out * fo1.w_out;
        let (qo1, so1) = relu_quant_owned(fo1.y.as_f32(), no1, stream, sc);
        chain.push((qo1.clone(), so1));
        let (hf, wf) = (fo1.h_out, fo1.w_out);

        // features: dequant -> mean over H -> [B, W, C]
        let fv = sc.f32(S_T1, no1);
        unsafe { launch_dequant_i8_f32(qo1.as_i8(), no1 as i64, so1, fv, stream.0) };
        let feat = DevBuf::new(b * wf * self.fd * 4);
        unsafe { launch_meanpool_h(fv as *const f32, self.fd as i32, hf as i32, wf as i32, b as i64, feat.as_f32_mut(), stream.0) };

        let out_tr = OutTrace {
            c0: trace_of(fo0, b, h, w, s_cur, q_cur.clone()),
            c1: trace_of(fo1, b, ho0, wo0, so0, qo0.clone()),
            q0: qo0,
            s0: so0,
            b,
            h_feat: hf,
            w_feat: wf,
        };
        (feat, NetTrace { stem: stem_tr, blocks, out: out_tr, q_chain: chain, s_img })
    }

    /// Backprop a `[B, T, fd]` feature gradient through the whole CNN.
    pub fn backward(&mut self, d_feat: &DevBuf, tr: &NetTrace, stream: &CudaStream, sc: &mut Scratch) {
        let b = tr.out.b;
        let (hf, wf) = (tr.out.h_feat, tr.out.w_feat);
        let no1 = b * self.fd * hf * wf;

        // meanpool backward -> dL/d(conv_out1 output value)
        let dv = sc.f32(S_T1, no1);
        unsafe { launch_meanpool_h_backward(d_feat.as_f32(), self.fd as i32, hf as i32, wf as i32, b as i64, dv, stream.0) };
        // value -> quant int gradient, then ReLU mask via qo1 sign
        let qo1 = &tr.q_chain.last().unwrap().0;
        let so1 = tr.q_chain.last().unwrap().1;
        unsafe { cuda_scale_vector(dv, so1, no1 as i64, stream.0) };
        let qv = sc.f32(S_T3, no1);
        unsafe { launch_dequant_i8_f32(qo1.as_i8(), no1 as i64, 1.0, qv, stream.0) };
        let dy1 = DevBuf::new(no1 * 4);
        unsafe { launch_mask_relu_bwd(qv as *const f32, dv as *const f32, no1 as i64, dy1.as_f32_mut(), stream.0) };
        let gv_o0 = self.o1.backward(dy1.as_f32(), &tr.out.c1, stream, sc); // dL/d v(o0 out)
        // ReLU mask of o0 via qo0
        let no0 = b * self.fd * tr.out.c0.h_out * tr.out.c0.w_out;
        let qv0 = sc.f32(S_T3, no0);
        unsafe { launch_dequant_i8_f32(tr.out.q0.as_i8(), no0 as i64, 1.0, qv0, stream.0) };
        let dy0 = DevBuf::new(no0 * 4);
        unsafe { launch_mask_relu_bwd(qv0 as *const f32, gv_o0.as_f32(), no0 as i64, dy0.as_f32_mut(), stream.0) };
        let mut gv = self.o0.backward(dy0.as_f32(), &tr.out.c0, stream, sc); // dL/d v(layer4 out)

        // Blocks in exact reverse forward order: layer4's last block first,
        // layer1's only block last.  `tr.blocks[k]` and `tr.q_chain[3+k]` are
        // recorded in forward order (layer1 -> layer4, block 0 -> n), so the
        // k-th visited block pairs with forward index n_blocks-1-k.
        //
        // This used to build [layer4, layer3, layer2, layer1] and then walk that
        // list *backwards*, which visits layer1 first and pairs the gradient
        // arriving at L4.2 with L1.0's trace.  n_out taken from the gradient
        // (b*512*H4*W4) then disagrees with the trace's b*c*h_out*w_out
        // (b*256*H1*W1): the block dequantises `dqi` past its end (illegal
        // memory access on the device, silent heap overflow on the CPU) and
        // every CNN gradient is computed against the wrong block's activations.
        let mut layers: Vec<&mut BasicBlock> = Vec::new();
        for layer in [&mut self.layer4, &mut self.layer3, &mut self.layer2, &mut self.layer1] {
            layers.extend(layer.iter_mut().rev());
        }
        // chain indices: [q0,s0],[q1,s1],[pool], then one per block, then o0, o1
        let n_blocks = tr.blocks.len();
        for (k, blk) in layers.iter_mut().enumerate() {
            let bi = n_blocks - 1 - k; // index into tr.blocks
            let btr = &tr.blocks[bi];
            // dq for this block output = gv * s_of_this_block_output
            let s_out = tr.q_chain[3 + bi].1;
            let q_out = &tr.q_chain[3 + bi].0;
            let n_out = gv.len / 4;
            // Invariant: the incoming gradient must describe exactly this
            // block's output tensor.  If the pairing above ever breaks again,
            // fail here with both shapes instead of reading out of bounds a few
            // kernels later.
            let expect = btr.b * btr.c * btr.h_out * btr.w_out;
            assert_eq!(
                n_out, expect,
                "backprop block/trace pairing: incoming gradient has {n_out} elements, \
                 but trace {bi} (c={} {}x{}, b={}) expects {expect}",
                btr.c, btr.h_out, btr.w_out, btr.b
            );
            unsafe { cuda_scale_vector(gv.as_f32_mut(), s_out, n_out as i64, stream.0) };
            let dqi = DevBuf::new(n_out);
            // quantise gv (now dL/dq_int) for the block backward
            let maxb = sc.f32(S_MAX, 1);
            unsafe { launch_reduce_max_abs(gv.as_f32(), n_out as i64, maxb, stream.0) };
            let mut mx = [0.0f32];
            unsafe { cuda_memcpy_d2h(mx.as_mut_ptr() as *mut CV, maxb as *mut CV, 4, stream.0) };
            stream.sync();
            let s_dq = (mx[0] / 127.0).max(1e-12);
            unsafe { launch_quant_f32_i8(gv.as_f32(), n_out as i64, s_dq, dqi.as_i8_mut(), stream.0) };
            gv = blk.backward(&dqi, s_dq, q_out, btr, stream, sc);
        }

        // stem: gv is dL/d v(pool output) == dL/d v(q1 selected)
        let s_pool = tr.stem.s1;
        let n_pool = gv.len / 4;
        unsafe { cuda_scale_vector(gv.as_f32_mut(), s_pool, n_pool as i64, stream.0) };
        // scatter through maxpool: the kernel recomputes the argmax from the
        // int8 activations still on the device, so no index tensor crosses PCIe
        // (it used to be 256 MB per batch).
        let n1 = b * self.c1.out_c * tr.stem.h_pool_in * tr.stem.w_pool_in;
        let dpre = DevBuf::new(n1 * 4);
        unsafe {
            launch_maxpool2x2_backward_i8(tr.stem.q1.as_i8(), gv.as_f32(), dpre.as_f32_mut(),
                                          b as i32, self.c1.out_c as i32, tr.stem.h_pool_in as i32,
                                          tr.stem.w_pool_in as i32, stream.0);
        }
        // ReLU mask of c1 via q1
        let qv1 = sc.f32(S_T3, n1);
        unsafe { launch_dequant_i8_f32(tr.stem.q1.as_i8(), n1 as i64, 1.0, qv1, stream.0) };
        let dyc1 = DevBuf::new(n1 * 4);
        unsafe { launch_mask_relu_bwd(qv1 as *const f32, dpre.as_f32(), n1 as i64, dyc1.as_f32_mut(), stream.0) };
        let gvc0 = self.c1.backward(dyc1.as_f32(), &tr.stem.c1, stream, sc);
        let n0 = b * self.c0.out_c * tr.stem.h_pool_in * tr.stem.w_pool_in;
        let qv0 = sc.f32(S_T3, n0);
        unsafe { launch_dequant_i8_f32(tr.stem.q0.as_i8(), n0 as i64, 1.0, qv0, stream.0) };
        let dyc0 = DevBuf::new(n0 * 4);
        unsafe { launch_mask_relu_bwd(qv0 as *const f32, gvc0.as_f32(), n0 as i64, dyc0.as_f32_mut(), stream.0) };
        let _ = self.c0.backward(dyc0.as_f32(), &tr.stem.c0, stream, sc);
    }

    /// Hook running-stat updates (call right after forward with the trace).
    pub fn update_running_stats(&mut self, tr: &NetTrace) {
        let order: Vec<(Vec<f32>, Vec<f32>)> = {
            let mut v = vec![(tr.stem.c0.mean_h.clone(), tr.stem.c0.var_h.clone()), (tr.stem.c1.mean_h.clone(), tr.stem.c1.var_h.clone())];
            for bt in &tr.blocks {
                if let Some(d) = &bt.ds {
                    v.push((d.mean_h.clone(), d.var_h.clone()));
                }
                v.push((bt.c1.mean_h.clone(), bt.c1.var_h.clone()));
                v.push((bt.c2.mean_h.clone(), bt.c2.var_h.clone()));
            }
            v.push((tr.out.c0.mean_h.clone(), tr.out.c0.var_h.clone()));
            v.push((tr.out.c1.mean_h.clone(), tr.out.c1.var_h.clone()));
            v
        };
        for (c, (m, vv)) in self.convs_mut().into_iter().zip(order.into_iter()) {
            c.bn.update_running(&m, &vv);
        }
    }
}
