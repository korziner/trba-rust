//! # MoPE — Mixture of Pretrained Experts
//!
//! Отдельная реализация, не трогающая существующую модель: TRBA остаётся
//! «экспертом», а MoPE добавляет поверх него роутер, агрегатор и harness
//! test-time compute. Заимствования из технического отчёта ZAYA1-8B
//! (arXiv:2605.05365, Zyphra, май 2026) помечены номерами уравнений и разделов.
//!
//! ## Соответствие понятий
//!
//! | ZAYA1-8B | MoPE для распознавания рукописей |
//! |---|---|
//! | токен последовательности | кроп строки (единица маршрутизации) |
//! | эксперт = FFN внутри слоя | эксперт = **целая предобученная TRBA-модель** (чекпоинт), специализация — писарь/тип письма |
//! | 16 экспертов на слой, top-1 | E = 2…256 экспертов, top-k (по умолчанию 1) |
//! | residual stream `x_l` | пул признаков CNN строки (mean ⊕ max по времени) |
//! | SFT/RL на aggregation-промптах | стадия обучения агрегатора на перетасованных роллаутах экспертов |
//! | H(p)/ln E — энтропия загрузки | та же метрика в логах балансировки |
//!
//! ## Что перенесено из отчёта
//!
//! * **ZAYA1 router** (§II-A2, ур. 1–4): даун-проекция residual stream в
//!   латентное пространство `R = 256`, **EDA** (Exponential Depth Averaging,
//!   `r_l = r_l + γ·r_{l−1}`), RMSNorm, **трёхслойный MLP с GeLU** → softmax →
//!   `topk(s_l + b_l)`. В отчёте k = 1 и residual-эксперта нет.
//! * **PID bias balancing** (§II-A2, ур. 5): aux-loss-free балансировка, где
//!   «PID-оптимизатор» внутри работает как AdamW, а сигнал ошибки —
//!   `∇b_e = p_e − 1/E` (доля токенов, ушедших эксперту e, минус равномерная
//!   доля). Перегруженные эксперты штрафуются, недогруженные поднимаются.
//! * **Learned residual scaling** (§II-A3, ур. 6): `Res-scale(x) = α·x + β`
//!   с отдельными α/β для residual-потока и для выхода слоя, инициализация
//!   α = 1, β = 0 (то есть старт — обычное остаточное соединение).
//! * **CCA — Compressed Convolutional Attention** (§II-A1): смешивание
//!   последовательности в сжатом латентном пространстве лёгким свёрточным
//!   даунпроектором; сжатие запросов **2×**, сжатие KV **8×**.
//! * **Markovian RSA** (§VI): N кандидатов параллельно, у каждого ограниченная
//!   длина декодирования β; в раунде t ≥ 1 равномерно случайно берутся C ≤ N
//!   хвостов длиной τ из предыдущей популяции, склеиваются в aggregation
//!   prompt, и модель выдаёт одно улучшенное решение; вперёд передаются только
//!   последние τ токенов каждой цепочки, поэтому контекст агрегации ≤ C·τ
//!   независимо от полной длины рассуждений; всего T раундов. Штатная
//!   конфигурация (N, C, T) = (16, 4, 2), τ ≤ β/2. Частные случаи: T = 0 —
//!   обычный параллельный сэмплинг, C = 1 — продолжение одной цепочки,
//!   τ = β — полная RSA без сжатия хвостов.
//!
//! ## Чего в отчёте нет и что добавлено здесь
//!
//! Отчёт не раскрывает точную структуру CCA (она в Appendix C и в отдельной
//! работе Figliolia et al., 2025), поэтому `Cca` ниже — реализация по описанию
//! §II-A1: неперекрывающийся conv1d-даунпроектор (kernel = stride) и
//! одноканальное внимание между сжатыми запросами и сжатыми KV. Числа сжатия
//! (2× и 8×) и место в блоке — из отчёта; остальное — адаптация под OCR.
//!
//! Эксперты — целые модели, поэтому «слой MoE» здесь один, и EDA вырождается
//! в `γ·r_prev` с нулём по умолчанию. Смысл сохраняется для многошкального
//! роутинга: `RouterMlp::scores_stages` принимает несколько представлений
//! (например, признаки целой строки и признаки её сегментов) и связывает их
//! через γ ровно так, как ур. (2) связывает слои.

use rand::Rng;

/// Диапазон числа экспертов, который обязан поддерживать MoPE.
pub const MIN_EXPERTS: usize = 2;
pub const MAX_EXPERTS: usize = 256;
/// Латентная размерность роутера ZAYA1-8B (Table I: «Router latent dimension 256»).
pub const ROUTER_LATENT: usize = 256;
pub const RMS_EPS: f32 = 1e-6;
/// Штатные (N, C, T) из §VI.
pub const RSA_N_DEFAULT: usize = 16;
pub const RSA_C_DEFAULT: usize = 4;
pub const RSA_T_DEFAULT: usize = 2;

// ------------------------------------------------------------- утилиты -----

pub fn softmax(x: &[f32]) -> Vec<f32> {
    let m = x.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
    let e: Vec<f32> = x.iter().map(|&v| (v - m).exp()).collect();
    let s: f32 = e.iter().sum();
    if s == 0.0 {
        return vec![1.0 / x.len() as f32; x.len()];
    }
    e.iter().map(|&v| v / s).collect()
}

pub fn log_softmax(x: &[f32]) -> Vec<f32> {
    let m = x.iter().cloned().fold(f32::NEG_INFINITY, f32::max);
    let mut s = 0.0f32;
    for &v in x {
        s += (v - m).exp();
    }
    x.iter().map(|&v| v - m - s.ln()).collect()
}

/// GeLU (tanh-аппроксимация) и её производная.
pub fn gelu(x: f32) -> f32 {
    const K: f32 = 0.797_884_56; // sqrt(2/pi)
    0.5 * x * (1.0 + (K * (x + 0.044_715 * x * x * x)).tanh())
}

pub fn gelu_grad(x: f32) -> f32 {
    const K: f32 = 0.797_884_56;
    let u = K * (x + 0.044_715 * x * x * x);
    let t = u.tanh();
    let du = K * (1.0 + 3.0 * 0.044_715 * x * x);
    0.5 * (1.0 + t) + 0.5 * x * (1.0 - t * t) * du
}

/// RMSNorm без обучаемого усиления, как в ур. (3): `MLP(RMSnorm(r))`.
pub fn rms_norm(x: &[f32]) -> Vec<f32> {
    let n = x.len().max(1) as f32;
    let ms = x.iter().map(|&v| v * v).sum::<f32>() / n;
    let r = (ms + RMS_EPS).sqrt();
    x.iter().map(|&v| v / r).collect()
}

/// Нормированная энтропия загрузки экспертов H(p)/ln E — метрика
/// сбалансированности из Fig. 4 отчёта. 1.0 — равномерная загрузка.
pub fn load_entropy_norm(loads: &[f64]) -> f64 {
    let e = loads.len();
    if e < 2 {
        return 1.0;
    }
    let total: f64 = loads.iter().sum();
    if total <= 0.0 {
        return 0.0;
    }
    let mut h = 0.0f64;
    for &c in loads {
        let p = c / total;
        if p > 0.0 {
            h -= p * p.ln();
        }
    }
    h / (e as f64).ln()
}

/// `y[r, o] = Σ_k x[r, k]·w[o, k] + b[o]` — строковый major, как хранит
/// `LinearF` в trba-rust (`w[o·inp + k]`).
fn lin(x: &[f32], rows: usize, inp: usize, w: &[f32], b: Option<&[f32]>, out: usize) -> Vec<f32> {
    let mut y = vec![0.0f32; rows * out];
    for r in 0..rows {
        let xr = &x[r * inp..(r + 1) * inp];
        for o in 0..out {
            let wr = &w[o * inp..(o + 1) * inp];
            let mut s = b.map_or(0.0, |bb| bb[o]);
            for k in 0..inp {
                s += xr[k] * wr[k];
            }
            y[r * out + o] = s;
        }
    }
    y
}

/// Обратный ход `lin`: возвращает (dx, dw, db).
fn lin_bwd(
    dy: &[f32],
    x: &[f32],
    rows: usize,
    inp: usize,
    w: &[f32],
    out: usize,
) -> (Vec<f32>, Vec<f32>, Vec<f32>) {
    let mut dx = vec![0.0f32; rows * inp];
    let mut dw = vec![0.0f32; out * inp];
    let mut db = vec![0.0f32; out];
    for r in 0..rows {
        for o in 0..out {
            let g = dy[r * out + o];
            if g == 0.0 {
                continue;
            }
            db[o] += g;
            let xr = &x[r * inp..(r + 1) * inp];
            let wr = &w[o * inp..(o + 1) * inp];
            for k in 0..inp {
                dw[o * inp + k] += g * xr[k];
                dx[r * inp + k] += g * wr[k];
            }
        }
    }
    (dx, dw, db)
}

// --------------------------------------- (6) learned residual scaling -----

/// `Res-scale(x) = α·x + β` (ур. 6), по каналам. α = 1, β = 0 на старте —
/// то есть изначально это обычное остаточное соединение. Отчёт применяет два
/// таких блока: один к residual-потоку, другой к выходу слоя.
pub struct ResidualScaling {
    pub d: usize,
    pub alpha: Vec<f32>,
    pub beta: Vec<f32>,
    pub g_alpha: Vec<f32>,
    pub g_beta: Vec<f32>,
}

impl ResidualScaling {
    pub fn new(d: usize) -> Self {
        Self { d, alpha: vec![1.0; d], beta: vec![0.0; d], g_alpha: vec![0.0; d], g_beta: vec![0.0; d] }
    }
    pub fn zero_grad(&mut self) {
        self.g_alpha.iter_mut().for_each(|v| *v = 0.0);
        self.g_beta.iter_mut().for_each(|v| *v = 0.0);
    }
    /// `x` — [rows, d]; α/β применяются по последнему измерению.
    pub fn forward(&self, x: &[f32], rows: usize) -> Vec<f32> {
        let mut y = vec![0.0f32; rows * self.d];
        for r in 0..rows {
            for c in 0..self.d {
                y[r * self.d + c] = self.alpha[c] * x[r * self.d + c] + self.beta[c];
            }
        }
        y
    }
    /// Возвращает dx и накапливает dα/dβ.
    pub fn backward(&mut self, dy: &[f32], x: &[f32], rows: usize) -> Vec<f32> {
        let mut dx = vec![0.0f32; rows * self.d];
        for r in 0..rows {
            for c in 0..self.d {
                let g = dy[r * self.d + c];
                self.g_alpha[c] += g * x[r * self.d + c];
                self.g_beta[c] += g;
                dx[r * self.d + c] = g * self.alpha[c];
            }
        }
        dx
    }
    pub fn params(&self) -> usize {
        2 * self.d
    }
}

// ----------------------------------------------- CCA: свёрточный даунпроектор --

/// Неперекрывающийся conv1d (kernel = stride): «лёгкий свёрточный
/// даунпроектор» из §II-A1. Неперекрываемость делает его обычным линейным
/// отображением окна `[stride·d_in] → d_out`, поэтому и обратный ход точный и
/// дешёвый. Хвост последовательности, не попавший в полное окно, отбрасывается.
pub struct ConvDown {
    pub d_in: usize,
    pub d_out: usize,
    pub stride: usize,
    pub w: Vec<f32>, // [d_out, stride, d_in]
    pub b: Vec<f32>,
    pub g_w: Vec<f32>,
    pub g_b: Vec<f32>,
}

impl ConvDown {
    pub fn new(d_in: usize, d_out: usize, stride: usize) -> Self {
        let fan = (stride * d_in) as f32;
        let lim = (6.0 / (fan + d_out as f32)).sqrt();
        let mut rng = rand::thread_rng();
        Self {
            d_in,
            d_out,
            stride,
            w: (0..d_out * stride * d_in).map(|_| rng.gen_range(-lim..lim)).collect(),
            b: vec![0.0; d_out],
            g_w: vec![0.0; d_out * stride * d_in],
            g_b: vec![0.0; d_out],
        }
    }
    pub fn out_len(&self, len: usize) -> usize {
        len / self.stride
    }
    pub fn zero_grad(&mut self) {
        self.g_w.iter_mut().for_each(|v| *v = 0.0);
        self.g_b.iter_mut().for_each(|v| *v = 0.0);
    }
    /// `x` — [len, d_in] → [len/stride, d_out]
    pub fn forward(&self, x: &[f32], len: usize) -> Vec<f32> {
        let p = self.out_len(len);
        let win = self.stride * self.d_in;
        // p·win <= len по построению (win = stride·d_in, p = len/stride),
        // поэтому окна берутся напрямую, без дополнения.
        let flat = &x[..p * win];
        // w хранится как [d_out, stride, d_in] = [d_out, win] — та же раскладка
        lin(flat, p, win, &self.w, Some(&self.b), self.d_out)
    }
    pub fn backward(&mut self, dy: &[f32], x: &[f32], len: usize) -> Vec<f32> {
        let p = self.out_len(len);
        let win = self.stride * self.d_in;
        let mut flat = vec![0.0f32; p * win];
        for i in 0..p {
            flat[i * win..(i + 1) * win].copy_from_slice(&x[i * win..(i + 1) * win]);
        }
        let (dflat, dw, db) = lin_bwd(dy, &flat, p, win, &self.w, self.d_out);
        for i in 0..self.g_w.len() {
            self.g_w[i] += dw[i];
        }
        for i in 0..self.g_b.len() {
            self.g_b[i] += db[i];
        }
        let mut dx = vec![0.0f32; len * self.d_in];
        dx[..p * win].copy_from_slice(&dflat);
        dx
    }
    pub fn params(&self) -> usize {
        self.w.len() + self.b.len()
    }
}

// ------------------------------------------------------- CCA (§II-A1) ------

pub struct CcaTrace {
    pub qc: Vec<f32>,   // [lq2, d_q]
    pub kvc: Vec<f32>,  // [lkv8, d_kv]
    pub q: Vec<f32>,    // [lq2, d_a]
    pub k: Vec<f32>,    // [lkv8, d_a]
    pub v: Vec<f32>,    // [lkv8, d_a]
    pub att: Vec<f32>,  // [lq2, lkv8]
    pub z: Vec<f32>,    // [lq2, d_a]
    pub lq2: usize,
    pub lkv8: usize,
}

/// Compressed Convolutional Attention: запросы сжимаются conv1d с шагом
/// `q_stride` (2×), ключи и значения — с шагом `kv_stride` (8×), внимание
/// считается уже в сжатом пространстве. Это ровно то, за счёт чего CCA
/// уменьшает FLOPs prefill и размер KV-кэша (§II-A1, Table I).
pub struct Cca {
    pub q_conv: ConvDown,
    pub kv_conv: ConvDown,
    pub wq: Vec<f32>, // [d_a, d_q]
    pub wk: Vec<f32>, // [d_a, d_kv]
    pub wv: Vec<f32>, // [d_a, d_kv]
    pub wo: Vec<f32>, // [d_out, d_a]
    pub bo: Vec<f32>,
    pub g_wq: Vec<f32>,
    pub g_wk: Vec<f32>,
    pub g_wv: Vec<f32>,
    pub g_wo: Vec<f32>,
    pub g_bo: Vec<f32>,
    pub d_a: usize,
    pub d_out: usize,
}

impl Cca {
    pub fn new(d_q_in: usize, d_kv_in: usize, d_a: usize, d_out: usize, q_stride: usize, kv_stride: usize) -> Self {
        let mut rng = rand::thread_rng();
        let lim = |fan: usize| (6.0 / (fan * 2) as f32).sqrt();
        Self {
            q_conv: ConvDown::new(d_q_in, d_a, q_stride),
            kv_conv: ConvDown::new(d_kv_in, d_a, kv_stride),
            wq: (0..d_a * d_a).map(|_| rng.gen_range(-lim(d_a)..lim(d_a))).collect(),
            wk: (0..d_a * d_a).map(|_| rng.gen_range(-lim(d_a)..lim(d_a))).collect(),
            wv: (0..d_a * d_a).map(|_| rng.gen_range(-lim(d_a)..lim(d_a))).collect(),
            wo: (0..d_out * d_a).map(|_| rng.gen_range(-lim(d_a)..lim(d_out))).collect(),
            bo: vec![0.0; d_out],
            g_wq: vec![0.0; d_a * d_a],
            g_wk: vec![0.0; d_a * d_a],
            g_wv: vec![0.0; d_a * d_a],
            g_wo: vec![0.0; d_out * d_a],
            g_bo: vec![0.0; d_out],
            d_a,
            d_out,
        }
    }
    pub fn zero_grad(&mut self) {
        self.q_conv.zero_grad();
        self.kv_conv.zero_grad();
        for v in [&mut self.g_wq, &mut self.g_wk, &mut self.g_wv, &mut self.g_wo, &mut self.g_bo] {
            v.iter_mut().for_each(|x| *x = 0.0);
        }
    }
    /// `q_seq` — [lq, d_q_in] (например, эмбеддинги хвостов кандидатов),
    /// `kv_seq` — [lkv, d_kv_in] (например, признаки изображения).
    /// Возвращает [lq/2, d_out] и трейс для обратного хода.
    pub fn forward(&self, q_seq: &[f32], lq: usize, kv_seq: &[f32], lkv: usize) -> (Vec<f32>, CcaTrace) {
        let qc = self.q_conv.forward(q_seq, lq);
        let kvc = self.kv_conv.forward(kv_seq, lkv);
        let lq2 = self.q_conv.out_len(lq);
        let lkv8 = self.kv_conv.out_len(lkv);
        let q = lin(&qc, lq2, self.q_conv.d_out, &self.wq, None, self.d_a);
        let k = lin(&kvc, lkv8, self.kv_conv.d_out, &self.wk, None, self.d_a);
        let v = lin(&kvc, lkv8, self.kv_conv.d_out, &self.wv, None, self.d_a);
        let scale = 1.0 / (self.d_a as f32).sqrt();
        let mut att = vec![0.0f32; lq2 * lkv8];
        for i in 0..lq2 {
            let mut row = vec![0.0f32; lkv8];
            for j in 0..lkv8 {
                let mut s = 0.0f32;
                for a in 0..self.d_a {
                    s += q[i * self.d_a + a] * k[j * self.d_a + a];
                }
                row[j] = s * scale;
            }
            let p = softmax(&row);
            att[i * lkv8..(i + 1) * lkv8].copy_from_slice(&p);
        }
        let mut z = vec![0.0f32; lq2 * self.d_a];
        for i in 0..lq2 {
            for j in 0..lkv8 {
                let a = att[i * lkv8 + j];
                if a == 0.0 {
                    continue;
                }
                for c in 0..self.d_a {
                    z[i * self.d_a + c] += a * v[j * self.d_a + c];
                }
            }
        }
        let out = lin(&z, lq2, self.d_a, &self.wo, Some(&self.bo), self.d_out);
        (out, CcaTrace { qc, kvc, q, k, v, att, z, lq2, lkv8 })
    }

    /// `dy` — [lq2, d_out]; возвращает (d_q_seq, d_kv_seq).
    pub fn backward(&mut self, dy: &[f32], q_seq: &[f32], lq: usize, kv_seq: &[f32], lkv: usize, tr: &CcaTrace) -> (Vec<f32>, Vec<f32>) {
        let (lq2, lkv8, da) = (tr.lq2, tr.lkv8, self.d_a);
        let (dz, dwo, dbo) = lin_bwd(dy, &tr.z, lq2, da, &self.wo, self.d_out);
        for i in 0..self.g_wo.len() {
            self.g_wo[i] += dwo[i];
        }
        for i in 0..self.g_bo.len() {
            self.g_bo[i] += dbo[i];
        }
        // z = att · v
        let mut datt = vec![0.0f32; lq2 * lkv8];
        let mut dv = vec![0.0f32; lkv8 * da];
        for i in 0..lq2 {
            for j in 0..lkv8 {
                let mut s = 0.0f32;
                for c in 0..da {
                    s += dz[i * da + c] * tr.v[j * da + c];
                    dv[j * da + c] += tr.att[i * lkv8 + j] * dz[i * da + c];
                }
                datt[i * lkv8 + j] = s;
            }
        }
        // softmax backward по строкам att
        let mut dlogits = vec![0.0f32; lq2 * lkv8];
        for i in 0..lq2 {
            let row = &tr.att[i * lkv8..(i + 1) * lkv8];
            let grow = &datt[i * lkv8..(i + 1) * lkv8];
            let dot: f32 = row.iter().zip(grow.iter()).map(|(p, g)| p * g).sum();
            for j in 0..lkv8 {
                dlogits[i * lkv8 + j] = row[j] * (grow[j] - dot);
            }
        }
        let scale = 1.0 / (da as f32).sqrt();
        let mut dq = vec![0.0f32; lq2 * da];
        let mut dk = vec![0.0f32; lkv8 * da];
        for i in 0..lq2 {
            for j in 0..lkv8 {
                let g = dlogits[i * lkv8 + j] * scale;
                if g == 0.0 {
                    continue;
                }
                for c in 0..da {
                    dq[i * da + c] += g * tr.k[j * da + c];
                    dk[j * da + c] += g * tr.q[i * da + c];
                }
            }
        }
        let (dqc, dwq, _) = lin_bwd(&dq, &tr.qc, lq2, self.q_conv.d_out, &self.wq, da);
        let (dkv_k, dwk, _) = lin_bwd(&dk, &tr.kvc, lkv8, self.kv_conv.d_out, &self.wk, da);
        let (dkv_v, dwv, _) = lin_bwd(&dv, &tr.kvc, lkv8, self.kv_conv.d_out, &self.wv, da);
        for i in 0..self.g_wq.len() {
            self.g_wq[i] += dwq[i];
        }
        for i in 0..self.g_wk.len() {
            self.g_wk[i] += dwk[i];
            self.g_wv[i] += dwv[i];
        }
        let mut dkvc = vec![0.0f32; lkv8 * self.kv_conv.d_out];
        for i in 0..dkvc.len() {
            dkvc[i] = dkv_k[i] + dkv_v[i];
        }
        let dq_seq = self.q_conv.backward(&dqc, q_seq, lq);
        let dkv_seq = self.kv_conv.backward(&dkvc, kv_seq, lkv);
        (dq_seq, dkv_seq)
    }
    pub fn params(&self) -> usize {
        self.q_conv.params() + self.kv_conv.params() + self.wq.len() + self.wk.len() + self.wv.len() + self.wo.len() + self.bo.len()
    }
}

// ------------------------------------------- (1)-(4) роутер ZAYA1 ----------

pub struct RouterTrace {
    /// [rows, R] после даун-проекции и EDA
    pub r: Vec<f32>,
    /// [rows, R] после RMSNorm
    pub n: Vec<f32>,
    /// pre-активации трёх слоёв MLP: [rows, R], [rows, R], [rows, E]
    pub pre: [Vec<f32>; 3],
    /// активации после GeLU первых двух слоёв
    pub act: [Vec<f32>; 2],
    /// [rows, E] — softmax (уравнение 3)
    pub s: Vec<f32>,
    pub rows: usize,
}

/// MLP-роутер из §II-A2: даун-проекция (1), EDA (2), RMSNorm + трёхслойный
/// MLP с GeLU + softmax (3), выбор экспертов по `topk(s + b)` (4).
pub struct RouterMlp {
    pub d_in: usize,
    pub r: usize,
    pub e: usize,
    pub w_down: Vec<f32>, // [R, D]
    pub gamma: f32,       // EDA
    pub mw: [Vec<f32>; 3],
    pub mb: [Vec<f32>; 3],
    /// `b_l` из уравнения (4): обучается НЕ основным лоссом, а правилом (5)
    pub bias: Vec<f32>,
    pub g_w_down: Vec<f32>,
    pub g_gamma: f32,
    pub g_mw: [Vec<f32>; 3],
    pub g_mb: [Vec<f32>; 3],
}

impl RouterMlp {
    pub fn new(d_in: usize, r: usize, e: usize) -> Self {
        let mut rng = rand::thread_rng();
        let lim = |fan_in: usize, fan_out: usize| (6.0 / (fan_in + fan_out) as f32).sqrt();
        Self {
            d_in,
            r,
            e,
            w_down: (0..r * d_in).map(|_| rng.gen_range(-lim(d_in, r)..lim(d_in, r))).collect(),
            gamma: 0.0, // EDA: на старте предыдущее представление не примешивается
            mw: [
                (0..r * r).map(|_| rng.gen_range(-lim(r, r)..lim(r, r))).collect(),
                (0..r * r).map(|_| rng.gen_range(-lim(r, r)..lim(r, r))).collect(),
                (0..e * r).map(|_| rng.gen_range(-lim(r, e)..lim(r, e))).collect(),
            ],
            mb: [vec![0.0; r], vec![0.0; r], vec![0.0; e]],
            bias: vec![0.0; e],
            g_w_down: vec![0.0; r * d_in],
            g_gamma: 0.0,
            g_mw: [vec![0.0; r * r], vec![0.0; r * r], vec![0.0; e * r]],
            g_mb: [vec![0.0; r], vec![0.0; r], vec![0.0; e]],
        }
    }

    pub fn zero_grad(&mut self) {
        self.g_w_down.iter_mut().for_each(|v| *v = 0.0);
        self.g_gamma = 0.0;
        for i in 0..3 {
            self.g_mw[i].iter_mut().for_each(|v| *v = 0.0);
            self.g_mb[i].iter_mut().for_each(|v| *v = 0.0);
        }
    }

    /// (1)–(3). `r_prev` — представление предыдущего «слоя»/шкалы для EDA.
    pub fn forward(&self, x: &[f32], rows: usize, r_prev: Option<&[f32]>) -> RouterTrace {
        // (1) r = W_down · x
        let mut r = lin(x, rows, self.d_in, &self.w_down, None, self.r);
        // (2) r = r + γ·r_prev
        if let Some(p) = r_prev {
            for i in 0..rows * self.r {
                r[i] += self.gamma * p[i];
            }
        }
        // (3) s = softmax(MLP(RMSNorm(r)))
        let mut n = vec![0.0f32; rows * self.r];
        for i in 0..rows {
            let row = &r[i * self.r..(i + 1) * self.r];
            n[i * self.r..(i + 1) * self.r].copy_from_slice(&rms_norm(row));
        }
        let pre0 = lin(&n, rows, self.r, &self.mw[0], Some(&self.mb[0]), self.r);
        let act0: Vec<f32> = pre0.iter().map(|&v| gelu(v)).collect();
        let pre1 = lin(&act0, rows, self.r, &self.mw[1], Some(&self.mb[1]), self.r);
        let act1: Vec<f32> = pre1.iter().map(|&v| gelu(v)).collect();
        let pre2 = lin(&act1, rows, self.r, &self.mw[2], Some(&self.mb[2]), self.e);
        let mut s = vec![0.0f32; rows * self.e];
        for i in 0..rows {
            let row = &pre2[i * self.e..(i + 1) * self.e];
            s[i * self.e..(i + 1) * self.e].copy_from_slice(&softmax(row));
        }
        RouterTrace { r, n, pre: [pre0, pre1, pre2], act: [act0, act1], s, rows }
    }

    /// (4) `topk(s + b)`. При k = 1 это argmax_e(s_e + b_e) — как в ZAYA1-8B.
    pub fn select(&self, s_row: &[f32], k: usize) -> Vec<usize> {
        let mut scored: Vec<(usize, f32)> =
            s_row.iter().enumerate().map(|(i, &v)| (i, v + self.bias[i])).collect();
        scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        scored.into_iter().take(k.min(self.e)).map(|(i, _)| i).collect()
    }

    /// Перекрёстная энтропия с мягкими целями [rows, E] и обратный ход.
    /// Возвращает средний лосс. Цели — это «сигнал от всех моделей»: см.
    /// `targets_from_losses` / `targets_from_rsa`.
    pub fn backward(&mut self, tr: &RouterTrace, x: &[f32], r_prev: Option<&[f32]>, targets: &[f32]) -> f32 {
        let (rows, r, e) = (tr.rows, self.r, self.e);
        let mut loss = 0.0f32;
        // d_pre2 = s − target (градиент CE через softmax); лосс — по log_softmax
        // Лосс — СРЕДНИЙ по строкам, поэтому и градиент softmax-CE делится на
        // rows: d = (s − target)/rows. Без этого деления градиенты были бы в
        // rows раз больше лосса (ровно это и ловит конечно-разностный тест).
        let inv_rows = 1.0f32 / rows.max(1) as f32;
        let mut d = vec![0.0f32; rows * e];
        for i in 0..rows {
            let pre = &tr.pre[2][i * e..(i + 1) * e];
            let ls = log_softmax(pre);
            for c in 0..e {
                let t = targets[i * e + c];
                loss -= t * ls[c] * inv_rows;
                d[i * e + c] = (tr.s[i * e + c] - t) * inv_rows;
            }
        }
        // слой 3
        let (dact1, dw2, db2) = lin_bwd(&d, &tr.act[1], rows, r, &self.mw[2], e);
        // GeLU'
        let mut dpre1 = vec![0.0f32; rows * r];
        for i in 0..rows * r {
            dpre1[i] = dact1[i] * gelu_grad(tr.pre[1][i]);
        }
        let (dact0, dw1, db1) = lin_bwd(&dpre1, &tr.act[0], rows, r, &self.mw[1], r);
        let mut dpre0 = vec![0.0f32; rows * r];
        for i in 0..rows * r {
            dpre0[i] = dact0[i] * gelu_grad(tr.pre[0][i]);
        }
        let (dn, dw0, db0) = lin_bwd(&dpre0, &tr.n, rows, r, &self.mw[0], r);
        // RMSNorm backward по строкам
        let mut dr = vec![0.0f32; rows * r];
        for i in 0..rows {
            let nr = &tr.n[i * r..(i + 1) * r];
            let gr = &dn[i * r..(i + 1) * r];
            let dot: f32 = nr.iter().zip(gr.iter()).map(|(a, b)| a * b).sum::<f32>() / r as f32;
            let ms = nr.iter().map(|&v| v * v).sum::<f32>() / r as f32;
            // n = r/R, R = sqrt(ms_r + eps); выражаем 1/R через |n|:
            // ms_n = ms_r/(ms_r+eps) => 1/R = sqrt(ms_n)/|r|_rms — проще напрямую
            let rr = &tr.r[i * r..(i + 1) * r];
            let msr = rr.iter().map(|&v| v * v).sum::<f32>() / r as f32;
            let inv = 1.0 / (msr + RMS_EPS).sqrt();
            let _ = ms;
            for c in 0..r {
                dr[i * r + c] = inv * (gr[c] - nr[c] * dot);
            }
        }
        // (2) EDA
        if let Some(p) = r_prev {
            for i in 0..rows * r {
                self.g_gamma += dr[i] * p[i];
            }
        }
        // (1) даун-проекция
        let (_dx, dwd, _dbd) = lin_bwd(&dr, x, rows, self.d_in, &self.w_down, r);
        for i in 0..self.g_w_down.len() {
            self.g_w_down[i] += dwd[i];
        }
        for (g, dw) in self.g_mw.iter_mut().zip([dw0, dw1, dw2].into_iter()) {
            for i in 0..g.len() {
                g[i] += dw[i];
            }
        }
        for (g, db) in self.g_mb.iter_mut().zip([db0, db1, db2].into_iter()) {
            for i in 0..g.len() {
                g[i] += db[i];
            }
        }
        loss
    }

    pub fn params(&self) -> usize {
        self.w_down.len() + self.mw.iter().map(|v| v.len()).sum::<usize>() + self.mb.iter().map(|v| v.len()).sum::<usize>() + self.e + 1
    }
}

/// Правило (5): `∇b_e = p_e − 1/E`, где p_e — фактическая доля примеров,
/// ушедших эксперту e в текущем батче. Отчёт описывает это как PID-регулятор,
/// внутри которого работает AdamW, поэтому шаг — AdamW с decoupled weight decay.
pub struct PidBias {
    pub m: Vec<f64>,
    pub v: Vec<f64>,
    pub t: u64,
    pub b1: f64,
    pub b2: f64,
    pub eps: f64,
}

impl PidBias {
    pub fn new(e: usize) -> Self {
        Self { m: vec![0.0; e], v: vec![0.0; e], t: 0, b1: 0.9, b2: 0.999, eps: 1e-8 }
    }
    /// `loads[e]` — сколько примеров батча отправлено эксперту e.
    pub fn step(&mut self, bias: &mut [f32], loads: &[f64], lr: f64, wd: f64) {
        let e = bias.len();
        let total: f64 = loads.iter().sum();
        if total <= 0.0 || e == 0 {
            return;
        }
        self.t += 1;
        let bc1 = 1.0 - self.b1.powi(self.t as i32);
        let bc2 = 1.0 - self.b2.powi(self.t as i32);
        for i in 0..e {
            let p = loads[i] / total;
            let grad = p - 1.0 / e as f64; // уравнение (5)
            self.m[i] = self.b1 * self.m[i] + (1.0 - self.b1) * grad;
            self.v[i] = self.b2 * self.v[i] + (1.0 - self.b2) * grad * grad;
            let mh = self.m[i] / bc1;
            let vh = self.v[i] / bc2;
            let step = lr * mh / (vh.sqrt() + self.eps);
            bias[i] = (bias[i] as f64 - step - lr * wd * bias[i] as f64) as f32;
        }
    }
}

// ------------------------------------- эксперты: int8-хранилище и LRU ------

/// Целая предобученная модель в int8: пользовательский сценарий — «разные
/// люди учат на своих датасетах, одна модель = один писарь». Резидентное
/// хранение int8 в 4 раза дешевле fp32, поэтому в VRAM держат только горячие
/// эксперты (`LruStore`), остальные ждут в памяти хоста/на диске.
pub struct ExpertBlob {
    pub name: String,
    pub lens: Vec<usize>,
    pub scales: Vec<f32>,
    pub q: Vec<i8>,
    /// running_mean ‖ running_var всех свёрток (в порядке `convs_mut()`).
    /// В манифест обучаемых параметров BN-статистика не входит, а для
    /// инференса она обязательна, поэтому хранится рядом в fp32: на 28
    /// свёрток это ~100 КБ, то есть ~0.2 % от int8-веса эксперта.
    pub bn: Vec<f32>,
}

impl ExpertBlob {
    pub fn bytes(&self) -> usize {
        self.q.len() + 4 * (self.scales.len() + self.lens.len() + self.bn.len())
    }

    /// Деквантовать ОДИН тензор прямо в назначение. Полное
    /// `dequantize_expert` делает fp32-копию всех весов сразу (+180 МБ на
    /// пике для 45M-параметровой модели) — при сборке эксперта из int8-хранилища
    /// это лишнее: параметры всё равно копируются по одному.
    pub fn dequantize_one(&self, i: usize, dst: &mut [f32]) -> usize {
        let off: usize = self.lens.iter().take(i).sum();
        let n = self.lens.get(i).copied().unwrap_or(0).min(dst.len());
        let s = self.scales.get(i).copied().unwrap_or(1.0);
        for k in 0..n {
            dst[k] = self.q[off + k] as f32 * s;
        }
        n
    }

    /// Приписать BN-статистику (см. поле `bn`).
    pub fn with_bn(mut self, bn: Vec<f32>) -> Self {
        self.bn = bn;
        self
    }
    pub fn params(&self) -> usize {
        self.lens.iter().sum()
    }
}

/// Квантование с той же конвенцией, что и в QAT trba-rust: шкала на тензор
/// `max|w|/127`, округление от нуля, насыщение ±127.
pub fn quantize_expert(name: &str, tensors: &[&[f32]]) -> ExpertBlob {
    let mut lens = Vec::with_capacity(tensors.len());
    let mut scales = Vec::with_capacity(tensors.len());
    let mut q: Vec<i8> = Vec::new();
    for t in tensors {
        let amax = t.iter().fold(0.0f32, |a, &v| a.max(v.abs()));
        let s = if amax > 0.0 { amax / 127.0 } else { 1.0 };
        for &v in t.iter() {
            let r = (v / s).round();
            q.push(r.clamp(-127.0, 127.0) as i8);
        }
        lens.push(t.len());
        scales.push(s);
    }
    ExpertBlob { name: name.to_string(), lens, scales, q, bn: Vec::new() }
}

pub fn dequantize_expert(b: &ExpertBlob) -> Vec<Vec<f32>> {
    let mut out = Vec::with_capacity(b.lens.len());
    let mut off = 0usize;
    for (i, &n) in b.lens.iter().enumerate() {
        let s = b.scales[i];
        out.push(b.q[off..off + n].iter().map(|&v| v as f32 * s).collect());
        off += n;
    }
    out
}

/// Кэш горячих экспертов: `touch` возвращает вытесненного (если кэш полон).
pub struct LruStore {
    pub cap: usize,
    pub order: Vec<usize>, // order[0] — самый горячий
}

impl LruStore {
    pub fn new(cap: usize) -> Self {
        Self { cap: cap.max(1), order: Vec::new() }
    }
    pub fn touch(&mut self, i: usize) -> Option<usize> {
        if let Some(p) = self.order.iter().position(|&x| x == i) {
            self.order.remove(p);
        }
        self.order.insert(0, i);
        if self.order.len() > self.cap {
            self.order.pop()
        } else {
            None
        }
    }
    pub fn resident(&self) -> &[usize] {
        &self.order
    }
}

// -------------------------------------------------- Markovian RSA (§VI) ----

#[derive(Clone, Debug)]
pub struct RsaCfg {
    /// N — сколько кандидатов рождается в раунде 0
    pub n: usize,
    /// C — сколько хвостов берётся в aggregation prompt (C ≤ N)
    pub c: usize,
    /// T — число раундов агрегации (T = 0 ⇒ обычный Best-of-N)
    pub t_rounds: usize,
    /// β — ограниченная длина декодирования кандидата
    pub beta: usize,
    /// τ — длина передаваемого хвоста (τ ≤ β, штатно τ ≤ β/2)
    pub tau: usize,
    pub temperature: f32,
    pub top_p: f32,
}

impl Default for RsaCfg {
    fn default() -> Self {
        Self { n: RSA_N_DEFAULT, c: RSA_C_DEFAULT, t_rounds: RSA_T_DEFAULT, beta: 64, tau: 16, temperature: 1.0, top_p: 1.0 }
    }
}

impl RsaCfg {
    /// Инварианты из §VI: C ≤ N, 1 ≤ τ ≤ β, контекст агрегации ≤ C·τ.
    pub fn validate(&self) -> Result<(), String> {
        if self.n == 0 {
            return Err("N должен быть >= 1".into());
        }
        if self.c == 0 || self.c > self.n {
            return Err(format!("C должно быть в [1, N={}]", self.n));
        }
        if self.tau == 0 || self.tau > self.beta {
            return Err(format!("tau должно быть в [1, beta={}]", self.beta));
        }
        Ok(())
    }
    /// Главная гарантия метода: контекст агрегации ограничен C·τ и не зависит
    /// от полной длины рассуждений.
    pub fn context_bound(&self) -> usize {
        self.c * self.tau
    }
    pub fn warn_long_tail(&self) -> Option<String> {
        if self.tau * 2 > self.beta {
            Some(format!("tau={} больше beta/2={} — отчёт рекомендует tau <= beta/2", self.tau, self.beta / 2))
        } else {
            None
        }
    }
}

#[derive(Clone, Debug)]
pub struct Candidate {
    pub tokens: Vec<usize>,
    /// какой эксперт породил кандидата (для кредита роутеру)
    pub expert: usize,
    /// уверенность/скор агрегатора — для выбора финального ответа
    pub score: f32,
}

#[derive(Clone, Debug)]
pub struct RsaRound {
    pub picks: Vec<usize>,
    pub prompt: Vec<usize>,
    pub out: Candidate,
}

#[derive(Clone, Debug)]
pub struct RsaTrace {
    pub round0: Vec<Candidate>,
    pub rounds: Vec<RsaRound>,
    /// финальный ответ: выход последнего раунда (или лучший из round0 при T = 0)
    pub best: Candidate,
    pub max_prompt: usize,
}

/// Хвост кандидата — последние τ токенов (именно они уходят в агрегацию).
pub fn tail_tokens(c: &Candidate, tau: usize) -> Vec<usize> {
    let n = c.tokens.len();
    if n <= tau {
        c.tokens.clone()
    } else {
        c.tokens[n - tau..].to_vec()
    }
}

/// Markovian RSA (алгоритм из §VI):
/// * раунд 0 — `generate(i)` для i = 0..N, параллельно, каждый кандидат
///   ограничен β токенами;
/// * раунды t ≥ 1 — равномерно случайно выбираются C различных индексов из
///   текущей популяции, их хвосты по τ токенов склеиваются в prompt длиной
///   ≤ C·τ, и `aggregate(prompt, round)` возвращает одного улучшенного
///   кандидата, который добавляется в популяцию;
/// * T = 0 вырождается в параллельный сэмплинг, где финальный ответ выбирает
///   внешний селектор (`best_by_score`).
pub fn markovian_rsa<G, A, R>(cfg: &RsaCfg, mut generate: G, mut aggregate: A, rng: &mut R) -> RsaTrace
where
    G: FnMut(usize) -> Candidate,
    A: FnMut(&[usize], usize) -> Candidate,
    R: Rng + ?Sized,
{
    let mut pop: Vec<Candidate> = (0..cfg.n).map(|i| generate(i)).collect();
    let mut rounds = Vec::with_capacity(cfg.t_rounds);
    let mut max_prompt = 0usize;
    for t in 1..=cfg.t_rounds {
        // C различных индексов равномерно из популяции
        let mut picks: Vec<usize> = Vec::with_capacity(cfg.c);
        while picks.len() < cfg.c.min(pop.len()) {
            let i = rng.gen_range(0..pop.len());
            if !picks.contains(&i) {
                picks.push(i);
            }
        }
        let mut prompt: Vec<usize> = Vec::with_capacity(cfg.context_bound());
        for &i in &picks {
            prompt.extend_from_slice(&tail_tokens(&pop[i], cfg.tau));
        }
        max_prompt = max_prompt.max(prompt.len());
        let out = aggregate(&prompt, t);
        pop.push(out.clone());
        rounds.push(RsaRound { picks, prompt, out });
    }
    let best = match rounds.last() {
        Some(r) => r.out.clone(),
        None => best_by_score(&pop),
    };
    RsaTrace { round0: pop.into_iter().take(cfg.n).collect(), rounds, best, max_prompt }
}

/// Best-of-N без агрегации: нужен внешний селектор (в отчёте — T = 0).
pub fn best_by_score(pop: &[Candidate]) -> Candidate {
    pop.iter()
        .max_by(|a, b| a.score.partial_cmp(&b.score).unwrap_or(std::cmp::Ordering::Equal))
        .cloned()
        .unwrap_or(Candidate { tokens: Vec::new(), expert: 0, score: 0.0 })
}

// ------------------------------- сигналы роутера: «от всех моделей лучшее» --

/// Мягкая цель: `softmax(−loss/T)` — чем лучше эксперт распознал пример, тем
/// больше веса. Это и есть «от всех моделей беря лучшее», превращённое в
/// обучающий сигнал роутера.
pub fn targets_from_losses(losses: &[f32], temperature: f32) -> Vec<f32> {
    let t = if temperature.abs() < 1e-6 { 1e-6 } else { temperature };
    let neg: Vec<f32> = losses.iter().map(|&l| -l / t).collect();
    softmax(&neg)
}

/// Жёсткая цель: one-hot лучшего эксперта.
/// CE эксперта с поправкой на символы, которых нет в его словаре.
///
/// Эксперт физически не может выдать символ, отсутствующий в его словаре, и при
/// teacher forcing такие символы выпадают из цели. Без поправки средний CE
/// считается по укороченной — а значит более лёгкой — последовательности, и
/// эксперт с меньшим словарём систематически выглядит лучше: оракул и роутер
/// выбирали бы того, кто знает МЕНЬШЕ. Для пары «base.mope (194 токена) +
/// kurrent.mope (97 токенов)» это не мелочь: у второго эксперта из цели
/// выпадает до трети символов.
///
/// Потерянный символ штрафуется как равномерное предсказание (`ln classes`), а
/// знаменатель возвращается к полному числу символов. Градиента поправка не
/// даёт (штраф от весов не зависит) — она влияет только на сравнение экспертов.
pub fn penalized_ce(mean_ce: f64, kept: usize, dropped: usize, classes: usize) -> f64 {
    if dropped == 0 || kept + dropped == 0 {
        return mean_ce;
    }
    let total = (kept + dropped) as f64;
    (mean_ce * kept as f64 + dropped as f64 * (classes.max(2) as f64).ln()) / total
}

pub fn targets_from_best(losses: &[f32]) -> Vec<f32> {
    let mut out = vec![0.0f32; losses.len()];
    if losses.is_empty() {
        return out;
    }
    let mut best = 0usize;
    for (i, &l) in losses.iter().enumerate() {
        if l < losses[best] {
            best = i;
        }
        let _ = i;
    }
    out[best] = 1.0;
    out
}

/// Кредит через агрегацию: эксперты, чьи кандидаты попали в aggregation
/// prompts и в финальный ответ, получают долю. Так роутер учится на сигналах
/// markovian-инференса, а не только на потерях отдельных экспертов.
pub fn targets_from_rsa(trace: &RsaTrace, e: usize, final_weight: f32) -> Vec<f32> {
    let mut acc = vec![0.0f64; e];
    let mut total = 0.0f64;
    for r in &trace.rounds {
        for &i in &r.picks {
            if let Some(c) = trace.round0.get(i) {
                if c.expert < e {
                    acc[c.expert] += 1.0;
                    total += 1.0;
                }
            }
        }
    }
    if trace.best.expert < e {
        acc[trace.best.expert] += final_weight as f64;
        total += final_weight as f64;
    }
    if total <= 0.0 {
        return vec![1.0 / e as f32; e];
    }
    acc.iter().map(|&v| (v / total) as f32).collect()
}

// ---------------------------------------------------- агрегатор (RSA) ------

pub struct AggTrace {
    /// [L, De] — эмбеддинги токенов aggregation prompt (токен + кандидат + позиция)
    pub emb: Vec<f32>,
    pub len: usize,
    pub cca: CcaTrace,
    /// [lq2, d_out] — выход CCA до residual scaling
    pub cca_out: Vec<f32>,
    pub lq2: usize,
    /// [d_out] — контекст агрегации после пула и обоих Res-scale
    pub ctx: Vec<f32>,
    pub pooled: Vec<f32>,
}

/// Агрегатор Markovian RSA: читает C хвостов по τ токенов и признаки
/// изображения, выдаёт один контекстный вектор, который подмешивается в память
/// декодера. Отчёт прямо говорит, что без обучения понимать такие промпты
/// схема не работает («training ZAYA1-8B to understand the Markovian-RSA
/// harness was important»), поэтому агрегатор обучаемый: у всех частей есть
/// обратный ход.
///
/// Устройство (по §II-A1/§II-A3):
/// * токены хвостов → эмбеддинг `tok + seg + pos` (seg — какой кандидат,
///   pos — позиция внутри хвоста), это «reshuffled rollouts» из SFT-стадии;
/// * **CCA**: запросы сжимаются conv1d с шагом 2 (τ·C/2 позиций), признаки
///   изображения — с шагом 8; внимание уже в сжатом пространстве;
/// * **learned residual scaling** (6): отдельные α/β для выхода CCA и для
///   residual-потока (пул сжатых запросов), сумма даёт контекст.
pub struct Aggregator {
    pub classes: usize,
    pub d_emb: usize,
    pub d_ctx: usize,
    pub max_c: usize,
    pub max_tau: usize,
    pub tok_emb: Vec<f32>,  // [V, De]
    pub seg_emb: Vec<f32>,  // [max_c, De]
    pub pos_emb: Vec<f32>,  // [max_tau, De]
    pub cca: Cca,
    pub res_out: ResidualScaling,
    pub res_res: ResidualScaling,
    pub g_tok_emb: Vec<f32>,
    pub g_seg_emb: Vec<f32>,
    pub g_pos_emb: Vec<f32>,
}

impl Aggregator {
    pub fn new(classes: usize, d_emb: usize, d_ctx: usize, d_feat: usize, max_c: usize, max_tau: usize) -> Self {
        let mut rng = rand::thread_rng();
        let lim = (6.0 / (classes + d_emb) as f32).sqrt();
        Self {
            classes,
            d_emb,
            d_ctx,
            max_c,
            max_tau,
            tok_emb: (0..classes * d_emb).map(|_| rng.gen_range(-lim..lim)).collect(),
            seg_emb: (0..max_c * d_emb).map(|_| rng.gen_range(-0.1..0.1)).collect(),
            pos_emb: (0..max_tau * d_emb).map(|_| rng.gen_range(-0.1..0.1)).collect(),
            // запросы — промпт (De), KV — признаки изображения (d_feat);
            // сжатие 2× и 8× как в Table I
            cca: Cca::new(d_emb, d_feat, d_emb, d_ctx, 2, 8),
            // ctx = res_res(pooled) + res_out(pooled), где pooled = mean(out):
            // обе ветви читают одно и то же, поэтому их α/β складываются. Если
            // обе инициализировать α=1 (как делает ResidualScaling::new),
            // инжектируемый контекст на старте равен 2·pooled, а не 1·pooled,
            // тогда как уравнение (6) предполагает тождественный старт α·x+β с
            // α=1, β=0. Вторая ветвь оставлена обучаемой поправкой с нулевым
            // стартом: формат контейнера и число обучаемых тензоров не меняются,
            // а уже сохранённые состояния сохраняют свои α/β.
            res_out: ResidualScaling {
                d: d_ctx,
                alpha: vec![0.0; d_ctx],
                beta: vec![0.0; d_ctx],
                g_alpha: vec![0.0; d_ctx],
                g_beta: vec![0.0; d_ctx],
            },
            res_res: ResidualScaling::new(d_ctx),
            g_tok_emb: vec![0.0; classes * d_emb],
            g_seg_emb: vec![0.0; max_c * d_emb],
            g_pos_emb: vec![0.0; max_tau * d_emb],
        }
    }

    pub fn zero_grad(&mut self) {
        self.g_tok_emb.iter_mut().for_each(|v| *v = 0.0);
        self.g_seg_emb.iter_mut().for_each(|v| *v = 0.0);
        self.g_pos_emb.iter_mut().for_each(|v| *v = 0.0);
        self.cca.zero_grad();
        self.res_out.zero_grad();
        self.res_res.zero_grad();
    }

    /// Промпт раскладывается на (токен, кандидат, позиция в хвосте) — так же,
    /// как `aggregation_prompt` склеивает хвосты по C штук.
    pub fn embed(&self, prompt: &[usize], tau: usize) -> Vec<f32> {
        let len = prompt.len();
        let mut e = vec![0.0f32; len * self.d_emb];
        for (i, &tok) in prompt.iter().enumerate() {
            let seg = (i / tau.max(1)).min(self.max_c - 1);
            let pos = (i % tau.max(1)).min(self.max_tau - 1);
            let t = tok.min(self.classes - 1);
            for c in 0..self.d_emb {
                e[i * self.d_emb + c] =
                    self.tok_emb[t * self.d_emb + c] + self.seg_emb[seg * self.d_emb + c] + self.pos_emb[pos * self.d_emb + c];
            }
        }
        e
    }

    /// `feat` — [t_feat, d_feat] признаки изображения (одна строка, без batch).
    /// Возвращает контекст [d_ctx] и трейс.
    pub fn forward(&mut self, prompt: &[usize], tau: usize, feat: &[f32], t_feat: usize) -> AggTrace {
        let emb = self.embed(prompt, tau);
        let len = prompt.len();
        // CCA хочет хотя бы по одному окну с каждой стороны
        let (lq, lkv) = (len.max(2), t_feat.max(8));
        let mut q = emb.clone();
        if len < 2 {
            q.resize(2 * self.d_emb, 0.0);
        }
        let mut kv = feat.to_vec();
        if t_feat < 8 {
            kv.resize(8 * self.cca.kv_conv.d_in, 0.0);
        }
        let (mut out, cca) = self.cca.forward(&q, lq, &kv, lkv);
        let lq2 = cca.lq2;
        // mean-pool по сжатым запросам → residual-поток
        let mut pooled = vec![0.0f32; self.d_ctx];
        let npos = lq2.max(1) as f32;
        for i in 0..lq2 {
            for c in 0..self.d_ctx {
                pooled[c] += out[i * self.d_ctx + c] / npos;
            }
        }
        let cca_out = out.clone();
        // (6): ctx = Res-scale_res(pooled) + Res-scale_out(mean(out))
        let a = self.res_res.forward(&pooled, 1);
        let b = self.res_out.forward(&pooled, 1);
        let ctx: Vec<f32> = a.iter().zip(b.iter()).map(|(x, y)| x + y).collect();
        out = cca_out;
        AggTrace { emb, len, cca, cca_out: out, lq2, ctx: ctx.clone(), pooled }
    }

    /// `d_ctx` — [d_ctx] градиент от декодера; возвращает d_feat [t_feat, d_feat].
    pub fn backward(&mut self, d_ctx: &[f32], tr: &AggTrace, tau: usize, prompt: &[usize], feat: &[f32], t_feat: usize) -> Vec<f32> {
        // обе ветви (6) получают один и тот же d_ctx, так как обе читают pooled
        let mut d_pooled = vec![0.0f32; self.d_ctx];
        let da = self.res_res.backward(d_ctx, &tr.pooled, 1);
        let db = self.res_out.backward(d_ctx, &tr.pooled, 1);
        for c in 0..self.d_ctx {
            d_pooled[c] = da[c] + db[c];
        }
        // mean-pool backward: равномерно по lq2 позициям
        let lq2 = tr.lq2.max(1);
        let mut d_out = vec![0.0f32; lq2 * self.d_ctx];
        for i in 0..lq2 {
            for c in 0..self.d_ctx {
                d_out[i * self.d_ctx + c] = d_pooled[c] / lq2 as f32;
            }
        }
        let (lq, lkv) = (tr.len.max(2), t_feat.max(8));
        let mut q = tr.emb.clone();
        if tr.len < 2 {
            q.resize(2 * self.d_emb, 0.0);
        }
        let mut kv = feat.to_vec();
        if t_feat < 8 {
            kv.resize(8 * self.cca.kv_conv.d_in, 0.0);
        }
        let (dq, dkv) = self.cca.backward(&d_out, &q, lq, &kv, lkv, &tr.cca);
        // эмбеддинги: scatter-add обратно в tok/seg/pos
        let n = dq.len() / self.d_emb;
        for i in 0..n.min(tr.len) {
            let seg = (i / tau.max(1)).min(self.max_c - 1);
            let pos = (i % tau.max(1)).min(self.max_tau - 1);
            let t = prompt[i].min(self.classes - 1);
            for c in 0..self.d_emb {
                let g = dq[i * self.d_emb + c];
                self.g_tok_emb[t * self.d_emb + c] += g;
                self.g_seg_emb[seg * self.d_emb + c] += g;
                self.g_pos_emb[pos * self.d_emb + c] += g;
            }
        }
        let mut d_feat = vec![0.0f32; t_feat * self.cca.kv_conv.d_in];
        let copy = d_feat.len().min(dkv.len());
        d_feat[..copy].copy_from_slice(&dkv[..copy]);
        d_feat
    }

    pub fn params(&self) -> usize {
        self.tok_emb.len() + self.seg_emb.len() + self.pos_emb.len() + self.cca.params() + self.res_out.params() + self.res_res.params()
    }
}

// ------------------------------------------------------- конфигурация ------

pub struct MopeCfg {
    pub experts: Vec<String>,
    pub top_k: usize,
    pub router_latent: usize,
    pub rsa: RsaCfg,
    /// сколько экспертов держать резидентно (остальные — int8 в хосте/на диске)
    pub vram_cache: usize,
    pub balance_lr: f64,
    pub balance_wd: f64,
    /// температура цели роутера (0 ⇒ жёсткий one-hot лучшего эксперта)
    pub target_temperature: f32,
}

impl MopeCfg {
    pub fn validate(&self) -> Result<(), String> {
        let e = self.experts.len();
        if e < MIN_EXPERTS || e > MAX_EXPERTS {
            return Err(format!(
                "экспертов должно быть от {MIN_EXPERTS} до {MAX_EXPERTS} (одна предобученная модель = один писарь), получено {e}"
            ));
        }
        if self.top_k == 0 || self.top_k > e {
            return Err(format!("top_k должен быть в [1, {e}]"));
        }
        self.rsa.validate()?;
        Ok(())
    }

    /// Честная арифметика памяти: эксперт = целая модель, поэтому 256 штук не
    /// помещаются ни в одну карту; int8 даёт ×4, а дальше решает кэш.
    pub fn memory_report(&self, params_per_expert: usize, vram_mib: f64, pcie_mib_s: f64) -> String {
        let e = self.experts.len();
        let fp32 = params_per_expert * 4;
        let int8 = params_per_expert;
        let cache = self.vram_cache.min(e).max(1);
        let swap_ms = int8 as f64 / (pcie_mib_s.max(1.0) * 1e6) * 1e3;
        format!(
            "экспертов {e} | fp32 {:.0} МБ/шт (всего {:.1} ГБ) | int8 {:.0} МБ/шт (всего {:.2} ГБ) | \
             резидентно в VRAM {cache} шт = {:.2} ГБ из {:.2} ГБ | подмена одного эксперта ~{:.0} мс по PCIe {:.0} МБ/с",
            fp32 as f64 / 1e6,
            fp32 as f64 * e as f64 / 1e9,
            int8 as f64 / 1e6,
            int8 as f64 * e as f64 / 1e9,
            int8 as f64 * cache as f64 / 1e9,
            vram_mib / 1024.0,
            swap_ms,
            pcie_mib_s
        )
    }
}

// --------------------------------------------------- оптимизатор роутера ---

/// AdamW-шаг по одному плоскому массиву (decoupled weight decay, как в
/// AdamW внутри «PID-оптимизатора» ZAYA1).
fn adam_vec(p: &mut [f32], g: &[f32], m: &mut [f64], v: &mut [f64], lr: f64, wd: f64, bc1: f64, bc2: f64) {
    for i in 0..p.len().min(g.len()) {
        let gi = g[i] as f64;
        if !gi.is_finite() {
            continue;
        }
        m[i] = 0.9 * m[i] + 0.1 * gi;
        v[i] = 0.999 * v[i] + 0.001 * gi * gi;
        let mh = m[i] / bc1;
        let vh = v[i] / bc2;
        let mut pi = p[i] as f64;
        pi -= lr * mh / (vh.sqrt() + 1e-8);
        pi -= lr * wd * pi;
        p[i] = pi as f32;
    }
}

/// Состояние AdamW для роутера. `bias` сюда не входит: его ведёт `PidBias`
/// (уравнение 5), это отдельная цель — балансировка загрузки.
pub struct RouterAdam {
    pub m: Vec<Vec<f64>>,
    pub v: Vec<Vec<f64>>,
    pub gm: f64,
    pub gv: f64,
    pub t: u64,
}

impl RouterAdam {
    pub fn new(r: &RouterMlp) -> Self {
        let shapes = [r.w_down.len(), r.mw[0].len(), r.mw[1].len(), r.mw[2].len(), r.mb[0].len(), r.mb[1].len(), r.mb[2].len()];
        Self {
            m: shapes.iter().map(|&n| vec![0.0f64; n]).collect(),
            v: shapes.iter().map(|&n| vec![0.0f64; n]).collect(),
            gm: 0.0,
            gv: 0.0,
            t: 0,
        }
    }

    pub fn step(&mut self, r: &mut RouterMlp, lr: f64, wd: f64) {
        self.t += 1;
        let bc1 = 1.0 - 0.9f64.powi(self.t as i32);
        let bc2 = 1.0 - 0.999f64.powi(self.t as i32);
        // поля не пересекаются, поэтому заимствования не конфликтуют
        adam_vec(&mut r.w_down, &r.g_w_down, &mut self.m[0], &mut self.v[0], lr, wd, bc1, bc2);
        for l in 0..3 {
            let (ml, vl) = (self.m[l + 1].clone(), self.v[l + 1].clone());
            let mut mm = ml;
            let mut vv = vl;
            adam_vec(&mut r.mw[l], &r.g_mw[l], &mut mm, &mut vv, lr, wd, bc1, bc2);
            self.m[l + 1] = mm;
            self.v[l + 1] = vv;
        }
        for l in 0..3 {
            let mut mm = self.m[l + 4].clone();
            let mut vv = self.v[l + 4].clone();
            adam_vec(&mut r.mb[l], &r.g_mb[l], &mut mm, &mut vv, lr, wd, bc1, bc2);
            self.m[l + 4] = mm;
            self.v[l + 4] = vv;
        }
        // γ — скаляр (EDA, уравнение 2)
        let gi = r.g_gamma as f64;
        if gi.is_finite() {
            self.gm = 0.9 * self.gm + 0.1 * gi;
            self.gv = 0.999 * self.gv + 0.001 * gi * gi;
            let mut g = r.gamma as f64;
            g -= lr * (self.gm / bc1) / ((self.gv / bc2).sqrt() + 1e-8);
            g -= lr * wd * g;
            r.gamma = g as f32;
        }
    }
}

// ---------------------------------------------------- сохранение весов -----

fn put_f32(buf: &mut Vec<u8>, v: &[f32]) {
    buf.extend_from_slice(&(v.len() as u64).to_le_bytes());
    for x in v {
        buf.extend_from_slice(&x.to_le_bytes());
    }
}

fn get_f32(b: &[u8], pos: &mut usize) -> Option<Vec<f32>> {
    if *pos + 8 > b.len() {
        return None;
    }
    let n = u64::from_le_bytes(b[*pos..*pos + 8].try_into().ok()?) as usize;
    *pos += 8;
    if *pos + n * 4 > b.len() {
        return None;
    }
    let mut out = Vec::with_capacity(n);
    for i in 0..n {
        let o = *pos + i * 4;
        out.push(f32::from_le_bytes(b[o..o + 4].try_into().ok()?));
    }
    *pos += n * 4;
    Some(out)
}

const MOPE_MAGIC: &[u8; 8] = b"MOPE0001";

/// Сохранить роутер вместе с его bias и состоянием PID-контроллера.
pub fn save_router(path: &str, r: &RouterMlp, pid: &PidBias) -> std::io::Result<usize> {
    let mut buf = Vec::new();
    buf.extend_from_slice(MOPE_MAGIC);
    buf.extend_from_slice(&(r.d_in as u64).to_le_bytes());
    buf.extend_from_slice(&(r.r as u64).to_le_bytes());
    buf.extend_from_slice(&(r.e as u64).to_le_bytes());
    buf.extend_from_slice(&pid.t.to_le_bytes());
    put_f32(&mut buf, &r.w_down);
    put_f32(&mut buf, &[r.gamma]);
    for l in 0..3 {
        put_f32(&mut buf, &r.mw[l]);
        put_f32(&mut buf, &r.mb[l]);
    }
    put_f32(&mut buf, &r.bias);
    // моменты AdamW внутри PID: f64 → f32, точности моментов это не портит
    let pm: Vec<f32> = pid.m.iter().map(|x| *x as f32).collect();
    let pv: Vec<f32> = pid.v.iter().map(|x| *x as f32).collect();
    put_f32(&mut buf, &pm);
    put_f32(&mut buf, &pv);
    std::fs::write(path, &buf)?;
    Ok(buf.len())
}

/// Загрузить роутер. Возвращает `None`, если файл не подходит по размерам
/// (тогда остаётся свежая инициализация) — молча применять чужие веса нельзя.
pub fn load_router(path: &str, r: &mut RouterMlp) -> std::io::Result<Option<PidBias>> {
    let b = std::fs::read(path)?;
    if b.len() < 8 || &b[..8] != MOPE_MAGIC {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "не файл роутера MoPE"));
    }
    let mut pos = 8;
    let rd = |pos: &mut usize| -> usize {
        let v = u64::from_le_bytes(b[*pos..*pos + 8].try_into().unwrap_or([0; 8])) as usize;
        *pos += 8;
        v
    };
    let (d_in, rr, e, pt) = (rd(&mut pos), rd(&mut pos), rd(&mut pos), rd(&mut pos));
    if (d_in, rr, e) != (r.d_in, r.r, r.e) {
        return Ok(None);
    }
    let w = match get_f32(&b, &mut pos) { Some(v) if v.len() == r.w_down.len() => v, _ => return Ok(None) };
    let g = match get_f32(&b, &mut pos) { Some(v) if v.len() == 1 => v[0], _ => return Ok(None) };
    let mut mw: Vec<Vec<f32>> = Vec::new();
    let mut mb: Vec<Vec<f32>> = Vec::new();
    for _ in 0..3 {
        match get_f32(&b, &mut pos) { Some(v) => mw.push(v), None => return Ok(None) }
        match get_f32(&b, &mut pos) { Some(v) => mb.push(v), None => return Ok(None) }
    }
    let bias = match get_f32(&b, &mut pos) { Some(v) if v.len() == e => v, _ => return Ok(None) };
    for l in 0..3 {
        if mw[l].len() != r.mw[l].len() || mb[l].len() != r.mb[l].len() {
            return Ok(None);
        }
    }
    r.w_down = w;
    r.gamma = g;
    r.mw = [mw[0].clone(), mw[1].clone(), mw[2].clone()];
    r.mb = [mb[0].clone(), mb[1].clone(), mb[2].clone()];
    r.bias = bias;
    let pm = get_f32(&b, &mut pos).unwrap_or_else(|| vec![0.0; e]);
    let pv = get_f32(&b, &mut pos).unwrap_or_else(|| vec![0.0; e]);
    let mut pid = PidBias::new(e);
    pid.t = pt as u64;
    if pm.len() == e {
        pid.m = pm.iter().map(|x| *x as f64).collect();
    }
    if pv.len() == e {
        pid.v = pv.iter().map(|x| *x as f64).collect();
    }
    Ok(Some(pid))
}

/// Сохранить агрегатор RSA (эмбеддинги + CCA + оба residual scaling).
pub fn save_aggregator(path: &str, a: &Aggregator) -> std::io::Result<usize> {
    let mut buf = Vec::new();
    buf.extend_from_slice(MOPE_MAGIC);
    buf.extend_from_slice(&(a.classes as u64).to_le_bytes());
    buf.extend_from_slice(&(a.d_emb as u64).to_le_bytes());
    buf.extend_from_slice(&(a.d_ctx as u64).to_le_bytes());
    put_f32(&mut buf, &a.tok_emb);
    put_f32(&mut buf, &a.seg_emb);
    put_f32(&mut buf, &a.pos_emb);
    put_f32(&mut buf, &a.cca.q_conv.w);
    put_f32(&mut buf, &a.cca.q_conv.b);
    put_f32(&mut buf, &a.cca.kv_conv.w);
    put_f32(&mut buf, &a.cca.kv_conv.b);
    put_f32(&mut buf, &a.cca.wq);
    put_f32(&mut buf, &a.cca.wk);
    put_f32(&mut buf, &a.cca.wv);
    put_f32(&mut buf, &a.cca.wo);
    put_f32(&mut buf, &a.cca.bo);
    put_f32(&mut buf, &a.res_out.alpha);
    put_f32(&mut buf, &a.res_out.beta);
    put_f32(&mut buf, &a.res_res.alpha);
    put_f32(&mut buf, &a.res_res.beta);
    std::fs::write(path, &buf)?;
    Ok(buf.len())
}

pub fn load_aggregator(path: &str, a: &mut Aggregator) -> std::io::Result<bool> {
    let b = std::fs::read(path)?;
    if b.len() < 8 || &b[..8] != MOPE_MAGIC {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "не файл агрегатора MoPE"));
    }
    let mut pos = 8;
    let rd = |pos: &mut usize| -> usize {
        let v = u64::from_le_bytes(b[*pos..*pos + 8].try_into().unwrap_or([0; 8])) as usize;
        *pos += 8;
        v
    };
    let (cl, de, dc) = (rd(&mut pos), rd(&mut pos), rd(&mut pos));
    if (cl, de, dc) != (a.classes, a.d_emb, a.d_ctx) {
        return Ok(false);
    }
    macro_rules! take {
        ($dst:expr) => {
            match get_f32(&b, &mut pos) {
                Some(v) if v.len() == $dst.len() => $dst = v,
                _ => return Ok(false),
            }
        };
    }
    take!(a.tok_emb);
    take!(a.seg_emb);
    take!(a.pos_emb);
    take!(a.cca.q_conv.w);
    take!(a.cca.q_conv.b);
    take!(a.cca.kv_conv.w);
    take!(a.cca.kv_conv.b);
    take!(a.cca.wq);
    take!(a.cca.wk);
    take!(a.cca.wv);
    take!(a.cca.wo);
    take!(a.cca.bo);
    take!(a.res_out.alpha);
    take!(a.res_out.beta);
    take!(a.res_res.alpha);
    take!(a.res_res.beta);
    Ok(true)
}

// ==========================================================================
//  Franken-MoE: предобученные эксперты РАЗНОЙ геометрии и РАЗНЫХ словарей
// ==========================================================================
//
// Экспертом может быть:
//   * чекпоинт trba-rust (`exp/checkpoint_last.bin`) — своя геометрия и свой
//     charset.txt (у куррентшрифта Кожина 140 токенов);
//   * экспорт Кожина `trba_base_g1.onnx` / `.pth` — 194 токена дореформенной
//     орфографии, hidden 256, 32×128, max_len 40;
//   * `trba_lite_g1` — тот же декодер, но depthwise-separable CNN.
//
// Поэтому MoPE хранит геометрию каждого эксперта отдельно (`ExpertSpec`),
// словари мёржит в один с отсечкой редких символов (`merge_charsets`), а
// несовпадающие размерности связывает обучаемыми адаптерами (`Adapter`).

/// Геометрия одного эксперта. Всё, что может отличаться между предобученными
/// моделями: размер входа, длина декодирования, ширина BiLSTM, выход CNN и
/// размер словаря вместе с индексами спецтокенов.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ExpertSpec {
    pub name: String,
    /// откуда взят: путь к файлу или имя пресета (`trba_base_g1`)
    pub source: String,
    /// "trba-rust-bin" | "onnx" | "torch" | "bundle"
    pub kind: String,
    pub img_h: usize,
    pub img_w: usize,
    pub max_len: usize,
    pub hidden: usize,
    /// выход CNN до BiLSTM (у SEResNet31 = 512)
    pub feat_dim: usize,
    pub classes: usize,
    pub pad: usize,
    pub sos: usize,
    pub eos: usize,
    /// число слоёв BiLSTM: у `trba_base_g1` их ОДИН (`num_encoder_layers: 1`
    /// в пресете Кожина), у локальных чекпоинтов trba-rust — два. Это такая же
    /// «разная размерность», как hidden или словарь, и её тоже надо дружить.
    pub rnn_layers: usize,
}

impl ExpertSpec {
    pub fn report(&self) -> String {
        format!(
            "{} [{}] img {}×{} max_len {} hidden {} feat {} классов {} rnn {} (pad {} sos {} eos {})",
            self.name, self.kind, self.img_h, self.img_w, self.max_len, self.hidden, self.feat_dim, self.classes, self.rnn_layers, self.pad, self.sos, self.eos
        )
    }

    /// Что именно не совпадает с общей геометрией MoPE — чтобы сообщать об этом
    /// честно, а не молча округлять.
    pub fn diff(&self, other: &ExpertSpec) -> Vec<String> {
        let mut d = Vec::new();
        if self.img_h != other.img_h || self.img_w != other.img_w {
            d.push(format!("вход {}×{} против {}×{}", self.img_h, self.img_w, other.img_h, other.img_w));
        }
        if self.hidden != other.hidden {
            d.push(format!("hidden {} против {}", self.hidden, other.hidden));
        }
        if self.feat_dim != other.feat_dim {
            d.push(format!("выход CNN {} против {}", self.feat_dim, other.feat_dim));
        }
        if self.classes != other.classes {
            d.push(format!("словарь {} против {} токенов", self.classes, other.classes));
        }
        if self.max_len != other.max_len {
            d.push(format!("max_len {} против {}", self.max_len, other.max_len));
        }
        if self.rnn_layers != other.rnn_layers {
            d.push(format!("слоёв BiLSTM {} против {}", self.rnn_layers, other.rnn_layers));
        }
        d
    }
}

pub const PAD_TOKEN: &str = "<PAD>";
pub const SOS_TOKEN: &str = "<SOS>";
pub const EOS_TOKEN: &str = "<EOS>";

/// Объединённый словарь MoPE и таблицы перенумерации для каждого эксперта.
pub struct MergedCharset {
    /// токены объединённого словаря; 0..2 всегда `<PAD> <SOS> <EOS>`
    pub itos: Vec<String>,
    pub stoi: std::collections::HashMap<String, usize>,
    /// `remap[e][old_id] = new_id`, `-1` = символ эксперта выброшен
    pub remap: Vec<Vec<i32>>,
    /// какие символы какого эксперта не вошли (для отчёта)
    pub dropped: Vec<Vec<String>>,
    pub min_freq: u64,
    pub max_size: usize,
}

impl MergedCharset {
    pub fn len(&self) -> usize {
        self.itos.len()
    }
    pub fn is_empty(&self) -> bool {
        self.itos.is_empty()
    }
    /// Текст по токенам эксперта (его собственная нумерация) через общий словарь.
    pub fn decode(&self, expert: usize, toks: &[usize]) -> String {
        let mut s = String::new();
        for &t in toks {
            let id = self.remap.get(expert).and_then(|r| r.get(t)).copied().unwrap_or(-1);
            if id < 0 {
                continue;
            }
            let tok = &self.itos[id as usize];
            if tok == PAD_TOKEN || tok == EOS_TOKEN || tok == SOS_TOKEN {
                continue;
            }
            s.push_str(tok);
        }
        s
    }
    pub fn report(&self) -> String {
        let mut r = format!(
            "общий словарь: {} токенов (порог частоты {}, предел {}); выброшено по экспертам: {:?}",
            self.itos.len(),
            self.min_freq,
            self.max_size,
            self.dropped.iter().map(|d| d.len()).collect::<Vec<_>>()
        );
        let total: usize = self.dropped.iter().map(|d| d.len()).sum();
        if total > 0 {
            let mut all: Vec<String> = self.dropped.iter().flatten().cloned().collect();
            all.sort();
            all.dedup();
            let shown: Vec<String> = all.iter().take(24).cloned().collect();
            r.push_str(&format!("; уникальных потеряно {} → {:?}", all.len(), shown));
        }
        r
    }
}

/// Слияние словарей нескольких экспертов.
///
/// Правила (по запросу: «разные charset.txt мёржить, отбрасывая редкие символы
/// с частотой менее 3 или 7, чтобы не превысить размер, например 256»):
///  1. `<PAD> <SOS> <EOS>` всегда на местах 0..2 и никогда не выбрасываются —
///     без них декодер не работает;
///  2. символ входит, если его суммарная частота во всех переданных корпусах
///     ≥ `min_freq`; символы без статистики (`counts` короче словаря) считаются
///     непроверенными и ВХОДЯТ — молча терять символы из-за отсутствия
///     статистики нельзя;
///  3. если после фильтра токенов больше `max_size`, отсекаются наименее
///     частотные (при равенстве — позже встреченные), спецтокены не трогаются;
///  4. порядок итогового словаря — порядок первой встречи по экспертам, это
///     стабильно и читаемо;
///  5. для каждого эксперта строится `remap`: старая нумерация → новая, −1 для
///     выброшенных.
pub fn merge_charsets(charsets: &[Vec<String>], counts: &[Vec<u64>], min_freq: u64, max_size: usize) -> MergedCharset {
    let specials = [PAD_TOKEN.to_string(), SOS_TOKEN.to_string(), EOS_TOKEN.to_string()];
    let cap = max_size.max(specials.len() + 1);
    // токен → (суммарная частота, порядок первой встречи)
    let mut freq: std::collections::HashMap<String, u64> = std::collections::HashMap::new();
    let mut order: std::collections::HashMap<String, usize> = std::collections::HashMap::new();
    for (ei, cs) in charsets.iter().enumerate() {
        let cnt = counts.get(ei);
        for (i, tok) in cs.iter().enumerate() {
            if specials.contains(tok) {
                continue;
            }
            let c = cnt.and_then(|v| v.get(i).copied());
            *freq.entry(tok.clone()).or_insert(0) += c.unwrap_or(0);
            if !order.contains_key(tok) {
                let n = order.len();
                order.insert(tok.clone(), n);
            }
            // если статистики нет ни у одного эксперта, помечаем «непроверенным»
            if c.is_none() {
                // статистики нет именно по этому токену: помечаем «непроверенным»
                // ПРИСВАИВАНИЕМ (or_insert здесь ничего не сделал бы — запись уже
                // создана нулём выше, и все символы молча отсеялись бы)
                *freq.entry(tok.clone()).or_insert(0) = u64::MAX / 2;
            }
        }
    }
    let mut cand: Vec<(String, u64, usize)> = freq
        .iter()
        .map(|(t, &f)| (t.clone(), f, order[t]))
        .filter(|(_, f, _)| *f >= min_freq || *f >= u64::MAX / 2)
        .collect();
    // сортировка для обрезки по пределу: чаще → раньше
    cand.sort_by(|a, b| b.1.cmp(&a.1).then(a.2.cmp(&b.2)));
    let room = cap.saturating_sub(specials.len());
    if cand.len() > room {
        cand.truncate(room);
    }
    // итоговый порядок — порядок первой встречи
    cand.sort_by_key(|c| c.2);
    let mut itos: Vec<String> = specials.to_vec();
    itos.extend(cand.iter().map(|c| c.0.clone()));
    let mut stoi = std::collections::HashMap::new();
    for (i, t) in itos.iter().enumerate() {
        stoi.entry(t.clone()).or_insert(i);
    }
    let mut remap = Vec::with_capacity(charsets.len());
    let mut dropped = Vec::with_capacity(charsets.len());
    for cs in charsets.iter() {
        let mut m = vec![-1i32; cs.len()];
        let mut dr = Vec::new();
        for (i, tok) in cs.iter().enumerate() {
            match stoi.get(tok) {
                Some(&j) => m[i] = j as i32,
                None => dr.push(tok.clone()),
            }
        }
        remap.push(m);
        dropped.push(dr);
    }
    MergedCharset { itos, stoi, remap, dropped, min_freq, max_size: cap }
}

/// Чтение charset.txt (по токену на строку, пустые строки пропускаются —
/// но ПРОБЕЛ как токен сохраняется: это значимый символ).
/// Первая не пустая строка CSV — заголовок, если в поле пути одно из служебных
/// слов.  Без этой проверки `filename,text` из labels.csv попал бы в словарь как
/// символы f,i,l,e,n,a,m,t,x и молча расширил его.
pub fn is_csv_header(path_field: &str) -> bool {
    matches!(
        path_field.trim().to_ascii_lowercase().as_str(),
        "filename" | "file" | "path" | "image" | "img" | "image_path" | "name"
    )
}

pub fn charset_from_file(path: &str) -> std::io::Result<Vec<String>> {
    let s = std::fs::read_to_string(path)?;
    let mut out = Vec::new();
    for line in s.split('\n') {
        let t = line.trim_end_matches('\r');
        if t.is_empty() && !line.ends_with(' ') {
            continue;
        }
        out.push(t.to_string());
    }
    while out.last().map(|x| x.is_empty()).unwrap_or(false) {
        out.pop();
    }
    Ok(out)
}

/// Частоты токенов словаря в текстовом файле (CSV с разметкой или дамп).
/// Считаем вхождения подстрок: для одностороннего решения «символ редкий»
/// этого достаточно, а порядок токенов совпадает с `itos`.
/// Длина teacher-forced прогона (в ШАГАХ) для конкретного эксперта.
///
/// Позиционные эмбеддинги его декодера рассчитаны на собственный `max_len`,
/// поэтому глобальный `--max-len` здесь работает только как ПОТОЛОК: длиннее
/// эталона гипотеза не нужна (CER уходит за 100%), а длиннее своих эмбеддингов
/// эксперт декодировать не может. Именно это позволяет смешивать в одном роутере
/// «корзины» по длине — экспертов, обученных на 7, 8, 16 и 24 шагах: каждый
/// тратит вычисления только на свою длину, а паддинг не считается впустую.
pub fn expert_steps(spec_max_len: usize, global_steps: usize) -> usize {
    let cap = global_steps.saturating_sub(1).max(1);
    spec_max_len.clamp(1, cap) + 1
}

pub fn count_charset_in_file(path: &str, itos: &[String]) -> std::io::Result<Vec<u64>> {
    let s = std::fs::read_to_string(path)?;
    let mut c = vec![0u64; itos.len()];
    for (i, tok) in itos.iter().enumerate() {
        if tok.is_empty() || tok == PAD_TOKEN || tok == SOS_TOKEN || tok == EOS_TOKEN {
            continue;
        }
        c[i] = s.matches(tok.as_str()).count() as u64;
    }
    Ok(c)
}

// ------------------------------------------------------------ адаптеры -----

/// Обучаемый линейный адаптер «чужая размерность → общая размерность MoPE».
/// При `inp == out` инициализируется ТОЖДЕСТВЕННО (и нулевым bias), поэтому
/// добавление адаптера не меняет уже работающего эксперта; при несовпадении —
/// единицы на диагонали перекрывающейся части и малый случайный шум в новых
/// строках, чтобы градиент сразу пошёл.
#[derive(Clone)]
pub struct Adapter {
    pub inp: usize,
    pub out: usize,
    pub w: Vec<f32>, // [out, inp]
    pub b: Vec<f32>,
    pub g_w: Vec<f32>,
    pub g_b: Vec<f32>,
}

impl Adapter {
    pub fn new(inp: usize, out: usize) -> Self {
        let mut rng = rand::thread_rng();
        let mut w = vec![0.0f32; out * inp];
        let diag = inp.min(out);
        for i in 0..diag {
            w[i * inp + i] = 1.0;
        }
        let lim = (6.0 / (inp + out) as f32).sqrt() * 0.1;
        for i in diag..out {
            for j in 0..inp {
                w[i * inp + j] = rng.gen_range(-lim..lim);
            }
        }
        Self { inp, out, w, b: vec![0.0; out], g_w: vec![0.0; out * inp], g_b: vec![0.0; out] }
    }

    pub fn is_identity(&self) -> bool {
        self.inp == self.out
    }

    pub fn forward(&self, x: &[f32], rows: usize) -> Vec<f32> {
        lin(x, rows, self.inp, &self.w, Some(&self.b), self.out)
    }

    /// Градиенты НАКАПЛИВАЮТСЯ (как в `RouterMlp`), возвращается dx.
    pub fn backward(&mut self, dy: &[f32], x: &[f32], rows: usize) -> Vec<f32> {
        let (dx, dw, db) = lin_bwd(dy, x, rows, self.inp, &self.w, self.out);
        for i in 0..self.g_w.len().min(dw.len()) {
            self.g_w[i] += dw[i];
        }
        for i in 0..self.g_b.len().min(db.len()) {
            self.g_b[i] += db[i];
        }
        dx
    }

    pub fn zero_grad(&mut self) {
        self.g_w.iter_mut().for_each(|v| *v = 0.0);
        self.g_b.iter_mut().for_each(|v| *v = 0.0);
    }

    pub fn params(&self) -> usize {
        self.w.len() + self.b.len()
    }
}

/// Перенос строк выходной проекции (CTC-голова, генератор декодера) из
/// словаря эксперта в объединённый словарь MoPE.
///
/// `src` — [src_classes, cols], `dst` — [dst_classes, cols]; строки, которых у
/// эксперта нет, обнуляются: эксперт физически не способен выдать символ,
/// которого не было в его разметке, и роутер должен это видеть.
pub fn remap_rows(src: &[f32], src_classes: usize, dst: &mut [f32], dst_classes: usize, cols: usize, remap: &[i32]) -> usize {
    dst.iter_mut().for_each(|v| *v = 0.0);
    let mut moved = 0usize;
    for old in 0..src_classes {
        let new = remap.get(old).copied().unwrap_or(-1);
        if new < 0 || new as usize >= dst_classes {
            continue;
        }
        let n = cols.min(src.len().saturating_sub(old * cols)).min(dst.len().saturating_sub(new as usize * cols));
        if n == 0 {
            continue;
        }
        dst[new as usize * cols..new as usize * cols + n].copy_from_slice(&src[old * cols..old * cols + n]);
        moved += 1;
    }
    moved
}

// ------------------------------------------------------------- бандлы ------

const BUNDLE_MAGIC: &[u8; 8] = b"MOPEXP02";

/// Эксперт как переносимый файл: геометрия + словарь + именованные тензоры в
/// ИМЕНАХ МАНИФЕСТА trba-rust (`stem.0.w`, `layer1.0.conv1.gamma`, `ctc.w`, …)
/// плюс BN-статистика (`{conv}.run_mean` / `.run_var`). Формат намеренно
/// примитивный (u64-длины + little-endian f32), чтобы конвертер из ONNX/PyTorch
/// можно было написать на чём угодно и проверить байт-в-байт.
#[derive(Clone)]
pub struct ExpertBundle {
    pub spec: ExpertSpec,
    pub charset: Vec<String>,
    pub tensors: Vec<(String, Vec<f32>)>,
}

impl ExpertBundle {
    pub fn get(&self, name: &str) -> Option<&[f32]> {
        self.tensors.iter().find(|(n, _)| n == name).map(|(_, v)| v.as_slice())
    }
    pub fn params(&self) -> usize {
        self.tensors.iter().map(|(_, v)| v.len()).sum()
    }
    pub fn bytes(&self) -> usize {
        self.tensors.iter().map(|(_, v)| v.len() * 4).sum()
    }
}

fn put_u64(b: &mut Vec<u8>, v: u64) {
    b.extend_from_slice(&v.to_le_bytes());
}
fn put_str(b: &mut Vec<u8>, s: &str) {
    put_u64(b, s.len() as u64);
    b.extend_from_slice(s.as_bytes());
}
fn put_f32s(b: &mut Vec<u8>, v: &[f32]) {
    put_u64(b, v.len() as u64);
    for x in v {
        b.extend_from_slice(&x.to_le_bytes());
    }
}

pub fn write_bundle(path: &str, bun: &ExpertBundle) -> std::io::Result<usize> {
    let mut b = Vec::new();
    b.extend_from_slice(BUNDLE_MAGIC);
    put_str(&mut b, &bun.spec.name);
    put_str(&mut b, &bun.spec.source);
    put_str(&mut b, &bun.spec.kind);
    for v in [
        bun.spec.img_h,
        bun.spec.img_w,
        bun.spec.max_len,
        bun.spec.hidden,
        bun.spec.feat_dim,
        bun.spec.classes,
        bun.spec.pad,
        bun.spec.sos,
        bun.spec.eos,
        bun.spec.rnn_layers,
    ] {
        put_u64(&mut b, v as u64);
    }
    put_u64(&mut b, bun.charset.len() as u64);
    for t in &bun.charset {
        put_str(&mut b, t);
    }
    put_u64(&mut b, bun.tensors.len() as u64);
    for (n, v) in &bun.tensors {
        put_str(&mut b, n);
        put_f32s(&mut b, v);
    }
    std::fs::write(path, &b)?;
    Ok(b.len())
}

struct Rd<'a> {
    b: &'a [u8],
    p: usize,
}
impl<'a> Rd<'a> {
    fn u64(&mut self) -> Option<u64> {
        if self.p + 8 > self.b.len() {
            return None;
        }
        let v = u64::from_le_bytes(self.b[self.p..self.p + 8].try_into().ok()?);
        self.p += 8;
        Some(v)
    }
    fn str(&mut self) -> Option<String> {
        let n = self.u64()? as usize;
        if self.p + n > self.b.len() {
            return None;
        }
        let s = String::from_utf8(self.b[self.p..self.p + n].to_vec()).ok()?;
        self.p += n;
        Some(s)
    }
    /// `n` сырых байт как i8 (веса int8-бандла).
    fn i8s(&mut self, n: usize) -> Option<Vec<i8>> {
        if self.p + n > self.b.len() {
            return None;
        }
        let v: Vec<i8> = self.b[self.p..self.p + n].iter().map(|&x| x as i8).collect();
        self.p += n;
        Some(v)
    }
    fn f32s(&mut self) -> Option<Vec<f32>> {
        let n = self.u64()? as usize;
        if self.p + n * 4 > self.b.len() {
            return None;
        }
        let mut v = Vec::with_capacity(n);
        for i in 0..n {
            let o = self.p + i * 4;
            v.push(f32::from_le_bytes(self.b[o..o + 4].try_into().ok()?));
        }
        self.p += n * 4;
        Some(v)
    }
}

pub fn read_bundle(path: &str) -> std::io::Result<ExpertBundle> {
    let b = std::fs::read(path)?;
    if b.len() < 8 || &b[..8] != BUNDLE_MAGIC {
        return Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "это не бандл эксперта MoPE (магия не совпала)"));
    }
    let mut r = Rd { b: &b, p: 8 };
    let bad = || std::io::Error::new(std::io::ErrorKind::InvalidData, "бандл оборван");
    let name = r.str().ok_or_else(bad)?;
    let source = r.str().ok_or_else(bad)?;
    let kind = r.str().ok_or_else(bad)?;
    let mut g = [0usize; 10];
    for x in g.iter_mut() {
        *x = r.u64().ok_or_else(bad)? as usize;
    }
    let spec = ExpertSpec {
        name,
        source,
        kind,
        img_h: g[0],
        img_w: g[1],
        max_len: g[2],
        hidden: g[3],
        feat_dim: g[4],
        classes: g[5],
        pad: g[6],
        sos: g[7],
        eos: g[8],
        rnn_layers: g[9],
    };
    let nt = r.u64().ok_or_else(bad)? as usize;
    let mut charset = Vec::with_capacity(nt);
    for _ in 0..nt {
        charset.push(r.str().ok_or_else(bad)?);
    }
    let nz = r.u64().ok_or_else(bad)? as usize;
    let mut tensors = Vec::with_capacity(nz);
    for _ in 0..nz {
        let n = r.str().ok_or_else(bad)?;
        let v = r.f32s().ok_or_else(bad)?;
        tensors.push((n, v));
    }
    Ok(ExpertBundle { spec, charset, tensors })
}

// ================= Franken-MoPE: обучаемое состояние и его оптимизатор =======
//
// До этого места MoPE умел только РАБОТАТЬ: эксперты конвертируются в `.mope`,
// роутер получал один шаг градиента на картинку по самооценке кандидатов, а
// агрегатор, CCA, residual scaling и адаптеры размерностей не обучались вовсе
// (и не сохранялись — `save_aggregator` существовал, но никем не вызывался).
// Ниже — то, чего не хватало для полноценного дообучения после конвертации:
//
// * `FlatAdam` — один оптимизатор на все обучаемые тензоры агрегатора/адаптеров
//   (у роутера свой `RouterAdam`, он уже был);
// * `Aggregator::adam_shapes` / `adam_step` — фиксированный порядок тензоров,
//   чтобы состояние оптимизатора нельзя было рассогласовать молча;
// * `Franken` + `save_franken` / `load_franken` — ВЕСЬ обученный Franken-MoPE
//   одним файлом `MOPEFR01`: общий словарь, роутер, PID-балансировка,
//   агрегатор (эмбеддинги, CCA, оба Res-scale) и адаптеры размерностей.
//   Файл сам описывает свои размерности, поэтому загрузка не требует заранее
//   знать геометрию экспертов; несовпадение размеров вызывающий видит явно.

/// Один Adam на набор тензоров разной длины. Индекс тензора фиксирован
/// порядком в `adam_shapes`, состояние (m, v) живёт здесь же, поэтому
/// Franken-файл можно сохранять и продолжать обучение с него.
pub struct FlatAdam {
    pub m: Vec<Vec<f64>>,
    pub v: Vec<Vec<f64>>,
    pub t: u64,
}

impl FlatAdam {
    pub fn new(shapes: &[usize]) -> Self {
        Self {
            m: shapes.iter().map(|&n| vec![0.0f64; n]).collect(),
            v: shapes.iter().map(|&n| vec![0.0f64; n]).collect(),
            t: 0,
        }
    }
    pub fn params(&self) -> usize {
        self.m.iter().map(|x| x.len()).sum()
    }
    /// Начало шага: счётчик растёт ОДИН раз на шаг оптимизатора (не на тензор),
    /// возвращает поправки на смещение для всех `apply` этого шага.
    pub fn begin_step(&mut self) -> (f64, f64) {
        self.t += 1;
        (1.0 - 0.9f64.powi(self.t as i32), 1.0 - 0.999f64.powi(self.t as i32))
    }
    pub fn apply(&mut self, i: usize, p: &mut [f32], g: &[f32], lr: f64, wd: f64, bc1: f64, bc2: f64) {
        if i >= self.m.len() {
            return;
        }
        let (m, v) = (&mut self.m[i], &mut self.v[i]);
        adam_vec(p, g, m, v, lr, wd, bc1, bc2);
    }
}

impl Aggregator {
    /// Длины всех обучаемых тензоров в том порядке, в котором их обходит
    /// `adam_step`. Порядок зафиксирован и попадает в `Franken`, поэтому
    /// сохранённое состояние оптимизатора остаётся согласованным.
    pub fn adam_shapes(&self) -> Vec<usize> {
        vec![
            self.tok_emb.len(),
            self.seg_emb.len(),
            self.pos_emb.len(),
            self.cca.q_conv.w.len(),
            self.cca.q_conv.b.len(),
            self.cca.kv_conv.w.len(),
            self.cca.kv_conv.b.len(),
            self.cca.wq.len(),
            self.cca.wk.len(),
            self.cca.wv.len(),
            self.cca.wo.len(),
            self.cca.bo.len(),
            self.res_out.alpha.len(),
            self.res_out.beta.len(),
            self.res_res.alpha.len(),
            self.res_res.beta.len(),
        ]
    }
    /// Один шаг Adam по всем тензорам агрегатора (эмбеддинги, CCA, Res-scale).
    /// Градиенты должны быть накоплены `backward` и не сброшены.
    pub fn adam_step(&mut self, a: &mut FlatAdam, lr: f64, wd: f64) {
        let (bc1, bc2) = a.begin_step();
        a.apply(0, &mut self.tok_emb, &self.g_tok_emb, lr, wd, bc1, bc2);
        a.apply(1, &mut self.seg_emb, &self.g_seg_emb, lr, wd, bc1, bc2);
        a.apply(2, &mut self.pos_emb, &self.g_pos_emb, lr, wd, bc1, bc2);
        a.apply(3, &mut self.cca.q_conv.w, &self.cca.q_conv.g_w, lr, wd, bc1, bc2);
        a.apply(4, &mut self.cca.q_conv.b, &self.cca.q_conv.g_b, lr, wd, bc1, bc2);
        a.apply(5, &mut self.cca.kv_conv.w, &self.cca.kv_conv.g_w, lr, wd, bc1, bc2);
        a.apply(6, &mut self.cca.kv_conv.b, &self.cca.kv_conv.g_b, lr, wd, bc1, bc2);
        a.apply(7, &mut self.cca.wq, &self.cca.g_wq, lr, wd, bc1, bc2);
        a.apply(8, &mut self.cca.wk, &self.cca.g_wk, lr, wd, bc1, bc2);
        a.apply(9, &mut self.cca.wv, &self.cca.g_wv, lr, wd, bc1, bc2);
        a.apply(10, &mut self.cca.wo, &self.cca.g_wo, lr, wd, bc1, bc2);
        a.apply(11, &mut self.cca.bo, &self.cca.g_bo, lr, wd, bc1, bc2);
        a.apply(12, &mut self.res_out.alpha, &self.res_out.g_alpha, lr, wd, bc1, bc2);
        a.apply(13, &mut self.res_out.beta, &self.res_out.g_beta, lr, wd, bc1, bc2);
        a.apply(14, &mut self.res_res.alpha, &self.res_res.g_alpha, lr, wd, bc1, bc2);
        a.apply(15, &mut self.res_res.beta, &self.res_res.g_beta, lr, wd, bc1, bc2);
    }
}

pub const FRANKEN_MAGIC: &[u8; 8] = b"MOPEFR02";
/// `MOPEFR01` — то же состояние, но без геометрии раундов RSA. Читается, не пишется.
pub const FRANKEN_MAGIC_V1: &[u8; 8] = b"MOPEFR01";

/// Всё обученное состояние Franken-MoPE: то, что нужно сохранить после
/// дообучения и загрузить перед инференсом, чтобы Best-of-N и Markovian-RSA
/// работали на выученном роутере и выученном агрегаторе.
pub struct Franken {
    /// общий словарь MoPE (0..2 = `<PAD> <SOS> <EOS>`)
    pub itos: Vec<String>,
    pub router: RouterMlp,
    pub pid: PidBias,
    pub agg: Aggregator,
    /// признаки эксперта -> общее пространство роутера/агрегатора
    pub feat_ad: Vec<Adapter>,
    /// контекст агрегации -> память конкретного эксперта
    pub ctx_ad: Vec<Adapter>,
    /// сколько шагов обучения пройдено (для отчёта и продолжения)
    pub steps: u64,
    /// Геометрия раундов RSA, с которой состояние обучалось (N, C, T, β, τ,
    /// temperature, top_p). `None` для файлов `MOPEFR01`. Инференс подставляет
    /// её сам, поэтому предупреждение «агрегатор обучен на промпте C·τ, а
    /// запрошено другое» без явных флагов пользователя больше не возникает.
    pub rsa: Option<RsaCfg>,
    /// состояние Adam агрегатора — чтобы продолжать обучение, а не начинать его
    pub opt: Option<FlatAdam>,
}

fn put_u64v(b: &mut Vec<u8>, v: &[u64]) {
    b.extend_from_slice(&(v.len() as u64).to_le_bytes());
    for x in v {
        b.extend_from_slice(&x.to_le_bytes());
    }
}
fn put_f64v(b: &mut Vec<u8>, v: &[f64]) {
    b.extend_from_slice(&(v.len() as u64).to_le_bytes());
    for x in v {
        b.extend_from_slice(&x.to_le_bytes());
    }
}
fn put_strings(b: &mut Vec<u8>, v: &[String]) {
    b.extend_from_slice(&(v.len() as u64).to_le_bytes());
    for s in v {
        put_str(b, s);
    }
}
fn put_adapter(b: &mut Vec<u8>, a: &Adapter) {
    b.extend_from_slice(&(a.inp as u64).to_le_bytes());
    b.extend_from_slice(&(a.out as u64).to_le_bytes());
    put_f32(b, &a.w);
    put_f32(b, &a.b);
}
fn put_res(b: &mut Vec<u8>, r: &ResidualScaling) {
    b.extend_from_slice(&(r.d as u64).to_le_bytes());
    put_f32(b, &r.alpha);
    put_f32(b, &r.beta);
}
fn put_conv(b: &mut Vec<u8>, c: &ConvDown) {
    b.extend_from_slice(&(c.d_in as u64).to_le_bytes());
    b.extend_from_slice(&(c.d_out as u64).to_le_bytes());
    b.extend_from_slice(&(c.stride as u64).to_le_bytes());
    put_f32(b, &c.w);
    put_f32(b, &c.b);
}

/// Сохраняет всё обученное состояние Franken-MoPE. Возвращает размер файла.
/// Принимает ссылки, а не готовый `Franken`: агрегатор в раннере живёт внутри
/// `Rc<RefCell<..>>`, а `RouterMlp`/`Aggregator` не клонируемы, поэтому собирать
/// владеющий объект ради записи было бы лишним.
#[allow(clippy::too_many_arguments)]
pub fn save_franken(
    path: &str,
    itos: &[String],
    router: &RouterMlp,
    pid: &PidBias,
    agg: &Aggregator,
    feat_ad: &[Adapter],
    ctx_ad: &[Adapter],
    steps: u64,
    opt: Option<&FlatAdam>,
    rsa: &RsaCfg,
) -> std::io::Result<usize> {
    let mut b = Vec::new();
    b.extend_from_slice(FRANKEN_MAGIC);
    b.extend_from_slice(&steps.to_le_bytes());
    // MOPEFR02: геометрия раундов — сразу за счётчиком шагов, остальной поток
    // байтов не отличается от MOPEFR01.
    for x in [rsa.n as u64, rsa.c as u64, rsa.t_rounds as u64, rsa.beta as u64, rsa.tau as u64] {
        b.extend_from_slice(&x.to_le_bytes());
    }
    put_f32(&mut b, &[rsa.temperature, rsa.top_p]);
    put_strings(&mut b, itos);
    // роутер
    let r = router;
    for x in [r.d_in as u64, r.r as u64, r.e as u64] {
        b.extend_from_slice(&x.to_le_bytes());
    }
    // gamma (EDA) пишем как f64: f32 -> f64 -> f32 проходит без потерь,
    // а разнобой ширины полей рассинхронизировал бы весь поток чтения
    b.extend_from_slice(&(r.gamma as f64).to_le_bytes());
    put_f32(&mut b, &r.w_down);
    for l in 0..3 {
        put_f32(&mut b, &r.mw[l]);
        put_f32(&mut b, &r.mb[l]);
    }
    put_f32(&mut b, &r.bias);
    // PID-балансировка (уравнение 5)
    put_f64v(&mut b, &pid.m);
    put_f64v(&mut b, &pid.v);
    b.extend_from_slice(&pid.t.to_le_bytes());
    for x in [pid.b1, pid.b2, pid.eps] {
        b.extend_from_slice(&x.to_le_bytes());
    }
    // агрегатор
    let a = agg;
    for x in [a.classes as u64, a.d_emb as u64, a.d_ctx as u64, a.max_c as u64, a.max_tau as u64] {
        b.extend_from_slice(&x.to_le_bytes());
    }
    put_f32(&mut b, &a.tok_emb);
    put_f32(&mut b, &a.seg_emb);
    put_f32(&mut b, &a.pos_emb);
    put_conv(&mut b, &a.cca.q_conv);
    put_conv(&mut b, &a.cca.kv_conv);
    put_f32(&mut b, &a.cca.wq);
    put_f32(&mut b, &a.cca.wk);
    put_f32(&mut b, &a.cca.wv);
    put_f32(&mut b, &a.cca.wo);
    put_f32(&mut b, &a.cca.bo);
    put_res(&mut b, &a.res_out);
    put_res(&mut b, &a.res_res);
    // адаптеры
    b.extend_from_slice(&(feat_ad.len() as u64).to_le_bytes());
    for x in feat_ad {
        put_adapter(&mut b, x);
    }
    b.extend_from_slice(&(ctx_ad.len() as u64).to_le_bytes());
    for x in ctx_ad {
        put_adapter(&mut b, x);
    }
    // состояние оптимизатора (может отсутствовать)
    match &opt {
        None => b.extend_from_slice(&0u64.to_le_bytes()),
        Some(o) => {
            b.extend_from_slice(&1u64.to_le_bytes());
            b.extend_from_slice(&o.t.to_le_bytes());
            for v in o.m.iter().chain(o.v.iter()) {
                put_f64v(&mut b, v);
            }
        }
    }
    std::fs::write(path, &b)?;
    Ok(b.len())
}

struct Frd<'a> {
    b: &'a [u8],
    p: usize,
}
impl<'a> Frd<'a> {
    fn u64(&mut self) -> Option<u64> {
        if self.p + 8 > self.b.len() {
            return None;
        }
        let v = u64::from_le_bytes(self.b[self.p..self.p + 8].try_into().ok()?);
        self.p += 8;
        Some(v)
    }
    fn f64(&mut self) -> Option<f64> {
        if self.p + 8 > self.b.len() {
            return None;
        }
        let v = f64::from_le_bytes(self.b[self.p..self.p + 8].try_into().ok()?);
        self.p += 8;
        Some(v)
    }
    fn f32v(&mut self) -> Option<Vec<f32>> {
        let n = self.u64()? as usize;
        if self.p + 4 * n > self.b.len() {
            return None;
        }
        let mut v = Vec::with_capacity(n);
        for _ in 0..n {
            v.push(f32::from_le_bytes(self.b[self.p..self.p + 4].try_into().ok()?));
            self.p += 4;
        }
        Some(v)
    }
    fn f64v(&mut self) -> Option<Vec<f64>> {
        let n = self.u64()? as usize;
        if self.p + 8 * n > self.b.len() {
            return None;
        }
        let mut v = Vec::with_capacity(n);
        for _ in 0..n {
            v.push(f64::from_le_bytes(self.b[self.p..self.p + 8].try_into().ok()?));
            self.p += 8;
        }
        Some(v)
    }
    fn string(&mut self) -> Option<String> {
        let n = self.u64()? as usize;
        if self.p + n > self.b.len() {
            return None;
        }
        let s = String::from_utf8_lossy(&self.b[self.p..self.p + n]).into_owned();
        self.p += n;
        Some(s)
    }
    fn strings(&mut self) -> Option<Vec<String>> {
        let n = self.u64()? as usize;
        (0..n).map(|_| self.string()).collect()
    }
    fn adapter(&mut self) -> Option<Adapter> {
        let inp = self.u64()? as usize;
        let out = self.u64()? as usize;
        Some(Adapter { inp, out, w: self.f32v()?, b: self.f32v()?, g_w: vec![0.0; out * inp], g_b: vec![0.0; out] })
    }
    fn res(&mut self) -> Option<ResidualScaling> {
        let d = self.u64()? as usize;
        Some(ResidualScaling { d, alpha: self.f32v()?, beta: self.f32v()?, g_alpha: vec![0.0; d], g_beta: vec![0.0; d] })
    }
    fn conv(&mut self) -> Option<ConvDown> {
        let d_in = self.u64()? as usize;
        let d_out = self.u64()? as usize;
        let stride = self.u64()? as usize;
        let w = self.f32v()?;
        let bb = self.f32v()?;
        let (nw, nb) = (w.len(), bb.len());
        Some(ConvDown { d_in, d_out, stride, w, b: bb, g_w: vec![0.0; nw], g_b: vec![0.0; nb] })
    }
}

/// Читает состояние Franken-MoPE. Размерности берутся из самого файла, поэтому
/// объект собирается заново (со сброшенными градиентами).
pub fn load_franken(path: &str) -> std::io::Result<Franken> {
    let buf = std::fs::read(path)?;
    let bad = || std::io::Error::new(std::io::ErrorKind::InvalidData, "файл Franken-MoPE оборван");
    let v1 = buf.len() >= 8 && &buf[..8] == FRANKEN_MAGIC_V1;
    if buf.len() < 8 || (&buf[..8] != FRANKEN_MAGIC && !v1) {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "это не файл состояния Franken-MoPE (магия MOPEFR02/MOPEFR01 не совпала)",
        ));
    }
    let mut r = Frd { b: &buf, p: 8 };
    let steps = r.u64().ok_or_else(bad)?;
    let rsa = if v1 {
        None
    } else {
        let n = r.u64().ok_or_else(bad)? as usize;
        let c = r.u64().ok_or_else(bad)? as usize;
        let t_rounds = r.u64().ok_or_else(bad)? as usize;
        let beta = r.u64().ok_or_else(bad)? as usize;
        let tau = r.u64().ok_or_else(bad)? as usize;
        let tt = r.f32v().ok_or_else(bad)?;
        Some(RsaCfg {
            n,
            c,
            t_rounds,
            beta,
            tau,
            temperature: tt.first().copied().unwrap_or(1.0),
            top_p: tt.get(1).copied().unwrap_or(1.0),
        })
    };
    let itos = r.strings().ok_or_else(bad)?;
    let d_in = r.u64().ok_or_else(bad)? as usize;
    let rl = r.u64().ok_or_else(bad)? as usize;
    let e = r.u64().ok_or_else(bad)? as usize;
    let gamma = r.f64().ok_or_else(bad)? as f32;
    let w_down = r.f32v().ok_or_else(bad)?;
    let mut mw = [Vec::new(), Vec::new(), Vec::new()];
    let mut mb = [Vec::new(), Vec::new(), Vec::new()];
    for l in 0..3 {
        mw[l] = r.f32v().ok_or_else(bad)?;
        mb[l] = r.f32v().ok_or_else(bad)?;
    }
    let bias = r.f32v().ok_or_else(bad)?;
    let mut router = RouterMlp::new(d_in, rl, e);
    router.gamma = gamma;
    router.w_down = w_down;
    router.mw = mw;
    router.mb = mb;
    router.bias = bias;
    let pm = r.f64v().ok_or_else(bad)?;
    let pv = r.f64v().ok_or_else(bad)?;
    let pt = r.u64().ok_or_else(bad)?;
    let b1 = r.f64().ok_or_else(bad)?;
    let b2 = r.f64().ok_or_else(bad)?;
    let eps = r.f64().ok_or_else(bad)?;
    let pid = PidBias { m: pm, v: pv, t: pt, b1, b2, eps };
    let classes = r.u64().ok_or_else(bad)? as usize;
    let d_emb = r.u64().ok_or_else(bad)? as usize;
    let d_ctx = r.u64().ok_or_else(bad)? as usize;
    let max_c = r.u64().ok_or_else(bad)? as usize;
    let max_tau = r.u64().ok_or_else(bad)? as usize;
    let tok_emb = r.f32v().ok_or_else(bad)?;
    let seg_emb = r.f32v().ok_or_else(bad)?;
    let pos_emb = r.f32v().ok_or_else(bad)?;
    let q_conv = r.conv().ok_or_else(bad)?;
    let kv_conv = r.conv().ok_or_else(bad)?;
    let d_feat = kv_conv.d_in;
    let mut agg = Aggregator::new(classes, d_emb, d_ctx, d_feat, max_c, max_tau);
    agg.tok_emb = tok_emb;
    agg.seg_emb = seg_emb;
    agg.pos_emb = pos_emb;
    agg.cca.q_conv = q_conv;
    agg.cca.kv_conv = kv_conv;
    agg.cca.wq = r.f32v().ok_or_else(bad)?;
    agg.cca.wk = r.f32v().ok_or_else(bad)?;
    agg.cca.wv = r.f32v().ok_or_else(bad)?;
    agg.cca.wo = r.f32v().ok_or_else(bad)?;
    agg.cca.bo = r.f32v().ok_or_else(bad)?;
    agg.res_out = r.res().ok_or_else(bad)?;
    agg.res_res = r.res().ok_or_else(bad)?;
    let nf = r.u64().ok_or_else(bad)? as usize;
    let feat_ad: Vec<Adapter> = (0..nf).map(|_| r.adapter().ok_or_else(bad)).collect::<Result<_, _>>()?;
    let nc = r.u64().ok_or_else(bad)? as usize;
    let ctx_ad: Vec<Adapter> = (0..nc).map(|_| r.adapter().ok_or_else(bad)).collect::<Result<_, _>>()?;
    let has_opt = r.u64().ok_or_else(bad)?;
    let opt = if has_opt == 0 {
        None
    } else {
        let t = r.u64().ok_or_else(bad)?;
        let n = agg.adam_shapes().len();
        let mut m = Vec::with_capacity(n);
        let mut v = Vec::with_capacity(n);
        for _ in 0..2 * n {
            let x = r.f64v().ok_or_else(bad)?;
            if m.len() < n {
                m.push(x)
            } else {
                v.push(x)
            }
        }
        Some(FlatAdam { m, v, t })
    };
    Ok(Franken { itos, router, pid, agg, feat_ad, ctx_ad, steps, opt, rsa })
}

/// Краткий отчёт о состоянии — печатается при загрузке, чтобы было видно, что
/// именно обучено и подходит ли файл к текущему набору экспертов.
pub fn franken_report(f: &Franken, experts: usize) -> String {
    let mut s = format!(
        "Franken-MoPE: {} токенов словаря, роутер {}→{} ({} экспертов, γ={:.3}), агрегатор {} параметров, {} адаптеров признаков + {} контекста, шагов обучения {}",
        f.itos.len(),
        f.router.d_in,
        f.router.r,
        f.router.e,
        f.router.gamma,
        f.agg.params(),
        f.feat_ad.len(),
        f.ctx_ad.len(),
        f.steps
    );
    if f.router.e != experts {
        s.push_str(&format!("; ⚠️  экспертов в файле {}, а загружено {experts}", f.router.e));
    }
    if f.pid.t > 0 {
        s.push_str(&format!("; PID-шагов {}", f.pid.t));
    }
    s
}

// ============================================================
// int8-контейнер эксперта (MOPEBI01)
// ============================================================

/// Магия int8-бандла эксперта.
///
/// `MOPEXP02` хранит fp32-тензоры: 4 байта на параметр, 172 МБ на 43M. Но
/// рантайм MoPE первым делом квантует их в int8 (`bundle_to_blob`, симметричное
/// квантование на тензор: шкала = max|w|/127) — то есть fp32 в файле живёт ровно
/// до загрузки, и на пике в памяти оказываются ОБЕ копии. int8-контейнер хранит
/// уже то представление, в котором эксперт живёт дальше: 43 МБ вместо 172,
/// загрузка без fp32-копии и без прохода квантования.
///
/// Потери при этом ровно те же, что и при загрузке fp32-бандла: квантование
/// выполняется один раз при экспорте той же функцией `bundle_to_blob`, поэтому
/// распознавание побитово совпадает с fp32-бандлом (проверено сквозным прогоном).
pub const BLOB_MAGIC: &[u8; 8] = b"MOPEBI01";

/// Записать эксперта в int8-контейнере. Возвращает размер файла в байтах.
pub fn write_blob(
    path: &str,
    spec: &ExpertSpec,
    charset: &[String],
    blob: &ExpertBlob,
) -> std::io::Result<usize> {
    let mut b = Vec::with_capacity(blob.q.len() + (1 << 16));
    b.extend_from_slice(BLOB_MAGIC);
    put_str(&mut b, &spec.name);
    put_str(&mut b, &spec.source);
    put_str(&mut b, &spec.kind);
    for v in [
        spec.img_h,
        spec.img_w,
        spec.max_len,
        spec.hidden,
        spec.feat_dim,
        spec.classes,
        spec.pad,
        spec.sos,
        spec.eos,
        spec.rnn_layers,
    ] {
        put_u64(&mut b, v as u64);
    }
    put_u64(&mut b, charset.len() as u64);
    for t in charset {
        put_str(&mut b, t);
    }
    put_str(&mut b, &blob.name);
    put_u64(&mut b, blob.lens.len() as u64);
    for l in &blob.lens {
        put_u64(&mut b, *l as u64);
    }
    put_f32s(&mut b, &blob.scales);
    put_u64(&mut b, blob.q.len() as u64);
    b.extend_from_slice(crate::backend::as_bytes(&blob.q));
    // BN-статистика остаётся fp32: она не входит в манифест обучаемых параметров
    // и весит ~100 КБ на 28 свёрток, то есть ~0.2 % от int8-весов.
    put_f32s(&mut b, &blob.bn);
    std::fs::write(path, &b)?;
    Ok(b.len())
}

/// Прочитать int8-контейнер. Ошибка — если магия не та или файл оборван.
pub fn read_blob(path: &str) -> std::io::Result<(ExpertSpec, Vec<String>, ExpertBlob)> {
    let bytes = std::fs::read(path)?;
    if bytes.len() < 8 || bytes[..8] != BLOB_MAGIC[..] {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "это не int8-бандл эксперта (ожидалась магия MOPEBI01)",
        ));
    }
    let mut r = Rd { b: &bytes, p: 8 };
    let bad = || std::io::Error::new(std::io::ErrorKind::InvalidData, "int8-бандл оборван");
    let name = r.str().ok_or_else(bad)?;
    let source = r.str().ok_or_else(bad)?;
    let kind = r.str().ok_or_else(bad)?;
    let mut dims = [0usize; 10];
    for d in dims.iter_mut() {
        *d = r.u64().ok_or_else(bad)? as usize;
    }
    let n_tok = r.u64().ok_or_else(bad)? as usize;
    if n_tok > 1 << 20 {
        return Err(bad());
    }
    let mut charset = Vec::with_capacity(n_tok);
    for _ in 0..n_tok {
        charset.push(r.str().ok_or_else(bad)?);
    }
    let blob_name = r.str().ok_or_else(bad)?;
    let n_t = r.u64().ok_or_else(bad)? as usize;
    if n_t > 1 << 16 {
        return Err(bad());
    }
    let mut lens = Vec::with_capacity(n_t);
    for _ in 0..n_t {
        lens.push(r.u64().ok_or_else(bad)? as usize);
    }
    let scales = r.f32s().ok_or_else(bad)?;
    let n_q = r.u64().ok_or_else(bad)? as usize;
    let q = r.i8s(n_q).ok_or_else(bad)?;
    let bn = r.f32s().ok_or_else(bad)?;
    if scales.len() != n_t || lens.iter().sum::<usize>() != q.len() {
        return Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "int8-бандл рассинхронизирован: шкалы/длины не сходятся с данными",
        ));
    }
    let spec = ExpertSpec {
        name,
        source,
        kind,
        img_h: dims[0],
        img_w: dims[1],
        max_len: dims[2],
        hidden: dims[3],
        feat_dim: dims[4],
        classes: dims[5],
        pad: dims[6],
        sos: dims[7],
        eos: dims[8],
        rnn_layers: dims[9],
    };
    let blob = ExpertBlob { name: blob_name, lens, scales, q, bn };
    Ok((spec, charset, blob))
}

/// Краткий отчёт о содержимом int8-бандла — в том же стиле, что `spec.report()`.
pub fn blob_report(spec: &ExpertSpec, blob: &ExpertBlob) -> String {
    format!(
        "{} [int8-бандл] {} тензоров, {:.2} МБ int8 + {:.1} КБ BN-статистики",
        spec.report(),
        blob.lens.len(),
        blob.q.len() as f64 / 1e6,
        blob.bn.len() as f64 * 4.0 / 1e3
    )
}
