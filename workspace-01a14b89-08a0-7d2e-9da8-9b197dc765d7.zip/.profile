[ -f "/home/user/.cache/cargo/env" ] && . "/home/user/.cache/cargo/env"
[ -f "$HOME/.cargo/env" ] && . "$HOME/.cargo/env"
