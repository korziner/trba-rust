# trba-rust: почему CUDA-версия не запускалась, и что исправлено

Дата аудита: 2026-10-16 · Ревизия: `082fa77` ("CPU only, CUDA not tested") — единственный коммит в репозитории
Целевая карта: **sm_75** (Turing: RTX 20xx / T4 / Titan RTX) · CUDA Toolkit 12.9 (проверено), nvcc 12.9

---

## TL;DR

CUDA-версия **не запускалась никогда**, и причина не в логике ядер:

1. `cuda/kernels.cu` **не компилировался** — 3 ошибки (необъявленный `align16`, дублирующееся имя
   параметра `W`, некорректный `std::max<long long>(x, 1)`), а на этапе линковки выяснилась четвёртая:
   `static=cudart` — в тулките нет `libcudart.a`, только `libcudart_static.a`.
2. `build.rs` при любой ошибке nvcc **молча линковал CPU-бэкенд** (`cargo:warning=` легко пролистать),
   поэтому `cargo build` «проходил», а обучение шло на CPU.
3. В `src/qnet.rs` — реальном GPU-пути обучения — **4 аргумента ядер были host-указателями**
   (`Vec::as_ptr()`). На CPU-бэкенде «device»-указатели и есть host-указатели, поэтому баг невидим;
   на GPU это мгновенный `illegal memory access`.
4. Ещё 3 логических бага в ядрах, которые CPU-эталон не воспроизводит: неполное покрытие `C`
   в WMMA GEMM, чтение операндов за границей буфера и **расходящиеся `__syncthreads()`**
   в `grad_weight_fused_kernel` (дедлок/гонка почти на каждом слое SEResNet31).

Всё исправлено, патч: [`trba-cuda-fixes.patch`](trba-cuda-fixes.patch) (2411 вставок, 186 удалений, 12 файлов),
применяется к чистому клону upstream (`git apply --check` прошёл).

**Этап 2 — трафик через PCIe (ваш случай: PCIe 2.0 x4).** Исходный GPU-путь перекачивал
**797 МБ на батч** (b=32, 32×1024) — это ~0.6–0.8 с на батч только на пересылки, независимо от
того, сколько считает GPU. Три правки (maxpool на устройстве, `grad_input` на int8-весах,
оптимизатор+реквантизация на устройстве) снизили это до **~19 МБ на батч**, замер
`TRBA_PCIE_COUNTER=1`: **361.42 → 0.64 МБ/батч** в weight-части бюджета. Попутно найдены и
исправлены ещё три настоящих бага: CPU-бэкенд **собирался без OpenMP** (однопоточно),
глобальная арена workspace **выдавала двум живым `GpuWorkspace` один и тот же указатель**,
и device-реквантизация не обнуляла дополненные строки весов. Подробности — раздел 6.

---

## 1. Багфиксы, которые уже были в репо (история в комментариях, не в git)

Git-история состоит из одного коммита, поэтому «багфиксы» здесь — это задокументированные в коде
исправления предыдущих версий. Они важны: именно они объясняют, почему код выглядит так странно,
и их нельзя откатывать.

| # | Что было | Что сделано | Где задокументировано |
|---|----------|-------------|----------------------|
| 1 | im2col в backward: `[256,512,4,16]` × 3×3 → **38.6 ГБ**, `cudaMalloc` падал, `CHECK_CUDA` только печатал ошибку, следующее ядро разыменовывало null → «illegal memory access (kernels.cu:112)» | Три **fused**-ядра `grad_W` / `grad_bias` / `grad_input`, читают активации и `grad_output` напрямую, col-матрица не материализуется | `cuda/kernels.cu:10-19`, `src/conv2d.rs:8-14` |
| 2 | `CHECK_CUDA` печатал ошибку и продолжал → ошибка «липкая», падение в случайном месте | `CHECK_CUDA` = `abort()`, плюс `CHECK_LAUNCH()` сразу после запуска, чтобы сообщение называло виновное ядро | `cuda/kernels.cu:20-22, 35-48` |
| 3 | `gemm_fp32` запускал `dim3 grid((N+15)/16,(M+15)/16)`; `gridDim.y ≤ 65535` → при M > 1 048 560 ядро **молча не запускалось** | Все запуски — 1-D grid-stride (`grid_for`, потолок 262144 блоков) | `cuda/kernels.cu:19-21`, тест `fp32_gemm_handles_huge_k_without_grid_overflow` |
| 4 | В maxpool backward передавали host-`Vec<f32>` | Только device-указатели; для CPU-maxpool оставлен `_host`-вариант | `cuda/kernels.cu:23-24, 767-772` |
| 5 | `#if defined(__CUDA_ARCH__)` вокруг host- launcher'ов → nvcc в host-проходе компилировал не ту ветку | Доступность определяется версией тулкита (`__CUDACC_VER_MAJOR__`), диспетчеризация — compute capability в рантайме | `cuda/kernels.cu:93-100` |
| 6 | Epilogue свёрки трактовал выход как **NHWC** (`i % C`, `i / C`) → мусор после первого conv | NCHW: `b = i/(C*hw)`, `oc = (i/hw)%C`, `row = b*hw + i%hw` | `cuda/kernels.cu:437-441`, `cuda/cpu_backend.cpp:160-166` |
| 7 | WMMA-ядро писало целые 16×16 тайлы с leading dimension `N` → выход за конец `C` при `N % 16 != 0` | `stage[64][64]` в shared memory + clip-on-store | `cuda/kernels.cu:88-92` |
| 8 | `launch_conv_epilogue` получал `acc_ld = align16(N)`, хотя GEMM пишет компактный `[M,N]` → чтение за пределами и мусор для `out_channels % 16 != 0` | `acc_ld = N` | `src/conv2d.rs:229-238` |
| 9 | `weight_int8` дополнительно транспонировали в `[col_cols][Cout]` → GEMM считал другую функцию (сеть «работала», но не то) | `[Cout][Cin·kH·kW]` — это и есть `Bt[N,K]`, никакой транспозиции | `src/conv2d.rs:88-96` |
| 10 | `ar crus` с длинными/абсолютными именами членов → rustc: «Unsupported archive identifier» | `ar` запускается внутри `OUT_DIR` с голыми именами файлов + удаление старого архива | `build.rs:92-104` |
| 11 | Хвост строк col-матрицы `[rows, align16(rows))` содержал мусор → `lrintf(NaN)` = UB | Хвост зануляется до запуска ядра | `cuda/kernels.cu:524-533`, `cpu_backend.cpp:214-217` |
| 12 | `blockDim` в `grad_bias` не степень двойки → shared-memory редукция ломалась | Округление вниз до степени двойки | `cuda/kernels.cu:660-666` |
| 13 | Bias обновлялся Muon'ом → нормировка матрицы на векторе «проглатывала» градиент | Bias — обычный SGD; у Muon добавлен cap `scale ≤ 10` | `src/conv2d.rs:118-138, 411-417` |
| 14 | `LD_LIBRARY_PATH=cuda/ ./target/release/...` | Статическая линковка всего | `build.rs:1-9`, `Cargo.toml:20-25` |
| 15 | LTO тройной расход памяти rustc без выигрыша | `lto = false`, отдельный профиль `release-lto`, `debug = 1` для cuda-gdb | `Cargo.toml:27-40` |

---

## 2. Найдено и исправлено сейчас

### A. Блокировщики сборки (именно они не давали запустить CUDA)

| # | Файл:строка | Проблема | Исправление |
|---|-------------|----------|-------------|
| A1 | `kernels.cu:230, 343` | `align16` **не объявлен** в .cu (есть только в `cpu_backend.cpp:75`) → `error: identifier "align16" is undefined` → nvcc падает → откат на CPU | Добавлены `align16`, `ceil_div` (`__host__ __device__`), `ll_max/ll_min` |
| A2 | `kernels.cu:709` | `grad_input_fused_kernel(const float *W, ..., int W, ...)`: **дублирующееся имя параметра** → `error: duplicate parameter name` + «expression must have arithmetic type» в `H * W` | Указатель весов переименован в `Wt` |
| A3 | `kernels.cu:238, 350, 663` | `std::max<long long>(x, 1)` / `std::min<long long>(x, 8192)`: с одним явным шаблонным аргументом nvcc выбирает `initializer_list`-перегрузку → `error: expression preceding parentheses of apparent call must have (pointer-to-) function type` | Заменено на `ll_max`/`ll_min` |
| A4 | `build.rs:186` | `cargo:rustc-link-lib=static=cudart` → **`libcudart.a` в тулките не существует** (есть `libcudart_static.a` и `libcudart.so`) → `rust-lld: error: unable to find library -lcudart` → снова откат на CPU | `static=cudart_static` + `static=culibos` (статический runtime тянет его pthread/rt-хелперы) |
| A5 | `build.rs` | glibc ≥ 2.41 (Debian 13, Ubuntu 25.10+) объявляет `sinpi/cospi` с динамической спецификацией исключений, CUDA ≤ 12.9 — `noexcept(true)` → host-проход падает. Debian-овский g++ по умолчанию определяет `_GNU_SOURCE`, который это объявление и включает | Авто-ретрай nvcc с `-Xcompiler -U_GNU_SOURCE` (с предупреждением); сначала пробуется обычный запуск |
| A6 | `build.rs:main()` | При любой ошибке — **тихий** откат на CPU: пользователь уверен, что тренирует на GPU | `TRBA_REQUIRE_CUDA=1`: build.rs **панкует** вместо отката + `src/main.rs` отказывается стартовать, если слинкован не CUDA-бэкенд. Обычный откат теперь печатает заметный баннер |
| A7 | `build.rs:120-129` | PTX-`gencode` добавлялся **дважды** (`iter().max()` и `last()`); `max()` по строкам даёт `"89" > "100"` → для Blackwell PTX собирался не от той архитектуры | `gencode_flags()`: числовое сравнение (`arch_num`), PTX ровно один раз |

**Проверено:** `nvcc 12.9 -gencode=arch=compute_75,code=sm_75 -Xcompiler -Wall` — 0 ошибок,
0 предупреждений; `cargo build --release --all-targets` с CUDA-бэкендом линкуется;
`nm`/`strings` подтверждают встроенный SASS `sm_75`.

### B. Логика ядер (CPU-эталон её не воспроизводит — на GPU это мусор или дедлок)

| # | Ядро | Проблема | Эффект на GPU | Исправление |
|---|------|----------|---------------|-------------|
| B1 | `gemm_int8_wmma_kernel`, `gemm_fp16_wmma_kernel` | `total_tiles = (Np/64) * (Mp/64)` — **floor**, а операнды выровнены только до 16 | Для `M<64` или `N<64` → `total_tiles = 0`, ядро **не пишет ничего**; для `N=96` (голова классификатора) теряются 5120 из 9216 элементов; `M=100` → хвост строк не считается | `ceil_div(Mp,64) * ceil_div(Np,64)` и в ядре, и в лаунчере |
| B2 | там же | Чтение `A`/`Bt` в shared memory **без границы по строкам**; у fp16-ядра границ не было вообще (ещё и по `K`) | Чтение за концом буфера → `illegal memory access` (операнды имеют размер `align16(M)·align16(K)`, а тайл 64×32) | Guards `row0+r < Mp`, `col0+r < Np`, `k0+c+8 <= Kp`; вне границ — нули |
| B3 | `grad_weight_fused_kernel` | `for (ci = tid; ci < col_cols; ci += 256)` с `__syncthreads()` **внутри**: потоки делают разное число итераций, когда `col_cols % 256 != 0` | Потоки, закончившие работу, не приходят на барьер → дедлок (pre-Volta) или гонка по `sgo` (Volta+). Реальные слои: `Cin=3`→27, `Cin=32`→288, `Cin=128`→1152 (расходилось 128 из 256 потоков); безопасны только 256 и 512 | Фиксированное число «раундов» `ceil_div(col_cols, nthreads)`, у каждого потока флаг `active`; барьеры выполняются всеми потоками одинаковое число раз |
| B4 | `launch_gemm_fp16` | Проверка `p.major >= 6 \|\| (5 && minor>=3)` — half-WMMA существует только с **7.0** | На Pascal запуск ядра, для которого нет бинарника | `p.major >= 7` |
| B5 | `cuda_memcpy_dtod` | Игнорировал `stream`, использовал блокирующий `cudaMemcpy` | Сериализация всего устройства против очереди слоя | `cudaMemcpyAsync(..., stream)` |
| B6 | `launch_im2col_pad`, `launch_conv_backward_grad_weight` | При плохих размерах — тихий `return`, выходной буфер остаётся с прошлыми данными | Продолжает обучение на мусоре, падает позже и «не там» | Макрос `REQUIRE_SHAPE` — `fprintf` + `abort` (в духе «CHECK_CUDA is fatal») |

### C. Rust-сторона: host-указатели в ядрах (`src/qnet.rs` — путь обучения `SEResNetQ`)

| # | Строка | Вызов | Что передавалось |
|---|--------|-------|------------------|
| C1 | 380 | `launch_gemm_int8` | `self.w_q_pad.as_ptr()` — **B-операнд GEMM** |
| C2 | 429-430 | `launch_bn_apply` | `self.bn.gamma.as_ptr()`, `self.bn.beta.as_ptr()` |
| C3 | 503 | `launch_bn_bwd_dx` | `self.bn.gamma.as_ptr()` |
| C4 | 586 | `launch_conv_backward_grad_input` | `self.w.as_ptr()` — fp32-веса |

На CPU-бэкенде `cuda_malloc` = `malloc`, поэтому все четыре вызова работают. На CUDA каждый из них —
обращение ядра к адресу хоста → `an illegal memory access was encountered`, причём ошибка липкая и
прилетает в следующем `cudaMalloc` (ровно тот сценарий, который описан в шапке `kernels.cu`).

**Исправление:** у `Scratch` появились `upload_f32()` / `upload_i8()` (копируют host-вектор в слот
арены и возвращают device-указатель) и новые слоты `S_WQ` (i8, 2), `S_WF32` (f32, 14),
`S_BNG`/`S_BNB` (f32, 15/16). Все четыре вызова теперь получают device-указатели.
Порядок в стриме соблюдён: `cudaMemcpyAsync` ставится в очередь раньше ядра.

Проверка: скрипт-сканер аргументов всех `launch_*` вызовов — **0** host-указателей осталось
(до правок — 4).

---

## 3. Что проверено в этой сессии (GPU в песочнице нет)

| Проверка | Результат |
|----------|-----------|
| `nvcc 12.9 -gencode sm_75 -Xcompiler -Wall -c cuda/kernels.cu` | ✅ 0 ошибок, 0 предупреждений |
| fatbin `75;86;89` + один PTX | ✅ собирается |
| `TRBA_REQUIRE_CUDA=1 cargo build --release --all-targets` (CUDA-бэкенд) | ✅ компиляция + линковка (`cudart_static`, `culibos`) |
| Бинарник действительно CUDA-сборка | ✅ падает `[CUDA FATAL] kernels.cu:101 cudaGetDevice` (нет драйвера), а не работает на CPU |
| `cargo test --release` на CPU-бэкенде | ✅ **23/23** (17 прежних + 6 новых на device-ядра), стабильно в 4 прогонах подряд |
| Smoke-прогон на CPU-бэкенде | ✅ `--smoke 2 -b 2 --img-w 128`: loss конечный, `✅ smoke завершён`, 12.5–14.4 c (было 24 c до фикса OpenMP) |
| Тот же smoke с `TRBA_HOST_CONV_ADAM=1` (старый host-путь) | ✅ работает, трафик 201.13 МБ/батч |
| Побитовое совпадение device-Adam и `src/opt.rs` | ✅ `device_adam_matches_host_adam_bit_for_bit` (w/m/v совпадают точно) |
| Device-реквантизация == `ConvQat::requantize` | ✅ масштаб и все int8-байты, включая дополненные строки/столбцы |
| Device-maxpool == host-эталон с индексами | ✅ значения и рассеяние градиента, включая разрешение ничьих |
| Замер трафика `TRBA_PCIE_COUNTER=1` | ✅ 361.42 → 201.13 → **0.64 МБ/батч** (см. 6.3) |
| `g++ -O3 -Wall -Wextra -fopenmp -c cuda/cpu_backend.cpp` | ✅ 0 ошибок, 0 предупреждений (раньше с `-fopenmp` не собиралось вовсе) |
| `tools/kernel_logic_check` (эмуляция индексной арифметики ядер на CPU, ~2 c) | ✅ **16/16** |
| Тот же чекер на **старой** логике (контроль чувствительности) | ❌ 6 из 9 форм GEMM падают: `M=16/N=16` → 256/256 элементов не записаны, `N=96` → 5120/9216, `M=63,N=65` → 63/4095 |
| `git apply --check` патча к чистому клону upstream | ✅ применяется без конфликтов |
| Свежий клон + патч: nvcc sm_75, `cargo test` 23/23, `make logic` 16/16, CUDA-линковка | ✅ всё зелёное отдельным прогоном (12 файлов, +2411/−186) |

### Что проверить уже на GPU (эмулятор этого не покрывает)
* реальные числа tensor-core WMMA `s8s8s32` на sm_75 (эмулятор считает обычной арифметикой);
* фактические гонки/дедлоки (эмулятор проверяет только расписание барьеров);
* производительность и потребление памяти.

Именно это делает `scripts/run_cuda_smoke.sh`: сначала `cargo test` (23 теста, на GPU — секунды),
потом 2 smoke-батча, опционально под `compute-sanitizer --tool memcheck`.
Плюс стоит посмотреть на реальное время батча и на фактический трафик (`PCIE=1`) — цифры из
раздела 6.3 получены на CPU-бэкенде, на GPU они должны совпасть по объёму.

---

## 4. Как запустить на вашей машине (sm_75)

```bash
git clone https://github.com/korziner/trba-rust && cd trba-rust
git apply /path/to/trba-cuda-fixes.patch        # или возьмите готовую копию trba-rust/

# 0) среда: нужен CUDA Toolkit (nvcc) и драйвер
nvidia-smi --query-gpu=name,compute_cap --format=csv,noheader   # ожидаем 7.5

# 1) только юнит-тесты ядер — самый быстрый способ отладки (секунды)
ARCH=75 TESTS_ONLY=1 ./scripts/run_cuda_smoke.sh

# 2) тесты + короткий smoke-прогон (датасет не нужен)
ARCH=75 ./scripts/run_cuda_smoke.sh

# 3) поймать OOB/гонки (медленно, зато честно)
SANITIZE=1 BATCH=1 IMG_W=64 SMOKE=1 ./scripts/run_cuda_smoke.sh

# 3b) замерить фактический трафик через PCIe (итог печатается на выходе)
PCIE=1 SMOKE=4 ARCH=75 ./scripts/run_cuda_smoke.sh

# 4) полный тренинг
TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release
./target/release/trba-rust train.csv val.csv exp --batch-size 32 --epochs 100
```

Эквивалент вручную:
```bash
TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release
cargo test --release                      # 17 тестов на CUDA-бэкенде
./target/release/trba-rust --smoke 2 --batch-size 2 --img-h 32 --img-w 128 \
    --max-len 24 --charset charset.txt exp_smoke
```

Переменные окружения, которые появились на этапе 2:

| Переменная | Действие |
|---|---|
| `TRBA_PCIE_COUNTER=1` | печатает суммарные байты H2D/D2H на выходе (работает в обоих бэкендах) |
| `TRBA_HOST_CONV_ADAM=1` | вернуть оптимизатор conv-весов на хост: −643 MiB VRAM, +201 МБ/батч по PCIe |
| `TRBA_GRAD_INPUT_FP32=1` | считать `grad_input` по fp32-весам (эталон для сравнения): +161 МБ/батч |

Первая строка запуска обязана быть `🚀 TRBA (Rust + INT8 QAT) | бэкенд: cuda | NVIDIA …`.
Если там `бэкенд: cpu` — сборка ушла на CPU; с `TRBA_REQUIRE_CUDA=1` она вместо этого упадёт
с внятной ошибкой.

Проверить логику ядер вообще без GPU и без тулкита (2 секунды, только g++):
```bash
make -f tools/Makefile logic
```

---

## 5. Замечания по производительности (важно для ожиданий от ускорения)

Правки делают CUDA-путь **корректным**, но архитектура портирования ограничивает ускорение:

1. **Не всё на GPU.** `src/rnn.rs` (BiLSTM), `src/attn.rs` (attention-декодер), `src/ctc.rs`,
   SE-блоки (`LinearF`) и maxpool2×2 — чисто host-код, они не вызывают CUDA вообще.
   GPU считает только conv GEMM / im2col / BN / квантование.
2. **Много мелких синхронизаций.** `quantize_owned` / `relu_quant_owned` делают `d2h` + `stream.sync()`
   на каждый активационный тензор (нужно узнать max-abs на хосте), `ConvQat::forward` скачивает
   `mean/var`, SE-блоки гоняют пул на хост и обратно. Байт здесь мало, но каждая синхронизация
   сериализует конвейер. *(Скачивание активаций для host-maxpool убрано — см. раздел 6.)*
3. ~~**Веса едут на устройство каждый батч**~~ — **исправлено в разделе 6**: веса, их градиенты и
   Adam-состояние теперь живут на GPU, через PCIe уходит 8 байт на батч (сумма квадратов градиентов
   для глобального клипа) и 4 байта на слой (масштаб квантования). Цена — ~643 MiB видеопамяти,
   откат — `TRBA_HOST_CONV_ADAM=1`.
4. **`cudaFree` при росте слота `Scratch`** — неявная синхронизация устройства. После первого батча
   размеры стабилизируются, дальше бесплатно.
5. **Память.** `NetTrace` хранит `x`, `y`, `mean`, `var` каждого слоя до конца backward
   (28 слоёв × 2 тензора активаций). Начинать стоит с `--batch-size 2..4` и `--img-w 128..256`,
   а не с `32 × 32×1024`.
6. **Недетерминизм.** `bn_stats`, `bn_bwd_sums` и `grad_bias` используют `atomicAdd` по float —
   порядок сложения меняется от запуска к запуску, последние биты результата могут отличаться.
   Для сверки «CPU vs GPU бит в бит» это надо учитывать.

---

## 6. Этап 2: PCIe-трафик (PCIe 2.0 x4)

Задача: «у меня PCIe 2 x4, поэтому важно уменьшить трафик». На такой шине реалистичная
пропускная способность — **1.0–1.3 ГБ/с** для pageable-памяти и **1.7–2.0 ГБ/с** для pinned
(`cudaHostAlloc`). Это в 10 раз медленнее PCIe 3.0 x16, поэтому объём пересылок, а не скорость
GPU, определяет время батча.

### 6.1 Исходный бюджет на батч (b=32, img 32×1024, 28 conv-слоёв, 42.15M параметров)

| Что ехало | Направление | МБ/батч |
|---|---|---|
| `pool_idx` (u64-индексы maxpool, обратно в backward) | H2D | **256.0** |
| `w` fp32 — веса для `grad_input` | H2D | **160.8** |
| `grad_W` int32 — накопление градиента на хосте | D2H | **160.8** |
| `q1` int8 — активации для host-maxpool | D2H | **128.0** |
| `w_q_pad` int8 — операнд GEMM | H2D | **40.2** |
| pooled int8 (результат host-maxpool) | H2D | **32.0** |
| feat `[B,T,512]` в RNN и `d_feat` обратно | D2H+H2D | 16.0 |
| изображения | H2D | 3.0 |
| **Итого** | | **796.8** |

При 1.15 ГБ/с это **~0.7 с на батч** только на пересылки — плюс `pool_idx` требовал **256 МБ
оперативной памяти** на хосте.

### 6.2 Три правки

**Fix 1 — maxpool 2×2 на устройстве (−416 МБ).** Новые ядра `launch_maxpool2x2_forward_i8` и
`launch_maxpool2x2_backward_i8` работают прямо по int8-активациям. Обратное ядро **пересчитывает
argmax** из того же `q1`, который и так хранится в трейсе (нужен для ReLU-маски), поэтому тензор
индексов не существует вообще: ни 256 МБ по шине, ни 256 МБ в оперативке. Правило разрешения
ничьих совпадает с host-эталоном `maxpool2x2_with_indices` (первый строгий максимум в порядке
(0,0),(0,1),(1,0),(1,1)) — это покрыто тестом. Ядра пишут **каждый** элемент `dx`, поэтому не
нужны ни атомики, ни memset. Требование: чётные H и W ≥ 2 (иначе `REQUIRE_SHAPE` — громкий
abort вместо тихой порчи данных).

**Fix 2 — `grad_input` читает int8-веса (−160.8 МБ).** `launch_conv_backward_grad_input_i8`
берёт операндом ту же fake-quant матрицу int8, которая уже лежит на устройстве (её использовал
прямой GEMM), плюс её масштаб — накопление идёт в fp32, масштаб применяется один раз в конце.
Это ещё и корректнее для QAT: dX считается из тех весов, которые реально применил forward.
Эталонный fp32-путь сохранён под флагом `TRBA_GRAD_INPUT_FP32=1`.

**Fix 3 — оптимизатор и реквантизация на устройстве (−201 МБ).** `w`, `g`, `m`, `v` всех
28 conv-слоёв живут на GPU (`struct DevOpt`):

* `launch_grad_accum_i32` — накопление int32-результата GEMM в fp32-градиент (вместо скачивания
  160.8 МБ и host-цикла);
* `launch_sum_sq_add_f32` — вклад слоя в сумму квадратов градиентов (f64-атомик); хост читает
  **8 байт** и собирает глобальную норму вместе с host-параметрами, поэтому
  `clip_grad_norm_(params, 5.0)` считается по всем параметрам, как и раньше;
* `launch_adam_f32` — шаг Adam с **той же арифметикой, что и `src/opt.rs`** (промежуточные f64,
  хранение f32), коэффициент клиппинга встроен в ядро так, что воспроизводит host-умножение
  `*x *= f` в f32 бит в бит;
* `launch_max_abs_f32` + `launch_quantize_pad_i8` — реквантизация весов прямо на устройстве;
  обратно приходит только масштаб (4 байта на слой, он нужен как скаляр для эпилога conv).

Цена: **~643 MiB видеопамяти** (42.15M × 16 байт). Если её не хватает — `TRBA_HOST_CONV_ADAM=1`
возвращает старый host-путь (+201 МБ/батч по шине, зато без этих 643 MiB).
Хостовые копии весов остаются тенями: они синхронизируются с устройства **только при сохранении
чекпойнта** (`sync_conv_shadows`) и заливаются обратно при `--resume` (`upload_conv_weights`),
формат чекпойнта не изменился.

### 6.3 Замер (не оценка)

`TRBA_PCIE_COUNTER=1` печатает на выходе фактические байты, прошедшие через `cuda_memcpy_h2d/d2h`
(в обоих бэкендах). Прогон с `--smoke 2` и `--smoke 4`: разница, делённая на 2, — трафик одного
батча без разовых расходов. CPU-бэкенд, b=2, 32×128:

| Режим | МБ/батч |
|---|---|
| host-Adam + fp32 `grad_input` (поведение этапа 1) | **361.42** |
| host-Adam + int8 `grad_input` (Fix 2) | **201.13** |
| device-Adam + device-реквантизация (Fix 3, по умолчанию) | **0.64** |

Весовая часть бюджета не зависит ни от размера батча, ни от размера картинки, поэтому эти числа
переносятся на b=32/32×1024 напрямую; к ним остаётся добавить активационную часть
(изображения 3 МБ + feat/d_feat 16 МБ ≈ 19 МБ):

| | было (797 МБ) | стало (~19 МБ) |
|---|---|---|
| PCIe 2.0 x4, pageable | 0.61–0.80 с | **15–19 мс** |
| PCIe 2.0 x4, pinned | 0.40–0.47 с | **10–11 мс** |
| PCIe 3.0 x16 | ~66 мс | ~1.6 мс |

Свой прогон можно замерить так: `PCIE=1 SMOKE=4 ARCH=75 ./scripts/run_cuda_smoke.sh`.

### 6.4 Три бага, найденных попутно (все исправлены)

1. **CPU-бэкенд собирался без OpenMP, то есть однопоточным.** В `launch_conv_epilogue`
   объявление `const long long hw` стояло между `#pragma omp parallel for` и циклом — с `-fopenmp`
   это ошибка компиляции («for statement expected before 'const'»), а `build.rs` в таком случае
   **молча** пересобирал файл без OpenMP. То есть все 40 `#pragma omp` в эталонном бэкенде не
   работали никогда. Объявление перенесено, а `build.rs` теперь печатает громкое предупреждение
   с первыми строками ошибки компилятора, если откат всё-таки случился.
   Замер: CPU smoke-прогон **24 с → 12.5–14.4 с** (~1.7× на 2 ядрах). Это напрямую относится к
   вашей исходной жалобе на долгие итерации на CPU.
2. **Глобальная арена workspace выдавала один указатель всем.** `trba_workspace_acquire`
   возвращал один и тот же `g_workspace` на каждый вызов, а при запросе большего размера
   освобождал его из-под живых пользователей. `GpuWorkspace` используется не только тестами, но и
   эталонными реализациями в `conv2d.rs`, `linear.rs`, `bilstm.rs` — два живых объекта молча
   перезаписывали друг друга (на GPU это ещё и use-after-free). Проявилось как «плавающие»
   падения новых тестов при параллельном запуске (`cargo test` гоняет тесты в несколько потоков).
   Заменено на настоящий пул блоков с `Drop for GpuWorkspace` и спинлоком (`std::mutex` нельзя:
   nvcc компилирует файл с `-U_GNU_SOURCE`, а без него `<mutex>` в glibc 2.41 не собирается).
3. **Device-реквантизация не обнуляла дополненные строки весов.** WMMA GEMM читает операнд до
   `align16(rows)`, и host-путь гарантировал нули там через `vec![0i8; rp * cp]`. Первая версия
   `launch_quantize_pad_i8` писала только `rows * kp` элементов, поэтому на GPU в дополненных
   строках оказался бы мусор из `cudaMalloc` (на CPU-бэкенде невидимо — там память переиспользуется
   от предыдущего теста). Исправлено и покрыто тестом `device_requantize_matches_host_requantize`.

Отдельно замечено (не менял): `--seed` влияет только на генератор данных — инициализация весов
везде идёт через `rand::thread_rng()`, поэтому два прогона с одинаковым `--seed` **не**
воспроизводят друг друга. Для отладки это стоит починить отдельно.

### 6.5 Что осталось и что делать дальше

* **~19 МБ/батч** активационного трафика: изображения (3 МБ) и `feat`/`d_feat` (16 МБ) — их не
  убрать, RNN/attention/CTC живут на хосте. Дальше помогает только pinned-память
  (`cudaHostAlloc`) под эти буферы: на PCIe 2.0 x4 это ~1.8× к оставшимся 15–19 мс.
* **Мелкие синхронизации**: SE-блоки (12 шт.) делают avgpool → d2h → host `LinearF` → h2d со
  `stream.sync()`, и каждая активация качает max-abs (4 байта + sync). Байт мало, но конвейер
  рвётся ~40 раз на батч. Лечится переносом SE-линейных слоёв на GPU.
* **Adam в f64** на sm_75 идёт на 1/32 скорости fp32: ~3–6 мс на батч для 42M параметров. Это
  осознанная цена побитового совпадения с `src/opt.rs`; если когда-нибудь станет узким местом —
  перевод на f32-арифметику (как в PyTorch) сэкономит почти всё, но слегка изменит численность.
* **Видеопамять**: ~643 MiB на состояние оптимизатора плюс трейсы активаций (28 слоёв × `x`,`y`).
  Начинать стоит с `--batch-size 2..4`; при нехватке памяти — `TRBA_HOST_CONV_ADAM=1`.

---

## 7. Состав поставки

| Файл | Что это |
|------|---------|
| `trba-cuda-fixes.patch` | Все правки одним патчем (git-формат, `git apply` / `patch -p1`) |
| `trba-rust/` | Полная рабочая копия репозитория с правками (собрана и протестирована здесь) |
| `trba-rust/scripts/run_cuda_smoke.sh` | Сборка CUDA + тесты ядер + smoke-прогон (+ `compute-sanitizer`) |
| `trba-rust/tools/kernel_logic_check.cpp`, `tools/Makefile` | Эмуляция индексной арифметики ядер на CPU — 16 проверок за 2 секунды, GPU не нужен |
| `trba-rust/README.md` | Разделы сборки/запуска на GPU, переменные окружения, трафик |

Изменённые файлы (этапы 1+2, `git diff --numstat`):

| Файл | +/− | Что менялось |
|---|---|---|
| `cuda/kernels.cu` | +534/−54 | блокировщики сборки, WMMA-тайлинг, `__syncthreads`, maxpool/grad_input/оптимизатор на устройстве, пул workspace, счётчик трафика |
| `src/tests.rs` | +357/−0 | 6 новых тестов: device-maxpool (включая ничьи), int8 `grad_input`, device-реквантизация, побитовый Adam, весь device-конвейер оптимизатора |
| `cuda/cpu_backend.cpp` | +278/−16 | CPU-зеркала всех новых ядер (по ним идёт проверка без GPU), фикс OpenMP, пул workspace |
| `src/qnet.rs` | +341/−53 | device-пути maxpool/grad_weight/grad_input/Adam/реквантизации, `DevOpt`, resident int8-веса |
| `build.rs` | +118/−47 | громкий отказ вместо тихого CPU-фолбэка, `-gencode`, `-U_GNU_SOURCE`, `cudart_static`, предупреждение про OpenMP |
| `scripts/run_cuda_smoke.sh` | +144/−0 | сборка+тесты+smoke на вашей машине, `SANITIZE=1`, `PCIE=1` |
| `src/main.rs` | +82/−13 | runtime-проверка бэкенда, `host_params()`, клип+Adam с device-частью, тени весов в чекпойнтах, баннер про VRAM |
| `README.md` | +67/−0 | как собрать и запустить на GPU |
| `src/backend.rs` | +45/−1 | объявления новых `extern "C"` + `Drop for GpuWorkspace` |
| `tools/kernel_logic_check.cpp`, `tools/Makefile` | +426/−0 | проверка индексной арифметики ядер без GPU |
| `src/opt.rs` | +19/−2 | `sum_sq()` и `bias_correction()` для device-шага |
| `src/autotune.rs` | +918/−0 | optuna-подобный подбор (batch_size, img_w) по сетке EAST, пробы дочерними процессами, отчёт JSON, 9 тестов |
| `src/lib.rs` | +1/−0 | `pub mod autotune;` |

Итого по патчу `trba-cuda-fixes.patch`: **14 файлов** (состав — в конце раздела 9). Раздел 8 описывает правки
четвёртого этапа: порядок обхода блоков в бэкенде QAT, две индексные ошибки в ядрах,
`TRBA_CUDA_DEBUG_SYNC=1` и `--autotune`.

## 8. Этап 4: ваши 4 падения тестов, `illegal memory access` при batch ≥ 3 и подбор размеров

### 8.1 Главный баг: бэкворд CNN шёл по блокам не в том порядке (`src/qnet.rs`)

`SEResNetQ::backward` обходит 11 SE-блоков и для каждого берёт трейс, записанный на прямом
проходе. Список строился как `layer4, layer3, layer2, layer1` и затем обходился **в обратную
сторону** (`.enumerate().rev()`), а индекс трейса считался как `bi = n_blocks - 1 - i`. Эти две
инверсии не сокращаются: первым посещался блок `layer1.0`, а ему доставался трейс `blocks[0]` —
тоже `layer1.0`, но **градиент в этот момент принадлежал выходу `layer4.2`**.

Дальше по цепочке пары расходятся всё сильнее:

| посещение | блок | трейс | формы |
|---|---|---|---|
| 1 | `layer1.0` | `blocks[0]` = layer1.0 | градиент 512×H4×W4, трейс ждёт 256×H1×W1 — **расхождение** |
| 2–3 | `layer2.1`, `layer2.0` | `blocks[1]`, `blocks[2]` | формы совпадают, данные чужие |
| 4 | `layer3.4` | `blocks[3]` = layer3.0 | `in_c` 512 против 256, stride 1 против 2 → `n_in` в 4 раза больше |
| 9–11 | `layer4.2/1/0` | `blocks[8..10]` = layer2.0/2.1/1.0 | каналы 512 против 256 — **расхождение** |

Последствия ровно те, что вы видели:

* `n_out` берётся из буфера градиента (`gv.len / 4`), а `BasicBlock::backward` деквантует
  `dq_out` по `n_out` из трейса. При расхождении чтение идёт **за пределами int8-буфера**:
  на GPU это `an illegal memory access was encountered`, на CPU — молчаливое чтение чужой
  кучи (поэтому «CPU-версия работает»).
* Почему падало только при `batch ≥ 3`: при малых батчах выход за границы попадает в соседние
  живые аллокации CUDA, при больших — уезжает за конец отображённой VA. Плюс `--img-w 256`
  увеличивает тензоры в 4 раза относительно `--img-w 128`.
* Все градиенты свёрток считались по чужим активациям, то есть обучение CNN шло «в никуда»
  независимо от батча: loss ≈ 5.0 и не снижался.

**Как найдено.** В песочнице нет GPU, поэтому CPU-бэкенд (те же размеры буферов задаёт тот же
Rust-код) собран с AddressSanitizer:

```
CXX='g++ -fsanitize=address -g' RUSTFLAGS="-C link-arg=-fsanitize=address -C link-arg=-lasan" \
    TRBA_FORCE_CPU=1 CARGO_TARGET_DIR=target-asan cargo build --release
LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libasan.so.8 ./target-asan/release/trba-rust \
    --smoke 1 --batch-size 4 --img-h 32 --img-w 256 --max-len 32 --charset charset.txt train.csv
```

```
ERROR: AddressSanitizer: heap-buffer-overflow
READ of size 1 at 0x7fd9b33aa800 thread T1
    #0 launch_dequant_i8_f32._omp_fn.0 cuda/cpu_backend.cpp:849
0x7fd9b33aa800 is located 0 bytes after 262144-byte region
allocated by thread T0 here:
    #3 DevBuf::new src/backend.rs:189
    #4 SEResNetQ::backward src/qnet.rs:1427      <-- let dqi = DevBuf::new(n_out);
```

262144 = 1·512·4·32·… ровно размер градиента layer4, а читали из него как из тензора layer1.

**Исправление** — список строится в точном обратном порядке прямого прохода (каждый слой
реверсируется внутри), и добавлен инвариант, который ломает сборку теста при любой будущей
рассинхронизации:

```rust
for layer in [&mut self.layer4, &mut self.layer3, &mut self.layer2, &mut self.layer1] {
    layers.extend(layer.iter_mut().rev());
}
for (k, blk) in layers.iter_mut().enumerate() {
    let bi = n_blocks - 1 - k;
    let expect = btr.b * btr.c * btr.h_out * btr.w_out;
    assert_eq!(gv.len / 4, expect, "backprop block/trace pairing: …");
```

Проверка, что инвариант действительно ловит старый порядок (откатил две строки, запустил тест):

```
panicked at src/qnet.rs:1442: assertion `left == right` failed:
  backprop block/trace pairing: incoming gradient has 16384 elements,
  but trace 0 (c=256 8x16, b=1) expects 32768
```

**Почему это не поймали тесты:** `backbone_forward_shape_and_backward_chain` проверяет
`seresnet::SEResNet31` (fp32-эталон), а `SEResNetQ::backward` не был покрыт ничем. Добавлен
тест `qat_backbone_backward_pairs_every_block_with_its_own_trace` (forward+backward QAT-сети
на 32×64) — на старом порядке он падает с сообщением выше, на новом проходит, в том числе
под ASAN.

### 8.2 Ваши 4 падения тестов на GPU: две индексные ошибки в ядрах

Обе видны только на GPU, потому что CPU-зеркала написаны правильно:

1. `gemm_fp32_tiled` (`cuda/kernels.cu:421`) накапливал `As[ty*4+i][tx] * Bs[k][tx]`,
   где `tx` — **колонка** потока, а не индекс `k`. Пары сомножителей получались случайными.
   Исправлено на `As[ty*4+i][k] * Bs[k][tx]`. → `fp32_gemm_matches_naive`,
   `fp32_gemm_handles_huge_k_without_grid_overflow`.
   В тренировке это ядро не используется (только в тестах и `launch_gemm_fp32`), поэтому на
   loss не влияло.
2. `grad_input_fused_kernel` и `grad_input_fused_i8_kernel` писали результат по плоскому
   индексу `t = ((b*hw_in+hw)*Cin+ci)`, тогда как `grad_input` лежит в NCHW
   `((b*Cin+ci)*hw_in+hw)`. Все каналы dX оказывались переставлены (совпадает только при
   `Cin == 1`, поэтому smoke на стеке давал конечные значения). Теперь пишется
   `grad_input[((long long)b*Cin+ci)*hw_in+hw]`. → `fused_backward_grad_input_matches_col2im_reference`,
   `grad_input_i8_matches_dequantised_fp32_reference`.
   **Вариант i8 — тот, что реально используется в тренировке**, то есть градиент по входу
   каждого свёрточного слоя был переставлен по каналам. Вместе с 8.1 это полностью объясняет,
   почему обучение не шло.

`cuda_memcpy_dtod` при этом оказался корректным (`cudaMemcpyDeviceToDevice`, асинхронный,
в потоке слоя) — подозрение снято.

### 8.3 `TRBA_CUDA_DEBUG_SYNC=1` — назвать ядро, которое упало

`CHECK_LAUNCH()` теперь умеет синхронизироваться после каждого запуска/копирования и
атрибутировать ошибку тому месту, где она возникла:

```bash
TRBA_CUDA_DEBUG_SYNC=1 ./target/release/trba-rust train.csv --smoke 2 --batch-size 4 --img-w 256
# [CUDA FATAL] cuda/kernels.cu:611: the kernel/memcpy launched just above faulted:
#              an illegal memory access was encountered
```

Без этого та же ошибка всплывает там, где драйвер случайно оказался вызван следующим, — у вас
это были `kernels.cu:1331` (`cudaMemcpyAsync` D2H) и `kernels.cu:1271` (`cudaFree`), то есть
совершенно неповинные места. Замедляет в несколько раз, поэтому годится для поиска, не для
тренировки. Альтернатива: `compute-sanitizer --tool memcheck ./target/release/trba-rust …`;
в скрипте проверки это `DEBUG_SYNC=1 ./scripts/run_cuda_smoke.sh`.

### 8.4 `--autotune` — optuna-подобный подбор (batch_size, img_w)

```bash
./target/release/trba-rust train.csv val.csv exp --charset charset.txt \
    --autotune --autotune-trials 24 --autotune-batches 6 --autotune-objective efficiency
```

Каждая проба — **отдельный дочерний процесс** с `--smoke K`: `illegal memory access` и CUDA OOM
уничтожают контекст, поэтому упавшая конфигурация не может быть домерена внутри того же
процесса; родитель фиксирует причину (сигнал/строка stderr) и продолжает поиск. Отчёт —
`<exp_dir>/autotune.json`. Цели: `throughput` (картинок/с), `efficiency` (картинок/с на GiB —
то самое «соотношение»), `latency` (с/батч). Трафик PCIe нормируется на батч.

Контрольный замер в песочнице (CPU-бэкенд, host-режим оптимизатора, b=2, 32×128) дал
**201.63 MB/батч** — совпадает с ранее измеренными 201.13 MB/батч, то есть зонд меряет то же,
что и ручной прогон со счётчиком.

### 8.5 Ширины кропов по сетке EAST

Из `manuscript-ocr/src/manuscript/detectors/_east/dataset.py`: `target_size=512`
(страница приводится к канве 512×512) и `score_geo_scale=0.25` (карта 128×128) ⇒
**шаг детектора 4 px**; `utils/geometry.py: warp_quad` режет кроп в пикселях канвы.
Референс распознавателя (`recognizers/_trba/configs/config.json`): `img_h=32, img_w=128,
max_len=40, batch_size=128`.

Отсюда правила в `src/autotune.rs`:

* шаг ширины = 4 (шаг EAST) × 8 (понижение ширины в SEResNetQ, `T = img_w/8`) = **32 px** —
  все кандидаты кратны 32, граница кропа остаётся на сетке детектора, а все стадии
  (maxpool 2×2, layer1 s2, layer3 s2, conv_out 2×2) целочисленны;
* лестница: 128…512 с шагом 32 (одна канва EAST), затем 640…1024 с шагом 128 (две канвы) —
  дорогой конец не перебирается излишне;
* нижняя граница `max_len × 8`: шагов признака `T = img_w/8`, и CTC не выдаст больше `T`
  символов. Поэтому **референсные `img_w=128` совместимы только с `max_len ≤ 16`**, для
  `max_len=40` нужно ≥ 320, для `max_len=64` — ≥ 512. Ваш прогон `--img-w 256 --max-len 32`
  находится ровно на этой границе (T = 32).

### 8.6 Проверено в песочнице после правок

| проверка | результат |
|---|---|
| `cargo test --release -- --test-threads=1` (CPU-бэкенд) | **33 passed / 0 failed** |
| тот же набор под AddressSanitizer | 33 passed, **0** heap-buffer-overflow |
| `nvcc -arch=sm_75 -c cuda/kernels.cu` | чисто, `-Wall` без предупреждений |
| `make -f tools/Makefile logic` | 16 passed / 0 failed |
| `TRBA_REQUIRE_CUDA=1 TRBA_CUDA_ARCH=75 cargo build --release --all-targets` | собирается и линкуется с CUDA |
| `git apply --check` патча на свежем клоне | APPLY_OK |
| `--autotune` end-to-end (4 пробы, дочерние процессы, отчёт JSON) | работает, PCIe 201.63 MB/батч |

Тесты в песочнице идут однопоточно: каждый тест строит полную модель на 42M параметров, и при
двух потоках коробку с 2 GB RAM убивает OOM-killer (на вашей машине это не ограничение).

### 8.7 Что запустить у вас

```bash
cd ~/Downloads/795b.zip.ZIP/trba-rust/trba-rust
git apply /path/to/trba-cuda-fixes.patch     # или скопировать файлы из поставки
TRBA_CUDA_ARCH=75 cargo build --release --all-targets

# 1) четыре теста, которые падали, теперь должны пройти (секунды)
./target/release/deps/trba_rust-* --test-threads=1 fp32_gemm grad_input

# 2) то, что падало при batch >= 3
TRBA_CUDA_ARCH=75 cargo test --release
./target/release/trba-rust /media/korziner/14ext4/trba/trba_kurrent/train.csv \
    /media/korziner/14ext4/trba/trba_kurrent/val.csv exp \
    --charset /media/korziner/14ext4/trba/trba_kurrent/charset.txt \
    --smoke 20 --batch-size 8 --img-w 256 --max-len 32

# 3) если что-то ещё падает — назвать ядро
TRBA_CUDA_DEBUG_SYNC=1 ./target/release/trba-rust … --smoke 2 --batch-size 4 --img-w 256

# 4) подобрать соотношение батч/ширина под вашу карту (10 GB)
./target/release/trba-rust train.csv val.csv exp --charset charset.txt \
    --autotune --autotune-trials 24 --autotune-batches 6 --autotune-objective efficiency
```

После 8.1 loss должен наконец снижаться: раньше градиенты свёрток считались по чужим
активациям, а dX приходил с переставленными каналами.

## 9. Этап 5: частые чекпоинты и продолжение с места обрыва

### 9.1 Что было

Чекпоинт писался только на границе эпох (`--ckpt-every N`) и в последней эпохе. Формат `TRBA_V4`
сохранял веса, BN-статистику, номер эпохи и `Adam.t` — но **не сохранял Adam-моменты** ни для
хостовых параметров, ни для device-состояния свёрток. При вашем датасете (214049 строк) эпоха —
это десятки тысяч батчей и часы работы: падение в середине эпохи отбрасывало всё, а продолжение
из чекпоинта ещё и сбрасывало скользящие средние в ноль при ненулевом `t` ( bias correction при
этом продолжает делить на `1 - beta^t ≈ 1`, то есть первые шаги после resume фактически
ненормированы).

### 9.2 Что сделано

**Формат `TRBA_V5`** — потоковая запись/чтение (`BufWriter`/`BufReader` по 1 MB), чтобы не
держать чекпоинт целиком в памяти:

```
magic "TRBA_V5"
u64 epoch_done            сколько эпох завершено
u64 batch_in_epoch        сколько батчей следующей эпохи уже пройдено
u64 Adam.t
u64 n_params
  для каждого параметра: len + f32[len] (веса), len + f32[len] (m), len + f32[len] (v)
  для каждой свёртки:    run_mean, run_var, m и v device-оптимизатора
```

* `len = 0` означает «не сохранено», а не «нули»: в host-режиме моменты свёрток уже лежат в
  host-Adam вместе с параметром, и дублировать их нулями — это лишние 338 MB в каждом файле.
* В device-режиме моменты свёрток качаются с GPU **по одному слою за раз** в переиспользуемый
  буфер (`ConvQat::download_moment` / `upload_moment` в `src/qnet.rs`): все слои сразу — это
  338 MB пиковой памяти хоста на каждое сохранение.
* `Adam::moment()` / `set_moment()` / `moment_count()` в `src/opt.rs`.

**Частые сохранения.** `--ckpt-every-batch N` (по умолчанию 500, 0 = выключено) пишет rolling
`<exp_dir>/checkpoint_last.bin` каждые N батчей и ещё раз в конце каждой эпохи. Запись атомарна
(`.tmp` + `rename`), поэтому прерывание посреди сохранения не портит предыдущую версию.
`--ckpt-every N` по-прежнему добавляет номерные `checkpoint_epochNNN.bin`.

**Продолжение.** Без `--no-resume` берётся самый свежий чекпоинт каталога **по mtime**
(`checkpoint_last.bin` либо номерной — файл «эпоха 3» может быть старше rolling-файла из середины
эпохи 4), `--resume PATH` задаёт файл явно. Обучение продолжается с `epoch_done + 1` и
**пропускает `batch_in_epoch` батчей** этой эпохи:

```
📂 resume: exp/checkpoint_last.bin
   завершено эпох: 2 | продолжать с эпохи 3, батч 5 | шаг оптимизатора 16 | Adam-моменты: восстановлены
```

Чтобы пропуск батчей продолжал ровно то же место, порядок батчей теперь функция от
`(seed, epoch)`, а не от всей истории перемешиваний (`StdRng::seed_from_u64(seed*golden_ratio +
epoch*const)`): при прежнем общем `rng` возобновление с середины эпохи попало бы в другую
последовательность, и часть данных за эпоху прошла бы дважды, а часть — ни разу.

**Отказ от загрузки.** Чтение потоковое, поэтому к моменту ошибки часть весов и `opt.t` уже
перезаписаны. Раньше сообщение «обучение с нуля» означало «обучение из половины чекпоинта»;
теперь при ошибке модель и оптимизатор пересоздаются целиком. Файлы `TRBA_V4` читаются
(веса + BN + `t`), о чём прогон говорит прямо: «Adam-моменты: нулевые (старый формат V4)».

### 9.3 Два бага, найденных при проверке этой же функции

* `read_f32s_vec` вызывал `read_f32s`, который читал префикс длины **ещё раз** → рассинхрон
  потока и мусорная длина («в чекпоинте тензор из 3825871617362214590, в модели из 1728»).
  Разделено на `read_f32s_body` (данные) и две обёртки (с проверкой размера / с размером из файла).
* Позиционные аргументы (`train.csv val.csv exp_dir`) игнорировались при `--smoke`, из-за чего
  **дочерние пробы `--autotune` мгновенно умирали на «не найден charset.txt»** (код возврата 1,
  50 проб за 4 с) — ровно та картина, что в вашем логе. Теперь позиционные аргументы
  запоминаются всегда, а требовательным к датасету остаётся только полный прогон. Заодно причина
  падения пробы берётся из её stderr (`Error: …`), а не только по списку ключевых слов.

### 9.4 Проверено в песочнице (CPU-бэкенд)

| сценарий | результат |
|---|---|
| 6 батчей, `--ckpt-every-batch 3`, эпоха 1 | сохранение на батчах 3 и 6 (шаг 3, 6) + `checkpoint_epoch001.bin` + rolling |
| тот же запуск с `--epochs 2` | `завершено эпох: 1 \| продолжать с эпохи 2, батч 1 \| шаг 6 \| Adam-моменты: восстановлены`, шаги 7…12, lr эпохи 2 |
| обрыв посреди эпохи 3 (`timeout 40`) | последнее сохранение: эпоха 3, батч 4/6, шаг 16 |
| возобновление после обрыва | `продолжать с эпохи 3, батч 5`, пропущены батчи 1–4, эпоха доработана за 13 s вместо 39 s, шаг 18 |
| размер файла | 553 MB (42M параметров свёрток: веса + m + v) |
| тесты | 33/33 в host-режиме, 32/32 в device-режиме (тяжёлый `qat_backbone…` требует ~1.1 GB, в песочнице сейчас свободно ~880 MB) |
| инвариант порядка блоков | при откате порядка тест падает: `incoming gradient has 8192 elements, but trace 0 (c=256 8x8, b=1) expects 16384` |

Практические следствия для вашего прогона: чекпоинт ~553 MB, сохранение — это ~0.5 GB D2H
(≈1.5–2 s на PCIe 2.0 x4) плюс запись на диск; при `--ckpt-every-batch 500` и ~0.8 s/батч
накладные расходы ≈1–2%. Накопительный файл один, место не растёт.

### 9.5 Что запустить

```bash
cd ~/Downloads/195a.ZIP/trba-rust
git apply /path/to/trba-cuda-fixes.patch
TRBA_CUDA_ARCH=75 cargo build --release

# обычный прогон с частыми чекпоинтами
./target/release/trba-rust \
    /media/korziner/14ext4/trba/trba_kurrent/train.csv \
    /media/korziner/14ext4/trba/trba_kurrent/val.csv exp \
    --charset /media/korziner/14ext4/trba/trba_kurrent/charset.txt \
    --batch-size 8 --img-w 256 --ckpt-every-batch 200 --ckpt-every 1

# после обрыва — та же команда без изменений, продолжит сама
# подбор (теперь пробы не умирают на charset)
./target/release/trba-rust train.csv val.csv exp --charset charset.txt \
    --autotune --autotune-batches 8 --autotune-objective efficiency
```

### 9.6 Состав поставки

`/home/user/trba-cuda-fixes.patch` — **14 файлов, +4119/−198**, `git apply --check` на свежем
клоне проходит, все файлы побайтово совпадают с проверенным рабочим деревом:

| файл | что изменилось на этом этапе |
|---|---|
| `src/main.rs` | формат чекпоинта V5 (потоковая запись, Adam m/v, позиция в эпохе), `--ckpt-every-batch`, resume по mtime с пропуском батчей, порядок батчей от (seed, epoch), per-epoch rolling-сохранение, позиция для `--autotune`, `PROBE`-строка |
| `src/qnet.rs` | порядок обхода блоков в бэкенде + инвариант формы, `download_moment`/`upload_moment` |
| `src/opt.rs` | `moment()`, `set_moment()`, `moment_count()` |
| `src/tests.rs` | тест `qat_backbone_backward_pairs_every_block_with_its_own_trace`, skip-гард device-теста в host-режиме |
| `src/autotune.rs` | причина падения пробы из stderr |
| `cuda/kernels.cu` | `gemm_fp32_tiled`, NCHW-индекс в `grad_input_fused_kernel`/`_i8_kernel`, `TRBA_CUDA_DEBUG_SYNC` |
| `README.md` | разделы про чекпоинты/resume, `--autotune`, отладку падения на GPU |

---

## 10. Этап 6: недогруженный GPU, лосс в именах чекпоинтов, `best.bin` и доказательства INT8

Ваш лог подбора (первые 5 проб, все `b=1`):

| img_w | T = img_w/8 | s/батч | img/s | VRAM, MiB | PCIe, МБ/батч |
|---|---|---|---|---|---|
| 512 | 64 | 1.07 | 0.94 | 880 | 20.80 |
| 640 | 80 | 1.43 | 0.70 | 72 | 35.95 |
| 768 | 96 | 1.69 | 0.59 | 84 | 36.02 |
| 896 | 112 | 1.93 | 0.52 | 98 | 36.10 |
| 1024 | 128 | 2.22 | 0.45 | 108 | 36.17 |

### 10.1 Почему 9–17 % из 56 SM: карта ждёт хост, а не «плохие ядра»

Главная примета таблицы — `s/батч` растёт почти ровно пропорционально `T` (512→1024 даёт ×2.07),
а VRAM при этом почти не меняется. На GPU выполняется только CNN; BiLSTM, attention-декодер, CTC и
Adam по не-свёрточным параметрам считаются **на хосте в скалярном Rust, в один поток**, и их цена
тоже пропорциональна `batch × T`.

Замер в песочнице (host-режим, `b=2`, `img_w=128` → `T=16`, профиль из 2 батчей):

```
rnn_fwd  89.26 мс/батч + rnn_bwd 234.13 мс/батч = 323 мс на 32 единицы (b×T)
       → ~10 мс на одну единицу b×T при hidden=256 (2 слоя × 2 направления)
```

Перенос на вашу конфигурацию `b=1, img_w=512` (`b×T = 64`): только BiLSTM ≈ **640 мс**, плюс
attention-декодер (≈ пропорционален `b`, частично `T`) и clip/Adam по host-параметрам. Итого
≈ 0.9 с из ваших 1.07 с — остаток и есть GPU-часть. То есть **80–90 % батча видеокарта простаивает**,
что `nvidia-smi` и показывает как 9–17 %.

Счётчики MAC (добавлены в `ConvQat`, печатаются как строки `[int8]`) дают вторую половину картины:
при `b=2, img_w=128` CNN делает **7.098 GMAC в forward и 14.197 GMAC в backward** (ровно 2×, как и
должно быть: grad_input + grad_weight). Для `b=1, img_w=512` это 14.2 и 28.4 GMAC. Даже при
скромных 300 GMAC/s это ~140 мс, а на тензорных ядрах — единицы миллисекунд.

Почему VRAM почти пустая: device-режим занимает ~643 MiB (42.15M параметров × 16 байт состояния
оптимизатора) плюс активации; дальше память растёт только от размера батча. Но **сейчас большой
батч не даёт выигрыша в пропускной способности**: host-часть линейна по `b`, поэтому `img/s`
остаётся плоским (в вашей таблице 0.94 → 0.45 img/s при росте `T`, а не `b`).

Что делать, по убыванию отдачи:

1. **Распараллелить host-часть по батчу** (rayon): `rnn.forward/backward`, attention, CTC и Adam по
   host-параметрам независимы между примерами батча. На 8+ ядрах это ~5–8× на доминирующей фазе,
   т.е. 1.07 с/батч → ~0.35–0.45 с.
2. **Только после этого** поднимать `batch`: GPU-часть почти бесплатна, VRAM позволяет, а
   фиксированные расходы (запуски ядер, PCIe-раундтрипы, SE-блоки с синхронизацией) распределяются.
3. В перспективе — RNN на GPU (большая переработка, но тогда `img/s` растёт и с `T`, и с `b`).

Инструмент для проверки на вашей карте — `TRBA_PROFILE=1` (раздел в README): раскладка по 14 фазам
с суммарной строкой `CPU / GPU / PCIe` и достижимыми `GMAC/s` для int8-GEMM. Профиль ставит
`cudaStreamSynchronize` на каждой границе фаз (иначе асинхронные запуски приписываются следующей
фазе), поэтому выключен по умолчанию.

Отдельно про аномалии в вашей таблице:

* **VRAM 880 MiB в первой пробе и 72–108 MiB в остальных.** Первая проба платит разово: контекст
  CUDA, загрузка модуля и первый рост пула рабочих буферов (`WsBlock`). Дальше эти байты уже
  выделены, и проба видит только дельту. После починки чекпоинтов в пробах (§10.2) цифры станут
  ровнее; если нет — `[profile]` покажет, какая фаза их ест.
* **~36 МБ/батч во 2–5-й строках.** Первая строка объясняется точно: (553 МБ чекпоинта D2H +
  162 МБ разовой загрузки весов) / 32 батча = **20.8 МБ/батч** — ровно ваша цифра. Для строк 2–5
  та же модель даёт ~21 МБ, а не 36; расхождение ~1.7× означает, что в этих пробах либо прошло
  меньше батчей, чем 32, либо добавился ещё один источник трафика. После §10.2 обе составляющие
  (чекпоинт и разовая загрузка) из отчёта уходят — пришлите новый лог, и остаток будет виден.

### 10.2 Регрессия из §9, которую вскрыл ваш лог: пробы писали чекпоинт по 553 МБ

Проба подбора — это `--smoke N`, то есть одна эпоха, поэтому безусловное сохранение в конце эпохи
срабатывало **в каждой пробе**: ~500 МБ D2H + 553 МБ на диск, плюс секунды на запись. Это и дало
20.80 МБ/батч в первой строке вашего лога.

Исправлено: при `TRBA_AUTOTUNE_PROBE=1` (его выставляет родитель `--autotune`) отключены rolling-
сохранение, номерное сохранение в конце эпохи и сам баннер «💾 rolling-чекпоинт…». Проверка:
`TRBA_AUTOTUNE_PROBE=1 … --smoke 4 --ckpt-every-batch 2` → строка `PROBE …` печатается, каталог
`exp_dir` остаётся **пустым**.

### 10.3 Лосс в именах чекпоинтов и `best.bin`

* Номерные файлы теперь `checkpoint_epoch003_loss4.1234.bin` — кривая видна из `ls`.
* Каждая валидация, улучшившая метрику, пишет `checkpoint_best_cer12.345_loss3.9871_epoch004.bin`
  и **жёсткую ссылку** `best.bin` на него. Это один inode: 553 МБ хранятся один раз (`ls -i`
  показывает одинаковый inode, `du` считает один раз), прежний лучший файл удаляется, поэтому
  улучшения не накапливают гигабайты. На ФС без жёстких ссылок (FAT/exFAT, сетевые шары) делается
  обычная копия, и это пишется в лог.
* Критерий — **CER**, потому что эталонная `validate()` валидационный лосс не считала вовсе:
  переменная `loss` объявлялась и выбрасывалась через `let _ = (pad, eos, cw, loss);`, а печатались
  только `acc` и `CER`. Теперь `validate()` возвращает `(CER %, acc %, n)`. Лосс эпохи (train) при
  этом всё равно попадает в имя файла, так что обе цифры видны без открытия файла.
* При возобновлении лучший CER читается обратно из имени уже лежащего файла
  (`existing_best_cer`), поэтому `best.bin` перезаписывается только при реальном улучшении, а не на
  первой же валидации после рестарта.

Проверено (host-режим, 16 train / 6 val картинок):

```
запуск 1 (--epochs 1):  📊 val: acc 0.0% | CER 100.0% | n=6
                        🏆 best.bin → checkpoint_best_cer100.00_loss3.8202_epoch001.bin
                        💾 …/checkpoint_epoch001_loss3.8202.bin
                        ls -i: 1573415 best.bin и 1573415 checkpoint_best_…  (один inode)
                        du: 1.6G на 4 имени (3 уникальных файла)

запуск 2 (--epochs 2):  завершено эпох: 1 | продолжать с эпохи 2, батч 1 | Adam-моменты: восстановлены
                        ♻️  лучший CER из уже сохранённых чекпоинтов: 100.00%
                        Эпоха 2/2 | loss 3.2800 | 📊 val: CER 100.0% → best.bin НЕ перезаписан
                        💾 …/checkpoint_epoch002_loss3.2800.bin
```

### 10.4 Доказательства того, что INT8 действительно работает (а не только добавляет накладные расходы QAT)

1. **Куда диспетчеризуется int8-GEMM.** В `launch_gemm_int8` путь выбирается по compute capability:
   `tensor_s8 = (major > 7) || (major == 7 && minor >= 2)`. Ваша карта — cc **7.5**, поэтому
   выполняется `gemm_int8_wmma_kernel` (`wmma::matrix_a/b<16,16,16,int8_t>` → `int32_t`-аккумулятор,
   то есть **IMMA на тензорных ядрах**). `gemm_int8_dp4a_kernel` — fallback для до-Turing карт,
   на sm_75 он не запускается.
2. **PTX для `compute_75` (собрано здесь, `nvcc -ptx -arch=compute_75`).** Внутри
   `gemm_int8_wmma_kernel`: 8 × `wmma.mma.sync.aligned.row.col.m16n16k16.s32.s8.s8.s32`,
   4 × `wmma.load.a…s8`, 8 × `wmma.load.b…s8`, 4 × `wmma.store.d…s32` — и **ни одного `dp4a`**.
   Все 23 `dp4a` в файле принадлежат `gemm_int8_dp4a_kernel`, который на вашей карте не
   диспетчеризуется.
3. **Объявление пути в рантайме.** Первый вызов GEMM печатает в stderr, что именно выбрано:
   `[trba] int8 GEMM: WMMA m16n16k16 s8*s8->s32 (тензорные ядра, IMMA) | cc 7.5 | SM 56 | выбран автоматически`.
4. **A/B-замер на вашей карте.** Новая переменная `TRBA_INT8_GEMM=wmma|dp4a` принудительно
   выбирает путь. Прогон с `TRBA_PROFILE=1` в обоих вариантах даёт прямое сравнение фаз `cnn_fwd` и
   `cnn_bwd`: отношение и есть вклад тензорных ядер. Если оно ≈1 — GEMM не узкое место вовсе.
5. **SASS в вашем бинарнике:**
   `cuobjdump -sass target/release/build/trba-rust-*/out/libtrba_cuda.a | grep -c IMMA`.
6. **Достигнутая производительность.** Строки `[int8]` в профиле делят накопленные MAC на время
   фаз: `CNN forward: 7.098 GMAC/батч за 526.04 мс -> 13 GMAC/s` (это host-режим в песочнице; на
   GPU сравните с пиком IMMA = `SM × 1024 MAC/такт × частота`, для 56 SM @ 1.4 ГГц ≈ 40 TMAC/s).

Честный вывод по существу вопроса. INT8 здесь — fake-quant: квантование → int8-GEMM →
деквантование, а вокруг него fp32/int8 элементные ядра (BN, im2col, requantize). GEMM действительно
считается на тензорных ядрах, но **GEMM не является узким местом**: при ~10 мс на единицу `b×T` в
host-BiLSTM и ~14–28 GMAC на батч в CNN ускорение от IMMA в общем времени шага тонет. То есть QAT
не «ускоряет обучение» и почти не «замедляет» его — его смысл в том, что полученные веса уже
int8-готовы для инференса (и для fine-tune под почерк конкретного писца). Если A/B из пункта 4
покажет заметную разницу — значит CNN всё же существенна, и тогда стоит смотреть на occupancy
int8-GEMM (тайлы 64×64, `min(tiles, 8192)` блоков).

Побочно: `launch_gemm_fp16` объявлен в `src/backend.rs`, но из Rust не вызывается ни разу — fp16-GEMM
в обучении не участвует (к тому же его PTX — это `wmma.mma…f32.f32`, эмуляция на CUDA-ядрах, а не
тензорные ядра).

### 10.5 Проверка этого этапа

| проверка | результат |
|---|---|
| `cargo test --release` (host-режим, `--test-threads=1`) | **33/33** |
| `cargo check --release` с CUDA-бэкендом (nvcc 12.9, sm_75/86/89) | чисто |
| `nvcc -c -arch=sm_75 -Xcompiler -U_GNU_SOURCE,-O3 cuda/kernels.cu` | rc=0 |
| `nvcc -ptx -arch=compute_75` + разбор PTX | 8 × `wmma.mma…s8.s8.s32`, 0 × `dp4a` в int8-WMMA ядре |
| `TRBA_PROFILE=1` (2 батча, b=2, img_w=128) | 14 фаз, суммы CPU/GPU/PCIe, `[int8]` 7.098/14.197 GMAC |
| чекпоинты с лоссом + `best.bin` | сценарии выше, inode общий, `du` 1.6G на 3 файла |
| возобновление после `best.bin` | CER восстановлен из имени, перезаписи без улучшения нет |
| `TRBA_AUTOTUNE_PROBE=1` | `exp_dir` пуст, строка `PROBE` печатается, баннера нет |

### 10.6 Инференс / ONNX: контракт собран, реализация — следующий шаг

Из `manuscript-ocr/src/manuscript/recognizers/_trba` вынут точный API `trba_base_g1.onnx`:

* экспорт (`__init__.py:1408-1424`): `torch.onnx.export(onnx_model, dummy_input, path,
  export_params=True, opset_version=…, do_constant_folding=True, input_names=["input"],
  output_names=["logits"], dynamic_axes={"input": {0: "batch_size"}, "logits": {0: "batch_size"}},
  dynamo=False)`;
* вход (`__init__.py:1360`): `dummy_input = torch.randn(1, 3, img_h, img_w)`, float32, NCHW, RGB;
  препроцессинг `_preprocess_image` = aspect-preserving resize (`INTER_AREA` при уменьшении) →
  белый холст `(img_h, img_w, 3)` → нормализация; батч динамический и проверяется пробой с `B=2`;
* обёртка `TRBAONNXWrapper(model, max_length=max_length + 1)` и флаг `onnx_mode=True` в
  `model.py:147,177,201`: число шагов декодера фиксируется (`max_steps = batch_max_length`, без
  `+1`) и ранний выход по EOS отключается, чтобы граф был статическим;
* рантайм (`__init__.py:632-651`) берёт имена из `session.get_inputs()[0].name` /
  `get_outputs()[0].name`, подаёт `np.stack([...])` и получает `logits` → `_decode_recognition_logits`;
  при ошибке формы батча падает в режим `B=1`.

Препроцессинг в Rust-тренере уже совпадает с этим контрактом (тот же resize/белый холст/
`p/255*2-1`), различие одно: Rust квантует вход в int8, а ONNX принимает float32.

Дальше возможны два маршрута, и они требуют разного: (A) конвертер на Python, который читает
чекпоинт `TRBA_V5` и раскладывает его в torch-модель из вашего репозитория, затем экспортирует её
штатным `torch.onnx.export` (нужно сопоставление имён параметров Rust ↔ torch, и torch/onnx на
вашей машине); (B) экспортёр ONNX прямо из Rust-бинарника, без torch (запись protobuf-графа своими
силами, зато работает сразу после обучения и не зависит от версии вашего `_trba`).

### 10.7 Состав поставки этого этапа

`/home/user/trba-cuda-fixes.patch` — **14 файлов, +4517/−299**, `git apply --check` на свежем клоне
проходит, все 14 файлов побайтово (md5) совпадают с проверенным рабочим деревом.

| файл | что добавилось на этом этапе |
|---|---|
| `src/main.rs` | `Profiler` (14 фаз, `TRBA_PROFILE=1`), `validate()` возвращает `(CER, acc, n)`, имена чекпоинтов с лоссом, `save_best_checkpoint` + `best.bin`-жёсткая ссылка, `existing_best_cer`, пробы `--autotune` без чекпоинтов и без баннера |
| `src/qnet.rs` | счётчики `macs_fwd`/`macs_bwd` в `ConvQat` (для строк `[int8]` в профиле) |
| `cuda/kernels.cu` | `TRBA_INT8_GEMM=wmma\|dp4a` (A/B-замер) и однократное объявление выбранного int8-пути в stderr |
| `README.md` | разделы `TRBA_PROFILE=1`, `best.bin`, «Proving that INT8 uses the tensor cores» |

---

## 11. Этап 7: инференс из бинарника (`--infer`) и план переноса RNN на GPU

### 11.1 `--infer` — распознавание готовым чекпоинтом (сделано и проверено)

```bash
# каталог картинок → stdout; чекпоинт найдётся сам (best.bin → самый свежий)
./target/release/trba-rust crops "" exp --charset charset.txt --img-w 512 --max-len 64 --infer

# CSV (первая колонка — пути, годится val.csv) → TSV-файл
./target/release/trba-rust val.csv results.tsv exp --charset charset.txt --img-w 512 --infer

# конкретный чекпоинт, батч 16
./target/release/trba-rust crops out.tsv exp --charset charset.txt --infer \
    --resume exp/checkpoint_epoch012_loss3.4210.bin --batch-size 16
```

Смысл позиционных аргументов в этом режиме: `[0]` — картинка, каталог картинок или CSV/TSV/TXT, у
которого первая колонка содержит пути; `[1]` — файл результатов (`путь<TAB>текст`, пустая строка или
ничего → stdout); `[2]` — `exp_dir`, тот же слот, что и в обучении. Чекпоинт: `--resume PATH`, иначе
`<exp_dir>/best.bin`, иначе самый свежий `checkpoint_*.bin`. Ошибка загрузки фатальна — распознавать
«половиной чекпоинта» нельзя (в обучении на этом месте осознанный откат к модели с нуля).

Препроцессинг и декодирование — ровно валидационные: aspect-preserving resize, белый холст,
`(p/255*2-1)`, int8 с шагом 1/127, CNN → BiLSTM → greedy attention decode. Поэтому текст совпадает
с тем, что модель выдавала на валидации, а `--charset/--img-h/--img-w/--max-len/--hidden` обязаны
соответствовать чекпоинту: расхождение размеров загружается с явной ошибкой, а не превращается в мусор.
Нечитаемые файлы пропускаются с предупреждением и считаются отдельно, картинки батчатся по
`--batch-size`.

Проверено в песочнице (host-режим, чекпоинт из одного эпохи на 16 шумовых картинках):

| сценарий | результат |
|---|---|
| каталог (16 png), `--batch-size 8`, вывод в stdout | `🧾 infer: …/best.bin \| завершено эпох 1 \| Adam-моменты восстановлены \| … (16 файл(ов)) \| результат: stdout`, 16 строк TSV |
| `val.csv` (первая колонка), `--batch-size 3`, вывод в файл, явный `--resume` | `💾 …/res.tsv: 6 строк`, `✅ infer: распознано 6, пропущено 0 \| 2.04 с \| 2.94 картинок/с` |
| `exp_dir` без чекпоинтов | `Error: --infer: в "…/nope" нет чекпоинта (нужен best.bin / checkpoint_*.bin или --resume PATH)` |

Распознанный текст после одной эпохи на шуме — `oo` для всех картинок, то есть модель ведёт себя
ровно так же, как на валидации (CER 97.2 %); это проверка plumbing, а не качества.

Для вашего конвейера это означает: fine-tune под почерк одного писца → `--infer` на его кропах →
сравнение с эталоном, и всё внутри одного бинарника, без Python. ONNX-экспорт (§10.6) остаётся
следующим шагом, контракт уже собран.

### 11.2 План: BiLSTM на GPU (выбран как следующий этап)

Цель — убрать ~60–80 % времени шага (host-BiLSTM, ~10 мс на единицу `b×T` при `hidden=256`) и
наконец сделать батч выгодным: сейчас GPU-часть почти бесплатна, а хост-часть линейна по `b`.

**Раскладка.** `feat [B,T,512]` сейчас выгружается на хост и возвращается обратно как `d_feat`. На
GPU оба перехода не нужны: RNN живёт там же, где CNN, поэтому из PCIe исчезает `2 × B × T × 512 × 4`
байт на батч и, важнее, две синхронизации.

**Ядра (по стадиям, каждая со своим CPU-зеркалом и проверкой):**

1. `lstm_input_gemm_f32` — один GEMM на весь слой: `M = B×T`, `K = 512`, `N = 4H` (вклад входа
   считается сразу для всех моментов времени, это единственная часть, не зависящая от предыдущего
   шага). Переиспользует уже починленный `gemm_fp32_tiled`.
2. `lstm_step_kernel` — на каждый момент времени: маленький GEMM `M = B, K = H, N = 4H` (рекуррентная
   часть) + слитый элементный блок (сигмоиды i/f/o, tanh g, обновление cell и hidden). При `B=1` GEMM
   крошечный, поэтому цена определяется запусками: `T=64 × 2 слоя × 2 направления ≈ 256` запусков
   ≈ 1–2 мс вместо нынешних ~640 мс.
3. `lstm_bwd_kernel` — обратный проход по времени: элементная часть (dCell, dh, градиенты врат) +
   два GEMM на шаг (по hidden и по входам слоя) + накопление `dW`/`db` на устройстве в fp32
   (приём тот же, что в CNN: `grad_accum_i32_kernel`-подобное накопление без атомарных гонок).
4. Следом (отдельная стадия) — attention-декодер и CTC: они дают ~5–10 % шага, поэтому их выгодно
   переносить уже после того, как RNN перестанет быть узким местом.

**Трассы.** Для backward нужно хранить на устройстве `i/f/o/g`, `cell`, `hidden` каждого шага:
`B × T × 4H × 4 байта` на слой-направление (при `B=8, T=64, H=256` — 2 МБ), то есть VRAM это не
заметит, а батч можно поднимать.

**Проверка без GPU в песочнице** (та же методика, что спасла CNN): CPU-зеркало каждого ядра в
`cuda/cpu_backend.cpp`, разбор индексов в `tools/kernel_logic_check.cpp` (16/16 сейчас), Rust-тест
«device-RNN == host-RNN» с допуском по порядку `device_conv_optimizer_pipeline_matches_host_pipeline`,
и переключатель `TRBA_GPU_RNN=1` — по умолчанию выключен, чтобы хост-путь оставался эталоном.
Порядок сложения в fp32 на GPU и на хосте различается, поэтому тесты на побитовое равенство здесь
невозможны: сравниваем с допуском и отдельно проверяем, что лосс за N шагов сходится одинаково.

**Ожидание.** При `b=1, img_w=512`: 1.07 с/батч → ~0.25–0.35 с, а после распараллеливания батча на
GPU рост `img/s` с ростом `b` станет реальным (сейчас он плоский).

**Порядок работ:** стадия 1–2 (forward) → тест эквивалентности `enc` → стадия 3 (backward) →
 end-to-end тест сходимости → attention/CTC. Каждая стадия отдельным патчем, чтобы в любой момент
можно было откатиться на хост-путь.

### 11.3 Состав поставки после этапа 7

`/home/user/trba-cuda-fixes.patch` — **14 файлов, +4758/−299**, `git apply --check` на свежем клоне
проходит, md5 всех 14 файлов совпадает с рабочим деревом. На этом этапе добавились: `--infer`
(`run_inference` + `collect_infer_inputs`, флаг, справка, диспетчеризация после загрузки charset) в
`src/main.rs` и раздел «Recognising images with a trained checkpoint» в `README.md` (362 строки).
Тесты: **33/33** в host-режиме, `cargo check --release` с CUDA-бэкендом чист.

---

## 12. Этап 8: BiLSTM читал вход как `[T, B, D]` — при `batch ≥ 2` время перемешивалось с батчем

Нашлось до написания LSTM-ядер: прежде чем переносить RNN на GPU, я сверил раскладки всех участников
конвейера — и переносить пришлось бы ошибку вместе с кодом.

### 12.1 Как устроены раскладки на самом деле

| участник | раскладка |
|---|---|
| CNN → `feat` | `[B, T, 512]` (`launch_meanpool_h`, комментарий «dequant -> mean over H -> [B, W, C]», `T = img_w/8`) |
| `BiLstmLayer::forward` (документация и `cat`/`y`) | вход `[B, T, D]`, выход `[B, T, out]` |
| attention (`src/attn.rs:160, 291, 295`) | `batch_h[(bi * t + tt) * c + k]` — `[B, T, C]` |
| `cnn.backward` | «Backprop a `[B, T, 512]` feature gradient» |
| внутренние трейсы `rnn.rs` (`gates`, `c`, `h` по направлениям) | `[T, B, ·]` — естественно для цикла по времени, наружу не выходят |

### 12.2 Что было не так

`run_dir` брал строку входа как `x[tt * b * d + bi * d + k]`, то есть читал `[T, B, D]`, а `bwd_dir`
так же читал `tr.x` **и так же писал `dx`**. Последствия при `b ≥ 2`:

1. **Вход BiLSTM — переставленная последовательность.** «Момент tt» читал подряд `b` строк плоского
   буфера: при `b=2, T=32` шаг 0 получал (пример 0, момент 0) и (пример 0, момент 1), шаг 1 —
   (пример 0, момент 2) и (пример 0, момент 3), а пример 1 начинался только с шага 16. Порядок
   времени и номер примера перемешаны.
2. **`d_feat` уходил в `cnn.backward` транспонированным** — градиент признака попадал не в те
   позиции `(b, t)`.
3. **То же во втором слое**: `y` первого слоя (`[B, T, 256]`) читался вторым как `[T, B, 256]`.
4. Градиенты весов считались по тому же перемешанному входу, поэтому forward и backward оставались
   самосогласованными: обучение шло, лосс уменьшался, ничего не падало и не расходилось.

При `b = 1` раскладки `[B, T, D]` и `[T, B, D]` совпадают (`x[tt * d + k]`), поэтому баг не было
видно нигде: ни в 33 тестах, ни в smoke-прогонах, ни в пробах `--autotune` (в вашем логе все пробы
`b=1`). Затронуты ровно прогоны с `--batch-size ≥ 2` — в том числе ваши ранние замеры на `b=2`
(361 → 0.64 МБ/батч по PCIe измерялись именно на `b=2`, но там измерялся трафик, а не качество).

### 12.3 Исправление

Три места в `src/rnn.rs`:

* `run_dir` — строка входа `&x[(bi * t + tt) * d .. +d]` внутри параллельного по батчу замыкания;
* `bwd_dir` — строка `tr.x` тем же индексом и запись `dx[(bi * t + tt) * d + k]`;
* `g_w_ih[o * d + k] += dv * xr[k]` — градиент веса по той же (теперь правильной) строке входа.

Внутренние буферы `[T, B, ·]` не тронуты: они согласованы между forward и backward и за пределы
модуля не выходят. Поведение при `b = 1` не изменилось вовсе (раскладки совпадали), то есть все
прошлые проверки и чекпоинты одноточечных прогонов остаются в силе.

### 12.4 Регрессионный тест

`bilstm_batch_items_do_not_mix_forward_or_backward` (в `src/tests.rs`): пример, попавший в батч,
обязан дать **тот же выход и тот же `dx`**, что и одиночный прогон с `b = 1` — проверяются и
forward, и backward, на двух слоях весов-клонах.

С прежней индексацией тест падает:

```
thread … panicked at src/tests.rs:1105:13:
forward: пример 0, строка 0: в батче -0.07378495, одиночно -0.103731446
```

(отличается даже пример 0 — именно потому, что его последовательность смешана с соседом по батчу).
С новой — проходит.

### 12.5 Проверка этапа

| проверка | результат |
|---|---|
| `cargo test --release` (host-режим, `--test-threads=1`) | **34/34** (33 прежних + новый) |
| новый тест со старой индексацией | падает (см. 12.4) — значит, ловит именно этот баг |
| сквозной прогон `b=2`, `img_w=128`, 8 батчей, `--eval-every 1 --ckpt-every 1` | loss 3.7574, `📊 val: CER 100.0%`, `🏆 best.bin → checkpoint_best_cer100.000_loss3.7574_epoch001.bin`, `💾 checkpoint_epoch001_loss3.7574.bin` |
| `--infer` по `val.csv` тем же чекпоинтом | `✅ infer: распознано 6, пропущено 0 \| 1.25 с \| 4.81 картинок/с` |
| профиль `TRBA_PROFILE=1` на `b=2` | `rnn_fwd 37.95 мс`, `rnn_bwd 119.12 мс` на батч (раскладка на скорость не влияет, цифры — тот же порядок) |

Ядра CUDA на этом этапе не менялись (`cuda/kernels.cu`, `cuda/cpu_backend.cpp` без правок), поэтому
проверка `nvcc -arch=sm_75` из этапа 6 остаётся в силе; правки чисто хостовые и от бэкенда не
зависят.

### 12.6 Практический вывод и связь с планом GPU-RNN

Если вы учили с `--batch-size ≥ 2`, эти прогоны стоит переделать: модель обучалась на
перемешанных последовательностях и получала транспонированный градиент признака. Прогоны с `b = 1`
не затронуты — а именно они сейчас и являются рабочим режимом (см. §10.1: большой батч пока не даёт
выигрыша, потому что host-BiLSTM линейна по `b`).

Для стадии 1–2 плана (§11.2) это означает: device-реализация LSTM обязана читать `feat` и писать
`d_feat` в `[B, T, D]`, а новый тест становится частью проверки эквивалентности «device-RNN ==
host-RNN» — раскладка теперь зафиксирована с обеих сторон.

### 12.7 Состав поставки после этапа 8

`/home/user/trba-cuda-fixes.patch` — **15 файлов, +4832/−304** (добавился `src/rnn.rs`),
`git apply --check` на свежем клоне `korziner/trba-rust` (`082fa77`) проходит, md5 всех 15 файлов
совпадает с рабочим деревом. `README.md` — 372 строки (добавлен раздел «Layout convention»),
отчёт — 1105 строк.

Замечание про песочницу: между ходами она пересоздаётся из снапшота, а `.cache/` и `target/` в
снапшот не входят, поэтому тулчейн (rustup/cargo, nvcc) и базовый клон пришлось поставить заново;
исходники, патч и отчёт сохраняются.
## 13. Этап 9: второй баг выравнивания в `rnn.rs` и BiLSTM на GPU (стадия 1, `TRBA_GPU_RNN=1`)

Этап сделан по вашему решению «начинать сразу»: цель — чтобы последовательная часть
сети считалась на 56 SM, а не на 4 ядрах CPU, и чтобы `feat`/`d_feat` не ездили через
PCIe 2.0 x4. Сначала найден и исправлен второй баг выравнивания в `rnn.rs` (иначе
GPU-порт унаследовал бы его), затем написаны ядра.

### 13.1 Второй баг `rnn.rs`: реверсное направление отдавало признаки не той позиции

§12 исправил раскладку `[T,B,D]` → `[B,T,D]` на входе/выходе направления. Осталась
вторая, независимая ошибка — и она ломала обучение **даже при `batch = 1`**.

Внутренние трейсы направления (`gates`, `c`, `h`) хранятся **в порядке слотов**:
`hs[step*b*h + bi*h + i]`, где `step` — номер итерации цикла. Для реверсного
направления слот `s` обрабатывает позицию `tt = T-1-s`. Но два места читали трейс по
`tt`, а не по `s`:

1. сборка `cat` (вторая половина — реверсные признаки) в `forward`;
2. запись `dh_b` (внешний градиент по состоянию) в `backward`.

В результате attention и CTC видели реверсные признаки позиции `T-1-tt` вместо `tt`, а
обратный проход отправлял градиент не в тот слот. Прямой и обратный проход снова были
согласованы друг с другом (поэтому лосс падал и «всё выглядело работающим»), но модель
училась на перепутанной половине признаков: половина каналов `enc` не соответствовала
своей позиции.

Исправление — одна переменная в двух местах:

```rust
let slot_b = t - 1 - tt;          // реверсный трейс хранится в порядке слотов
```

Регрессионный тест `bilstm_directions_are_aligned_by_time_position` сравнивает
`BiLstmStack` с независимой эталонной реализацией `ref_lstm_dir` (проекция =
тождественная, `out = 2h`, веса направлений заданы вручную). Проверка чувствительности:
с откатом исправления тест падает —

```
реверсное направление, позиция 0, признак 0: -0.0076391166 != -0.021256499
```

**Практический вывод:** баги §12 и §13.1 означают, что все прежние прогоны обучались на
перемешанных признаках (при `b ≥ 2` — оба бага, при `b = 1` — только §13.1).
Чекпоинты, полученные до этих исправлений, продолжать дообучать не стоит: их надо
переобучить с нуля.

### 13.2 Что перенесено на GPU и что осталось на хосте

Стадия 1 — гибрид: **оба направления LSTM обоих слоёв считаются на устройстве**,
проекция `cat → y` (и её обратный проход) остаётся на хосте. Это осознанный выбор:
проекция — один GEMM `[B*T, 2H] × [2H, out]` без рекурсии, он дешёвый, а его перенос
потребовал бы отдельного набора ядер и своего теста. Выгода же почти полностью в
рекуррентной части: именно она последовательна по времени и именно она занимала
39.6 + 141.6 мс/батч на CPU при `b=2, T=16` (измерено `TRBA_PROFILE=1`).

Чтобы хостовый и device-пути не разъезжались, проекция вынесена в общие функции, и оба
пути вызывают один и тот же код: `cat_from_h`, `proj_forward`, `proj_backward_dcat`,
`proj_grads`, `split_dcat`.

Новые ядра в `cuda/kernels.cu` (6 семейств, `extern "C"`-лаунчеры `launch_lstm_*`):

| ядро | распараллеливание | что делает |
|---|---|---|
| `lstm_fwd_step_kernel` | warp на пару `(b, i)`, 4 × `__shfl_down_sync` | один шаг времени: `gates = W_ih·x + W_hh·h_prev + b`, активации, обновление ячейки |
| `lstm_bwd_cell_kernel` | поток на `(b, i)` | `dgates[slot]` из `dh_out`, `dc_next`, `c_prev/h_prev` |
| `lstm_bwd_rec_kernel` | поток на `(b, k)` | `dx[(bi*T+tt)*D+k]` при `k < D`, иначе `dh_next` |
| `lstm_wgrad_ih_kernel` | поток на `(o, k)` | `g_w_ih += Σ dgates ⊗ x` (флаг `accumulate`) |
| `lstm_wgrad_hh_kernel` | поток на `(o, k)` | то же по `h_prev`, цикл с слота 1 |
| `lstm_bgrad_kernel` | поток на `o` | сумма `dgates` по `(slot, b)` в `g_b_ih` и `g_b_hh` |

Соглашения (совпадают с хостовым путём, поэтому тесты переносимы):

* `x`, `dx` — `[B, T, D]`; `gates` — `[T, B, 4H]` после активаций; `c`, `h`, `dh_out` —
  `[T, B, H]` **в порядке слотов**;
* `c_prev`/`h_prev` читаются из слота `slot-1` того же трейса, для `slot = 0` — нули:
  отдельные буферы состояний не нужны, гонок и атомарных операций нет;
* порядок гейтов `(i, f, g, o)` — как в PyTorch;
* ядра принимают указатели **одного направления** и флаг `rev`, запускаются отдельно для
  каждого направления: это убирает гонку при накоплении `dx` и делает отображение
  `slot → tt = rev ? T-1-slot : slot` единственным местом, где живёт реверс (тот самый
  инвариант из §13.1 теперь зашит в ядро, а не размазан по хостовому коду);
* градиенты весов считаются **одним запуском на направление после цикла по слотам** из
  сохранённых `dgates`, а не по шагам — иначе на каждом шаге нужен был бы атомарный
  `atomicAdd` в 3 МБ весов.

Отдельно про неинициализированную память устройства: `DevBuf::new` не обнуляет буфер,
поэтому `dh_next`/`dc_next` для первого слота обратного прохода загружаются явными
нулями. Без этого первый шаг читал бы мусор из VRAM — плавающий баг, который
воспроизводится только на реальной карте.

**Латентность, а не поток.** В `lstm_bwd_rec_kernel` и в трёх ядрах градиентов весов сумма идёт по
`4H` (или по `T·B`) слагаемым. Одна переменная-накопитель превращает её в цепочку зависимых FMA с
латентностью ~4 такта на слагаемое: ядро упирается в латентность, а не в пропускную способность.
Поэтому суммы считаются четырьмя независимыми накопителями (`s0..s3`, результат
`(s0+s1)+(s2+s3)`), а вложенный цикл `(slot, bi)` в ядрах градиентов развёрнут в один плоский по
`j = slot*B + bi` — для `dgates` это тождественно (`dgates[j*(4H)+o]`), зато цикл можно
разворачивать на 4 (хелперы `wgrad_ih_term`/`wgrad_hh_term`). Плата — перестановка слагаемых в
fp32: расхождение с хостовым путём порядка 1e-4 относительных, внутри допуска теста
эквивалентности.

В `cuda/cpu_backend.cpp` добавлены 6 CPU-зеркал тех же ядер (по слоту последовательно,
два ядра градиентов весов — с `#pragma omp parallel for`). Зеркала нужны не для
скорости, а чтобы весь device-путь можно было прогнать и проверить в песочнице без GPU:
тот же Rust-код, те же индексы, те же тесты.

### 13.3 Как включается и как устроен поток данных

Флаг `TRBA_GPU_RNN=1` (по умолчанию выключен — хостовый путь остаётся прежним):

```bash
TRBA_GPU_RNN=1 TRBA_PROFILE=1 ./target/release/trba-rust train.csv val.csv exp \
    --charset charset.txt --img-w 512 --batch-size 8 --smoke 20
```

В `src/main.rs` шаг обучения теперь ветвится:

* `cnn.forward` возвращает `feat` как `DevBuf`; в device-режиме он **не скачивается** —
  передаётся прямо в `rnn.forward_device(feat, b, t, stream)`;
* `rnn.backward_device` возвращает `d_feat` как `DevBuf`, который уходит в
  `cnn.backward` **без выгрузки на хост и обратной загрузки**;
* на хост приходят только `enc` (для attention/CTC) и `dy` обратно — это ~64 КБ при
  `b=2, T=16`, а не 200 МБ.

Профайлер учитывает режим: фазы `rnn_fwd`/`rnn_bwd` помечаются `[gpu]`, а `feat_d2h` и
`dfeat_h2d` печатаются как «выгрузки/загрузки нет». Без этого таблица приписывала бы
время устройства к CPU (в песочнице все `[gpu]`-фазы — это CPU-зеркала, в том числе
`cnn_fwd`, так что обозначения согласованы).

### 13.4 Трафик через PCIe: расчёт совпал с измерением

Стадия 1 поднимает на устройство веса LSTM и спускает их градиенты каждый батч
(проекция остаётся на хосте, её веса не ездят):

| | МБ/батч |
|---|---|
| `w_ih + w_hh + b` двух слоёв × 2 направления (hidden 256, d 512/256) | 10.5 |
| те же градиенты обратно | 10.5 |
| `enc` вниз + `dy` вверх (b=2, T=16) | ~0.13 |
| **итого добавка стадии 1** | **~21** |

Измерено `TRBA_PCIE_COUNTER=1` (8 батчей, `b=2, img_w=128`, песочница,
`TRBA_HOST_CONV_ADAM=1`): 1654.54 МБ → 1818.79 МБ за эпоху, то есть 206.8 → 227.3
МБ/батч, **дельта +20.5 МБ/батч** — расчёт подтверждён.

Что это значит на вашей машине:

* PCIe 2.0 x4 даёт ~1.6 ГБ/с практически ⇒ 20.5 МБ ≈ **13 мс/батч**;
* хостовый BiLSTM при тех же `b=2, T=16` стоит **181 мс/батч**, а при вашем рабочем
  `b=1, img_w=512 (T=64)` — порядка **314 мс/батч** (76 мс forward + 238 мс backward);
* добавка не зависит ни от `T`, ни от `b` (веса одного размера), а выигрыш растёт
  линейно с `b·T` ⇒ чем шире картинка и больше батч, тем выгоднее: при `b=8` экономия
  составляет ~95 % времени RNN.

Оговорка про режим, в котором свёрточные веса и Adam живут на устройстве (ваш основной
режим, 0.64 МБ/батч): там 20.5 МБ/батч станут главным потребителем PCIe. Это и есть
причина делать стадию 2.

### 13.5 Загрузка SM: что распараллелено полностью, а что упирается в рекуррентность

Ваше требование — «чтобы работало 56 SM, а не 4 ядра». Честная картина по семействам ядер
(потоков на один запуск; `hidden=256`, `d=512`, `b=8`):

| ядро | потоков на запуск | блоков по 256 | 56 SM заняты? |
|---|---|---|---|
| `lstm_fwd_step_kernel` | `B·H` warps = 65 536 потоков | 256 | **да** |
| `lstm_wgrad_ih_kernel` | `4H·D` = 524 288 | 2 048 | **да** |
| `lstm_wgrad_hh_kernel` | `4H·H` = 262 144 | 1 024 | **да** |
| `lstm_bwd_rec_kernel` | `B·(D+H)` = 6 144 | 24 | нет, ~24 SM |
| `lstm_bwd_cell_kernel` | `B·H` = 2 048 | 8 | нет, ~8 SM |
| `lstm_bgrad_kernel` | `4H` = 1 024 | 4 | нет (но работы на микросекунды) |

Два послотовых ядра обратного прохода ограничены **не кодом, а самой рекурсией**: на одном шаге
времени независимых единиц работы ровно `B·H` (по ячейке на элемент батча), и взять их неоткуда —
предыдущий шаг ещё не посчитан. Отсюда два следствия:

* загрузка растёт линейно с батчем: при `b=2` это 2 блока, при `b=8` — 8 и 24, при `b=32` — 32 и
  128 блоков, то есть карта заполняется. `--autotune` и так подбирает `(batch, img_w)`, и с
  device-RNN большой батч выгоднее не только по PCIe, но и по SM;
* forward и градиенты весов (самые тяжёлые части: `4H·D·T·B` MAC) загружают все 56 SM уже сейчас.

Отдельно про запуски: на шаг приходится `4T` запусков forward и `8T` backward (по два ядра на
направление и слой на каждый слот) плюс 12 запусков градиентов — при `T=64` около 780 запусков,
то есть 1.5–3 мс накладных расходов на шаг. Против 314 мс хостового BiLSTM это незаметно, но если
после стадии 2 RNN станет совсем быстрым, следующим шагом будет CUDA Graph (один «граф» на слот
вместо восьми запусков) либо параллельный scan по времени, который снимет и ограничение `B·H`.

### 13.6 Стадия 2 (следующий шаг, не сделано)

Веса LSTM, их градиенты и состояния Adam сделать резидентными на устройстве — ровно так,
как уже сделано для 42.15M свёрточных весов: `DevOpt`, `launch_adam_f32`, подача
`S_GSQ` через `sum_sq_add`, исключение этих параметров из `host_params()` и
синхронизация теней перед сохранением чекпоинта. Тогда трафик стадии 1 (21 МБ/батч)
уходит полностью, а от PCIe остаётся только `enc`/`dy` (~0.13 МБ).

### 13.7 Проверка этапа

**1. Тест эквивалентности device-пути хостовому** — `device_bilstm_matches_host_bilstm`
(`b=2, t=5, d=8, h=4`, 2 слоя): сравниваются `enc`, `dx` и **все** градиенты
(`g_w_ih`, `g_w_hh`, `g_b_ih`, `g_b_hh` обоих направлений обоих слоёв, плюс `g_proj_w`,
`g_proj_b`), допуск `1e-4` относительный (порядок сложения в fp32 различается:
warp-редукция против последовательной суммы). В песочнице тест прогоняет CPU-зеркала, на
карте — настоящие ядра: код теста один и тот же.

Проверка чувствительности теста: с подменой `tt = rev ? T-1-slot : slot` на `tt = slot`
в зеркале `lstm_bwd_rec_kernel` тест падает —

```
dx[0]: host -0.0030343644, device -0.0018309271
```

**2. Весь набор тестов: 36/36** (`TRBA_FORCE_CPU=1 TRBA_HOST_CONV_ADAM=1 cargo test
--release -- --test-threads=1`, 3.3 с) — 35 прежних плюс новый.

**3. Обучение совпадает с хостовым побитово.** Прогон из песочницы: эпоха 1 обучена
хостовым путём, чекпоинт скопирован в два каталога, эпоха 2 дообучена из одного и того
же состояния — один раз хостовым RNN, второй раз device-RNN:

| путь | эпоха 2 |
|---|---|
| хостовый | `loss 3.2462 (attn 3.1772 ctc 3.4218, w_ctc 0.282)` |
| device | `loss 3.2463 (attn 3.1773 ctc 3.4219, w_ctc 0.282)` |

Совпадают лосс, обе составляющие и `w_ctc`; расхождение ~1e-4 относительных — перестановка
слагаемых в fp32 из-за четырёх накопителей (§13.2), а не расхождение математики. Одинаковые веса,
одинаковый порядок данных (per-epoch RNG), одинаковое состояние Adam ⇒ различается только путь
RNN. Первая эпоха у обоих продолжений общая: `loss 3.8711 (attn 3.3000 ctc 5.2038)`.

Таблица профиля в device-режиме печатается с правильными метками (песочница, CPU-зеркала):

```
   feat_d2h       0.00 мс/батч   0.0%  [pcie] выгрузки feat нет: буфер остаётся на GPU
   rnn_fwd       50.41 мс/батч   0.9%  [gpu]  BiLSTM forward на GPU (2 слоя x 2 направления)
   rnn_bwd      270.26 мс/батч   4.6%  [gpu]  BiLSTM backward на GPU + градиенты весов
   dfeat_h2d      0.00 мс/батч   0.0%  [pcie] загрузки d_feat нет: буфер остаётся на GPU
```

**4. CUDA-сборка и код устройства.** `TRBA_CUDA_ARCH=75 TRBA_REQUIRE_CUDA=1 cargo build
--release` ⇒ `CUDA backend built with .../nvcc`, бинарник 17.9 МБ, статически
слинкован с cudart. В PTX для `compute_75` все шесть ядер присутствуют как
`.visible .entry` (`_Z20lstm_fwd_step_kernel…`, `_Z20lstm_bwd_cell_kernel…`,
`_Z19lstm_bwd_rec_kernel…`, `_Z20lstm_wgrad_ih_kernel…`, `_Z20lstm_wgrad_hh_kernel…`,
`_Z17lstm_bgrad_kernel…`), `shfl.sync.down` встречается **40 раз** — warp-редукции
скомпилированы, а не вырождены в последовательные циклы. `nm` бинарника: 6 символов
`T launch_lstm_*`.

**5. Что осталось непроверенным в песочнице** (GPU здесь нет): фактическая скорость на
CMP 50HX и поведение при `batch ≥ 3` на реальной памяти. Поэтому флаг выключен по
умолчанию.

Важно про цифры из песочницы: в device-режиме здесь `rnn_fwd 52.1 / rnn_bwd 171.3
мс/батч` — это **CPU-зеркала**, скалярный последовательный код на 2 ядрах, они медленнее
оптимизированного хостового пути (39.6 / 141.6). На карте те же вызовы становятся
шестью семействами ядер по 56 SM; ожидать от песочницы ускорения нельзя, она проверяет
только правильность.

### 13.8 Что запустить на вашей машине

```bash
cd ~/Downloads/195a.ZIP/trba-rust
git apply trba-cuda-fixes.patch          # или скопировать 15 файлов

# 1) эквивалентность ядер и хостового пути (секунды, GPU не нужен)
cargo test --release device_bilstm_matches_host_bilstm -- --test-threads=1

# 2) короткий прогон с device-RNN и профилем
TRBA_CUDA_ARCH=75 TRBA_REQUIRE_CUDA=1 cargo build --release
TRBA_GPU_RNN=1 TRBA_PROFILE=1 TRBA_PCIE_COUNTER=1 \
  ./target/release/trba-rust /media/korziner/14ext4/trba/trba_kurrent/train.csv \
  /media/korziner/14ext4/trba/trba_kurrent/val.csv exp --charset \
  /media/korziner/14ext4/trba/trba_kurrent/charset.txt \
  --img-w 512 --batch-size 8 --smoke 20
```

На что смотреть в таблице профиля: `rnn_fwd`/`rnn_bwd` должны упасть с сотен
миллисекунд до единиц-десятков и перейти в колонку GPU; `feat_d2h`/`dfeat_h2d` —
ноль; строка `[pcie]` — примерно +20 МБ/батч к прежним 0.64 МБ. Если `rnn_bwd`
останется больше `cnn_bwd`, узкое место — трафик весов, и нужна стадия 2 (§13.6).

### 13.9 Состав поставки после этапа 9

Патч — **15 файлов**: `cuda/kernels.cu` (2146 строк, +6 семейств LSTM-ядер),
`cuda/cpu_backend.cpp` (+6 зеркал), `src/rnn.rs` (исправление §13.1, общие функции
проекции, `DirDev`, `DevLayerTrace`, `forward_device`, `backward_device`,
`gpu_rnn_enabled`), `src/backend.rs` (+6 `extern "C"` объявлений), `src/main.rs`
(ветвление шага обучения, `enum RnnTrace`, баннер, режим профайлера), `src/tests.rs`
(+2 теста: §13.1 и §13.7), `src/qnet.rs`, `src/opt.rs`, `src/autotune.rs`, `src/lib.rs`,
`build.rs`, `README.md`, `scripts/run_cuda_smoke.sh`, `tools/kernel_logic_check.cpp`,
`tools/Makefile`.
## 14. Этап 10: `clip_adam` 392 мс → 40 мс. Muon (momentum-free) вместо Adam, MuonQ int8

Вы указали на строку профиля `clip_adam 392.17 мс/батч 7.4% [cpu]` и на то, что в вашем
репозитории уже есть momentum-free Muon (`src/conv2d.rs::muon_update`), который нигде не
используется: свёртки считал device-Adam, хостовые параметры — host-Adam. Теперь Muon —
основной оптимизатор, Adam остался только для векторов.

### 14.1 Почему это было 392 мс

Дело не в «Adam тяжёлый», а в реализации `src/opt.rs`:

| что | цена |
|---|---|
| каждый элемент в **f64**: `g[i] as f64`, `m[i] as f64`, `sqrt`, `/`, обратный каст | ~10 кастов + sqrt + div на элемент, авто-векторизация невозможна |
| **один поток** (ни rayon, ни OpenMP) | на вашем CPU работает одно ядро из нескольких |
| `global_norm` — **отдельный полный проход** по всем градиентам, тоже f64-скалярный | +1 проход по ~4M элементов |
| `m`/`v` — два массива на параметр | 24 байта трафика на элемент вместо 12 |
| `self.m.entry(pr.name.clone())` | клон `String` + хеш на каждый параметр каждый шаг |

### 14.2 Что сделано

**Хост (`src/opt.rs`).** `ParamRef` получил форму `shape: Option<(rows, cols)>`; всё, у
чего форма есть, уходит на Muon, всё остальное (bias, BN `gamma`/`beta`) — на Adam.
Формы проставлены во всех 14 местах `params_filtered` (`push2d!`): свёртки
`[out_c, in_c·kh·kw]`, SE `fc1/fc2`, `rnn*.{f,b}.w_ih` `[4H, D]`, `w_hh` `[4H, H]`,
`proj.w` `[out, 2H]`, `attn.{i2h,h2h,score,gen}.w`, `attn.w_ih` `[4Hs, ctx+classes]`,
`attn.w_hh`, `ctc.w`. `rows/cols` вычисляются в макросе **до** взятия `&mut`, иначе
`c.col_cols()` конфликтует с `&mut c.w`.

Шаг Muon — ровно ваша формула из `conv2d.rs`, плюс автомасштаб:

```text
scale  = min( sqrt(min(rows,cols)) / ||g||_F , cap )     cap = 10, как у вас
lr_eff = lr * sqrt(max(rows,cols))                       автомасштаб
w     -= lr_eff * scale * g   и   w *= (1 - lr*wd)       weight decay decoupled
```

Автомасштаб — не косметика. Поскольку `n = rows·cols`, величина шага на элемент равна
`lr_eff · scale · g_rms = lr · sqrt(max·min)/(sqrt(n)·g_rms) · g_rms = lr`: то есть по
модулю шаг остаётся порядка `lr`, как у Adam. Без множителя `sqrt(max_dim)` он был бы в
23–32 раза меньше (для 1024×512), и обучение почти остановилось бы.

Всё в f32 и параллельно: внешний `par_iter` по матрицам (их десятки, внутренние проходы
последовательные — их векторизует LLVM), вложенный rayon не используется сознательно,
задачи слишком мелкие. Арифметика Adam для векторов оставлена **побитово прежней** (тот
же f64 элемент за элементом): её сравнивают с устройством два существующих теста, и
векторы — это доли процента элементов, ускорять там нечего.

**Clip только на warmup.** `--clip-warmup N` (дефолт 500, `TRBA_CLIP_WARMUP`): первые N
шагов глобальная норма считается и применяется, дальше — нет, потому что шаг ограничивает
нормировка Muon с капом. После warmup исчезает и `read_grad_sq` — а это синхронизация с
устройством на каждый батч. Проход нормы (`sum_sq`) и применение множителя (`scale_grads`)
параллельны, но накопление осталось в f64 и побитово совместимым: тест
`device_conv_optimizer_pipeline_matches_host_pipeline` сравнивает эту сумму с устройством
с точностью 1e-12.

**Устройство (`cuda/kernels.cu`).** Свёрточные веса (42.15M) тоже переведены на Muon:
`muon_step_f32_kernel` + `launch_muon_step_f32`. Норма градиента считается на устройстве
в f64-скаляр (тем же `launch_sum_sq_add_f32`, что кормил clip), масштаб
`min(sqrt(min_dim)/||g||_F, cap)` вычисляется **внутри ядра шага**, поэтому на хост не
возвращается ни одного байта и синхронизация не нужна. На слой приходится 4 запуска:
обнулить скаляр, норма, шаг, обнулить градиент.

**Память.** В режиме Muon `m`/`v` на устройстве не выделяются вовсе (4-байтные
заглушки): это **−338 MB VRAM**. Из чекпоинта исчезают и моменты свёрток, и моменты
хостовых матриц: файл стал **184 591 952 байта вместо 553 324 344** — в 3 раза меньше,
что при `--ckpt-every-batch 500` существенно.

**Найденный по пути баг.** Загрузка старого (adam'овского) чекпоинта в Muon-режиме
приводила к записи `n` элементов в 4-байтную заглушку `m`/`v` на устройстве — то есть к
порче памяти GPU. `upload_moment` теперь в Muon-режиме возвращает управление сразу;
симметрично `device_adam` доращивает `m`/`v`, если Adam включили после создания
device-состояния (`TRBA_OPT=adam`).

### 14.3 MuonQ: int8 блоками по 128 — и честный результат

`TRBA_MUON_Q=1` (размер блока — `TRBA_MUON_Q_BLOCK`, дефолт 128). Градиент матрицы
квантуется в int8, шкала блока — `max|g|/127`, округление half-away (как во всём
проекте, а не half-to-even из CUDA `rintf`). `||g||_F²` считается как `Σ s_b² · Σ q²`,
внутренняя сумма — в i64, то есть **точно**: точность нормы больше не зависит от порядка
сложения fp32. Шаг читает 1 байт на элемент вместо 4.

Качество шага проверено тестом `muon_q_block128_tracks_fp32_muon` (матрица 37×259, один
блок нарочно в 40 раз крупнее остальных — per-tensor шкала на таком ломается, per-block
нет): косинус направлений fp32- и int8-шага **0.999994**, поэлементное расхождение не
превышает половины шага квантования своего блока.

Но по скорости на хосте MuonQ **медленнее** fp32 Muon: 140.85 против 60.32 мс/батч.
Причина конкретная: градиент и так лежит в RAM в fp32, поэтому квантование добавляет два
прохода (max по блоку + запись int8) и не экономит ничего — чтение int8 в последнем
проходе выигрыш не окупает. Ваша интуиция про «меньше памяти и чаще хиты в кэш» верна, но
она относится к случаю, когда градиент **хранится или передаётся** в int8, а не
квантуется на месте. В этом проекте такое место есть, и оно главное: PCIe. На стадии 2
GPU-RNN градиенты весов LSTM едут с устройства на хост — 10.5 МБ/батч; в int8 это
2.6 МБ/батч, то есть MuonQ превращается из накладных расходов в экономию ~8 МБ/батч
(~5 мс на PCIe 2.0 x4). Плюс шум квантования как регуляризатор остаётся в силе
независимо от транспорта.

Вывод: `TRBA_MUON_Q=1` сейчас — это инструмент регуляризации, а не ускорения. По
умолчанию он выключен; включать стоит осознанно и сравнивать по CER.

### 14.4 Измерения

Песочница, 2 ядра, `b=2, img_w=128, hidden=256`, `TRBA_HOST_CONV_ADAM=1` (свёртки на
хосте, поэтому их 42.15M параметров проходят через хостовый оптимизатор — это худший
случай; в вашем основном режиме свёртки на устройстве и хостовая часть в разы меньше):

| конфигурация | `clip_adam`, мс/батч | доля шага |
|---|---|---|
| Adam как было (f64, один поток, clip всегда) | **392.17** | 7.4 % |
| Adam, но параллельный (`TRBA_OPT=adam`), clip 500 | 177.30 | 3.6 % |
| Adam параллельный, clip выключен | 168.78 | 3.5 % |
| **Muon fp32, clip на warmup** | **60.32** | 1.3 % |
| **Muon fp32, clip выключен (установившийся режим)** | **40.37** | 0.8 % |
| MuonQ int8/128, clip на warmup | 140.85 | 2.9 % |
| MuonQ int8/128, clip выключен | 121.03 | 2.5 % |

Итого **392 → 40 мс, в 9.7 раза**; вклад CPU в батч упал с 413.8 до 312.3 мс. Учтите,
что это на 2 ядрах: параллельная часть масштабируется по ядрам, поэтому на вашей машине
относительный выигрыш от Muon против Adam будет тем же, а абсолютные числа — меньше.
`adam_dev` (151 мс в песочнице) в вашем режиме останется на устройстве, но уже как
`muon_step`: там выигрыш — минус два массива `m`/`v` (338 MB VRAM и 336 MB трафика на
шаг) и минус `sqrt`/`div` на элемент.

### 14.5 Обучается ли это (A/B на игрушечном наборе)

Три эпохи на 16 картинках, `b=2` (24 шага), один и тот же `--seed 7`:

| эпоха | Adam | Muon |
|---|---|---|
| 1 | 3.9115 (attn 3.3219 ctc 5.2873) | **3.8278** (attn 3.3503 ctc 4.9419) |
| 2 | **3.2309** (attn 3.1852 ctc 3.3472) | 3.3157 (attn 3.2725 ctc 3.4259) |
| 3 | **3.1614** (attn 3.1509 ctc 3.1907) | 3.2502 (attn 3.2122 ctc 3.3563) |

Ни одного вывода отсюда сделать нельзя: 16 картинок и 24 шага — это шум, а CER на 6
валидационных картинках в обоих случаях 100 %. Смысл таблицы только в том, что Muon не
расходится и не замирает: величина шага у него того же порядка, что у Adam (см. §14.2).
Настоящая проверка — несколько эпох на вашем train.csv с сравнением CER; переключатель
`TRBA_OPT=adam` делает A/B однокомандным.

### 14.6 Проверка этапа

* **39/39 тестов** (`TRBA_FORCE_CPU=1 TRBA_HOST_CONV_ADAM=1 cargo test --release --
  --test-threads=1`, 2.4 с) — 36 прежних плюс три новых:
  * `muon_step_matches_reference_formula` — шаг совпадает с формулой; у матрицы нет
    состояния (`opt.moment("m.w")` = `None`), у вектора есть, и его арифметика
    побитово прежняя;
  * `muon_q_block128_tracks_fp32_muon` — косинус 0.999994, поэлементный допуск по
    максимуму своего блока, и отдельная проверка, что расхождение **ненулевое**
    (иначе квантование молча не произошло бы);
  * `device_conv_muon_matches_host_reference` — device-ядро (в песочнице его зеркало)
    приходит к тем же весам, что эталонная формула: тот же int32-градиент через
    `device_grad_accum`, та же норма в f64. Худшее расхождение 8.8e-4 при масштабе
    веса 0.246 — это сам шаг Muon; ошибка против эталона на 5 порядков меньше.
    Тест читает веса новым `ConvQat::peek_device_weights`, потому что
    `sync_shadow_from_device` в host-режиме — no-op и сравнивать было бы нечего.
* Существующие тесты не правились по смыслу: в `device_conv_optimizer_pipeline_matches_host_pipeline`
  параметру добавлен `shape: None`, потому что он проверяет именно device-Adam.
* `nvcc -arch=sm_75` компилирует `kernels.cu` с новым ядром (объект 768 КБ),
  `TRBA_CUDA_ARCH=75 TRBA_REQUIRE_CUDA=1 cargo build --release` ⇒ `CUDA backend built`,
  в бинарнике 7 новых `T`-символов (6 LSTM + `launch_muon_step_f32`), в PTX 24 вхождения
  `muon_step_f32_kernel`.

### 14.7 Флаги

| переменная / флаг | значение |
|---|---|
| — (по умолчанию) | Muon для матриц + Adam для векторов, автомасштаб, cap 10, clip на первых 500 шагах |
| `TRBA_OPT=adam` | прежний Adam для всех параметров (A/B) |
| `TRBA_MUON_Q=1` | MuonQ: int8-градиент блоками (регуляризация, не ускорение — см. §14.3) |
| `TRBA_MUON_Q_BLOCK=N` | размер блока, дефолт 128 |
| `TRBA_MUON_CAP=X` | кап масштаба, дефолт 10 |
| `TRBA_MUON_AUTOSCALE=0` | выключить `lr·sqrt(max_dim)` |
| `TRBA_CLIP_WARMUP=N` / `--clip-warmup N` | сколько первых шагов считать глобальный clip, дефолт 500 |

При запуске печатается строка вида:

```
⚙️  оптимизатор: Muon (momentum-free) для матриц, lr·sqrt(max_dim) + Adam для векторов, cap 10 | глобальный clip: первые 500 шаг(ов)
```

Что запустить у себя:

```bash
cargo test --release muon -- --test-threads=1          # три теста, секунды
TRBA_CUDA_ARCH=75 TRBA_REQUIRE_CUDA=1 cargo build --release
TRBA_PROFILE=1 ./target/release/trba-rust train.csv val.csv exp \
    --img-w 512 --batch-size 8 --smoke 20               # clip_adam после warmup
# A/B против прежнего оптимизатора:
TRBA_OPT=adam TRBA_PROFILE=1 ./target/release/trba-rust ... --clip-warmup 100000
```

Смотреть в профиле: `clip_adam` должен упасть в разы, а после `--clip-warmup` шагов —
ещё примерно вдвое (уходит проход нормы и одна синхронизация на батч). Если лосс растёт
вместо того чтобы падать, первое, что уменьшить, — `TRBA_MUON_CAP` (например до 1.0) и
включить clip подольше (`--clip-warmup 5000`).

### 14.8 Состав поставки после этапа 10

Патч — те же **15 файлов**: `src/opt.rs` (переписан: `MuonSpec`, `ParamRef.shape`,
гибридный `step`, `sum_sq`/`scale_grads` параллельно, `muon_step_f32`, `muon_step_q`),
`src/main.rs` (`push2d!` и формы во всех 14 местах, clip-warmup, ветка device Muon,
`--clip-warmup`, баннер), `src/qnet.rs` (`DevOpt.gsq`, заглушки `m`/`v`, `device_muon`,
`device_muon_step`, `muon_conv_on_device`, `peek_device_weights`, защиты
`download_moment`/`upload_moment`/`device_adam`), `cuda/kernels.cu`
(`muon_step_f32_kernel` + лаунчер), `cuda/cpu_backend.cpp` (зеркало), `src/backend.rs`
(объявление), `src/tests.rs` (+3 теста), `README.md`, остальные файлы — как в §13.9.

---

## §15. Оптимизированный ONNX-инференс (экспорт из тех же весов, что и `--infer`)

**Что сделано.** Новый модуль `src/onnx.rs` (~1100 строк) пишет ONNX-граф
напрямую, без Python и без torch: собственный сериализатор protobuf
(varint/tag/`TensorProto`/`NodeProto`/`GraphProto`), opset 17, IR 8. Экспорт
идёт из тех же весов, которые использует `--infer`, поэтому граф можно сверить
с рантаймом побайтово.

```
trba-rust <imgs|dir|csv> "" <exp_dir> --charset C --img-h 32 --img-w 128 \
    --hidden 256 --max-len 16 --export-onnx M.onnx \
    [--onnx-layout nhwc|nchw] [--onnx-int8] [--onnx-no-decoder] \
    [--onnx-ref DIR] [--onnx-debug] [--onnx-calib N]
```

**Граф.** `input [batch,32,128,3]` → `feat [batch,16,512]` → `enc [batch,16,256]`
→ `ctc_logits [batch,16,31]` + `logits [batch,max_len+1,31]` + `pred` (int64).
BatchNorm свёрнут в Conv: `W' = W·γ/σ`, `b' = β − μ·γ/σ`, `σ² = run_var + 1e-5`.
`dim_param="batch"` — динамический батч. Attention-декодер развёрнут
(`build_decoder`, ~26 узлов на шаг) с автокорректной обратной связью через
`OneHot`, поэтому early-stop не нужен и граф статичен по числу шагов.

| граф | узлов | инициализаторов | размер |
|---|---|---|---|
| fp32, только энкодер | 188 | — | 181.4 МБ |
| fp32, с декодером | 641 | 130 | 184.2 МБ |
| **INT8 QDQ, энкодер** | **272** (28 пар Q/DQ) | — | **55.0 МБ (3.3×)** |

INT8-ветка ставит `QuantizeLinear`/`DequantizeLinear` вокруг свёрток по шкалам
QAT, собранным с реального прогона (`collect_act_scales`, `--onnx-calib N`),
поэтому onnxruntime может уйти в тензорные ядра, не переобучая модель.

**Сверка (независимый numpy против onnxruntime, toy-чекпоинт 5 эпох, n=4):**

| блок | относительная ошибка |
|---|---|
| stem (Conv+BN+ReLU+MaxPool) | 2.87e-7 |
| BiLSTM + проекция | 6.21e-7 |
| CTC-голова | 4.85e-7 |
| развёрнутый декодер | 8.08e-7 (обученный) / 4.3e-7 (случайные веса) |

Rust(int8 QAT) ↔ onnxruntime: `stem` cos 0.842 → `feat` 0.9766 → `enc` 0.99926
→ CTC-логиты **cos 0.99984, argmax 64/64** → логиты декодера **argmax 68/68**.
Текст: на случайных весах 4/4 строки совпали буквально (`цмншэкфяиииоо`) — это
и есть доказательство авторегрессионного цикла; на toy-наборе обе стороны
выдают пустую строку (модель недообучена), поэтому сравнение текста там
неинформативно.

**Найденное попутно (важно для точности, а не для экспорта).**

1. **`load_image_q` пишет HWC-interleaved, а `launch_im2col_pad` читает NCHW.**
   То есть обученные веса видят «перемешанные» каналы. Экспорт по умолчанию
   идёт в NHWC + `Transpose([0,3,1,2])`, чтобы граф повторял фактическое
   поведение рантайма; `--onnx-layout nchw` совпадает с фиктивным входом
   Python-референса Кожина, но НЕ с тем, на чём обучены веса Rust. Это
   кандидат в баги точности: исправление требует переобучения.
2. **У ONNX-оператора `LSTM` обратный выход `Y[:,1]` уже выровнен по позициям** —
   переворот по времени не нужен. Первая версия экспорта добавляла
   `Slice(steps=-1)`: cos падал до 0.97; после удаления — 8.7e-7. Решающая
   проверка: `R=0` и всплеск в `x[T-1]` дают отклик в `Y[T-1,1]`.
3. **Порядок вентилей.** trba-rust/PyTorch — `i,f,g,o`, ONNX `LSTM` — `i,o,f,c`,
   поэтому `perm_gates` с порядком `[0,3,1,2]` применяется к `W`, `R` и обеим
   половинам bias. В декодере `Split` идёт в том же порядке, что и Rust, —
   перестановка не нужна.
4. **Секция G сверки читала `ref_dec_logits.raw` не в той раскладке.** Rust
   пишет логиты декодера step-major `[steps,B,V]` (`greedy_decode_full`
   дописывает по блоку `[B,V]` на шаг), а сверка делала
   `reshape(n,steps,classes)` — отсюда косинус 0.2198 при полностью совпавших
   текстах. Исправлено: размер шага выводится из длины файла, затем
   `reshape(steps,n,classes).transpose(1,0,2)`. Секции E/F этот файл не читают.
5. **Пороги сверки для QDQ-графа другие.** onnxruntime исполняет настоящие
   int8-свёртки, поэтому `rel ≈ 8.6e-2` при `cos 0.99993` — корректное
   поведение, а не ошибка экспорта (прежний порог `rel ≤ 1e-4` там неприменим).

6. **Харнесс молча сдвигал словарь на единицу.** Строка
   `toks = [l.rstrip("\n") for l in open(charset) if l.strip()]` отбрасывала
   строку, состоящую из одного пробела, — а пробел в charset.txt Кожина
   полноценный класс (стоит четвёртым, после `<PAD> <SOS> <EOS>`). Все id
   ≥ 3 декодировались следующим символом, поэтому секция F рапортовала
   «текст не совпал 0/3» при совпавших **96/96** argmax логитов: `z`→`A`,
   `u`→`v`, `n`→`o`. Исправлено общим `read_charset()` (отбрасываются только
   пустые строки в хвосте) в обоих местах харнесса; загрузчики
   `main.rs::load_charset` (`!t.is_empty()`) и `mope_import.py::read_charset`
   были корректны изначально, то есть модель и конвертер не затронуты.
   После фикса на трёх картинках 64×256: **F — текст Rust ↔ ONNX 3/3
   идентичен** (`zunnnLI–s`), **G — логиты декодера cos 0.99988, argmax 27/27**
   (до фикса раскладки step-major там было 0.2198).
   Попутно выяснилось, что баг раскладки G при `n=1` невидим: транспозиция по
   батчу размера 1 — тождество, поэтому проверять её надо минимум на двух
   картинках.

Инструмент сверки: `tools/check_onnx_export.py REF_DIR MODEL.onnx [CHARSET]` —
секции A (checker + формы ort), B (Rust ↔ ort), C (numpy stem), D (numpy
BiLSTM+proj+CTC), E (numpy-развёртка декодера), F (текст Rust ↔ ONNX +
предсказанные id), G (логиты декодера).

**Осталось по ONNX:** юнит-тесты на сам сериализатор (round-trip protobuf,
`fold_conv_bn`, `perm_gates`, `greedy_decode` против
`greedy_decode_full(early_stop=true)`) — сейчас эти пути покрыты только
внешней сверкой с onnxruntime/numpy.

---

## §16. MoPE — Mixture of Pretrained Experts по техотчёту ZAYA1-8B

Отдельная реализация в `src/moe.rs` (~1750 строк, `pub mod moe;`), существующую
модель НЕ переписывает. Источник: ZAYA1-8B Technical Report, arXiv:2605.05365v1
(Zyphra, 06.05.2026), §II-A1…A3, §VI, Table I.

**Перенос терминов на OCR.**

| ZAYA1-8B | MoPE в trba-rust |
|---|---|
| токен | строка рукописи (кроп) — единица маршрутизации |
| эксперт FFN | **целая предобученная модель** на своём писаре/уставе |
| 16 экспертов/слой, top-1 | E = 2…256, top-k (по умолчанию 1) |
| residual stream `x_l` | mean ⊕ max пул признаков CNN `feat [B,T,512]` → `d_in = 1024` |
| SFT/RL на aggregation-промптах | отдельная стадия обучения агрегатора |
| `H(p)/ln E` | та же метрика в логах балансировки |

**Что перенесено дословно (с уравнениями).**

* Роутер, уравнения (1)–(4): `r = W_down·x` (R = 256), EDA `r += γ·r_prev`,
  `s = softmax(MLP(RMSNorm(r)))` — трёхслойный MLP с GeLU; выбор
  `argmax(s + b)` (`select()`).
* PID-балансировка, уравнение (5): `∇b_e = p_e − 1/E` через AdamW
  (`PidBias`), контроль по `H(p)/ln E`.
* Learned residual scaling, уравнение (6): `α·x + β`, по каналу, отдельные
  гейты для residual-потока и выхода слоя, инициализация `α=1, β=0`.
* CCA (§II-A1, Table I): свёрточный даунпроектор, сжатие запросов **2×** и
  KV **8×**, внимание уже в сжатом пространстве. Внутренности CCA из
  Appendix C получить не удалось (страница 20 — библиография, прокси-ссылки
  одноразовые), поэтому структура неперекрывающегося conv1d (kernel = stride)
  и одноголового внимания — документированная адаптация под OCR; коэффициенты
  2×/8× и место блока взяты из отчёта.
* Markovian RSA (§I, §VI): раунд 0 — **N** кандидатов; раунды t ≥ 1 — **C ≤ N**
  хвостов по **τ** токенов, склеенных в промпт агрегации, один улучшенный
  ответ; **T** раундов; штатно (N,C,T) = (16,4,2), `T=0` → Best-of-N,
  `C=1` → Delethink, `τ=β` → полная RSA. Реализация `markovian_rsa` чистая и
  параметрическая (generate/aggregate/rng), поэтому тестируется без модели.

**Канал переноса знаний между моделями** (то, что просил пользователь:
«от всех моделей беря лучшее»): цель роутера строится из лоссов/уверенностей
ВСЕХ экспертов — `targets_from_losses` = softmax(−loss/T), `targets_from_best`
= one-hot лучшего, `targets_from_rsa` = кредит экспертам, чьи кандидаты попали
в промпты и в финал. Плюс агрегатор, который читает хвосты чужих кандидатов и
подмешивает свой контекст в память декодера **дополнительным шагом** — поэтому
градиент по нему даёт существующий attention-декодер, без нового backward.

**Память (честная арифметика, а не обещание «256 экспертов в VRAM»).**
Эксперт = целая модель ≈ 45M параметров: 180 МБ в fp32 и **45 МБ в int8**.
256 экспертов = 11.5 ГБ int8 — на CMP 50HX (9798–10240 МиБ) не помещается,
поэтому int8-хранилище живёт в хосте, а в VRAM резидентно `--mope-cache K`
штук с вытеснением LRU; подмена одного эксперта ≈ 28 мс по PCIe 2.0 x4
(1600 МБ/с). 8–16 int8-экспертов входят в карту комфортно.

**Franken-MoE: эксперты разного происхождения, разной геометрии и разных словарей.**

Источники экспертов (можно вперемешку в одном запуске):

* `base.mope` — бандл из `trba_base_g1.onnx`/`.pth` Кожина
  (64×256, **1** слой BiLSTM, 194 токена дореформенной орфографии);
* `exp/checkpoint_last.bin` — чекпоинт trba-rust (32×128, 2 слоя, свой
  charset.txt, например куррентшрифт с умляутами);
* `kurrent.mope` — тот же чекпоинт trba-rust, выгруженный в бандл
  (`--mope-export-bundle`).

Конвертер `tools/mope_import.py`: ONNX/PyTorch → бандл `MOPEXP02` (геометрия +
словарь + именованные тензоры **в именах манифеста trba-rust**). Экспорт Кожина
обезличивает имена CNN-весов (`onnx::Conv_2428`), поэтому свёртки разбираются
по именам УЗЛОВ (`/cnn/layer1/layer1.0/conv1/Conv_output_0`), BN в нём уже
свёрнут в Conv — в trba-rust это представляется тождественным BN
(`γ=1, μ=0, σ²=1−eps`), а весь перенос уходит в `β`. Вентили LSTM
переставляются `i,o,f,c → i,f,g,o`. Отчёт конвертера на реальном
`trba_base_g1.onnx`: **28 свёрток, 22 SE-блока, 1 LSTM, 182 тензора,
45 097 858 параметров, 0 ложных срабатываний**; CTC-голова в экспорте Кожина
отсутствует (attention-only) и это сообщается прямо, а не подменяется чужим
тензором (первая версия `resolve` деградировала до суффикса `bias` и молча
брала `enc_rnn.0.linear.bias` — исправлено: суффикс не короче двух сегментов).

Слияние словарей `merge_charsets` (тот же алгоритм продублирован в Python и
покрыт тестами с обеих сторон): `<PAD> <SOS> <EOS>` всегда на 0..2 и не
выбрасываются; символ входит, если его суммарная частота ≥ `--mope-min-freq`
(3 или 7, как просили); без статистики символы НЕ теряются; при превышении
`--mope-charset-max` (256) отсекаются наименее частотные; порядок — первая
встреча; для каждого эксперта строится `remap`, а строки CTC-головы и
генератора переносятся в общий словарь через `remap_rows` (чужие строки
обнуляются: эксперт физически не может выдать символ, которого не было в его
разметке, и роутер должен это видеть).

Разные размерности дружатся так: каждый эксперт считает в СВОЕЙ геометрии
(свой img_h/img_w, свой hidden, своё число слоёв BiLSTM — для этого добавлен
`Model::new_layers`), а в общее пространство его переводят обучаемые адаптеры
(`Adapter`: признаки → 512 для роутера, контекст агрегации → hidden эксперта).
При совпадении размеров адаптер тождественен и не тратит ни времени, ни
точности. Отчёт `ExpertSpec::diff` печатает расхождения честно:

```
📦 trba_base_g1 [onnx] img 64×256 max_len 40 hidden 256 feat 512 классов 194 rnn 1
📦 exp_toy [trba-rust-bin] img 32×128 max_len 16 hidden 256 feat 512 классов 140 rnn 2
   ⇄ эксперт 1 отличается от 0: вход 32×128 против 64×256
   ⇄ эксперт 1 отличается от 0: словарь 140 против 194 токенов
   ⇄ эксперт 1 отличается от 0: max_len 16 против 40
   ⇄ эксперт 1 отличается от 0: слоёв BiLSTM 2 против 1
🔤 общий словарь: 88 токенов (порог частоты 3, предел 256); выброшено по экспертам: [117, 52]
```

**Замеренный прогон** (песочница: 2 ядра, ~2 ГБ ОЗУ, без GPU; эксперты —
реальный ONNX Кожина и бандл trba-rust со случайными весами, картинка
синтетическая, корпус частот — 3.9 КБ, поэтому текст бессмысленный, а словарь
ужался до 88 токенов; проверяется plumbing, не качество):

```
🧠 MoPE: 2 экспертов → int8 за 3.6 с (45 МБ/шт, 45124292 параметров)
   экспертов 2 | int8 45 МБ/шт | резидентно в VRAM 1 шт = 0.05 ГБ из 10.00 ГБ | подмена ~28 мс
🔀 RSA: N=2 C=2 T=1 τ=4 β=40 top-k=1 temperature=1 top-p=1
▸ line.png
   маршрутизация: [0] из 2, s(top-1) = 0.7243, 4.2 с/строка
   Best-of-2: trba_base_g1 «юааыееаае еащссуеащщуещъщуъуцъаауесу  щVю» score -1.6988
   RSA T=1: агрегатор «юааа ещысъысыыыъÄыъа(а.съаы ысамыъъасссыс» score -2.0659, промпт ≤ 8 (граница C·τ = 8)
  [trba_base_g1] 308 строк проекций перенесено в общий словарь
  балансировка H(p)/ln E = 0.0000 | средний лосс роутера 0.3226 | подмен экспертов 1
  bias (уравнение 5): [-0.01, 0.01]
💾 роутер + PID сохранены (1 577 124 байт)
```

**Тесты: 62/62** (было 39). Новые покрывают конечно-разностными проверками
градиенты `ResidualScaling`, `ConvDown`, `Cca`, `RouterMlp` (включая γ из EDA)
и `Aggregator`; PID-балансировку (перегруженный эксперт получает
отрицательный bias, при равномерной загрузке шаг нулевой); инварианты RSA
(ровно N кандидатов, ровно T раундов, C различных индексов, промпт = C·τ и не
превышает границу, `T=0` → Best-of-N, `C=1`, `τ=β`, отклонение `C>N` и `τ>β`);
цели роутера («лучший из всех моделей», при T→0 вырождается в one-hot);
int8 round-trip эксперта (ошибка ≤ половины шага, своя шкала на тензор) и LRU;
сохранение/загрузку роутера с PID и агрегатора (чужие размеры отклоняются, а не
применяются молча); сэмплирующее декодирование (при T→0 совпадает с argmax,
при T=2 даёт ≥4 различных токена, top-p=0.3 сужает ядро до одного, на
вырожденном ряде нет NaN); AdamW роутера (шаг ≈ −lr, decoupled wd);
`merge_charsets` (отсечка на 3 и 7, предел размера, дедупликация общего
символа, стабильный порядок, сохранение символов без статистики, `decode`
пропускает спецтокены и выброшенные); `Adapter` (тождественность при равных
размерностях + FD-градиент); `remap_rows`; round-trip бандла с не-ASCII
словарём и `rnn_layers`; `ExpertSpec::diff`; подсчёт частот по корпусу.

**Найденные при этом баги (исправлены).**

1. `RouterMlp::backward` не делил градиент softmax-CE на число строк, хотя
   лосс средний: градиенты были в `rows` раз больше (конечно-разностный тест
   показал ровно 3×). Исправлено: `d = (s − target)/rows`.
2. `merge_charsets` помечал «непроверенные» символы через
   `entry().or_insert(MAX/2)` ПОСЛЕ того, как та же запись уже была создана
   нулём — без корпуса частот отсекалось всё, кроме спецтокенов (словарь
   схлопывался до 3). Исправлено на присваивание.
3. `resolve()` в конвертере укорачивал суффикс до одиночного `weight`/`bias` и
   подставлял чужой тензор в CTC-голову. Исправлено: суффикс ≥ 2 сегментов.
4. `Adapter::backward` перепутал порядок возврата `lin_bwd` (`(dx,dw,db)`).
5. `markovian_rsa<…, Rng>` затенял трейт `rand::Rng` одноимённым параметром
   типа (E0404).

**Память в песочнице.** Пара экспертов 64×256 первое время убивалась
OOM-killer'ом (rc=137, RSS 1.67 ГБ): полную fp32-копию весов при деквантовании
(180 МБ) и новый `Scratch` на каждого кандидата (пул воркспейсов CPU-бэкенда не
возвращает память ОС). Исправлено поштучным `ExpertBlob::dequantize_one` и
одним общим `Scratch` на прогон: peak 1.57 ГБ для base×2 и 1.01 ГБ для
смешанной пары, все прогоны rc=0. На машине пользователя (10 ГБ VRAM, десятки
ГБ ОЗУ) это не ограничение.

**Чего MoPE пока НЕ умеет (честно).**

* Агрегатор по умолчанию не обучен: без стадии обучения он выдаёт случайные
  раунды, а отчёт прямо говорит «training ZAYA1-8B to understand the
  Markovian-RSA harness was important». Все части обучаемы (forward+backward у
  эмбеддингов, CCA, residual scaling, адаптеров, роутера), но сам цикл
  SFT-стадии (перемешанные rollout'ы экспертов → целевая разметка) ещё не
  собран в обучающий прогон; сейчас есть только онлайн-обучение роутера по
  сигналу «лучший из всех моделей» внутри `--mope`.
* `trba_lite_g1/g2/g3_prt` — depthwise-separable CNN; плотный `ConvQat`
  раздул бы 37 МБ в сотни МБ и замедлил свёртку, поэтому конвертер отклоняет
  lite с объяснением и вариантами (base как эксперт / внешний ONNX-рантайм).
* Сэмплирующее декодирование работает, но `top_p`-ядро пересчитывается на
  каждом шаге сортировкой — для N=16 и словаря 194 это приемлемо, для больших
  N стоит кэшировать.

---

## §17. Постепенный рост геометрии: `--resume` переносит веса, а не начинает с нуля

**Задача (формулировка пользователя):** «kurrent (32×128) нужно уметь расширять до
kurrent (64×256) опцией `--resume`, переиспользуя веса, а не с нуля продолжая
более крупную более выразительную. Постепенно наращивая размеры.»

### Что вообще зависит от размера картинки

Главный факт, на котором держится всё остальное: **свёртки, BatchNorm, SE-блоки,
BiLSTM и attention-декодер от разрешения входа не зависят**. Формы весов
определяют только `hidden`, `classes`, `rnn_layers` и выход CNN (`feat_dim`).
Разрешение меняет лишь число шагов `T = img_w/8`, а позиционных эмбеддингов в
архитектуре нет — поэтому рост `32×128 → 48×192 → 64×256` **бесплатный**:
переносятся все 138 тензоров без единой хирургической операции. Замер:

```
⇄ вход 64×256 вместо 32×128 (весов не касается: свёртки и BiLSTM от размера
   картинки не зависят, меняется только число шагов T)
🧬 перенос весов: скопировано 138 тензоров, выращено 0, усечено 0, пропущено 0
ℹ️  формы весов не изменились: разрешение и max_len на них не влияют
```

Цена роста разрешения — вычислительная, не весовая: 10 с/эпоха на 32×128
превращаются в 44 с/эпоха на 64×256 (4× пикселей), и CTC-лосс на первых порах
подскакивает (8.87 → 17.97), потому что шагов стало вдвое больше и модель
видит непривычные последовательности. Именно поэтому рост делают постепенно:
на каждой ступени сеть успевает привыкнуть к новому числу шагов.

### Хирургия весов при росте `hidden` (`src/surgery.rs`, ~700 строк)

Правило — Net2Net/Net2WiderNet: новые **строки** заполняются дубликатами
существующих (`r % src_rows` внутри своего блока), поэтому новая ячейка LSTM с
первого шага вычисляет осмысленное; новые **столбцы** (вклад новых ячеек в
старые) заполняются нулями при `--surgery-eps 0` — тогда выход сети
сохраняется **побитово**, либо шумом `±eps·std` при `eps > 0`, чтобы новые
ячейки получали градиент (нулевой столбец = мёртвый вес).

Критично, что тензоры нельзя просто «дописать в хвост»:

* вентили LSTM лежат блоками по `h` — строка `r` матрицы `[4h, ·]` это вентиль
  `r/h`, ячейка `r%h`, поэтому новые строки вставляются **в конец каждого из
  четырёх блоков**;
* `rnn*.proj.w [h, 2h]` — столбцы это два блока (прямое и обратное направления),
  новые столбцы идут в конец каждого;
* `attn.w_ih [4h, ctx+classes]` разбит и по строкам (4 вентиля), и по столбцам
  (контекст и эмбеддинг токена) — они растут независимо.

Всё это описывается одной структурой `Block { rows: Vec<(src,dst)>, cols:
Vec<(src,dst)> }`, а соответствие имени тензора разбиению — таблицей
`blocks_for()`. Семь тестов фиксируют именно блочность (включая проверку, что
новая строка вентиля `g` — дубликат из своего блока, а не из чужого).

### Доказательство сохранения функции (не на словах)

Один и тот же батч, одни и те же веса, три запуска:

| прогон | геометрия | attn | ctc | итог |
|---|---|---|---|---|
| A, эпоха 2 (эталон) | 32×128, h=64 | 4.9369 | 8.8665 | 6.0451 |
| B, resume без роста | 32×128, h=64 | 4.9369 | 8.8665 | 6.0451 |
| **C, рост h=64→96, `--surgery-eps 0`** | 32×128, h=96 | **4.9369** | **8.8665** | 6.1158 |
| D, рост h=64→96, `--surgery-eps 0.05` | 32×128, h=96 | 4.9370 | 8.8657 | 6.1156 |

Компоненты C совпадают с эталоном **побитово** при том, что параметров стало
вдвое больше (`rnn0.f.w_hh` 16384 → 36864, `attn.w_ih` 405504 → 804864).
Итоговый лосс отличается только потому, что он смешивается с эпохальным весом
CTC: `0.718·4.9369 + 0.282·8.8665 = 6.0451` у эталона против
`0.700·4.9369 + 0.300·8.8665 = 6.1158` у ступени роста (счётчик эпох
сбрасывается, поэтому `w_ctc` берётся для эпохи 1). Прогонов D показывает
ожидаемый дрейф от шума: ~1e-4 относительных.

### Формат чекпоинта V6

V5 не хранил ни геометрии, ни имён тензоров — только порядок, который совпадает
с `model.params()`, и точные длины. Поэтому:

* **V6** (`TRBA_V6\n`) = V5 + 7 чисел геометрии (`img_h, img_w, max_len, hidden,
  classes, rnn_layers, feat_dim`) + имя каждого тензора. Пишется всегда.
* **V5/V4 читаются**: порядок тензоров от геометрии не зависит, поэтому имена
  берутся из манифеста текущей модели по индексу, а геометрия источника
  выводится из форм (`geometry_from_lens`: `ctc.b` → classes, `attn.h2h.b` →
  hidden, число `rnn{i}.proj.b` → слои, `rnn0.f.w_ih / 4h` → feat_dim).
  Разрешение из весов не восстанавливается в принципе — и не нужно: на формы
  оно не влияет. В отчёте это печатается честно, а не как «вход 0×0»:
  `⇄ разрешение и max_len в V4/V5 не записываются — из форм весов выведены
  только hidden, словарь, число слоёв BiLSTM и выход CNN`.
* Проверено на реальном V5-чекпоинте прошлых прогонов (176.7 МБ, hidden 256):
  рост до 384 — 108 тензоров копируются, 30 растут, 58 Adam-моментов
  восстанавливаются, эпоха обучается за 11 с.

### Семантика `--epochs` после изменения геометрии

Прежняя логика (`start_epoch = epoch_done + 1`) делала ступень роста
бессмысленной: после чекпоинта с 20 эпохами команда `--grow-ladder "64x256:5"`
не обучила бы ничего, потому что `start_epoch = 21 > epochs`. Теперь **любое
изменение геометрии сбрасывает счётчики эпох и шагов оптимизатора**:
`--epochs N` задаёт бюджет этой ступени, warmup clip и bias-correction Adam
отрабатывают заново, а моменты изменённых тензоров обнулены (статистика старых
ячеек для новых не имеет смысла). Моменты тензоров, которые скопировались без
изменений, переносятся как есть. Если же геометрия совпала и обучать действительно
нечего, это говорится прямо, а не молча:

```
ℹ️  в чекпоинте завершено эпох: 2, а --epochs 1 — обучать нечего. Увеличьте
    --epochs либо растите геометрию (--img-h/--img-w/--hidden, --grow-ladder)
```

### Лестница роста одной командой

```bash
cargo run --release -- $D/train.csv $D/val.csv exp/ --epochs 30 \
    --grow-ladder "48x192:5,64x256:10,64x256h384:15"
```

Спецификация ступени — `HxW[hNNN][LNN][mNN][:эпохи]`; каждая ступень наследует
предыдущую, а не базовую геометрию. Замеренный прогон двух ступеней:

```
🪜 лестница роста от 32×128 max_len 8 hidden 64 классов 140 rnn 2 feat 512:
   ступень 1: 48×192 … hidden 64 — 1 эпох(и)
        ⇄ вход 48×192 вместо 32×128 (весов не касается …)
   ступень 2: 64×256 … hidden 96 — 1 эпох(и)
        ⇄ hidden 96 вместо 64 — хирургия rnn/attn/ctc: рост
▶ ступень 1/2 … 🧬 скопировано 138 тензоров, выращено 0 | Эпоха 1/1 | 22s | loss 7.4378
   💾 слепок ступени: exp/checkpoint_stage01_48x192h64.bin
▶ ступень 2/2 … 🧬 скопировано 108, выращено 30 | Эпоха 1/1 | 44s | loss 8.7821
   💾 слепок ступени: exp/checkpoint_stage02_64x256h96.bin
✅ лестница роста пройдена: 64×256 max_len 8 hidden 96 …
```

Каждая ступень — отдельный процесс (`run_grow_ladder` перезапускает сам себя с
подставленной геометрией): это не расточительство, а гарантия, что память прошлой
ступени точно освобождена (в песочнице с 2 ГБ ОЗУ иначе OOM), и что падение одной
ступени не теряет сохранённые. Неудача ступени прерывает лестницу с сообщением —
иначе рост продолжился бы из неполных весов.

### `--inspect-ckpt`: посмотреть до того, как расти

```
🔎 exp_onnx3/checkpoint_last.bin (V5 формат, 176.7 МБ)
   завершено эпох: 2 | батч внутри эпохи: 0 | шаг оптимизатора: 2 | Adam-моменты: есть
   геометрия чекпоинта: hidden 256 классов 140 rnn 2 feat 512
   геометрия запуска  : 64×256 max_len 8 hidden 384 классов 140 rnn 2 feat 512
   ⇄ hidden 384 вместо 256 — хирургия rnn/attn/ctc: рост
   🔧 attn.w_ih: 405504 → 804864 (рост)
   …
   итог: 108 тензоров копируются как есть, 30 меняют форму, всего в файле 138
   ✅ рост бесплатный: разрешение и max_len на формы весов не влияют
```

Заголовок читается одним проходом с пропуском данных через `seek`, поэтому
просмотр 500-МБ чекпоинта мгновенный и не требует видеопамяти.

### `--help` с примерами

Справка переписана: восемь готовых рецептов (дым, полное обучение, autotune,
`--infer`, постепенный рост a–e, ONNX fp32/INT8, MoPE, сборка под sm_75) с
реальными путями датасета, отдельный блок переменных окружения
(`TRBA_REQUIRE_CUDA`, `TRBA_CUDA_ARCH`, `TRBA_HOST_CONV_ADAM`, `TRBA_GPU_RNN`,
`TRBA_PCIE_COUNTER`, `TRBA_INT8_GEMM`, `TRBA_FORCE_CPU`) и полный список флагов
с новыми `--rnn-layers`, `--surgery-eps`, `--grow-ladder`, `--inspect-ckpt`.

### Тесты: 75/75 (было 62)

Новые 13 — на `src/surgery.rs`: побитовое сохранение логитов при `eps=0`;
вентильные строки растут внутри своих блоков, а не в хвост; `proj.w` — два
блочных столбца (прямое/обратное направления); `attn.w_ih` — 4 вентильных блока
строк и две группы столбцов (контекст + словарь); усечение идёт по тем же блокам;
шум `eps` мал, детерминирован при одном seed и ломает симметрию дубликатов;
рост разрешения и `max_len` не меняет ни одной формы; рост словаря переносит
строки выходов; чужое семейство (свёртка при несовпавшей форме) получает
`Skip` с причиной, а не мусор; разбор спецификации ступени (`64x256h384L3m32`,
ошибки на `h384`, `64x`, `64x256z9`, `64x256h0`); вывод геометрии из длин
тензоров; лестница наследует предыдущую ступень; направление `diff` (рост против
усечения) зависит от порядка аргументов — именно этот баг был найден тестом
после того, как предпросмотр лестницы напечатал «усечение» для роста.

### Найденные и исправленные баги этого раунда

1. **Инверсия направления в `Geometry::diff`**: сообщение «рост/усечение»
   вычислялось как `other.hidden > self.hidden`, а предпросмотр лестницы вызывал
   `new.diff(old)` — рост 64→96 печатался как «усечение». Исправлено: `diff`
   читается строго как переход от `self` к `other` (`old.diff(&new)`), порядок
   зафиксирован тестом.
2. **Ступень роста не обучала бы ничего** при `start_epoch > --epochs`
   (см. выше) — исправлено сбросом счётчиков при изменении геометрии и явным
   сообщением, когда обучать действительно нечего.
3. **V6 не читался бы старым загрузчиком** в `--infer`/`--export-onnx`/`--mope`:
   `load_checkpoint` переписан как делегирование в `load_checkpoint_surgery`,
   поэтому все пути понимают V6/V5/V4, а расхождение форм больше не приводит к
   молчаливому переобучению половины модели.
4. **Пустой аргумент `""`** в shell-переменной съедается при раскрытии без кавычек
   (проверено на себе: `exp_dir` уезжал в `exp/`, а `--inspect-ckpt` оставался без
   значения и запускал 100 эпох) — в рецептах `--help` и в тестах используются
   bash-массивы `"${ARGS[@]}"`.

### Ограничения роста (честно)

* Рост `--rnn-layers` **не** сохраняет функцию: новому слою BiLSTM не из чего
  расти, он инициализируется заново (в отчёте так и печатается). Старые слои
  переносятся.
* Число каналов CNN (`feat_dim`)固定 512: `SEResNetQ::new()` его не
  параметризует, поэтому рост «выразительности» идёт через `hidden`, глубину
  BiLSTM и разрешение, а не через ширину свёрток.
* Перенос поштучный, без межслойного перемасштабирования (в духе uptraining'а
  LLaMA, где embedding/выход делят на число дубликатов): при `eps > 0` дрейф
  выхода остаётся в пределах ~eps, при `eps = 0` он нулевой, поэтому
  перемасштабирование не понадобилось.
* Шкалы int8-активаций переносятся как есть и уточняются на новых батчах: при
  скачке разрешения в 4 раза первые батчи могут квантоваться грубее, чем в
  установившемся режиме (лечится ступенчатым ростом и `--smoke`-проверкой).

### §17.1. A/B «рост против обучения с нуля» — и баг, который этот опыт вскрыл

Опыт: 6 синтетических картинок, charset 97 токенов, `hidden 64`, batch 3, seed 7.
Обе руки получают **одинаковый бюджет в целевой геометрии** — 3 эпохи на 64×256
(2 батча на эпоху, ~93 с/эпоха). Рука G дополнительно потратила 69 с на 3 эпохи
при 32×128 (23 с/эпоха).

| эпоха на 64×256 | S: с нуля | G: рост из 32×128 | G2: рост после фикса моментов |
|---|---|---|---|
| 1 | 8.1669 (attn 4.5772, ctc 16.5428) | **8.1021** (attn 4.5703, ctc 16.3432) | 8.1058 (attn 4.5711, ctc 16.3534) |
| 2 | **7.5571** (attn 4.5740, ctc 15.1523) | 7.6273 (attn 4.5638, ctc 15.4275) | 7.6408 (attn 4.5658, ctc 15.4703) |
| 3 | **6.8349** (attn 4.5659, ctc 13.1605) | 7.1027 (attn 4.5634, ctc 14.1820) | 7.1208 (attn 4.5657, ctc 14.2441) |

**Что видно.** Форы у переноса реальны, но локальны: рука G стартует ниже (8.10
против 8.17) и её attention-ветка лучше на каждой эпохе (4.5634 против 4.5659).
Проигрыш к третьей эпохе целиком сделан CTC-веткой: у S она падает на 3.38,
у G — на 2.11.

**Почему так, и почему это не опровергает перенос.**

1. Бюджет — 6 шагов оптимизатора на всю ступень. За 6 шагов перенесённые веса
   не успевают перестроиться, а случайно инициализированной модели нечего
   разучивать. Прогрессивный рост применяют именно потому, что на ступени дают
   десятки эпох, а не шесть.
2. При росте 32×128 → 64×256 число шагов `T` удваивается (16 → 32), а `max_len`
   остался 8: CTC-голова видит вдвое больше кадров на тот же текст, то есть
   вдвое больше blank'ов. Перенесённый приоритет «blank доминирует» настроен на
   другую плотность кадров — его надо переучивать, и это самая чувствительная к
   смене разрешения часть модели. Attention-ветка от T зависит слабее, поэтому
   она и выигрывает сразу.
3. CNN руки G обучалась на **уменьшенных** копиях тех же картинок, то есть на
   размытых штрихах. На синтетическом шуме с произвольными подписями
   переносить нечего (структуры штриха нет, модель запоминает 6 картинок),
   поэтому опыт измеряет скорость адаптации, а не ценность переноса. На реальном
   куррентшрифте переносятся именно формы букв и штрихов — то, что помогает.

**Практические следствия (внесены в рекомендации):**

* ступени роста разрешения нужны короткие: `32×128 → 48×192 → 64×256`, а не
  одним скачком;
* бюджет ступени — не менее 10–20 эпох, иначе перенесённые веса не успевают
  переучиться под новое `T`;
* `max_len` полезно растить вместе с `img_w` (`32x128m8 → 64x256m16`), чтобы
  плотность кадров на символ не менялась скачком;
* контролируйте фору по лоссу **первой** эпохи новой ступени против прогона с
  нуля: если перенос сработал, первая эпоха начинается ниже (здесь 8.10 против
  8.17).

**Баг, который опыт вскрыл (исправлен).** Счётчик шагов `opt.t` при смене
геометрии сбрасывался в 0, а Adam-моменты переносились из чекпоинта. Поправка на
смещение `m_hat = m/(1-β1^t)` при `t = 1` равна `1/(1-0.9) = 10`, поэтому первый
шаг на новой ступени выходил примерно в 9 раз крупнее обычного — прыжок, который
мог смазать весь перенос. Исправлено предикатом `Geometry::same_training_regime`:
моменты переносятся только если не изменились **ни формы весов, ни число шагов**;
в противном случае оптимизатор стартует чистым (и об этом печатается
`ℹ️ Adam-моменты НЕ перенесены: … первый шаг в ~9 раз больше обычного`). На этом
toy-опыте эффект мал (7.1027 → 7.1208) — шесть шагов слишком короткий горизонт,
— но на длинных ступенях усиление первого шага в 9 раз уже существенно.
Добавлены `same_weight_shapes`/`same_training_regime` и тест
`moments_are_only_worth_carrying_in_the_same_regime` (включая случай V4/V5, где
разрешение неизвестно и режим сравнивается только по формам). Тестов стало 76.

---

## §18. Распараллеливание CPU-горячего пути (rayon) + два найденных бага декодера

Запрос: «Параллелить rayon CPU операции надо» — по профилю пользователя
(`TRBA_PROFILE=1`, epoch 13/500, 12066 мс/батч) **CPU занимал 11006 мс (91%)**:
`rnn_bwd` 6028 мс (50.0%), `attn_fwd` 2724.72 (22.6%), `attn_bwd` 1327.37 (11.0%),
`rnn_fwd` 877.56 (7.3%); GPU при этом 1041 мс (9%), PCIe 18.5 мс.
rayon в проекте уже был, но только в «старых» модулях (`attention.rs`, `bilstm.rs`,
`conv2d.rs`); живые `attn.rs` и `rnn.rs` считали почти всё в один поток.

### 18.1. Что найдено при чтении кода (до всякого параллелизма)

**(а) `AttentionDecoder::backward` пересчитывал `d_alpha` квадратично.**
Блок «h2h grad» выглядел так:

```rust
for bi in 0..b {
    for tt in 0..t {
        let mut d_alpha = vec![0.0f32; t];          // ← аллокация на каждой итерации
        for tt2 in 0..t { /* d_alpha[tt2] = Σ_k dctx[k]·batch_h[tt2][k] */ }
        let dot = (0..t).map(|x| alpha[x]*d_alpha[x]).sum();   // ← O(t) заново
        let de = alpha[tt]*(d_alpha[tt]-dot);
        ...
    }
}
```

Весь вектор `d_alpha[0..t]` и `dot` пересчитывались **внутри** цикла по `tt`,
то есть O(t²·c) вместо O(t·c), плюс `b·t·steps` аллокаций (на конфигурации
пользователя b=32, t=32, steps=41 это 41 984 аллокации на батч). Тот же самый
`d_alpha` уже был посчитан чуть выше, в блоке «context gradients -> alpha».
На b=32, t=32, c=512, hs=256 лишний объём — **≈1.0 GMAC/батч** против ≈2.2 GMAC
полезной арифметики всего `attn_bwd`. Рядом лежал и мёртвый блок
`let dprojhh = { … for tt in 0..t { let _ = tt; } v }; let _ = dprojhh;` — ещё
одна аллокация на каждую пару (шаг, образец).

Итог: `d_alpha`/`dot` считаются один раз на (шаг, образец) в регионе P1 и
переиспользуются регионами P2a/P2b/P3; мёртвый блок удалён.

**(б) `LstmDir::bwd_dir` был последовательным и гонял градиенты по памяти
b раз.** Единственный цикл `for bi { … for o in 0..4h { … for k … } }` на каждом
образце проходил по всему блоку `g_w_ih` (4h·d) и `g_w_hh` (4h·h): при hidden=256,
d=512 это ≈3 МБ на образец, то есть **трафик ∝ b** (96 МБ на шаг·направление·слой
при b=32 против 3 МБ минимально возможных). Отсюда 6028 мс/батч при ~3.2 GMAC
арифметики — стадия была ограничена памятью, а не счётом.

**(в) БАГ: `forward_train` клал контекст внимания не в свой слот.**

```rust
for bi in 0..b {
    onehots[st*b*v + bi*v + text_in[bi][st]] = 1.0;
    cell_in[st*b*(c+v) .. st*b*(c+v)+c].copy_from_slice(&context[bi*c..(bi+1)*c]);  // ← НЕТ + bi*(c+v)
    let co = st*b*(c+v) + bi*(c+v) + c;                                             // ← а здесь bi учтён
    cell_in[co..co+v].copy_from_slice(&onehots[...]);
}
```

Диапазон для контекста не содержал `bi*(c+v)`, поэтому **все** образцы писали свой
контекст в слот нулевого образца: образец 0 получал контекст последнего образца,
а образцы 1..b−1 — **нули** вместо визуального контекста. One-hot часть при этом
ложилась правильно, поэтому расхождение было не видно по форме тензора.

Декодер (`decode_full`: `ci[bi*(c+v) .. bi*(c+v)+c]`) и ONNX-граф
(`Concat(dec_context, onehot)` по образцам) всегда делали это правильно — то есть
**обучение расходилось с инференсом при любом batch > 1**. При batch=1 баг
невидим (единственный образец пишет в свой же слот), чем и объясняется, что он
дожил до сих пор: все smoke-проверки и эталоны шли на b=1…3, а сравнение с
onnxruntime — через `decode_full`.

Исправление попало в код вместе с параллельной версией региона (там контекст
пишется в чанк своего образца). Оно закреплено тестом
`forward_train_feeds_each_sample_its_own_attention_context`: признаки образца 0
сплошь 1.0, образца 1 — 2.0, тогда контекст (выпуклая комбинация строк `batch_h`
с весами `alpha`) обязан быть 1.0/2.0 независимо от `alpha`.

* На новом коде: `77 passed`.
* На оригинальном коде тот же тест падает:
  `шаг 0 образец 0 элемент 0: в cell_in лежит 2.0000 вместо 1.0 (чужой или нулевой контекст)`.

**Практическое следствие для уже обученных моделей.** Чекпоинт, обученный с
batch=32, обучался на покалеченном входе декодера: 31 образец из 32 не видел
картинку, а нулевой видел чужую. Ветвь attention при этом всё равно сходится —
но к языковому prior, а не к визуальному контексту (профиль пользователя:
attn-loss 4.6447 при ctc 4.7462, то есть ветви почти равны, хотя attention
декодер обязан быть сильнее CTC именно за счёт контекста). После фикса при
`--resume` attn-loss сначала подрастёт (веса адаптированы к нулевому входу),
затем должен уйти ниже прежнего уровня; CTC-ветвь не затрагивается.

### 18.2. Что распараллелено

Принцип: **порядок суммирования каждого аккумулятора сохранён**, поэтому числа
не меняются. Параллелизм там, где записи не пересекаются.

`src/rnn.rs`
* `run_dir` — активация вентилей (exp/tanh) по образцам батча; матричное
  умножение вентилей было параллельным и раньше.
* `bwd_dir` разделён на три региона, каждый со своим порядком:
  * **A** градиенты вентилей — параллельно по `bi` (`dgates`/`dc_next`/`dh_next`
    у каждого образца свои);
  * **B** градиенты весов — параллельно по строкам `o` (`g_w_ih[o·d..]`,
    `g_w_hh[o·h..]`, `g_b_*[o]`), суммирование по `bi` внутри строки в прежнем
    порядке 0..b. Это заодно чинит (б): строка градиента (2 кБ) остаётся в кэше,
    пока по ней проходят все образцы, вместо потока по 3 МБ на образец;
  * **C** `dx` и `dh_next` — параллельно по `bi`, веса только читаются.
* `proj_grads` — параллельно по строкам `o` при внутреннем цикле по `r`.
* `dx = dx1 + dx2` — поэлементно параллельно.

`src/attn.rs`
* `cell_gates`, tanh+score, softmax, context, onehot/`cell_in`, активация
  вентилей, перестановка `[steps,B,V] → [B,steps,V]` — параллельно по образцам
  (tanh+score — по парам (образец, позиция)).
* `backward`: регион A (вентили) и B2 (`d_cellin`, `dh_prev`) — по `bi`;
  регион B1 (градиенты весов клетки) — по `o`; P1 (`d_alpha`, `dot`, `d_batch_h`)
  — по `bi`; P2a (`d_proj_h`) — по `bi`; **P2b (`score.g_w`) — по `k`**, потому
  что этот аккумулятор общий для всех (bi, tt) и порядок суммирования по
  (bi, tt) можно сохранить только так; P3 (`d proj_hh`) — по `bi`.

`src/qnet.rs`
* `LinearF::forward` — параллельно по строкам (это `i2h`, `h2h`, `generator`,
  CTC-голова).
* новый `LinearF::backward_rows_par(x, dy, rows)` — батч-версия `backward_row`:
  проход 1 считает градиенты весов параллельно по `o` (внутри — по `r` в прежнем
  порядке), проход 2 считает `dx` параллельно по `r` (внутри — по `o`). Объём
  арифметики тот же, что у слитной версии (по одному умножению на элемент в
  каждом проходе), а `b·t` отдельных вызовов превращаются в два параллельных
  прохода. Используется для `generator` (steps·b строк), `h2h` (b строк на шаг)
  и `i2h` (b·t строк).
* `par_min(ops)` — порог для `with_min_len`: `1` (параллелить) при ops ≥ 2^16,
  иначе `usize::MAX` (выполнить регион последовательно в вызывающем потоке).
  Без порога на мелких батчах шесть регионов по 3–5 мкс на шаг декодера давали
  **+19…30% к `attn_fwd` при одном потоке**; на рабочих размерах (b=32,
  hidden=256) каждый регион в сотни раз больше порога и распараллеливается
  всегда.

### 18.3. Как проверена побитовость

Сравнение md5 чекпоинта после одного и того же шага обучения из одного и того же
стартового чекпоинта (`base.bin`, 32×128 h128, batch 3):

| сборка | потоков | md5 чекпоинта | loss (attn / ctc) |
|---|---|---|---|
| оригинал | 1 | `880a9ef8…` | 5.5218 (4.5690 / 7.9477) |
| оригинал | 1 (повтор) | `880a9ef8…` | 5.5218 (4.5690 / 7.9477) |
| оригинал | 2 | `880a9ef8…` | 5.5218 (4.5690 / 7.9477) |
| **гибрид**: старый `attn.forward` + новые `attn.backward`, `rnn.rs`, `qnet.rs` | 1 | `880a9ef8…` | 5.5218 (4.5690 / 7.9477) |
| новая сборка | 1 | `8863e40a…` | 5.5217 (4.5689 / 7.9477) |
| новая сборка | 2 | `8863e40a…` | 5.5217 (4.5689 / 7.9477) |

Отсюда три вывода:
1. новая сборка **не зависит от числа потоков** (`new@1 == new@2` побитово) —
   порядок суммирования действительно сохранён;
2. `rnn.rs`, `qnet.rs` и `attn.backward` **побитово эквивалентны оригиналу**
   (гибрид дал тот же md5, что и оригинал);
3. единственное отличие новой сборки — исправленный `cell_in` в `attn.forward`:
   CTC-ветвь осталась побитово той же (7.9477), изменилась только attention
   (4.5690 → 4.5689), потому что веса декодера — единственные, на которые
   влияет этот баг.

`cargo test --release -- --test-threads=1`: **77 passed / 0 failed**.

### 18.4. Замеры (песочница: 2 ядра, 6 синтетических картинок, batch 3, hidden 128)

мс/батч, `TRBA_FORCE_CPU=1 TRBA_PROFILE=1`, `RAYON_NUM_THREADS` = 1 или 2.
`t` — число шагов BiLSTM (= img_w/8).

img 32×128 (t=16), среднее по 5 батчам:

| фаза | было, 1 поток | было, 2 | стало, 1 | стало, 2 |
|---|---|---|---|---|
| rnn_fwd | 61.18 | 50.16 | 62.85 | 48.82 |
| attn_fwd | 14.50 | 14.35 | 17.26 | 15.51 |
| attn_bwd | 46.27 | 44.07 | **37.52** | **33.01** |
| rnn_bwd | 73.00 | 72.95 | 80.86 | **59.55** |

img 32×256 (t=32), среднее по 2 батчам:

| фаза | было, 1 поток | было, 2 | стало, 1 | стало, 2 |
|---|---|---|---|---|
| rnn_fwd | 125.74 | 99.73 | 121.73 | 98.34 |
| attn_fwd | 16.50 | 16.31 | 18.25 | 16.34 |
| attn_bwd | 67.27 | 66.97 | **50.84** | **49.04** |
| rnn_bwd | 153.74 | 143.58 | 157.30 | **111.70** |

Честное чтение этих таблиц:
* `attn_bwd` ускоряется **и на одном потоке** (−24% при t=32) — это
  алгоритмическая часть (убран квадратичный пересчёт и 42k аллокаций);
  остальные ~3–5% дают потоки.
* `rnn_bwd` на двух потоках −18% (t=16) и −22% (t=32); на одном потоке чуть
  медленнее (+2…+10%) — цена split/join региона B, которая на двух ядрах
  окупается, а на одном нет.
* `rnn_fwd`/`attn_fwd` в пределах шума (±10% между повторными прогонами одной и
  той же сборки), при одном потоке `attn_fwd` немного хуже — остаточная цена
  параллельного `cell_gates` (порог `par_min` на b=3 его не отключает: работы
  там 1.1 млн операций).

### 18.5. Почему на машине пользователя выигрыш должен быть заметно больше

Замеры выше сделаны на **2 ядрах и batch=3** — это худший случай для такой
параллелизации: в регионах «по образцам» всего 3 задачи, а ускорение от
переупорядочивания региона B пропорционально `b`. На конфигурации из профиля
(b=32, t=32, hidden=256, 41 шаг декодера, ядер много):

* регион B в `bwd_dir`: задач 4h = 1024 вместо 512, сумм по `bi` — 32 вместо 3;
  трафик по градиентам падает примерно в `b` раз (96 МБ → 3 МБ на
  шаг·направление·слой), а именно трафик, а не арифметика, давал 6028 мс;
* регионы «по образцам» в `attn`: 32 задачи вместо 3;
* квадратичный член `attn_bwd` рос как t² — при t=32 он убран целиком
  (~1.0 GMAC/батч и ~42k аллокаций).

Оценка сверху (не замер, а проекция по долям из профиля пользователя): если
`rnn_bwd` ускорится в 2–4 раза, `attn_fwd` в 2–4 раза, `attn_bwd` в 3–5 раз и
`rnn_fwd` вдвое, CPU-составляющая падает с 11006 до ~3000–4000 мс, а батч — с
12066 до ~4500–5000 мс, то есть **эпоха ~2.5 раза быстрее**. Проверить у себя:
тот же `TRBA_PROFILE=1` и сравнение долей `rnn_bwd`/`attn_fwd`; число потоков
rayon задаётся `RAYON_NUM_THREADS` (по умолчанию — все ядра).

---

## §19. Franken-MoPE: дообучение после конвертации (`--mope-train`, контейнер `MOPEFR01`)

Запрос: «Нужна полная поддержка обучения MoPE после конвертации. Пока не ясно
что делать после создания 2 и более .mope файлов из onnx и bin чтобы запустилось
дообучение роутера и всего Franken-MoPE».

Короткий ответ до этого этапа был таким: после конвертации можно было запустить
`--mope`, посмотреть Best-of-N и Markovian RSA и… всё. Обучался один роутер,
учитель у него был свой собственный, агрегатор оставался случайным, адаптеры не
сохранялись, эпох и контроля не было. Ниже — что именно мешало, что добавлено и
чем это проверено.

### 19.1. Диагноз: шесть дыр между «конвертировал» и «дообучил»

**(а) Учителем роутера были его же собственные кандидаты.** `run_mope` читал
вход через `collect_infer_inputs`, а она выбрасывает разметку (ей нужны только
пути к картинкам). Поэтому единственной доступной целью была
`targets_from_losses(&losses)`, где `losses[e] = min(−cand.score)` — лог-вероятности
собственных сгенерированных кандидатов. Формально это тот же «лучший из всех
моделей», но измеряется он самооценкой модели, а не совпадением с настоящим
текстом: у двух одинаково плохих экспертов цель вырождается, у уверенно
ошибающегося — врёт. В ZAYA1-8B стадия обучения на harness обязательна именно
потому, что сигнал приходит извне.

**(б) Агрегатор, CCA и Res-scale не обучались никогда.** `save_aggregator`
существовала, но не вызывалась ни разу (мёртвый код), `Aggregator::backward`
никто не звал, и отчёт сам это признавал:
`⚠️ агрегатор не обучен (--mope-agg): его раунды случайны, смотрите на Best-of-N`.
То есть раунды Markovian RSA (главная часть переноса знаний) работали на
случайных весах.

**(в) Адаптеры размерностей не обучались и не сериализовались.** `Adapter`
создавался тождественным, применялся в forward, но градиенты в него не шли
(`backward` не вызывался), а сохранить его было некуда: ни `--mope-save-router`,
ни мёртвая `save_aggregator` адаптеров не знали. Franken-MoPE из экспертов с
разным `hidden` (ровно кейс «ONNX Кожина 64×256 hidden 256 + свой чекпоинт
hidden 384») терял всё обученное при выходе из процесса.

**(г) В MoPE-режиме не было ни эпох, ни контроля.** `--epochs`, `--eval-every`
и второй позиционный аргумент (`val.csv`) игнорировались: один проход по
`--mope-limit` строкам, причём дефолт лимита — **4** (см. 19.6).

**(д) Не было единого артефакта.** Роутер — в `--mope-save-router`, агрегатор —
никуда, PID-состояние — внутри файла роутера, адаптеры — никуда, состояние Adam
— никуда. «Один файл, который инференс подхватывает целиком» отсутствовал как
класс.

**(е) Баг размерности в агрегации (исправлен).** Замыкание `aggregate` подставляло
в память декодера контекст агрегатора напрямую, минуя адаптер контекста:

```rust
// было: ctx_ad[ei] не применялся — для эксперта с чужим hidden это вектор
// не той размерности, а при совпадении hidden молча пропускался обучаемый слой
let ctx_e = atr.ctx.clone();

// стало: адаптер применяется всегда; при совпадении размеров он тождественен
// и ветка `is_identity()` не стоит ни времени, ни точности
let ctx_ad_pick = ctx_ad[picked_a[0]].clone();
let ctx_e = if ctx_ad_pick.is_identity() { atr.ctx.clone() } else { ctx_ad_pick.forward(&atr.ctx, 1) };
```

`.clone()` здесь не случайность: адаптер живёт в общем `Vec`, а замыкание
захватывает его по значению, иначе borrow checker не даёт одновременно читать
`ctx_ad` и писать в `agg` (`Rc<RefCell<..>>`).

### 19.2. Что добавлено

**`src/moe.rs`** (конец файла, ~330 строк):

* `FlatAdam { m, v, t, b1, b2, eps }` — Adam по плоскому списку размеров.
  `RouterAdam` не годился: у него семь жёстко зашитых форм под роутер, а у
  агрегатора 16 обучаемых тензоров, у адаптеров — по четыре на штуку.
* `Aggregator::adam_shapes() -> Vec<usize>` и `Aggregator::adam_step(&mut FlatAdam, lr, wd)`
  — **порядок тензоров зафиксирован и покрыт тестом**: token/segment/position
  эмбеддинги, `q_conv.{w,b}`, `kv_conv.{w,b}`, `wq`, `wk`, `wv`, `wo`, `bo`,
  `res_out.{alpha,beta}`, `res_res.{alpha,beta}`. Рассинхрон порядка означал бы
  молча разъехавшиеся моменты Adam — самый противный класс бага, потому что
  обучение при этом «работает», но хуже.
* `FRANKEN_MAGIC = b"MOPEFR01"`, `struct Franken { itos, router, pid, agg,
  feat_ad, ctx_ad, steps, opt }`, `save_franken(..)`, `Frd` (читатель с
  проверкой границ на каждое поле), `load_franken`, `franken_report`.
  `save_franken` принимает **ссылки**, а не значения: агрегатор живёт в
  `Rc<RefCell<Aggregator>>`, а ни `Aggregator`, ни `RouterMlp` не `Clone`.

**`src/main.rs`**:

* вспомогательные функции `teacher_ce` (CE teacher-forced прогона против
  настоящей разметки), `mope_forward_all` (один проход по всем экспертам:
  признаки опорного эксперта для роутера + CE каждого эксперта),
  `mope_oracle` (индекс лучшего по CE), `adapter_shapes`, `adapters_adam_step`;
* драйвер `--mope-train` (~340 строк) — см. 19.3;
* пять флагов: `--mope-train`, `--mope-target soft|hard`, `--mope-agg-lr`
  (дефолт 3e-4), `--mope-save-franken PATH`, `--mope-franken PATH`;
* блок загрузки состояния с проверкой размеров (число экспертов, `d_in`
  роутера, число классов агрегатора) и предупреждением о разъехавшемся словаре
  вместо падения;
* `--mope-adapt` и заморозка роутера на инференсе — см. 19.5.

### 19.3. Анатомия одного шага дообучения

На каждую строку `train.csv` («путь,текст»):

1. **Все эксперты читают строку** (`mope_forward_all`): у каждого свой вход
   (своя геометрия, свой словарь через `merged.remap`), на выходе — CE
   teacher-forced прогона против настоящей разметки (`teacher_ce`) и признаки
   опорного эксперта для роутера.
2. **Роутер**: `feat_ad[0]` → `pool_feat` (mean⊕max, 1024) → `forward` →
   цель `softmax(−CE/T)` (`soft`) или one-hot лучшего (`hard`) → `backward` →
   `RouterAdam::step`. Вход роутера построен **идентично** в обучении, в
   контроле и в инференсе (проверено по всем трём местам вызова
   `router.forward`), иначе выученное не переносилось бы на боевой прогон.
3. **PID-балансировка** (ур. 5): `pid.step(&mut router.bias, &loads, lr, wd)`
   по накопленной загрузке; энтропия `H(p)/ln E` печатается каждую эпоху.
4. **Промпт агрегации**: у C кандидатов берутся жадные хвосты длиной τ,
   токены переводятся из словаря эксперта в общий (`merged.remap[ei]`, выпавшие
   отбрасываются), добавляются segment/position эмбеддинги.
5. **Агрегатор**: `forward(prompt, τ, feat, t_feat)` → контекст `ctx` →
   `ctx_ad[ei]` → память декодера выбранного эксперта дополнительным шагом →
   `forward_train` → CE против настоящей разметки → `backward` через декодер в
   `d_ctx` → `Aggregator::backward` → `adam_step` по 16 тензорам +
   `adapters_adam_step`. Градиент в CCA и Res-scale даёт существующий
   attention-декодер, новых слоёв не добавлено.
6. **Эксперты заморожены**: `attn.backward` по устройству кода накапливает
   градиенты в весах эксперта, поэтому перед каждым прогоном вызывается
   `m.attn.zero_grad()`, а оптимизатор по `Model` не шагает никогда. Проверено
   снаружи: md5 обоих `.mope` после обучения совпадает с исходным, а жадные
   кандидаты Best-of-N в прогоне с `--mope-franken` и без него побитово
   одинаковы (md5 `2e88c5c52787587439b5f1089003238c`, совпадают и скоры до
   четвёртого знака).

### 19.4. Контейнер `MOPEFR01` и баг ширины поля

Порядок полей: магия (8 Б) → `steps` (u64) → словарь (список строк) → роутер
(`d_in`, `r`, `e`, γ, `w_down`, `mw[3]`, `mb[3]`, `bias`) → PID (`m`, `v` как
f64, `t`, `b1`, `b2`, `eps`) → агрегатор (5 размеров, три эмбеддинга,
`q_conv`, `kv_conv`, `wq`, `wk`, `wv`, `wo`, `bo`, `res_out`, `res_res`) →
число адаптеров признаков и сами адаптеры → число адаптеров контекста и они же →
флаг наличия Adam и, если есть, `t` и `m`/`v` каждого тензора.

Новый тест `franken_state_roundtrips_bitwise` сразу поймал рассинхрон: γ
записывался как `f32` (4 байта), а читался как `f64` (8 байт) — весь остальной
поток съезжал, и читатель сообщал «файл Franken-MoPE оборван». Исправлено
записью `(γ as f64).to_le_bytes()`: переход f32 → f64 → f32 точен, а ширина
поля теперь одна. Тест сравнивает побитово `w_down`, `mw`, `mb`, γ, `bias`,
`m`/`v`/`t` PID, все три эмбеддинга, `cca.wq`, `q_conv.w`, `kv_conv.b`,
`alpha`/`beta` обоих Res-scale, адаптеры и наличие состояния Adam; отдельно
проверяется путь без оптимизатора и отказ чужого файла по магии.

Загрузчик не падает на несовпадении размеров: если словарь, число экспертов или
число классов не те, печатаются обе цифры и работа продолжается с тем, что было.
Проверено намеренно испорченным запуском (`--mope-min-freq 40` вместо 0 при
файле, обученном на 97 токенах):

```
🔤 общий словарь: 3 токенов (порог частоты 40, предел 256); выброшено по экспертам: [94, 94]
📦 Franken-MoPE: 97 токенов словаря, роутер 1024→256 (2 экспертов, γ=0.000), агрегатор 293760 параметров, …
   ⚠️  словарь в файле (97 токенов) отличается от пересчитанного (3): проверьте --mope-min-freq, --mope-charset-max и --mope-char-counts
   ⚠️  размеры не совпали (роутер 1024→256 на 2 экспертов, агрегатор на 97 классов, нужно 1024 / 256 / 2 / 3) — работаем с тем, что было
```

### 19.5. Пик памяти `ExpertCache`: было `cap + 1` моделей, стало `cap`

Материализованный эксперт — fp32-веса, градиенты и Adam-моменты свёрток,
≈700 МБ на 43M параметров. Кэш вытеснял старого эксперта **после** создания
нового:

```rust
// было
let m = materialize_expert(i, ctx, stream);   // новая модель уже в памяти
self.items.insert(0, (i, m));
while self.items.len() > self.cap { self.items.pop(); }   // старая освобождается потом

// стало
let cap = self.cap.max(1);
while self.items.len() >= cap { self.items.pop(); }       // сначала освободить место
let m = materialize_expert(i, ctx, stream);
self.items.insert(0, (i, m));
```

Замер RSS в песочнице (2 ядра, 1982 МБ всего, CPU-бэкенд, 2 эксперта 43M
параметров, `--mope-cache 1`, 4 строки):

| | кривая RSS, МБ | пик | исход |
|---|---|---|---|
| до | 364 534 868 983 **352** 578 867 712 864 948 1102 1491 1511 1515 | 1515+ | `rc=137`, OOM-kill, эпоха не дошла до конца |
| после | 368 544 888 **250** 444 852 711 864 905 908 908 908 908 … | **908** | `rc=0`, эпоха прошла, RSS не растёт от образца к образцу |

Провалы (983→352, 888→250) — момент, когда вытесненный эксперт освобождается;
пила осталась, но её потолок теперь `cap` моделей, а не `cap + 1`.

Что проверено попутно и **не** оказалось причиной: `cuda_malloc`/`cuda_free`
CPU-бэкенда — обычные `malloc`/`free` (`DevBuf::drop` освобождает честно), пул
воркспейсов `trba_workspace_acquire` переиспользует блоки по размеру, а
`allocate_model_weights` с процесс-глобальными `g_cnn_weights`/`g_attention_weights`
из Rust не вызывается вообще (мёртвый код в обоих бэкендах) — трогать его не
стал, но отметил: если когда-нибудь понадобится второй резидентный набор весов,
эти глобалы станут граблей.

Для карты пользователя это разница между 13 и 14 резидентными экспертами в
10 ГБ VRAM; в хосте, где запас меньше, — между «прошёл» и «убит».

### 19.6. Инференс размывал выученное состояние

В `run_mope` после каждого образа стояли

```rust
router_opt.step(&mut router, args.mope_lr, 1e-4);
pid.step(&mut router.bias, &loads, cfg.balance_lr, cfg.balance_wd);
```

с целью, построенной по скорам собственных кандидатов. Пока обучать роутер было
негде, это была единственная адаптация; теперь же она за один боевой прогон
уводила выученную на разметке политику в сторону (дефолт `--mope-lr` = 1e-2, то
есть шаг в 30 раз крупнее обучающего 3e-4) и делала прогон невоспроизводимым:
результат зависел от порядка картинок.

Стало: при загруженном состоянии (`--mope-franken` или `--mope-router`) роутер
и PID **заморожены**, `--mope-adapt` возвращает прежнее поведение, а без
загруженного файла всё как раньше. Замер (4 строки, жадное декодирование,
`--seed 7`):

| прогон | лосс роутера | `bias` | md5 текстов |
|---|---|---|---|
| `--mope-franken` (заморожен), запуск 1 | 2.5068 | [0.006429, −0.006429] | `2ff74fbc…` |
| `--mope-franken` (заморожен), запуск 2 | 2.5068 | [0.006429, −0.006429] | `2ff74fbc…` |
| `--mope-franken --mope-adapt` | 0.6177 | [−0.002619, 0.002619] | `2ff74fbc…` |

Честная оговорка: 2.5068 и 0.6177 **несопоставимы** — это одна и та же метрика
на разных состояниях роутера, причём цель в инференсе (скоры кандидатов) не та,
на которой роутер обучался (CE учителя); у `--infer`/`--mope` разметки просто
нет. В подписи итога это теперь сказано явно, чтобы цифру не приняли за
«обучение всё испортило».

Побочно убран шум: предупреждение «агрегатор не обучен» печаталось на каждой
картинке (4 раза на 4 строках) и продолжало печататься даже с загруженным
обученным состоянием — теперь оно одно, и при загруженном `MOPEFR01` его нет
вовсе, потому что состояние обучено.

### 19.7. `--mope-limit` молча резал обучающую выборку

Дефолт флага — 4 (это «быстрый просмотр» для инференса), и тренировочный цикл
усекал перестановку строк тем же числом: прогон на 214049 строках датасета
пользователя «обучил» бы роутер на четырёх картинках, не сказав ни слова.
Добавлен флаг `mope_limit_set` (ставится только парсером), в `--mope-train`
дефолт не применяется, а явно заданный лимит сопровождается предупреждением:

```
⚠️ --mope-limit 2: дообучение пойдёт по 2 строкам из 6 (снимите флаг или задайте 0, чтобы учить на всём датасете)
```

Проверено: прогон без флага на 6 строках печатает «6 обучающих строк» и
«агрегатор 4.5733 (**6** шагов)» вместо прежних четырёх.

### 19.8. Сквозной замер (песочница, CPU-бэкенд, 2 потока)

Два эксперта из настоящих чекпоинтов, оба 32×128, `max_len 8`, словарь 97:
`e1.mope` (hidden 64, 42 941 186 параметров, 171.77 МБ) и `e2.mope` (hidden 96,
43 286 850 параметров, 173.15 МБ). Разный `hidden` выбран нарочно: он делает
`ctx_ad[1]` нетождественным, то есть прогон заодно проверяет и адаптеры
19.1(е). Датасет — 6 синтетических строк `images6.csv`.

| прогон | роутер (CE) | агрегатор (CE) | контроль: оракул / выбор / разрыв | примечание |
|---|---|---|---|---|
| 4 эпохи × 4 строки | 0.8216 → 0.7332 → 0.7088 → **0.6993** | 4.5791 → 4.5726 → 4.5621 → **4.5031** | 4.5700 / 4.5705 / +0.0005 | 63 с, `H(p)/ln E` 0.954, загрузка [6, 10] |
| 2 эпохи × 6 строк | 0.7857 → **0.7097** | 4.5733 → **4.5333** | 4.5679 / 4.5683 / +0.0004 | 47.5 с, `franken.bin` 9.60 МБ, пик RSS 908 МБ |
| продолжение с `franken.bin`, 2 эпохи | 0.7345 → **0.7040** | 4.5005 → **4.4938** | 4.5679 / 4.5683 / +0.0004 | счётчик шагов 12 → 24, лосс пошёл вниз с прежней точки |
| `--mope-target hard`, 1 эпоха × 2 строки | 0.5181 | 4.5700 | — | ветка hard-цели жива |

Что эти числа доказывают и чего не доказывают. Доказывают: градиенты доходят до
роутера, агрегатора, CCA, Res-scale и адаптеров; потери монотонно падают;
состояние переживает сохранение/загрузку вместе с Adam-моментами (иначе первый
шаг продолжения был бы в ~9 раз крупнее, как в §17); эксперты не меняются.
**Не** доказывают качество: 6 синтетических строк, оба эксперта игрушечные
(3 эпохи на шести картинках), контроль — те же строки, что и обучение, поэтому
его цифры не оценка обобщения. Абсолютные значения CE агрегатора держатся около
ln 97 = 4.575 именно потому, что эксперты текст почти не читают: замер
подтверждает plumbing, а не пользу. На настоящем датасете
(`/media/korziner/14ext4/trba/trba_kurrent`, 214049 / 23783 строки, 140 токенов)
смысл появится только вместе с читающими экспертами.

**Стоимость эпохи (проекция).** На шаг обучения приходится `E` teacher-forced
декодов (по одному на эксперта) + `N` кандидатов + `C` хвостов + 1
агрегированный; при `E=2, N=4, C=2` это 9 последовательных декодов на строку.
Ранее замеренная на CMP 50HX скорость `--infer` — 4.81 картинки/с, то есть
≈0.21 с на жадный декод в геометрии 32×128, откуда ≈1.5–1.9 с/строку и
**≈90–110 часов на эпоху** по всем 214049 строкам `train.csv`. Это проекция по
чужому замеру, а не измерение данного прогона: на песочнице (2 ядра CPU,
`--mope-cache 1`) шаг стоил ≈4 с — 47.5 с на 12 шагов, и заметную долю съедали
подмены экспертов. Практический вывод для боевого запуска: учить на подвыборке
(`--mope-limit 20000` ≈ 8–11 часов) и/или удешевить шаг (`--mope-n 2
--mope-c 1`, Delethink — 4 декода на строку), а `--mope-cache` ставить не
меньше числа экспертов.

Отдельно отмечу: γ (EDA `r += γ·r_prev`) остаётся нулевым и не получает
градиента — во всех трёх местах вызова `router.forward(&x, 1, None)` предыдущего
состояния нет, потому что у нас один образ = одно решение роутера, а не
последовательность. Отчёт печатает `γ=0.000` честно, а не выдаёт его за
обученный.

### 19.9. Тесты: 77 → 80

* `franken_state_roundtrips_bitwise` — побитовое сравнение всех полей
  контейнера после записи/чтения, путь без состояния Adam, отказ файла с чужой
  магией (именно он поймал баг ширины γ из 19.4);
* `aggregator_adam_covers_every_trainable_tensor` — 16 форм,
  `Σ shapes == agg.params()`, меняются только тензоры с ненулевым градиентом
  (`g_tok_emb[0]`, `cca.g_wq[1]`), тензор без градиента не тронут, `opt.t`
  растёт на единицу за шаг, а не за тензор;
* `router_targets_follow_the_best_expert` — argmax обеих целей (`soft` и
  `hard`) указывает на эксперта с наименьшим лоссом, `hard` суммируется в 1,
  `soft` — распределение, вес убывает с ростом лосса.

`cargo test --release` — **80 passed / 0 failed**; `cargo build --release` без
ошибок и новых предупреждений.

### 19.10. Как повторить

```bash
cd ~/.cache/franken           # или любой каталог с двумя .mope и CSV «путь,текст»
B=~/trba-rust/target/release/trba-rust
C="--charset kurrent_charset.txt --mope --mope-experts e1.mope,e2.mope \
   --mope-char-counts images6.csv --mope-min-freq 0 --mope-charset-max 256 \
   --img-h 32 --img-w 128 --max-len 8 --hidden 64 \
   --mope-n 2 --mope-c 2 --mope-tau 4 --mope-cache 1"

# обучение (2 эпохи) и сохранение одного файла состояния
TRBA_FORCE_CPU=1 $B images6.csv images6.csv exp/ $C --mope-train --epochs 2 \
    --mope-lr 3e-4 --mope-agg-lr 3e-4 --mope-balance-lr 1e-3 \
    --mope-save-franken franken.bin --seed 7

# инференс на нём (роутер заморожен, прогон воспроизводим)
TRBA_FORCE_CPU=1 $B images6.csv "" exp/ $C --mope-franken franken.bin --mope-t 1 --seed 7

# продолжение обучения с того же файла
TRBA_FORCE_CPU=1 $B images6.csv images6.csv exp/ $C --mope-train \
    --mope-franken franken.bin --epochs 2 --mope-save-franken franken2.bin --seed 7
```

На машине пользователя вместо `TRBA_FORCE_CPU=1` — обычный CUDA-запуск, вместо
`--mope-cache 1` — значение не меньше числа экспертов (подмены на обучении
дорогие), вместо игрушечных `e1/e2.mope` — `base.mope` из `trba_base_g1.onnx`
и `kurrent.mope` из своего чекпоинта, и полный датасет: `--epochs 3` на
214049 строках — это уже настоящий прогон, а не smoke.

---

## §20. Два эксперта на Bullinger (200 и 400 строк), int8-контейнер `MOPEBI01` и три бага маршрутизации

### 20.1 Датасет `dh-unibe/image-text_bullinger-autoren-lines` → `data/bullinger`, `data/bull40`

Источник: 73502 строки (8.27 ГБ) рукописных строк переписки XVII века, поля
`image` / `text` / `page` / `line_index`. Скачивание — datasets-server API
`/rows?dataset=…&config=default&split=train&offset=N&length=100` (не больше 100
строк на вызов), `image.src` — готовый URL кадра.

`tools/bullinger_fetch.py` (stdlib + Pillow, кэширует исходники, поэтому
перезапускаемый):

- **темп 1.2 с + экспоненциальный backoff на HTTP 429.** Первая попытка умерла
  на 429 после ~28 быстрых вызовов (2800 строк, 119 проходов);
- **фильтр «целая строка ≤ 64 символов».** Медиана длины строки 76, ≤64 — 30 %
  выборки, ≤20 — 4 %. Резать строку по проекции чернил нельзя: курсив сливает
  слова, число чернильных прогонов не равно числу слов (замер: 8 прогонов на 11
  слов, совпадение с плато 1/2 строки) ⇒ метка перестала бы соответствовать
  картинке. Поэтому берутся только целые строки, влезающие в канву;
- **разбиение по целым страницам (`page`), не по строкам:** A∩B = 0 общих
  страниц, так что эксперт A и эксперт B — разные страницы и разные руки, а не
  одна страница, порезанная пополам;
- **pre-fit под канву загрузчика:** кадр сразу приводится к 32×256, потому что
  `load_image_q` заполняет канву 255, центрирует изображение по вертикали,
  прижимает влево и берёт `scale = min(img_h/h, img_w/w)`; на обучении
  scale = 1, второго ресайза нет.

Итог — 700 PNG, 3.48 МБ:

| файл | строк | назначение |
|---|---|---|
| `a_train.csv` | 200 | обучение эксперта A |
| `b_train.csv` | 400 | обучение эксперта B |
| `val_a.csv` / `val_b.csv` | 40 / 60 | валидация каждой руки отдельно |
| `val.csv` | 100 | смешанная валидация — на ней роутеру есть работа |

Словари: A 65 токенов, B 69, объединённый 71. Только у A нет `J K W j z 7`,
только у B нет `6 9`. Это не декорация: разность словарей включает
`MergedCharset` (перенумерация) и — после фикса 20.2 — штраф за незнание
символа.

`data/bull40` — те же строки, перекроенные `tools/bullinger_recrop.py`
(`--crop-chars 40 --img-w 160 --img-h 32`): обрезается левая доля кадра, метка
режется тем же коэффициентом, соответствие картинка↔текст сохраняется. Словари
64/68/70. Причина перекроя — память, см. 20.6.

### 20.2 Баг: CE эксперта считалась на отфильтрованном таргете — эксперт с маленьким словарём выглядел лучше

Где: `teacher_ce` (`src/main.rs`), вызов из `mope_forward_all`.

Было: таргет прогонялся через словарь эксперта, неизвестные символы
выбрасывались, CE усреднялась по оставшимся. Эксперт, который «не знает»
половину алфавита, платил только за знакомые символы, то есть его CE была
занижена ровно настолько, насколько он невежественен. Роутер и агрегатор
получали сигнал «этот эксперт лучше», хотя он просто меньше отвечал. При
A 65 / B 69 / merged 71 это штатный сценарий, а не академический.

Стало: `moe::penalized_ce(mean, kept, dropped, classes)` =
`(mean·kept + dropped·ln classes)/(kept + dropped)` — за каждый выброшенный
символ эксперт платит CE максимально неосведомлённого распределения по полному
словарю, знаменатель — полное число символов. Это ровно логарифмическая потеря
модели, которая на незнакомых символах говорит «не знаю» равномерно.
`MopeFwd.dropped` выводится в отчёт агрегатора, чтобы подмену было видно
глазами, а не только в цифре CE.

Тест `charset_penalty_makes_ignorance_expensive`: эксперт, знающий все символы
с CE 1.2, обязан проигрывать эксперту, знающему половину с сырой CE 1.0.

### 20.3 Баг: агрегатор на инициализации удваивал pooled-контекст

Где: `Aggregator::new`, поле `res_out` (`ResidualScaling`, уравнение (6)
техотчёта: `α·x + β`).

Было: `ResidualScaling` по умолчанию α=1, β=0 — правильно для ветки, которая
добавляет новое к старому, но `res_out` стоит на выходе, куда pooled-контекст
уже пришёл, и вторая ветка на инициализации давала тот же pooled ⇒
`ctx = 2·pooled`. Обучение начинали не с тождественного отображения, а с
удвоенного входа: первые шаги просто возвращали масштаб на место и выглядели
как «обучение».

Стало: `res_out` инициализируется α=0, β=0 ⇒ на шаге 0 `ctx == pooled` ровно.
Тест `aggregator_context_starts_as_identity` сравнивает выход агрегатора до
обучения с pooled поэлементно.

### 20.4 Баг: `franken.bin` с меньшим C·τ молча урезал контекст

Если файл сохранён при `--mope-c 1 --mope-tau 4`, а запуск просят
`--mope-c 2 --mope-tau 8`, загрузка брала первые C·τ сегментов и не сообщала об
этом: казалось, что инференс идёт на том же контексте, что и обучение. Теперь
`load_franken` печатает предупреждение с обеими цифрами (`max_c`/`max_tau` из
файла против запрошенных); поведение прежнее, но расхождение видно.

### 20.5 Контейнер `MOPEBI01`: int8-эксперт вместо 172 МБ fp32-бандла

`ExpertBundle` (`MOPEXP02`) хранит веса в fp32: один эксперт hidden 256 —
172 МБ, два не влезают ни в бюджет, ни в zstd-22 (сжатие мантисс почти ничего
не даёт). При этом загрузчик всё равно квантует бандл в `ExpertBlob` через
`bundle_to_blob` (scale = max|w|/127 на тензор), то есть fp32 в файле живёт
ровно до первой загрузки.

Формат (`src/moe.rs`: `write_blob`, `read_blob`, `blob_report`, `Rd::i8s`):
magic `MOPEBI01` + spec (3 строки, 10 u64) + charset + имя блоба + длины
тензоров (u64) + масштабы (f32) + квантованные веса (i8 подряд) + BatchNorm
(f32). Квантование бит в бит совпадает с загрузочным путём `bundle_to_blob` ⇒
распознавание int8-эксперта обязано совпадать с fp32-бандлом побитово;
зафиксировано тестом `int8_blob_roundtrips_bitwise`.

Экономия: 172 МБ → 43 МБ на эксперт (hidden 256); загрузка не материализует
fp32-копию ⇒ минус 172 МБ пика и ~2 с на эксперта.

Флаги: экспорт — `--mope-export-bundle P --mope-int8`; загрузка определяет
формат сама (`file_magic()` читает первые 8 байт) и диспетчеризует в
`direct: Vec<Option<ExpertBlob>>` внутри `run_mope`, поэтому
`--mope-experts a.mope,b.mope` принимает fp32-бандлы, int8-бандлы и обычные
чекпоинты trba-rust вперемешку.

### 20.6 Память CPU-бэкенда: рост фронтальный, плато 926 МБ

Замеры (2 потока rayon, hidden 64, batch 4):

- 405 МБ после загрузки модели → 882 МБ на первом батче → 926–936 МБ ровно до
  конца прогона (12 батч, 48 картинок, 143 с). Это не утечка, а grow-only пул
  рабочих блоков `trba_workspace_acquire`/`release` (first-fit): размер запроса
  зависит от упакованной длины таргета, первые батчи покрывают разные размеры,
  дальше блоки переиспользуются;
- 32×256 / max_len 64 / batch 4 — OOM-kill (rc=137) в середине первой эпохи на
  машине с 1.5 ГБ доступной памяти;
- 32×160 / max_len 40 / batch 4 — 11.5 с/батч (2.85 с/картинку), пик 941 МБ,
  эпоха из 200 картинок — 574 с.

Отсюда: в песочнице batch 4 при max_len 40 — потолок, и чекпоинты экспертов
обучены на `data/bull40`. На машине пользователя (10 ГБ видеопамяти,
CUDA-бэкенд) штатная геометрия — полные строки `data/bullinger`, 32×256,
max_len 64; команда перетренировки есть в README (рецепт 8).

---

## §20.7 (продолжение). MoPE: три несогласованных числа — словарь, шаги, строки

**Симптом.** Связка двух экспертов с **разными** словарями (64 и 68 токенов) падала:

```
thread 'main' panicked at src/attn.rs:276:42:
range end index 2800 out of range for slice of length 2788
```

2788 = 41 × 68 (буфер CE в нумерации эксперта), 2800 = 40 × 70 (индексация в общем
словаре). То есть один и тот же тензор индексировали двумя разными парами
`(шаги, классы)`.

**Причины (три сразу).**
1. `materialize_expert` собирал модель по `ctx.classes` (общий словарь), а не по
   собственному словарю эксперта, и перемазывал только 4 тензора головы; учительские
   `ti/ty` при этом оставались в нумерации эксперта.
2. Число шагов декодера брали как `max_len + 1`, тогда как реальное число строк
   forward'а — `text_in[0].len()` (attn.rs:121).
3. После исправления словаря «угаданное» число строк `fw.ts[ei] + 1 = 21` всё равно
   не совпало с фактическими 22.

**Исправление.** Эксперт живёт в собственном словаре (`spec.classes`), общий словарь
используется только для отчётов и для штрафа `penalized_ce`; перемазывание головы
удалено (оно и создавало рассогласование); число строк **выводится из возвращённого
буфера** — `rows = logits.len() / classes`, а не угадывается; добавлены `to_merged()`,
печать словаря каждого эксперта и предупреждение о непокрытых токенах.

**Урок.** Никогда не угадывать размерность по конфигурации — брать её из фактического
буфера. В 12-м раунде баг не проявился только потому, что оба эксперта имели
одинаковый charset. Это прямой аналог морали из статьи-эталона
(habr.com/ru/articles/1095474): «проверяй не только код, но и способ проверки» —
там расхождение дал stride 384 против 512 при чтении строк.

## §20.8. int8-квантование: host считает в f32, device — в f64

`Conv2dQ::requantize` (qnet.rs:764) и `moe::quantize_expert` квантуют в **f32**,
а `quantize_pad_i8_kernel` (cuda/kernels.cu:1084) и его CPU-зеркало
(cuda/cpu_backend.cpp:467) — в **double** с последующим `roundf`. Расхождение
возможно только на границе `.5` после деления на масштаб.

**Проверка.** Эксперимент на 8 000 000 случайных выборок (python, точно те же
формулы: `scale = max|w|/127`, округление от нуля, клампинг ±127): **0 расхождений**
(ожидаемая частота ~2⁻⁵⁰ на элемент). То есть практического расхождения нет, но
конвенции должны совпадать: унифицировать на f32 и добавить тест, вызывающий extern
`launch_quantize_pad_i8` и сравнивающий байты, включая align16-дополнение.

## §20.9. `--seed` не покрывает инициализацию весов

`ConvQat::new` и `LinearF::new` берут `rand::thread_rng()` (qnet.rs:108, :481), то
есть **не сидируются** от `--seed`. Сидируется только перемешивание данных.

**Доказательство** (одинаковые флаги, одинаковый датасет, `--seed 5`, 48 изображений,
1 эпоха): loss `3.5342` (attn 4.1415, ctc 2.1172) против `3.5341` (attn 4.1524,
ctc 2.0916); на 8 изображениях — `2.9070`, `2.9119`, `2.9101`, `2.9117`. Для
MoPE-связки то же самое: роутер `0.6581` против `0.6621`, агрегатор `3.4072` против
`3.4447` при одинаковых флагах.

**Следствие.** Два «одинаковых» свежих прогона несравнимы, а A/B-эксперименты
содержат шум инициализации. **Исправление (не внесено):** прокинуть
`StdRng::seed_from_u64(args.seed)` в конструкторы весов; это меняет все свежие
обучения, поэтому требует отдельного решения о совместимости.

## §20.10. `TRBA_AVX` не перезапускал build script

`build.rs` объявлял `rerun-if-env-changed` для семи переменных, но не для новой
`TRBA_AVX`: при смене только этой переменной cargo переиспользовал прежний
`cpu_backend.o`. Добавлено `cargo:rerun-if-env-changed=TRBA_AVX`.

## §20.11. `--feat-dim`: plumbing разведён, узкий энкодер падает в CPU-бэкенде

Ширина вынесена в одно место (`SEResNetQ::widths(fd)`), распространена через
`Geometry`/`ExpertSpec`/адаптеры MoPE/экспорт ONNX/`pool_feat`/`expert_encode`
и пересобираемый рост (`--grow-ladder` снова подставляет `--feat-dim`); при fd=512
таблица каналов 64/128/256/256/512/512 воспроизводит историческую архитектуру
побайтово, 84 теста проходят.

**Но** при fd<512 обучение падает: fd=256 — SIGSEGV на **втором** батче (первый
считается корректно: 10.54M весов, 5 с против 22 с), fd=128 — на **первом**.
Падают обе ширины и с `TRBA_HOST_CONV_ADAM=1`, и с `RAYON_NUM_THREADS=1`; в
`cuda/cpu_backend.cpp`, `kernels.cu` и `src/*.rs` зашитых 512 больше нет
(проверено grep'ом), `DevOpt` и `device_requantize` масштабируются от
`out_c * col_cols()`. Отладчика (gdb/valgrind) в песочнице нет, а segfault без
стека локализовать не удалось.

**Решение.** Флаг принимает только 512 и на остальных значениях возвращает явную
ошибку с измеренными числами вместо SIGSEGV. Plumbing остаётся в дереве: для
доведения нужно найти рассогласование размеров, проявляющееся только на втором
батче, то есть в переиспользуемых буферах (Scratch-слоты, workspace-пул,
`w_q_dev`).

## §21. AVX1 против AVX2: замер и соответствие INT8-приёмам эталонной статьи

Один батч (4 изображения 32×160, fd=512, 2 ядра, `TRBA_FORCE_CPU=1`):

| сборка | `.text`, Б | Δ к базовой | время батча | ускорение | VEX-инструкций |
|---|---|---|---|---|---|
| SSE2 (базовая) | 1 761 980 | — | 22.6 с | 1.00× | 23 |
| AVX1 (`-mavx`) | 1 772 668 | +0.61 % | 20.2 с | 1.12× | 431 |
| AVX2+FMA | 1 791 292 | +1.66 % | 19.0 с | 1.19× | 1070 |

Гипотеза «AVX1 вдвое компактнее AVX2» **не подтвердилась по объёму кода**: разница
`.text` — 1.03 % (18.6 КБ), потому что горячее ядро — рукописный int8-GEMM, а
векторизуемая компилятором часть мала. По числу широких инструкций направление то
же: AVX2 даёт в 2.5× больше VEX-операций, чем AVX1. AVX1 остаётся осмысленным
выбором не из-за размера, а из-за отсутствия AVX2-частотного троттлинга и более
широкой совместимости; базовая сборка детерминирована (повторная сборка после AVX2
дала байт-в-байт тот же бинарник).

**Соответствие приёмов статьи (habr.com/ru/articles/1095474) нашему коду.**

| приём статьи | у нас | вывод |
|---|---|---|
| веса int8, масштаб на **выходной канал** | масштаб на тензор (`max|w|/127`) | пер-канальные масштабы дали бы точность, но сломали бы побайтовую совместимость с существующими чекпоинтами ⇒ только новый magic `MOPEBI02` |
| активации int8 с **динамическим** масштабом на токен | активации fp32 в MoPE, динамический пер-тензор в QAT | переносимо для CPU-инференса, не для текущего контейнера |
| группо́вое квантование по K (чанки по 96) | блоки по 128 уже есть в MuonQ (int8-градиенты) | механизм в кодовой базе присутствует, для весов не используется |
| раскладка `[O][T]` в быстрой памяти (×3.5) | веса уже хранятся транспонированно; узкое место — PCIe 2.0 x4 | аналог — `w_q_dev`: int8-веса пересекают PCIe один раз на слой на батч |
| одна арена на все фазы + **аллокация от большего к меньшему** | `trba_workspace_acquire/release` без порядка по размеру | кандидат против плато RSS 926–941 МБ |
| ветки CFG батчем, чтобы веса читались один раз | эксперты декодируются по очереди | пакетировать N экспертов в один проход — прямая экономия |
| `mmap` весов | int8-контейнер `MOPEBI01` читается без fp32-материализации | −172 МБ пика и ~2 с на эксперта |
| `rne()` магической константой, таблицы exp/GELU | не нужно: x86-64 и CUDA дают аппаратное RNE | неприменимо |
| numpy-симулятор, сверяющий арифметику прошивки побайтово | есть `int8_blob_roundtrips_bitwise`, нет кросс-бэкендного теста | недостающее звено; см. §20.8 |

## §20.12. Обновление §20.11: причина SIGSEGV при `--feat-dim < 512` найдена и устранена

**Метод.** В песочнице появился gdb (16.3). Падение происходит в OpenMP-потоке,
поэтому обычный `bt` показывает только `launch_*._omp_fn → libgomp → libc`:
вызывающий остаётся в основном потоке, заблокированном на `GOMP_parallel`.
Решение — `thread apply all bt`:

```
Thread 2: #0 launch_reduce_max_abs._omp_fn ()
Thread 1: #2 launch_reduce_max_abs ()
          #3 trba_rust::qnet::relu_quant_owned () at src/qnet.rs:1104
          #4 trba_rust::qnet::SEResNetQ::forward () at src/qnet.rs:1551
```

**Причина.** В `SEResNetQ::forward`/`backward` размеры стебельных активаций были
зашиты числами исторической ширины:

```rust
let n0 = b * 64  * h * w;    // каналы stem.0 = fd/8
let n1 = b * 128 * h * w;    // каналы stem.1 = fd/4
let q_pool = Arc::new(DevBuf::new(b * 128 * h * w));
launch_maxpool2x2_forward_i8(.., b as i32, 128, ..);   // и то же в backward
```

При fd=512 числа верны, поэтому дефект не проявлялся. При fd=256 длина завышалась
вдвое, при fd=128 — вчетверо, и `relu_quant_owned` / maxpool читали за концом
буфера. Поиск по `512` ничего не давал: зашиты были **64 и 128**.

**Исправление.** Все пять мест переведены на `self.c0.out_c` / `self.c1.out_c` —
при fd=512 значения совпадают с прежними, поэтому поведение исторической ширины
не изменилось (84 теста проходили до и после). Запрет `--feat-dim != 512` снят,
осталось требование кратности 8.

**Результат.** 8 изображений, 2 батча, 2 ядра CPU: fd=512 — 21.3 с (42.15M
conv-весов), fd=256 — 5.3 с (10.54M), fd=128 — 1.3 с (2.63M). Обучение эксперта
A (200 строк, 2 эпохи) — 58 с вместо 574 с, B (400 строк) — 115 с вместо 1174 с;
лосс сопоставим: 3.1359 против 3.1076 у A, 2.9507 против 2.8288 у B. Связка MoPE —
3.9 с вместо 56 с. Поставочные эксперты пересобраны на fd=128: **2.93 МБ вместо
43.00 МБ (14.7×)**, рабочее дерево 14 МБ вместо 95 МБ.

**Урок.** При вынесении размера в параметр искать надо не literal исходного
значения, а все производные от него числа (64 = fd/8, 128 = fd/4). И наоборот:
если падает в OpenMP-области, стек надо снимать со всех потоков.

## §20.13. `MOPEFR02`: геометрия раундов RSA в контейнере состояния

**Симптом (реальный прогон на CMP 50HX).** Инференс, запущенный по подсказке
программы, уходил на дефолты `N=16 C=4 τ=4` и получал
`⚠️ агрегатор обучен на промпте C=2·τ=8, а запрошено C=4·τ=4` — агрегатор резал
хвосты кандидатов не так, как его учили, и выдавал текст со скором −3.5 вместо −2.0.
Подсказка после `--mope-save-franken` печатала `--mope-n/-c/-t`, но не `--mope-tau`.

**Исправление (два слоя).**
1. Подсказка печатает полный набор: `--mope-n --mope-c --mope-t --mope-tau
   --mope-temperature 0`.
2. Контейнер bumped до `MOPEFR02`: сразу за счётчиком шагов пишутся
   `n, c, t_rounds, beta, tau` (u64) и `temperature, top_p` (f32), остальной поток
   байтов не отличается от `MOPEFR01`. При загрузке геометрия подставляется сама,
   если пользователь не задавал RSA-флагов явно (`Args.rsa_user_set` взводится
   пятью соответствующими ветвями разбора); если задавал — побеждают его значения,
   а программа печатает сравнение. `MOPEFR01` продолжает читаться (`Franken.rsa =
   None`) с явной пометкой, что геометрию нужно задать флагами.

**Проверка.** Тест `franken_state_roundtrips_bitwise` расширен: сохраняет
`N=4 C=2 T=2 β=40 τ=8 temperature=0.0 top_p=0.9` и сверяет после чтения
(85 тестов проходят). Сквозной прогон: инференс без единого RSA-флага напечатал
`🔀 геометрия раундов из файла: N=4 C=2 T=2 β=40 τ=8 temperature=1 (свои RSA-флаги
не заданы)` — предупреждение о C·τ не появилось. Предупреждение остаётся как
страховка на случай, если пользователь сознательно задаст другую геометрию.

## §20.14. `--build-charset`: словарь из CSV внутри бинарника

Раньше charset приходилось собирать внешним скриптом (python), а при переходе на
датасет в раскладке `<split>/{img/,labels.csv}` (YeniseiGovReports-HWR) конвертер
становился обязательным: trba-rust читает `path,text` без заголовка и разрешает
пути относительно каталога CSV.

Добавлен `--build-charset a.csv[,b.csv] --charset out.txt`: разбор строк тем же
`parse_csv_line`, что и при обучении, символы — в порядке кодовых точек, формат
результата совпадает с `load_charset` (`<PAD>`, `<SOS>`, `<EOS>` + символы).
Заголовок распознаётся (`is_csv_header`: filename/file/path/image/img/image_path/
name) и пропускается — иначе символы слова «filename» молча расширили бы словарь.
Позиционный `train.csv` в этом режиме не требуется.

**Проверка.** `--build-charset /tmp/hdr.csv,data/bull40/a_train.csv` на 202 строках
(2 из них с кириллицей, 1 заголовок): `пропущено заголовков 1`, 76 символов,
эталонный словарь `charset_a.txt` (61 символ) — подмножество собранного, добавились
ровно кириллические `В Р а в е и л о п р с т у ч ъ`. Тест
`csv_header_is_recognised_and_data_rows_are_not` фиксирует поведение на заголовке.

## §20.15. Нулевая частота в `--mope-char-counts` отсеивала символы эксперта

**Симптом (реальный прогон).** `🔤 общий словарь: 144 токенов (порог частоты 1,
предел 256); выброшено по экспертам: [0, 6]; уникальных потеряно 6 → ["+", "І",
"Ц", "Ы", "і", "Ѣ"]` — из объединённого словаря пропали дореформенные буквы.

**Причина.** Корпус для подсчёта частот (`--mope-char-counts`) указывал на первые
20 000 строк, а словарь эксперта был построен по всем 109 570. Редкие символы в
подмножество не попали ⇒ частота 0 ⇒ отсечены порогом `--mope-min-freq 1`.
Существующий механизм «непроверенных» токенов (`u64::MAX/2`) срабатывал только
когда статистики не было вовсе (`counts.get(ei) == None`), а честный ноль
воспринимался как «символ редкий».

**Почему это опасно.** Токен из собственного словаря эксперта модель умеет
выдавать. Выбросив его из общего словаря, мы навсегда запрещаем символ: CE платит
`ln(classes)` через `penalized_ce`, а расшифровка не может его содержать.

**Исправление.** Нули в накопленной статистике помечаются как непроверенные
(`u64::MAX/2`), порог частоты применяется только к реальным наблюдениям; печать
перечисляет затронутые токены (до 12) и напоминает, что корпус должен
соответствовать обучению эксперта. Специальные токены (индексы 0..3) в отчёт не
попадают — в текстах их не бывает.

**Проверка.** Связка fd=128-экспертов с корпусом из 20 строк: `21` и `25` токенов
получили ноль и были оставлены, общий словарь — полное объединение `70 токенов`,
`выброшено по экспертам: [0, 0]`.

**Побочный эффект (полезный).** Объединённый словарь перестал зависеть от того,
передан ли корпус и какой он: раньше обучение с `--mope-min-freq 1 --mope-char-counts`
давало 144 токена, а инференс без этих флагов — 150, из-за чего franken-состояние
отвергалось по размеру (`⚠️ размеры не совпали … работаем с тем, что было`) и
роутер с агрегатором оставались случайными. Теперь оба режима дают полное
объединение, то есть состояние подставляется.

## §20.16. CER больше 100 % без объяснения пугал и скрывал причину

CER = edit_distance / len(эталон), метрика не ограничена сверху: гипотеза длиннее
эталона ⇒ вставки дают 516.8 %. Так и было на Енисее при `--max-len 40` и длине
слов p50 = 5: декодер проходит все 40 шагов, ранний стоп не срабатывает, пока EOS
не выучен.

**Исправление.** В строку валидации добавлены средние длины
(`длина: эталон 5.1, гипотеза 40.0`), а при CER > 100 % печатается пояснение с
указанием уменьшить `--max-len` до p99 длины текста + 2…4 и перегенерировать CSV
тем же значением (загрузчик обрезает длинные тексты молча, конвертер — отбрасывает
и печатает счётчик).

## §20.17. Процентили в `tools/yenisei_import.py` считались нарастающим итогом

Аккумулятор не сбрасывался между p50/p90/p99, поэтому p90 и p99 находились на
первом же шаге цикла и выходили **меньше** p50: `p50 5 · p90 4 · p99 2 · max 32`.
По таким числам `--max-len` выбрать нельзя — а это ключевой параметр геометрии
(см. §20.16). Исправлено: `acc = 0` внутри цикла по процентилям.

### §20.15.1 Проверка на полном датасете и уточнение причины

В коде **нет** запрета на дореформенные буквы: `moe::count_charset_in_file`
считает частоту как `s.matches(tok).count()` — посимвольный поиск подстроки по
всему тексту файла, без нормализации Unicode, без ASCII-фильтров и без разбиения
на слова. «Ѣ» и «Ц» обрабатываются ровно как «а». Ноль означает только «в этом
файле подстрока не встретилась».

Значит причина не в буквах, а в **корпусе**: в `--mope-char-counts` попал
`head -20001` от train, а вхождения «Церквей» (53), «ЗА ЧѢМЪ», «ОЦИФРОВАНО»,
«іюля» сгруппированы по документам и в эту голову не попали. Прописать разницу
между полным корпусом и его первыми N строками можно скриптом
`tools/check_charset_loss.py` — он повторяет арифметику программы и печатает три
группы: (1) токенов, которых нет даже в полном корпусе, (2) токенов, которые
обнулились бы на подмножестве (их и терял старый код), (3) сильно разреженных на
подмножестве (риск при `--mope-min-freq > 1`).

После правки §20.15 нули больше не отсеивают токен, но **частоты остаются
неверными, пока корпус не полный** — поэтому при `--mope-min-freq > 1` в
`--mope-char-counts` нужно передавать полный train.csv эксперта.

## §20.18. Корзины по длине: MoPE декодировал всех экспертов глобальным `--max-len`

**Симптом.** Смешать экспертов с разным `max_len` (корзины 7/8/9/16 шагов) было
нельзя: прогон везде шёл длиной `args.max_len + 1`, а позиционные эмбеддинги
декодера каждого эксперта рассчитаны на его собственный `max_len`.

**Где именно.** Три места: `mope_forward_all` (teacher-forced прогон и построение
`ti`/`ty`), раунды RSA при обучении (`decode_full(&fw.encs[cj], …, beta, …)`) и
инференс — оба замыкания, `generate` (кандидаты) и `aggregate` (агрегирующий
раунд, который тоже идёт моделью выбранного эксперта).

**Исправление.** Чистая функция `moe::expert_steps(spec_max_len, global_steps)`
возвращает `clamp(spec_max_len, 1, global_steps-1) + 1`: свой `max_len` эксперта,
ограниченный сверху прогоном. Длины векторов `ti`/`ty` задаются до цикла, чтобы
даже пропущенный эксперт (нет картинки) имел векторы своего размера — иначе
потребитель прочитал бы чужую длину. `beta` в RSA-раундах и в инференсе
ограничивается `specs[ei].max_len`; второму замыканию отдаётся клон (`beta_e_a`),
поскольку `move` не позволяет двум замыканиям владеть одним `Vec`.

**Тест.** `expert_steps_caps_own_max_len_by_global` (8 утверждений, включая
вырожденные входы `spec=0`, `global=0`, `global=1`). Всего **86 тестов**.

**Проверка.** Два эксперта fd=128 на `data/bull40` с `--max-len 8` и `16`:
обучение rc=0, экспорт `MOPEBI01` 2 935 399 и 2 935 402 Б, связка при
`--max-len 16` rc=0, напечатаны `⇄ max_len 16 против 8` и
`📏 длина прогона по экспертам: [8, 16] шагов (потолок --max-len 16)`.

**Уточнение к прежнему утверждению.** Разный `--img-w` у экспертов НЕ был
заблокирован: `load_image_q(path, sp.img_h, sp.img_w)` и `expert_encode(…,
sp.img_h, sp.img_w, …)` всегда брали геометрию из `ExpertSpec`. Блокировала
только длина декодирования.

### §20.18.1 Корзины по длине: планировщик и цикл

Добавлены `tools/len_buckets.py` (разбивка конвертированного корпуса на корзины
по длине текста; схемы `auto`/`exact`/`cum`; пишет `bucket_<tag>.csv`,
`bucket_<tag>_val.csv` и план `buckets_plan.tsv` со столбцами
`tag lo hi rows img_w max_len`) и переписан `scripts/run_len_buckets.sh` под этот
план; в `scripts/mope_menu.sh` появился пункт 5 (включая режим «только план»), а
проверка выбора больше не зашита на 1…4 — диапазон берётся из числа вариантов.

Три правила, которые пришлось зафиксировать в коде и документации:

1. **Корзина не может содержать строк длиннее своей верхней границы** — загрузчик
   обрезает их молча. Поэтому `auto` расширяет диапазон вниз, а не вверх.
2. **Контроль каждой корзины — строки её длины.** На чужих длинах CER корзины
   снова уходит за 100 % (§20.16), и выбор `best.bin` начинает сравнивать
   несравнимое.
3. **`--feat-dim` обязан совпадать у всех корзин**, а `--max-len`, `--img-w`,
   `--hidden` и словарь могут различаться: роутеру подаётся признак первого
   эксперта (`out.feat0` при `ei == 0`), поэтому вход роутера `2×feat_dim`.

Проверка: 6 корзин `exact` (длины 8, 9, 11, 15, 16, 17; ширина кадра 128, 160,
192, 256, 256, 256) на `data/bull40`, fd=128 — обучение и экспорт всех шести
rc=0 (2 935 414 Б каждый), связка rc=0, инференс rc=0 на роутере из шести
экспертов: `загрузка экспертов: [0.0, 5.0, 0.0, 0.0, 0.0, 0.0]`, `подмен
экспертов 2 | 1.9 с`. Отличия геометрии печатаются по каждому эксперту
(`⇄ отличается от 0: вход 32×160 против 32×128`, `max_len 9 против 8`).
